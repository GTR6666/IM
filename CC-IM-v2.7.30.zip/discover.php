<?php
/**
 * CC商聊 - 广场（朋友圈 / 扫一扫 / 邀请有礼 / 群组入口）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myUid = (int)$me['id'];

function p_av(string $avatar, string $name, string $cls = ''): string
{
    if ($avatar !== '') return '<span class="avatar ' . $cls . '"><img src="' . e($avatar) . '" alt=""></span>';
    return '<span class="avatar ' . $cls . '" style="background:var(--brand)">' . e(mb_substr($name !== '' ? $name : '?', 0, 1)) . '</span>';
}

// 朋友圈未读：评论 + 赞
$lastRead = (int)val('SELECT last_read_at FROM moment_reads WHERE uid=?', [$myUid]);
$unreadLikes = (int)val('SELECT COUNT(*) FROM moment_likes l JOIN moment m ON m.id=l.mid WHERE m.uid=? AND l.uid<>? AND l.created_at>?', [$myUid, $myUid, $lastRead]);
$unreadComments = (int)val('SELECT COUNT(*) FROM moment_comments c JOIN moment m ON m.id=c.mid WHERE m.uid=? AND c.uid<>? AND c.created_at>? AND c.deleted=0', [$myUid, $myUid, $lastRead]);
$momentUnread = $unreadLikes + $unreadComments;

// 最新 3 条动态（公开 + 好友可见）
$latest = all('SELECT m.*, u.nickname, u.avatar FROM moment m JOIN users u ON u.id=m.uid
    WHERE m.deleted=0 AND m.visibility<2 ORDER BY m.id DESC LIMIT 3');
$momentTotal = (int)val('SELECT COUNT(*) FROM moment WHERE deleted=0 AND visibility<2');


cc_head('广场', ['css' => '
.disc-list{margin:12px}
.disc-item{display:flex;align-items:center;gap:13px;background:var(--card);border-radius:16px;padding:14px 15px;margin-bottom:10px;
  box-shadow:0 4px 16px rgba(26,32,60,.045)}
.disc-item:active{background:#FBFCFE}
.d-ico{width:44px;height:44px;border-radius:14px;display:flex;align-items:center;justify-content:center;color:#fff;flex:0 0 auto}
.d-ico.a{background:linear-gradient(135deg,#9B7BFF,#7C5CFF)}
.d-ico.b{background:linear-gradient(135deg,#5AC8FA,#3B9BFF)}
.d-ico.c{background:linear-gradient(135deg,#FFC44D,#F59E0B)}
.d-ico.d{background:linear-gradient(135deg,#4ADE80,#07C160)}
.d-ico.e{background:linear-gradient(135deg,#FB7185,#EF4444)}
.d-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.d-t{font-size:15.5px;font-weight:600;color:var(--text)}
.d-s{font-size:11.5px;color:var(--t3)}
.d-dot{min-width:19px;height:19px;padding:0 5px;border-radius:10px;background:#FF4757;color:#fff;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center}
.d-tag{font-size:10.5px;font-weight:700;color:#fff;padding:2px 7px;border-radius:8px;background:linear-gradient(135deg,#FFB020,#FF7A00)}
']);
?>
<div class="app">
  <div class="page">
    <div class="topbar">
      <h1>广场</h1>
      <div class="tb-actions">
        <a class="tb-btn" href="moment.php" aria-label="朋友圈">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5A2.5 2.5 0 0 1 5.5 6h1.6l1.2-1.7h6.4L15.9 6h2.6A2.5 2.5 0 0 1 21 8.5v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5z"/><circle cx="12" cy="12.6" r="3.6"/></svg>
        </a>
      </div>
    </div>

    <div class="page-body">

      <div class="disc-list">
        <a class="disc-item" href="moment.php">
          <span class="d-ico a">
            <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.4"/><path d="M12 3.5v2M12 18.5v2M3.5 12h2M18.5 12h2M6 6l1.4 1.4M16.6 16.6L18 18M18 6l-1.4 1.4M7.4 16.6L6 18"/></svg>
          </span>
          <span class="d-main">
            <span class="d-t">朋友圈</span>
            <span class="d-s">记录与分享生活</span>
          </span>
          <?php if ($momentUnread > 0): ?><span class="d-dot dot-dotonly" aria-label="有新动态"></span><?php endif; ?>
          <span class="arrow">›</span>
        </a>
        <a class="disc-item" href="scan.php">
          <span class="d-ico b">
            <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16"/><path d="M4 12h16"/></svg>
          </span>
          <span class="d-main"><span class="d-t">扫一扫</span><span class="d-s">扫码加好友 / 进群</span></span>
          <span class="arrow">›</span>
        </a>
        <a class="disc-item" href="invite.php">
          <span class="d-ico c">
            <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.8" y="6" width="18.4" height="12" rx="2.6"/><path d="M2.8 10h18.4"/><path d="M6.5 14.5h4"/></svg>
          </span>
          <span class="d-main"><span class="d-t">邀请有礼</span><span class="d-s">邀好友得会员 · 靓号</span></span>
          <span class="d-tag">有奖</span>
          <span class="arrow">›</span>
        </a>
        <a class="disc-item" href="group_list.php">
          <span class="d-ico d">
            <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8.5" r="3"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><circle cx="17" cy="9.5" r="2.4"/><path d="M15 19a4.5 4.5 0 0 1 5.5-4.4"/></svg>
          </span>
          <span class="d-main"><span class="d-t">我的群组</span><span class="d-s">已加入和创建的群聊</span></span>
          <span class="arrow">›</span>
        </a>
        <a class="disc-item" href="group_join.php">
          <span class="d-ico e">
            <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
          </span>
          <span class="d-main"><span class="d-t">加入群聊</span><span class="d-s">按群号或群名查找</span></span>
          <span class="arrow">›</span>
        </a>
      </div>

      <div class="empty" style="padding:22px 20px 10px;font-size:11.5px;color:var(--t3)">更多功能开发中</div>
    </div>

    <?php cc_tabbar('discover'); ?>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
document.addEventListener('DOMContentLoaded', function () {
  CC.api('moment_unread_info').then(function (d) {
    var n = parseInt(d.total || 0, 10);
    var el = document.getElementById('momentDot');
    if (n > 0) {
      el.textContent = n > 99 ? '99+' : n;
      el.style.display = 'inline-block';
    } else {
      el.style.display = 'none';
    }
  }).catch(function () { });
});
</script>
<?php cc_foot(); ?>
