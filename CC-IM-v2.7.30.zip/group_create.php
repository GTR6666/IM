<?php
/**
 * CC商聊 - 创建群聊
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$vip = is_vip($me);
$maxLimit = (int)setting('group_max_limit', '2000');

cc_head('创建群聊');
?>
<div class="app">
  <div class="page">
    <?php cc_topbar('创建群聊', 'group_list.php'); ?>
    <div class="page-body no-tab">
      <div class="card" style="text-align:center;padding:22px 16px 18px">
        <button id="avatarBtn" style="display:inline-block;position:relative">
          <span class="avatar xl" id="avatarBox" style="background:var(--line);color:var(--t3);font-size:30px">＋</span>
          <span style="position:absolute;right:-4px;bottom:-4px;width:26px;height:26px;border-radius:50%;background:var(--brand);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;border:2px solid var(--card)">📷</span>
        </button>
        <input type="file" id="avatarFile" accept="image/*" class="hidden">
        <div class="t3 small" style="margin-top:10px">点击设置群头像，建群后也能修改</div>
      </div>

      <div class="cell-group">
        <div class="field-row">
          <label>群名称</label>
          <input id="gName" maxlength="20" placeholder="给群聊取个名字">
          <span class="t3 small" id="nameCount" style="flex:0 0 auto">0/20</span>
        </div>
        <div class="field-row" style="align-items:flex-start">
          <label style="padding-top:2px">群简介</label>
          <textarea id="gIntro" maxlength="200" placeholder="简单介绍一下这个群" style="min-height:72px"></textarea>
          <span class="t3 small" id="introCount" style="flex:0 0 auto;padding-top:2px">0/200</span>
        </div>
      </div>

      <div class="card">
        <div class="row-between"><span class="t2">群人数上限</span><span>100 人</span></div>
        <div class="t3 small" style="margin-top:8px;line-height:1.7">开通 VIP 可把群人数上限升级至 500 人，SVIP 可升级至 <?= $maxLimit ?> 人。建群后可在「群资料」里升级。</div>
        <div class="row-between" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)">
          <span class="t2">群号</span><span>系统生成 7 位数字</span>
        </div>
      </div>

      <div style="padding:16px 12px 24px">
        <button class="btn" id="btnCreate">创建群聊</button>
      </div>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
document.addEventListener('DOMContentLoaded', function () {
  var gName = document.getElementById('gName');
  var gIntro = document.getElementById('gIntro');
  var nameCount = document.getElementById('nameCount');
  var introCount = document.getElementById('introCount');
  var btnCreate = document.getElementById('btnCreate');
  var avatarBtn = document.getElementById('avatarBtn');
  var avatarFile = document.getElementById('avatarFile');
  var avatarBox = document.getElementById('avatarBox');
  var avatarObj = null;

  function copyText(t) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      CC.toast(ok ? '已复制' : '复制失败，请长按群号复制');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () { CC.toast('已复制'); }, fallback);
    } else {
      fallback();
    }
  }

  function pickFriends(title, onDone) {
    CC.api('share_targets').then(function (d) {
      var friends = d.friends || [];
      if (!friends.length) { CC.toast('还没有好友，先去通讯录添加吧'); return; }
      var html = '<div class="picker-list">' + friends.map(function (f) {
        return '<div class="picker-item" data-uid="' + f.id + '">' +
          '<span class="check">✓</span>' + CC.avatarHtml({ avatar: f.avatar, nickname: f.name }, 'sm') +
          '<div class="flex1 nowrap">' + CC.esc(f.name) + '</div></div>';
      }).join('') + '</div><div style="padding:12px 0 4px"><button class="btn" id="pickOk">确定邀请</button></div>';
      var s = CC.sheet(title, html);
      s.el.querySelectorAll('.picker-item').forEach(function (el) {
        el.onclick = function () { el.classList.toggle('selected'); };
      });
      s.el.querySelector('#pickOk').onclick = function () {
        var ids = [];
        s.el.querySelectorAll('.picker-item.selected').forEach(function (el) {
          ids.push(parseInt(el.getAttribute('data-uid'), 10));
        });
        if (!ids.length) { CC.toast('请选择好友'); return; }
        s.close();
        onDone(ids);
      };
    }).catch(function (e) { CC.toast(e.message || '加载好友失败'); });
  }

  function inviteTo(gid, ids, done) {
    var i = 0, okCount = 0;
    function next() {
      if (i >= ids.length) {
        CC.toast('已邀请 ' + okCount + ' 位好友');
        if (done) done();
        return;
      }
      CC.api('group_share_card', { gid: gid, to: ids[i++] }).then(function () {
        okCount++;
        next();
      }).catch(function () { next(); });
    }
    next();
  }

  function showSuccess(g) {
    var mask = document.createElement('div');
    mask.className = 'mask show';
    var box = document.createElement('div');
    box.className = 'dialog show';
    box.innerHTML = '<h3>群聊创建成功</h3>' +
      '<p>把群号发给好友，或直接邀请他们加入</p>' +
      '<div style="background:var(--bg);border-radius:12px;padding:14px 12px;margin-bottom:14px">' +
        '<div class="t3 small">群号</div>' +
        '<div style="font-size:26px;font-weight:700;letter-spacing:2px;margin-top:2px">' + g.gid + '</div>' +
        '<div class="t3 small" style="margin-top:2px">' + CC.esc(g.name) + '</div>' +
        '<button class="btn small" id="btnCopyGid" style="margin:10px auto 0">复制群号</button>' +
      '</div>' +
      '<div class="dlg-actions"><button class="ghost" id="btnInvite">邀请好友</button>' +
      '<button class="primary" id="btnDone">完成</button></div>';
    document.body.appendChild(mask);
    document.body.appendChild(box);
    box.querySelector('#btnCopyGid').onclick = function () { copyText(String(g.gid)); };
    box.querySelector('#btnInvite').onclick = function () {
      pickFriends('邀请好友加入', function (ids) { inviteTo(g.gid, ids); });
    };
    box.querySelector('#btnDone').onclick = function () {
      location.href = 'index.php?gid=' + g.gid;
    };
  }

  gName.addEventListener('input', function () { nameCount.textContent = gName.value.length + '/20'; });
  gIntro.addEventListener('input', function () { introCount.textContent = gIntro.value.length + '/200'; });

  avatarBtn.onclick = function () { avatarFile.click(); };
  avatarFile.onchange = function () {
    var f = avatarFile.files && avatarFile.files[0];
    if (!f) return;
    avatarObj = f;
    var url = URL.createObjectURL(f);
    avatarBox.innerHTML = '<img src="' + url + '" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:18px">';
  };

  btnCreate.onclick = function () {
    var name = gName.value.trim();
    if (!name) { CC.toast('请填写群名称'); gName.focus(); return; }
    btnCreate.disabled = true;
    btnCreate.textContent = '创建中…';
    CC.api('group_create', { name: name, intro: gIntro.value.trim() }).then(function (g) {
      var finish = function () { showSuccess(g); };
      if (avatarObj) {
        CC.upload('group_upload_avatar', avatarObj, { gid: g.gid }).then(finish).catch(finish);
      } else {
        finish();
      }
    }).catch(function (e) {
      CC.toast(e.message || '创建失败');
      btnCreate.disabled = false;
      btnCreate.textContent = '创建群聊';
    });
  };
});
</script>
<?php cc_foot(); ?>
