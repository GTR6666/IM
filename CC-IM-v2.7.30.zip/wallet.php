<?php
/**
 * CC商聊 - CC币钱包（余额 / 收支明细 / 客服充值 / 提现 / 我的申请 / VIP / 靓号）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
if (!$u) {
    header('Location: login.php');
    exit;
}

$uid        = (int)$u['id'];
$coin       = (int)$u['coin'];
$income     = (int)$u['total_income'];
$expense    = (int)$u['total_expense'];
$hasPayPwd  = !empty($u['pay_password']);
$isVip      = is_vip($u);
$vipLevel   = $isVip ? (int)$u['vip_level'] : 0;
$vipExpire  = (int)$u['vip_expire_at'];
$vipText    = $isVip ? ('有效期至 ' . date('Y-m-d H:i', $vipExpire)) : '开通会员解锁更多特权';

$withdrawMin = max(1, (int)setting('withdraw_min', '100'));
$usdtRate    = max(1, (int)setting('usdt_rate', '7'));
$usdtMin     = max(1, (int)setting('usdt_min_coin', '10'));
$usdtNetwork = (string)setting('usdt_network', 'TRC20');

$svcUid = (int)val('SELECT id FROM users WHERE account=?', [(string)setting('service_uid', '10086')]);
$svcRow = $svcUid ? one('SELECT id,nickname,avatar,yx_id,pretty_yxid FROM users WHERE id=?', [$svcUid]) : null;

$vipPlans   = all('SELECT * FROM vip_plans WHERE status=1 ORDER BY sort,id');
$prettyType  = (isset($_GET['ptype']) && $_GET['ptype'] === 'group') ? 'group' : 'user';
$prettyList  = all('SELECT * FROM pretty_ids WHERE status=0 AND ptype=? ORDER BY price ASC LIMIT 60', [$prettyType]);
$myGroups    = all('SELECT gid,name,pretty_gid FROM groups WHERE owner_uid=? AND status=1 ORDER BY id DESC LIMIT 50', [(int)$u['id']]);
$prettyCount = [];
foreach (all('SELECT ptype, COUNT(*) AS n FROM pretty_ids WHERE status=0 GROUP BY ptype') as $r) $prettyCount[(string)$r['ptype']] = (int)$r['n'];
$myAk       = $u['pretty_yxid'] ?: ($u['yx_id'] ?: (string)$u['account']);

$tab = (string)($_GET['tab'] ?? '');
if (!in_array($tab, ['vip', 'pretty', 'orders'], true)) $tab = '';
$view = $tab === '' ? 'home' : $tab;

$css = <<<CSS
.wh-stats{display:flex;gap:28px;margin-top:12px}
.wh-stats div span{display:block;font-size:11px;opacity:.82}
.wh-stats div b{font-size:15px;font-weight:600;letter-spacing:.2px}
.wallet-tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0 12px}
.wallet-tiles .wt{background:var(--card);border-radius:12px;padding:14px 6px;display:flex;flex-direction:column;align-items:center;gap:7px;font-size:12.5px;color:var(--text);text-align:center}
.wallet-tiles .wt:active{background:var(--line)}
.wallet-tiles .wi{width:36px;height:36px;border-radius:10px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center}
.log-card{background:var(--card);border-radius:var(--radius);margin:14px 12px 0;overflow:hidden}
.log-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:14px 16px 6px}
.log-head h3{font-size:15px;margin:0}
.log-tabs{display:flex;gap:6px}
.log-tabs button{height:28px;padding:0 12px;border-radius:8px;background:var(--bg);color:var(--t2);font-size:12.5px}
.log-tabs button.active{background:var(--brand);color:#fff;font-weight:600}
.log-item .li-info{flex:1;min-width:0;padding-right:10px}
.log-item .li-info b{display:block;font-size:14px}
.log-item .li-amount{flex:0 0 auto}
.log-more{text-align:center;padding:14px;font-size:12.5px;color:var(--t2);border-top:1px solid var(--line);cursor:pointer}
.log-more:active{background:var(--line)}
.order-row{display:flex;align-items:flex-start;gap:10px;padding:13px 16px;border-bottom:1px solid var(--line)}
.order-row:last-child{border-bottom:0}
.order-row .or-main{flex:1;min-width:0}
.order-row .or-main b{font-size:14.5px}
.order-row .or-main span{display:block;font-size:11.5px;color:var(--t3);margin-top:3px;word-break:break-all}
.orders-empty{text-align:center;color:var(--t3);font-size:12.5px;padding:22px 16px}
.plan-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 12px}
.plan{background:var(--card);border-radius:14px;padding:14px;text-align:left;display:flex;flex-direction:column;gap:3px;border:1px solid transparent}
.plan:active{border-color:var(--brand)}
.plan b{font-size:14.5px}
.plan span{font-size:11.5px;color:var(--t3)}
.plan em{font-style:normal;font-size:16px;font-weight:700;color:var(--brand);margin-top:5px}
.pretty-row{display:flex;align-items:center;gap:10px;padding:14px 16px;border-bottom:1px solid var(--line);background:var(--card)}
.pretty-row:last-child{border-bottom:0}
.pretty-row .pr-id{font-size:19px;font-weight:700;letter-spacing:1.5px;flex:1;min-width:0}
.pretty-row .pr-price{font-size:12px;color:var(--t3);margin-right:2px}
.fm-label{display:flex;align-items:center;justify-content:space-between;font-size:13px;color:var(--t2);margin:14px 0 7px}
.fm-label:first-child{margin-top:2px}
.fm-input{width:100%;height:46px;border-radius:11px;background:var(--bg);padding:0 14px;font-size:15px}
.fm-input::placeholder{color:var(--t3)}
textarea.fm-input{height:auto;padding:11px 14px;line-height:1.5;resize:none}
.chips{display:flex;gap:8px;margin-top:8px}
.chips button{flex:1;height:34px;border-radius:9px;background:var(--bg);color:var(--t2);font-size:13px}
.chips button:active{background:var(--line)}
.qr-block{display:flex;align-items:center;gap:12px;background:var(--bg);border-radius:11px;padding:10px 12px}
.qr-block .qrp{width:52px;height:52px;border-radius:9px;background:var(--card);display:flex;align-items:center;justify-content:center;overflow:hidden;color:var(--t3);flex:0 0 auto}
.qr-block .qrp img{width:100%;height:100%;object-fit:cover}
.qr-block .qri{flex:1;min-width:0}
.qr-block .qri b{display:block;font-size:13.5px}
.qr-block .qri span{display:block;font-size:11.5px;color:var(--t3);margin-top:1px}
.qr-block .qrb{height:32px;padding:0 12px;border-radius:8px;background:var(--card);color:var(--brand);font-size:12.5px;font-weight:600;flex:0 0 auto}
.usdt-entry{display:flex;align-items:center;gap:10px;background:var(--brand-soft);border-radius:12px;padding:12px 14px;margin-bottom:4px}
.usdt-entry .ue-ico{width:34px;height:34px;border-radius:9px;background:var(--brand);color:#fff;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.usdt-entry .ue-txt{flex:1;min-width:0}
.usdt-entry .ue-txt b{display:block;font-size:14px}
.usdt-entry .ue-txt span{display:block;font-size:11.5px;color:var(--t3);margin-top:1px}
.or-split{display:flex;align-items:center;gap:10px;margin:16px 0 2px}
.or-split span{font-size:11.5px;color:var(--t3)}
.or-split i{flex:1;height:1px;background:var(--line);font-style:normal}
.hint-line{font-size:11.5px;color:var(--t3);margin-top:10px;text-align:center;line-height:1.6}
.notice-box{background:rgba(245,166,35,.12);color:var(--gold);border-radius:10px;padding:10px 12px;font-size:12.5px;line-height:1.6;margin-top:10px}
.notice-box a{color:var(--gold);font-weight:600;text-decoration:underline}
.vip-cur{display:flex;align-items:center;justify-content:space-between;gap:10px}
.vip-cur .vc-l span{font-size:11.5px;color:var(--t3)}
.vip-cur .vc-l b{display:block;font-size:16px;margin-top:2px}

/* ===== v2.7 覆盖：渐变卡 / 四宫格 / 套餐层级 ===== */
.wallet-hero{margin:12px;border-radius:20px;padding:20px 18px 16px;color:#fff;position:relative;overflow:hidden;
  background:linear-gradient(125deg,#0FB981 0%,#14A88F 42%,#4E7BE8 100%);
  box-shadow:0 16px 36px rgba(21,120,160,.28)}
.wallet-hero::before{content:"";position:absolute;width:210px;height:210px;border-radius:50%;right:-80px;top:-110px;background:rgba(255,255,255,.14)}
.wallet-hero::after{content:"";position:absolute;width:150px;height:150px;border-radius:50%;left:-60px;bottom:-90px;background:rgba(255,255,255,.1)}
.wh-label{font-size:12.5px;opacity:.9;display:flex;align-items:center;gap:6px}
.wh-coin{font-size:34px;font-weight:800;letter-spacing:.5px;margin-top:6px;line-height:1.2;font-variant-numeric:tabular-nums}
.wh-stats{display:flex;gap:34px;margin-top:14px;padding-top:13px;border-top:1px solid rgba(255,255,255,.22)}
.wh-stats div span{display:block;font-size:11px;opacity:.82}
.wh-stats div b{font-size:15px;font-weight:600;letter-spacing:.2px}
.wallet-actions{display:flex;gap:10px;margin-top:15px}
.wallet-actions .wl-btn{flex:1;height:40px;border-radius:12px;background:rgba(255,255,255,.2);color:#fff;font-size:14px;font-weight:600;
  display:flex;align-items:center;justify-content:center;border:1px solid rgba(255,255,255,.18)}
.wallet-actions .wl-btn:active{background:rgba(255,255,255,.3)}
.wallet-tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:0 12px}
.wallet-tiles .wt{background:var(--card);border-radius:14px;padding:13px 4px 11px;display:flex;flex-direction:column;align-items:center;gap:7px;font-size:11.5px;color:var(--text);text-align:center}
.wallet-tiles .wt:active{background:var(--line)}
.wallet-tiles .wi{width:38px;height:38px;border-radius:12px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center}
.wallet-tiles .wt:nth-child(2) .wi{background:rgba(245,158,11,.13);color:#F59E0B}
.wallet-tiles .wt:nth-child(3) .wi{background:rgba(96,165,250,.14);color:#3B82F6}
.wallet-tiles .wt:nth-child(4) .wi{background:rgba(16,185,129,.13);color:#10B981}
.log-card{background:var(--card);border-radius:var(--radius);margin:14px 12px 0;overflow:hidden}
.log-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:14px 16px 6px}
.log-head h3{font-size:15px;margin:0;display:flex;align-items:center;gap:7px}
.log-head h3::before{content:"";width:3px;height:14px;border-radius:2px;background:var(--brand)}
.log-tabs{display:flex;gap:6px}
.log-tabs button{height:28px;padding:0 12px;border-radius:8px;background:var(--bg);color:var(--t2);font-size:12.5px}
.log-tabs button.active{background:var(--brand);color:#fff;font-weight:600}
.log-item .li-info{flex:1;min-width:0;padding-right:10px}
.log-item .li-info b{display:block;font-size:14px}
.log-item .li-amount{flex:0 0 auto}
.log-more{text-align:center;padding:14px;font-size:12.5px;color:var(--t2);border-top:1px solid var(--line);cursor:pointer}
.log-more:active{background:var(--line)}
/* 靓号个人 / 群 切换 */
.pt-tabs{display:flex;gap:8px;margin:12px 12px 0}
.pt-tab{flex:1;height:38px;border-radius:11px;background:var(--card);display:flex;align-items:center;justify-content:center;gap:6px;
  font-size:13.5px;color:var(--t2);font-weight:500;box-shadow:0 2px 10px rgba(26,32,60,.04)}
.pt-tab em{font-style:normal;font-size:11px;color:var(--t3);background:var(--bg);border-radius:8px;padding:1px 6px}
.pt-tab.on{background:var(--brand);color:#fff;font-weight:600;box-shadow:0 6px 16px rgba(7,193,96,.24)}
.pt-tab.on em{background:rgba(255,255,255,.22);color:#fff}
/* 套餐层级标签 */
.plan-tier{align-self:flex-start;font-size:10px;font-weight:700;padding:1px 6px;border-radius:5px;background:rgba(245,166,35,.14);color:var(--gold)}
.plan-tier.svip{background:linear-gradient(135deg,#7C3AED,#F59E0B);color:#fff}
.vip-cur .vc-l b.svip-text{background:linear-gradient(135deg,#7C3AED,#F59E0B);-webkit-background-clip:text;background-clip:text;color:transparent}
CSS;
cc_head('CC币钱包', ['body_class' => 'app-body', 'css' => $css]);
?>
<div class="app">
  <div class="page">
    <div class="topbar">
      <button class="tb-back" id="btnBack" aria-label="返回">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <div class="tb-title">CC币钱包</div>
      <div class="tb-right"><button class="tb-btn" id="btnSvc" style="width:auto;padding:0 8px;font-size:13px;color:var(--brand);font-weight:500">客服</button></div>
    </div>

    <div class="page-body no-tab">

      <div class="wallet-hero">
        <div class="wh-label"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.6h4.8M9.6 12h4.8M12 9.6v4.8"/></svg>CC币余额</div>
        <div class="wh-coin"><span id="coinText"><?= $coin ?></span><span style="font-size:13px;font-weight:500;opacity:.9;margin-left:6px">CC币</span></div>
        <div class="wh-stats">
          <div><span>累计收入</span><b id="incomeText"><?= $income ?></b></div>
          <div><span>累计支出</span><b id="expenseText"><?= $expense ?></b></div>
        </div>
        <div class="wallet-actions">
          <a class="wl-btn" href="usdt_pay.php">充值</a>
          <button class="wl-btn" id="btnWithdraw">提现</button>
          <button class="wl-btn" id="btnOrders">我的申请</button>
        </div>
      </div>

      <div class="wallet-tiles">
        <a class="wt" href="usdt_pay.php">
          <span class="wi">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
          </span>
          <span>充值</span>
        </a>
        <button class="wt" id="btnWithdraw2">
          <span class="wi">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 4v13"/><path d="M7.5 12.5L12 17l4.5-4.5"/><path d="M4.5 20h15"/></svg>
          </span>
          <span>提现</span>
        </button>
        <button class="wt" id="btnOrders2">
          <span class="wi">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="3.5" width="15" height="17" rx="2.4"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4"/></svg>
          </span>
          <span>我的申请</span>
        </button>
        <a class="wt" href="service.php">
          <span class="wi">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 13v-1a7.5 7.5 0 0 1 15 0v1"/><rect x="2.8" y="12.6" width="4" height="6.2" rx="2"/><rect x="17.2" y="12.6" width="4" height="6.2" rx="2"/><path d="M19.2 18.8v.7a2.6 2.6 0 0 1-2.6 2.6H13"/></svg>
          </span>
          <span>客服</span>
        </a>
      </div>

      <!-- ===== 收支明细 ===== -->
      <div id="viewHome">
        <div class="log-card">
          <div class="log-head">
            <h3>收支明细</h3>
            <div class="log-tabs" id="logTabs">
              <button class="active" data-dir="0">全部</button>
              <button data-dir="1">收入</button>
              <button data-dir="2">支出</button>
            </div>
          </div>
          <div id="logList"><div class="loading">加载中…</div></div>
          <div class="log-more hidden" id="logMore">加载更多</div>
        </div>
      </div>

      <!-- ===== VIP ===== -->
      <div id="viewVip" class="hidden">
        <div class="card">
          <div class="vip-cur">
            <div class="vc-l">
              <span>当前会员</span>
              <b id="vipState" class="<?= $vipLevel > 0 && vip_tier($vipLevel) === 'SVIP' ? 'svip-text' : '' ?>"><?= $vipLevel > 0 ? e(vip_label($vipLevel)) : '未开通' ?></b>
              <span id="vipExpire"><?= e($vipText) ?></span>
            </div>
            <?= $vipLevel > 0 ? vip_badge($vipLevel) : '<span class="badge" style="background:var(--brand-soft);color:var(--brand)">去开通</span>' ?>
          </div>
        </div>
        <div class="group-title">选择套餐</div>
        <?php if (!$vipPlans): ?>
        <div class="empty">暂无可购买套餐</div>
        <?php else: ?>
        <div class="plan-grid">
          <?php foreach ($vipPlans as $p): ?>
          <button class="plan" data-plan="<?= (int)$p['id'] ?>" data-name="<?= e($p['name']) ?>" data-days="<?= (int)$p['days'] ?>" data-price="<?= (int)$p['price'] ?>">
            <b><?= e($p['name']) ?></b>
            <span class="plan-tier <?= vip_badge_cls((int)$p['level']) === 'svip' ? 'svip' : '' ?>"><?= e(vip_tier((int)$p['level'])) ?></span>
            <span><?= (int)$p['days'] ?> 天</span>
            <em><?= (int)$p['price'] ?> CC币</em>
          </button>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="hint-line">购买后立即生效，多套餐可叠加时长</div>
      </div>

      <!-- ===== 靓号 ===== -->
      <div id="viewPretty" class="hidden">
        <div class="pt-tabs">
          <a class="pt-tab <?= $prettyType === 'user' ? 'on' : '' ?>" href="wallet.php?tab=pretty&ptype=user">个人靓号<em><?= (int)($prettyCount['user'] ?? 0) ?></em></a>
          <a class="pt-tab <?= $prettyType === 'group' ? 'on' : '' ?>" href="wallet.php?tab=pretty&ptype=group">群靓号<em><?= (int)($prettyCount['group'] ?? 0) ?></em></a>
        </div>
        <div class="card">
          <div class="vip-cur">
            <div class="vc-l">
              <span><?= $prettyType === 'group' ? '我的群号' : '我的CC号' ?></span>
              <b id="myAkText" style="letter-spacing:1.5px"><?= e($prettyType === 'group' ? ($myGroups && (int)$myGroups[0]['pretty_gid'] > 0 ? (string)$myGroups[0]['pretty_gid'] : '未设置') : $myAk) ?></b>
              <span><?= $prettyType === 'group' ? '购买后自动应用到所选群聊' : '购买靓号后自动替换展示号' ?></span>
            </div>
            <?php if ($prettyType === 'user'): ?>
            <button class="btn small outline" id="btnCopyAk" style="width:auto;flex:0 0 auto">复制</button>
            <?php endif; ?>
          </div>
          <?php if ($prettyType === 'group'): ?>
          <?php if ($myGroups): ?>
          <div style="margin-top:12px">
            <div class="fm-label" style="margin-top:0"><span>购买后应用到</span></div>
            <select class="fm-input" id="prettyGroup" style="height:44px">
              <?php foreach ($myGroups as $g): ?>
              <option value="<?= (int)$g['gid'] ?>"><?= e($g['name']) ?><?= (int)$g['pretty_gid'] > 0 ? '（现靓号 ' . (int)$g['pretty_gid'] . '）' : '（' . (int)$g['gid'] . '）' ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php else: ?>
          <div class="notice-box" style="margin-top:12px">你还不是任何群聊的群主，无法购买群靓号</div>
          <?php endif; ?>
          <?php endif; ?>
        </div>
        <div class="group-title"><?= $prettyType === 'group' ? '群靓号商城' : '靓号商城' ?></div>
        <?php if (!$prettyList): ?>
        <div class="empty"><?= $prettyType === 'group' ? '群靓号已抢空' : '靓号已抢空' ?>，过几天再来看看</div>
        <?php else: ?>
        <div class="cell-group">
          <?php foreach ($prettyList as $p): ?>
          <div class="pretty-row" data-pid="<?= (int)$p['id'] ?>">
            <div class="pr-id"><?= e($p['yx_id']) ?><?php if ((string)($p['ptype'] ?? 'user') === 'group'): ?><span class="tag-pretty" style="margin-left:6px;vertical-align:3px">群</span><?php endif; ?></div>
            <div class="pr-price"><?= (int)$p['price'] ?> CC币</div>
            <button class="btn small" data-buy-pretty="<?= (int)$p['id'] ?>" data-yxid="<?= e($p['yx_id']) ?>" data-price="<?= (int)$p['price'] ?>" data-ptype="<?= e((string)($p['ptype'] ?? 'user')) ?>">购买</button>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="hint-line">靓号永久有效，购买后不可退换<?= $prettyType === 'group' ? '；群靓号仅在群主名下有效，换群需重新购买' : '' ?></div>
      </div>

      <!-- ===== 我的申请 ===== -->
      <div id="viewOrders" class="hidden">
        <div class="group-title" style="padding-top:12px">充值 / 提现申请</div>
        <div class="cell-group" id="ordersBox"><div class="loading">加载中…</div></div>
        <div class="hint-line">充值单由客服确认到账，提现单审核通过后打款</div>
      </div>

    </div>
  </div>
</div>

<!-- 提现 -->
<div class="mask" id="maskWithdraw"></div>
<div class="sheet" id="sheetWithdraw">
  <div class="sheet-hd">
    <h3>提现申请</h3>
    <button class="close" type="button" data-close="withdraw">✕</button>
  </div>
  <div class="sheet-body">
    <div class="fm-label"><span>提现金额</span><span style="color:var(--t3);font-size:11.5px">可提 <?= $coin ?> CC币</span></div>
    <input class="fm-input" id="wdAmount" type="number" min="1" inputmode="numeric" placeholder="请输入提现CC币数">
    <div class="chips">
      <button type="button" data-amt="100">100</button>
      <button type="button" data-amt="500">500</button>
      <button type="button" data-amt="1000">1000</button>
      <button type="button" data-amt="all">全部</button>
    </div>
    <p class="hint-line" style="text-align:left;margin-top:8px">最低提现 <?= $withdrawMin ?> CC币，审核通过后打款</p>

    <div class="fm-label"><span>收款账号</span></div>
    <input class="fm-input" id="wdAccount" type="text" maxlength="120" placeholder="微信号 / 支付宝 / 银行卡号" autocomplete="off">

    <div class="fm-label"><span>收款码</span><span style="color:var(--t3);font-size:11.5px">选填</span></div>
    <div class="qr-block">
      <div class="qrp" id="wdQrPreview">
        <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><path d="M13.5 13.5h3v3M20.5 13.5v3M13.5 20.5h7"/></svg>
      </div>
      <div class="qri"><b>上传收款码</b><span>上传后客服直接扫码打款</span></div>
      <button class="qrb" type="button" id="wdQrPick">选择图片</button>
      <input type="file" id="wdQrFile" accept="image/*" style="display:none">
    </div>

    <div class="fm-label"><span>支付密码</span><span style="color:var(--t3);font-size:11.5px">6 位数字</span></div>
    <input class="fm-input" id="wdPayPwd" type="password" maxlength="6" inputmode="numeric" placeholder="请输入支付密码" autocomplete="off">
    <?php if (!$hasPayPwd): ?>
    <div class="notice-box">你还没有设置支付密码，设置后才能提现。<a href="profile.php">去设置</a></div>
    <?php endif; ?>

    <button class="btn" id="btnWithdrawDo" type="button" style="margin-top:16px">提交申请</button>
    <p class="hint-line">提交后等待管理员审核，审核结果可在「我的申请」查看</p>
  </div>
</div>

<!-- VIP 购买 -->
<div class="mask" id="maskVip"></div>
<div class="sheet" id="sheetVip">
  <div class="sheet-hd">
    <h3>开通会员</h3>
    <button class="close" type="button" data-close="vip">✕</button>
  </div>
  <div class="sheet-body">
    <div class="card" style="margin:0;background:var(--bg)">
      <div class="vc-l"><span style="font-size:11.5px;color:var(--t3)">套餐</span><b id="vipName" style="display:block;font-size:15px;margin-top:2px">-</b></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
        <span style="font-size:12.5px;color:var(--t2)">应付</span>
        <b id="vipPrice" style="color:var(--brand);font-size:17px">0 CC币</b>
      </div>
    </div>
    <div class="fm-label"><span>支付密码</span></div>
    <input class="fm-input" id="vipPwd" type="password" maxlength="6" inputmode="numeric" placeholder="请输入支付密码" autocomplete="off">
    <?php if (!$hasPayPwd): ?>
    <div class="notice-box">你还没有设置支付密码，请先<a href="profile.php">去设置</a></div>
    <?php endif; ?>
    <button class="btn" id="btnVipDo" type="button" style="margin-top:16px">确认支付</button>
  </div>
</div>

<!-- 靓号购买 -->
<div class="mask" id="maskPretty"></div>
<div class="sheet" id="sheetPretty">
  <div class="sheet-hd">
    <h3>购买靓号</h3>
    <button class="close" type="button" data-close="pretty">✕</button>
  </div>
  <div class="sheet-body">
    <div class="card" style="margin:0;background:var(--bg);text-align:center">
      <div style="font-size:26px;font-weight:700;letter-spacing:2px" id="prettyId">-</div>
      <div style="margin-top:8px;font-size:12.5px;color:var(--t2)">价格 <b id="prettyPrice" style="color:var(--brand);font-size:16px">0</b> CC币</div>
    </div>
    <div class="fm-label"><span>支付密码</span></div>
    <input class="fm-input" id="prettyPwd" type="password" maxlength="6" inputmode="numeric" placeholder="请输入支付密码" autocomplete="off">
    <?php if (!$hasPayPwd): ?>
    <div class="notice-box">你还没有设置支付密码，请先<a href="profile.php">去设置</a></div>
    <?php endif; ?>
    <button class="btn" id="btnPrettyDo" type="button" style="margin-top:16px">确认购买</button>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
window.WALLET_CFG = {
  view: <?= json_encode($view) ?>,
  prettyType: <?= json_encode($prettyType) ?>,
  coin: <?= $coin ?>,
  hasPayPwd: <?= $hasPayPwd ? 1 : 0 ?>,
  withdrawMin: <?= $withdrawMin ?>,
  svcUid: <?= $svcUid ?>
};
</script>
<script>
(function () {
  var CFG = window.WALLET_CFG;
  var S = {
    coin: CFG.coin, hasPayPwd: CFG.hasPayPwd, withdrawMin: CFG.withdrawMin, svcUid: CFG.svcUid,
    page: 1, dir: 0, more: 0, loading: false, qrUrl: '', vip: null, pretty: null
  };
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return CC.esc(s); }
  function toast(m) { CC.toast(m); }
  function api(action, data) {
    return CC.ajax(action, data, { silent: true }).then(function (res) {
      if (res.code === 401) { location.href = 'login.php'; throw new Error('401'); }
      return res;
    });
  }
  function reloadSoon(ms) { setTimeout(function () { location.reload(); }, ms || 800); }
  function payFail(res) {
    if (res.code === 1001) {
      CC.confirm({ title: '未设置支付密码', text: '请先设置 6 位支付密码后再操作', ok: '去设置', cancel: '取消' })
        .then(function (go) { if (go) location.href = 'profile.php'; });
      return true;
    }
    if (res.code === 1002) { toast('支付密码不正确'); return true; }
    return false;
  }

  var SHEETS = {
    withdraw: ['maskWithdraw', 'sheetWithdraw'],
    vip: ['maskVip', 'sheetVip'],
    pretty: ['maskPretty', 'sheetPretty']
  };
  function openSheet(k) { document.getElementById(SHEETS[k][0]).classList.add('show'); document.getElementById(SHEETS[k][1]).classList.add('show'); }
  function closeSheet(k) { document.getElementById(SHEETS[k][0]).classList.remove('show'); document.getElementById(SHEETS[k][1]).classList.remove('show'); }
  $$('[data-close]').forEach(function (b) {
    b.onclick = function () { closeSheet(b.getAttribute('data-close')); };
  });
  Object.keys(SHEETS).forEach(function (k) {
    var m = document.getElementById(SHEETS[k][0]);
    if (m) m.onclick = function () { closeSheet(k); };
  });

  var VIEWS = { home: 'viewHome', vip: 'viewVip', pretty: 'viewPretty', orders: 'viewOrders' };
  function showView(name) {
    if (!VIEWS[name]) name = 'home';
    Object.keys(VIEWS).forEach(function (k) {
      var el = document.getElementById(VIEWS[k]);
      if (el) el.classList.toggle('hidden', k !== name);
    });
    var pb = $('.page-body'); if (pb) pb.scrollTop = 0;
    try {
      var extra = (name === 'pretty' && CFG.prettyType === 'group') ? '&ptype=group' : '';
      history.replaceState(null, '', name === 'home' ? 'wallet.php' : 'wallet.php?tab=' + name + extra);
    } catch (e) { }
    if (name === 'orders') loadOrders();
  }

  /* ---------- 收支明细 ---------- */
  var BIZ = {
    usdt_recharge: 'USDT充值', recharge: '客服充值', withdraw: '提现', withdraw_refund: '提现退回',
    transfer: '转账', redpacket: '红包', gift: '礼物', vip: '会员', pretty: '靓号',
    invite: '邀请奖励', admin: '管理员调整'
  };
  var logList = $('#logList'), logMore = $('#logMore');

  function logRow(it) {
    var isIn = parseInt(it.direction, 10) === 1;
    var name = BIZ[it.biz] || (it.biz ? String(it.biz) : 'CC币变动');
    var amt = (isIn ? '+' : '-') + parseInt(it.amount, 10);
    var sub = CC.fmtFull(it.created_at) + ' · 余额 ' + parseInt(it.balance_after, 10);
    var remark = it.remark ? '<span>' + esc(it.remark) + '</span>' : '';
    return '<div class="log-item">' +
      '<div class="li-info"><b>' + esc(name) + '</b><span>' + sub + '</span>' + remark + '</div>' +
      '<div class="li-amount ' + (isIn ? 'in' : 'out') + '">' + amt + '</div>' +
      '</div>';
  }

  function loadLogs(reset) {
    if (S.loading) return;
    S.loading = true;
    if (reset) {
      S.page = 1; S.more = 0;
      logList.innerHTML = '<div class="loading">加载中…</div>';
      logMore.classList.add('hidden');
    }
    api('wallet_logs', { direction: S.dir, page: S.page }).then(function (res) {
      S.loading = false;
      if (res.code !== 0) { toast(res.msg || '加载失败'); if (reset) logList.innerHTML = ''; return; }
      var list = res.data.list || [];
      if (reset) logList.innerHTML = '';
      if (reset && !list.length) {
        logList.innerHTML = '<div class="empty"><div class="ico">📒</div><div>暂无收支明细</div>' +
          '<div style="font-size:12px;margin-top:4px">充值、消费后都会记录在这里</div></div>';
        logMore.classList.add('hidden');
        return;
      }
      logList.insertAdjacentHTML('beforeend', list.map(logRow).join(''));
      S.more = parseInt(res.data.has_more, 10) || 0;
      logMore.classList.toggle('hidden', !S.more);
    }).catch(function () {
      S.loading = false;
      toast('网络异常，请重试');
      if (reset) logList.innerHTML = '<div class="empty">加载失败，点击重试</div>';
    });
  }
  logMore.onclick = function () {
    if (!S.more || S.loading) return;
    S.page++;
    loadLogs(false);
  };
  $('#logTabs').onclick = function (e) {
    var b = e.target.closest('button[data-dir]');
    if (!b) return;
    var d = parseInt(b.getAttribute('data-dir'), 10);
    if (d === S.dir) return;
    S.dir = d;
    $$('#logTabs button').forEach(function (o) { o.classList.toggle('active', o === b); });
    loadLogs(true);
  };

  /* ---------- 充值 ---------- */
  /* ---------- 提现 ---------- */
  var qrFile = $('#wdQrFile'), qrPreview = $('#wdQrPreview');
  var QR_SVG = qrPreview.innerHTML;
  function openWithdraw(){
    $('#wdAmount').value = '';
    $('#wdAccount').value = '';
    $('#wdPayPwd').value = '';
    S.qrUrl = '';
    qrFile.value = '';
    qrPreview.innerHTML = QR_SVG;
    openSheet('withdraw');
  };
  $('#wdQrPick').onclick = function () { qrFile.click(); };
  qrPreview.onclick = function () { if (S.qrUrl) CC.previewImage(S.qrUrl); else qrFile.click(); };
  qrFile.onchange = function () {
    var f = qrFile.files && qrFile.files[0];
    if (!f) return;
    if (!/^image\//.test(f.type)) { toast('请选择图片文件'); qrFile.value = ''; return; }
    if (f.size > 5 * 1024 * 1024) { toast('图片不能超过 5MB'); qrFile.value = ''; return; }
    qrPreview.innerHTML = '<span class="spin"></span>';
    CC.upload('upload_image', f).then(function (d) {
      S.qrUrl = d.url;
      qrPreview.innerHTML = '<img src="' + esc(d.url) + '" alt="">';
      toast('收款码已上传');
    }).catch(function (err) {
      S.qrUrl = '';
      qrPreview.innerHTML = QR_SVG;
      toast(err.message || '上传失败');
    });
  };
  $('#btnWithdrawDo').onclick = function () {
    var btn = this;
    var amount = parseInt($('#wdAmount').value, 10) || 0;
    var account = $('#wdAccount').value.trim();
    var pwd = $('#wdPayPwd').value;
    if (amount <= 0) return toast('请输入提现金额');
    if (amount < S.withdrawMin) return toast('最低提现 ' + S.withdrawMin + ' CC币');
    if (amount > S.coin) return toast('CC币余额不足');
    if (!account) return toast('请填写收款账号');
    if (!/^\d{6}$/.test(pwd)) return toast('请输入 6 位数字支付密码');
    btn.disabled = true; btn.textContent = '提交中…';
    api('wallet_withdraw', { amount: amount, account: account, qr: S.qrUrl, pay_password: pwd }).then(function (res) {
      btn.disabled = false; btn.textContent = '提交申请';
      if (res.code !== 0) {
        if (res.code === 1002) { $('#wdPayPwd').value = ''; $('#wdPayPwd').focus(); }
        if (payFail(res)) return;
        return toast(res.msg || '提交失败');
      }
      closeSheet('withdraw');
      toast('提现申请已提交，等待审核');
      S.coin = Math.max(0, S.coin - amount);
      reloadSoon(900);
    }).catch(function () {
      btn.disabled = false; btn.textContent = '提交申请';
      toast('网络异常，请重试');
    });
  };

  /* ---------- 快捷金额 ---------- */
  $$('.chips [data-amt]').forEach(function (b) {
    b.onclick = function () {
      var sheet = b.closest('.sheet');
      var target = sheet && sheet.id === 'sheetRecharge' ? $('#rcAmount') : $('#wdAmount');
      var v = b.getAttribute('data-amt');
      target.value = v === 'all' ? S.coin : v;
    };
  });

  /* ---------- VIP ---------- */
  $$('.plan[data-plan]').forEach(function (p) {
    p.onclick = function () {
      S.vip = {
        id: parseInt(p.getAttribute('data-plan'), 10),
        name: p.getAttribute('data-name'),
        days: parseInt(p.getAttribute('data-days'), 10),
        price: parseInt(p.getAttribute('data-price'), 10)
      };
      $('#vipName').textContent = S.vip.name + ' · ' + S.vip.days + ' 天';
      $('#vipPrice').textContent = S.vip.price + ' CC币';
      $('#vipPwd').value = '';
      openSheet('vip');
    };
  });
  $('#btnVipDo').onclick = function () {
    if (!S.vip) return;
    var btn = this, pwd = $('#vipPwd').value;
    if (!/^\d{6}$/.test(pwd)) return toast('请输入 6 位数字支付密码');
    if (S.coin < S.vip.price) return toast('CC币余额不足，请先充值');
    btn.disabled = true; btn.textContent = '支付中…';
    api('buy_vip', { plan_id: S.vip.id, pay_password: pwd }).then(function (res) {
      btn.disabled = false; btn.textContent = '确认支付';
      if (res.code !== 0) {
        if (res.code === 1002) { $('#vipPwd').value = ''; $('#vipPwd').focus(); }
        if (payFail(res)) return;
        return toast(res.msg || '开通失败');
      }
      closeSheet('vip');
      toast('开通成功');
      reloadSoon(800);
    }).catch(function () {
      btn.disabled = false; btn.textContent = '确认支付';
      toast('网络异常，请重试');
    });
  };

  /* ---------- 靓号 ---------- */
  $$('[data-buy-pretty]').forEach(function (b) {
    b.onclick = function () {
      var gsel = document.getElementById('prettyGroup');
      S.pretty = {
        gid: gsel ? parseInt(gsel.value, 10) : 0,
        ptype: b.getAttribute('data-ptype') || 'user',
        id: parseInt(b.getAttribute('data-buy-pretty'), 10),
        yxid: b.getAttribute('data-yxid'),
        price: parseInt(b.getAttribute('data-price'), 10)
      };
      $('#prettyId').textContent = S.pretty.yxid;
      $('#prettyPrice').textContent = S.pretty.price;
      $('#prettyPwd').value = '';
      openSheet('pretty');
    };
  });
  $('#btnPrettyDo').onclick = function () {
    if (!S.pretty) return;
    var btn = this, pwd = $('#prettyPwd').value;
    if (!/^\d{6}$/.test(pwd)) return toast('请输入 6 位数字支付密码');
    if (S.coin < S.pretty.price) return toast('CC币余额不足，请先充值');
    btn.disabled = true; btn.textContent = '支付中…';
    api('buy_pretty', { id: S.pretty.id, pay_password: pwd, gid: S.pretty.gid || 0 }).then(function (res) {
      btn.disabled = false; btn.textContent = '确认购买';
      if (res.code !== 0) {
        if (res.code === 1002) { $('#prettyPwd').value = ''; $('#prettyPwd').focus(); }
        if (payFail(res)) return;
        return toast(res.msg || '购买失败');
      }
      closeSheet('pretty');
      toast('靓号已生效');
      reloadSoon(800);
    }).catch(function () {
      btn.disabled = false; btn.textContent = '确认购买';
      toast('网络异常，请重试');
    });
  };
  // 复制按钮仅在「个人靓号」页出现，群靓号页无此元素，必须判空
  var copyAkBtn = $('#btnCopyAk');
  if (copyAkBtn) copyAkBtn.onclick = function () {
    var el = $('#myAkText');
    var txt = el ? el.textContent.trim() : '';
    var done = function () { toast('CC号已复制'); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(txt).then(done).catch(function () { fallbackCopy(txt, done); });
    } else fallbackCopy(txt, done);
  };
  function fallbackCopy(txt, done) {
    try {
      var ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      done();
    } catch (e) { toast('复制失败，请长按选择'); }
  }

  /* ---------- 我的申请 ---------- */
  var RC_ST = ['待支付', '待审核', '已到账', '已拒绝'];
  var RC_ST_SVC = ['待客服确认', '待审核', '已到账', '已拒绝'];
  var WD_ST = ['待审核', '已通过', '已拒绝', '已打款'];
  var ORDERS_LOADED = false;

  function orderRow(title, sub, statusText, badgeCls) {
    return '<div class="order-row"><div class="or-main"><b>' + title + '</b><span>' + sub + '</span></div>' +
      '<span class="badge ' + badgeCls + '" style="flex:0 0 auto">' + statusText + '</span></div>';
  }
  function loadOrders() {
    var box = $('#ordersBox');
    box.innerHTML = '<div class="loading">加载中…</div>';
    api('wallet_orders', {}).then(function (res) {
      if (res.code !== 0) {
        box.innerHTML = '<div class="orders-empty">' + esc(res.msg || '加载失败') + '</div>';
        return;
      }
      var rc = res.data.recharge || [], wd = res.data.withdraw || [];
      var html = '';
      html += '<div class="order-row" style="background:var(--bg);padding:10px 16px"><b style="font-size:12.5px;color:var(--t2)">充值申请</b></div>';
      if (!rc.length) html += '<div class="orders-empty">暂无充值申请</div>';
      rc.forEach(function (o) {
        var st = parseInt(o.status, 10);
        if (st < 0 || st > 3) st = 0;
        var isSvc = String(o.network || '') === '客服';
        var stTxt = (isSvc ? RC_ST_SVC : RC_ST)[st];
        var cls = st === 2 ? 'badge' : (st === 3 ? 'badge red' : (st === 1 || (isSvc && st === 0) ? 'badge gold' : 'badge gray'));
        var sub = [CC.fmtFull(o.created_at), '订单号 ' + o.order_no];
        if (parseFloat(o.amount_usdt) > 0) sub.push(o.amount_usdt + ' USDT');
        if (o.remark) sub.push(o.remark);
        html += orderRow('+' + parseInt(o.coin, 10) + ' CC币', sub.map(esc).join(' · '), stTxt, cls);
      });
      html += '<div class="order-row" style="background:var(--bg);padding:10px 16px"><b style="font-size:12.5px;color:var(--t2)">提现申请</b></div>';
      if (!wd.length) html += '<div class="orders-empty">暂无提现申请</div>';
      wd.forEach(function (w) {
        var st = parseInt(w.status, 10);
        if (st < 0 || st > 3) st = 0;
        var cls = st === 3 ? 'badge' : (st === 2 ? 'badge red' : (st === 1 ? 'badge gold' : 'badge gray'));
        var sub = [CC.fmtFull(w.created_at), '订单号 ' + w.order_no, '到账账号 ' + w.account];
        if (w.remark) sub.push(w.remark);
        html += orderRow('-' + parseInt(w.amount, 10) + ' CC币', sub.map(esc).join(' · '), WD_ST[st], cls);
      });
      box.innerHTML = html;
      ORDERS_LOADED = true;
    }).catch(function () {
      box.innerHTML = '<div class="orders-empty">加载失败，请下拉重试</div>';
    });
  }

  /* ---------- 入口 ---------- */
  $('#btnOrders').onclick = function () { showView('orders'); };
  var wa2 = document.getElementById('btnWithdraw2'); if (wa2) wa2.onclick = function(){ openWithdraw(); };
  var or2 = document.getElementById('btnOrders2'); if (or2) or2.onclick = function(){ showView('orders'); };
  $$('[data-view]').forEach(function (b) {
    b.onclick = function () { showView(b.getAttribute('data-view')); };
  });
  $('#btnBack').onclick = function () {
    if (history.length > 1) history.back();
    else location.href = 'me.php';
  };
  $('#btnSvc').onclick = function () {
    if (S.svcUid) location.href = 'index.php?to=' + S.svcUid;
    else toast('客服暂未配置');
  };
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') Object.keys(SHEETS).forEach(closeSheet);
  });

  // 先切换视图，再异步加载明细（避免加载异常影响视图）
  showView(CFG.view);
  try { loadLogs(true); } catch (e) { }
})();
</script>
<?php cc_foot(); ?>
