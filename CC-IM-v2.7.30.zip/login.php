<?php
/**
 * CC商聊 - 登录
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';

if (current_uid()) {
    $cu = current_user();
    if ($cu && (int)$cu['status'] !== 1) {
        header('Location: index.php');
        exit;
    }
}

$site = setting('site_name', 'CC商聊');
cc_head('登录', ['index' => true, 'desc' => setting('site_name', 'CC商聊') . ' 登录入口。注册即可获得专属' . term_id() . '，支持私聊、群聊、语音视频通话、群直播与朋友圈。', 'body_class' => 'login-body', 'css' => '
html{background:#F5F6F8;min-height:100%;}html,body{height:100%;}
body{min-height:100vh;min-height:100dvh;}
body{background:#F5F6F8;}
.login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 22px;}
.login-card{width:100%;max-width:420px;}
.auth-logo{width:84px;height:84px;border-radius:26px;background:linear-gradient(135deg,#07C160,#06AD56);color:#fff;font-size:30px;font-weight:800;display:flex;align-items:center;justify-content:center;margin:0 auto 22px;box-shadow:0 18px 36px rgba(7,193,96,.35);}
.auth-logo img{width:100%;height:100%;object-fit:cover;border-radius:26px;}
.auth-title{font-size:25px;font-weight:700;text-align:center;margin:0;}
.auth-sub{text-align:center;color:#9AA0AC;font-size:13px;margin:10px 0 32px;}
.field{height:54px;border-radius:14px;background:#fff;border:1.5px solid transparent;box-shadow:0 2px 10px rgba(26,32,60,.03);}
.field:focus-within{border-color:#B9EBD0;box-shadow:0 0 0 4px rgba(7,193,96,.1);}
.auth-row{display:flex;justify-content:space-between;align-items:center;font-size:13px;color:#6B7280;margin:8px 2px 24px;}
.auth-row a{color:#07C160;font-weight:500;}
.auth-foot{text-align:center;font-size:13.5px;color:#9AA0AC;margin-top:26px;}
.auth-foot a{color:#07C160;font-weight:600;}
.eye{width:34px;height:34px;display:flex;align-items:center;justify-content:center;color:#9AA0AC;}
']); ?>

<div class="login-wrap">
  <div class="login-card">
    <div class="auth-logo">
      <?php if (is_file(CC_ROOT . '/icons/icon-192.png')): ?>
      <img src="icons/icon-192.png" alt="">
      <?php else: ?><?= e(setting('brand', 'CC')) ?><?php endif; ?>
    </div>
    <h1 class="auth-title">欢迎回来</h1>
    <p class="auth-sub">登录 <?= e($site) ?>，连接每一次商机</p>

    <div class="field">
      <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/></svg>
      <input id="keyword" type="text" placeholder="CC号 / 邮箱 / 手机号" autocomplete="username" autofocus>
    </div>

    <div class="field">
      <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
      <input id="password" type="password" maxlength="32" placeholder="请输入密码" autocomplete="current-password">
      <button class="eye" id="eye" type="button" aria-label="显示密码">
        <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>
      </button>
    </div>

    <div class="auth-row">
      <label><input type="checkbox" id="remember" checked> 记住我</label>
      <a href="forget.php">忘记密码？</a>
    </div>

    <button class="btn" id="btnLogin">登 录</button>

    <div class="auth-foot">
      还没有账号？<a href="register.php<?= !empty($_GET['invite']) ? '?invite=' . e($_GET['invite']) : '' ?>">立即注册</a>
    </div>
    <?php
      $dlUrl = trim((string)setting('app_download_url', ''));
    ?>
    <?php if ($dlUrl !== ''): ?>
    <div class="auth-foot" style="margin-top:8px;font-size:11.5px;">
      <a href="<?= e($dlUrl) ?>" target="_blank" rel="noopener"><?= e($site) ?> APP 下载</a>
      <span style="color:#C4C9D2">·</span>
      <span>Android / iOS</span>
    </div>
    <?php endif; ?>
  </div>
</div>

<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var keyword = document.getElementById('keyword');
  var pwd = document.getElementById('password');
  var btn = document.getElementById('btnLogin');
  try{ var saved = localStorage.getItem('cc_login_keyword'); if(saved) keyword.value = saved; }catch(e){}

  document.getElementById('eye').onclick = function(){
    pwd.type = pwd.type === 'password' ? 'text' : 'password';
    this.style.color = pwd.type === 'text' ? '#07C160' : '#9AA0AC';
  };

  function submit(){
    var k = keyword.value.trim(), p = pwd.value;
    if (!k) { CC.toast('请输入 CC号或邮箱'); keyword.focus(); return; }
    if (!p) { CC.toast('请输入密码'); pwd.focus(); return; }
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span> 登录中…';
    try{ localStorage.setItem('cc_login_keyword', k); }catch(e){}
    CC.ajax('login', {keyword:k, password:p, remember: document.getElementById('remember').checked ? 1 : 0}).then(function(res){
      if (res.code === 0){
        // 记录到本机的「切换账号」列表（最多 3 个）
        try {
          var tok = (res.data && res.data.switch_token) || '';
          var uid = res.data && res.data.id;
          if (tok && uid){
            var KEY = 'cc_accounts', MAX = 3;
            var list = [];
            try { list = JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) {}
            list = list.filter(function(x){ return parseInt(x.uid, 10) !== parseInt(uid, 10); });
            list.unshift({ uid: uid, token: tok });
            localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
          }
        } catch (e) {}
        CC.toast('登录成功');
        var to = (new URLSearchParams(location.search)).get('add') === '1' ? 'me.php' : 'index.php';
        setTimeout(function(){ location.replace(to); }, 380);
        return;
      }
      btn.disabled = false; btn.textContent = '登 录';
      if (res.code === 3){ showBan(res.data || {}); return; }
      CC.toast(res.msg || '登录失败');
    }).catch(function(){ btn.disabled = false; btn.textContent = '登 录'; CC.toast('网络异常'); });
  }
  btn.onclick = submit;
  pwd.addEventListener('keydown', function(e){ if (e.key === 'Enter') submit(); });
  keyword.addEventListener('keydown', function(e){ if (e.key === 'Enter') pwd.focus(); });

  function showBan(d){
    var reason = d.ban_reason || '违反平台规定';
    var left = '永久封禁';
    if (!parseInt(d.ban_forever,10) && parseInt(d.ban_until,10) > 0){
      var s = parseInt(d.ban_until,10) - Math.floor(Date.now()/1000);
      if (s > 0){
        var day = Math.floor(s/86400), hr = Math.floor((s%86400)/3600);
        left = day > 0 ? (day + ' 天后解封') : (hr + ' 小时后解封');
      }
    }
    CC.confirm({
      title: '账号已被封禁',
      html: '<p>封禁原因：' + CC.esc(reason) + '<br>封禁时长：' + CC.esc(left) + '</p>' +
            '<p style="font-size:12px">如需申诉，可提交申诉或联系客服：' + CC.esc(d.service || '') + '</p>' +
            '<button class="btn ghost" id="apBtn" style="margin-bottom:10px">提交申诉</button>',
      ok: '知道了', cancel: '关闭'
    });
    setTimeout(function(){
      var b = document.getElementById('apBtn');
      if (b) b.onclick = function(){ location.href = 'forget.php?appeal=1&account=' + encodeURIComponent(keyword.value.trim()); };
    }, 50);
  }
})();
</script>
</body>
</html>
