/* ============================================================
   CC商聊 - 全局脚本
   ============================================================ */
(function (w, d) {
  var CC = w.CC = w.CC || {};
  // 称号（后台可自定义）：页面已注入 window.TERMS
  var T = w.TERMS || {};
  CC.T = function (k, dft) { return (T && T[k]) || dft || ''; };
  CC.me = w.ME || null;
  CC.isMe = function (u) { return CC.me && parseInt(u, 10) === parseInt(CC.me.id, 10); };

  /* ---------- 基础 ---------- */
  CC.esc = function (s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };
  CC.ajax = function (action, data, opts) {
    opts = opts || {};
    var fd = new FormData();
    fd.append('action', action);
    Object.keys(data || {}).forEach(function (k) {
      var v = data[k];
      if (v === undefined || v === null) return;
      if (typeof v === 'object') v = JSON.stringify(v);
      fd.append(k, v);
    });
    return fetch('api.php?action=' + encodeURIComponent(action), {
      method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store'
    }).then(function (r) {
      return r.json().catch(function () {
        // 接口返回非 JSON（如 PHP 500）时，转成友好中文，避免暴露英文解析错误
        throw new Error('服务异常（' + r.status + '），请稍后重试');
      });
    }).then(function (res) {
      if (opts.silent) return res;
      if (res.code === 401) { location.href = 'login.php'; throw new Error('未登录'); }
      return res;
    });
  };
  CC.api = function (action, data) {
    return CC.ajax(action, data).then(function (res) {
      if (res.code !== 0) throw new Error(res.msg || '请求失败');
      return res.data;
    });
  };
  CC.upload = function (action, file, extra) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('file', file);
    Object.keys(extra || {}).forEach(function (k) { fd.append(k, extra[k]); });
    return fetch('api.php?action=' + action, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) {
        return r.json().catch(function () {
          throw new Error('上传失败（服务异常 ' + r.status + '），请稍后重试');
        });
      })
      .then(function (res) {
        if (res.code !== 0) throw new Error(res.msg || '上传失败');
        return res.data;
      });
  };

  /* ---------- Toast ---------- */
  var toastEl = null, toastTimer = null;
  CC.toast = function (msg, ms) {
    if (!toastEl) {
      toastEl = d.createElement('div');
      toastEl.className = 'toast';
      d.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 2200);
  };

  /* ---------- 确认框 ---------- */
  CC.confirm = function (opts) {
    if (typeof opts === 'string') opts = { text: opts };
    return new Promise(function (resolve) {
      var mask = d.createElement('div'); mask.className = 'mask show';
      var box = d.createElement('div'); box.className = 'dialog show';
      box.innerHTML = '<h3>' + CC.esc(opts.title || '提示') + '</h3>' +
        (opts.html || ('<p>' + CC.esc(opts.text || '') + '</p>')) +
        '<div class="dlg-actions">' +
        (opts.single ? '' : '<button class="ghost" data-x="0">' + CC.esc(opts.cancel || '取消') + '</button>') +
        '<button class="' + (opts.danger ? 'danger' : 'primary') + '" data-x="1">' + CC.esc(opts.ok || '确定') + '</button></div>';
      d.body.appendChild(mask); d.body.appendChild(box);
      function close(v) {
        mask.remove(); box.remove(); resolve(v);
      }
      mask.onclick = function () { if (!opts.single) close(false); };
      box.querySelectorAll('[data-x]').forEach(function (b) {
        b.onclick = function () { close(b.getAttribute('data-x') === '1'); };
      });
    });
  };

  /* ---------- 输入框弹窗 ---------- */
  CC.prompt = function (opts) {
    if (typeof opts === 'string') opts = { title: opts };
    return new Promise(function (resolve) {
      var mask = d.createElement('div'); mask.className = 'mask show';
      var box = d.createElement('div'); box.className = 'dialog show';
      box.innerHTML = '<h3>' + CC.esc(opts.title || '') + '</h3>' +
        (opts.text ? '<p>' + CC.esc(opts.text) + '</p>' : '') +
        (opts.multiline
          ? '<textarea id="ccPromptInput" maxlength="' + (opts.max || 200) + '" placeholder="' + CC.esc(opts.placeholder || '') + '"></textarea>'
          : '<input id="ccPromptInput" maxlength="' + (opts.max || 100) + '" placeholder="' + CC.esc(opts.placeholder || '') + '" value="' + CC.esc(opts.value || '') + '">') +
        '<div class="dlg-actions">' +
        '<button class="ghost" data-x="0">取消</button>' +
        '<button class="primary" data-x="1">确定</button></div>';
      d.body.appendChild(mask); d.body.appendChild(box);
      var input = box.querySelector('#ccPromptInput');
      setTimeout(function () { input.focus(); }, 60);
      function close(v) { mask.remove(); box.remove(); resolve(v); }
      mask.onclick = function () { close(null); };
      box.querySelectorAll('[data-x]').forEach(function (b) {
        b.onclick = function () {
          if (b.getAttribute('data-x') === '1') close(input.value.trim());
          else close(null);
        };
      });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !opts.multiline) close(input.value.trim());
      });
    });
  };

  /* ---------- 靓号标识 ---------- */
  CC.prettyBadge = function (pretty, title) {
    var p = pretty == null ? '' : String(pretty).trim();
    if (p === '') return '';
    return '<span class="tag-pretty" title="' + CC.esc(title || CC.T('pretty','靓号')) + '">靓 ' + CC.esc(p) + '</span>';
  };

  /* ---------- 头像 ---------- */
  /* ---------- 会员标识（VIP / SVIP） ---------- */
  CC.svipMinLevel = function () {
    var v = parseInt(window.CC_SVIP_MIN || (CC.cfg && CC.cfg.svipMinLevel) || 4, 10);
    return (v >= 2 && v <= 20) ? v : 4;
  };
  CC.vipTier = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    return level >= CC.svipMinLevel() ? 'SVIP' : 'VIP';
  };
  CC.vipLabel = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    var min = CC.svipMinLevel();
    if (level < min) return 'VIP' + level;
    var step = level - min + 1;
    return step <= 1 ? 'SVIP' : 'SVIP' + step;
  };
  CC.vipBadge = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    var cls = CC.vipTier(level) === 'SVIP' ? 'svip' : 'gold';
    return ' <span class="badge ' + cls + '">' + CC.esc(CC.vipLabel(level)) + '</span>';
  };

  /* 列表里的会员标识：与靓号牌同尺寸，保证同一基线 */
  CC.vipTag = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    var cls = CC.vipTier(level) === 'SVIP' ? 'svip' : 'gold';
    return '<span class="tag-vip ' + cls + '">' + CC.esc(CC.vipLabel(level)) + '</span>';
  };

  CC.avatarHtml = function (u, cls) {
    var avatar = u && u.avatar ? u.avatar : '';
    var name = (u && (u.nickname || u.name)) || '?';
    var color = CC.colorOf(String(name));
    if (avatar) {
      return '<span class="avatar ' + (cls || '') + '"><img src="' + CC.esc(avatar) + '" alt="" loading="lazy" onerror="this.style.display=\'none\'"></span>';
    }
    return '<span class="avatar ' + (cls || '') + '" style="background:' + color + '">' + CC.esc(String(name).slice(0, 1)) + '</span>';
  };
  CC.colorOf = function (s) {
    var colors = ['#F59E0B', '#10B981', '#3B82F6', '#8B5CF6', '#EC4899', '#EF4444', '#14B8A6', '#6366F1'];
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return colors[h % colors.length];
  };

  /* ---------- 时间 ---------- */
  CC.pad = function (n) { return n < 10 ? '0' + n : '' + n; };
  CC.fmtTime = function (t) {
    t = parseInt(t, 10) || 0;
    if (!t) return '';
    var d1 = new Date(t * 1000), n = new Date();
    var sameDay = d1.toDateString() === n.toDateString();
    var y = new Date(n.getTime() - 86400000);
    if (sameDay) return CC.pad(d1.getHours()) + ':' + CC.pad(d1.getMinutes());
    if (d1.toDateString() === y.toDateString()) return '昨天';
    if (d1.getFullYear() === n.getFullYear()) return (d1.getMonth() + 1) + '月' + d1.getDate() + '日';
    return d1.getFullYear() + '-' + CC.pad(d1.getMonth() + 1) + '-' + CC.pad(d1.getDate());
  };
  CC.fmtFull = function (t) {
    t = parseInt(t, 10) || 0;
    if (!t) return '';
    var d1 = new Date(t * 1000);
    return d1.getFullYear() + '-' + CC.pad(d1.getMonth() + 1) + '-' + CC.pad(d1.getDate()) + ' ' +
      CC.pad(d1.getHours()) + ':' + CC.pad(d1.getMinutes());
  };
  CC.fmtChatTime = function (t) {
    var d1 = new Date(t * 1000), n = new Date();
    if (d1.toDateString() === n.toDateString()) return CC.pad(d1.getHours()) + ':' + CC.pad(d1.getMinutes());
    var y = new Date(n.getTime() - 86400000);
    if (d1.toDateString() === y.toDateString()) return '昨天 ' + CC.pad(d1.getHours()) + ':' + CC.pad(d1.getMinutes());
    return (d1.getMonth() + 1) + '月' + d1.getDate() + '日 ' + CC.pad(d1.getHours()) + ':' + CC.pad(d1.getMinutes());
  };
  CC.timeAgo = function (t) {
    var s = Math.floor(Date.now() / 1000) - t;
    if (s < 60) return '刚刚';
    if (s < 3600) return Math.floor(s / 60) + '分钟前';
    if (s < 86400) return Math.floor(s / 3600) + '小时前';
    if (s < 86400 * 30) return Math.floor(s / 86400) + '天前';
    return CC.fmtTime(t);
  };

  /* ---------- 图片预览 ---------- */
  CC.previewImage = function (url) {
    var mask = d.createElement('div');
    mask.className = 'mask show';
    mask.style.background = 'rgba(0,0,0,.94)';
    mask.style.zIndex = 9000;
    var img = d.createElement('img');
    img.src = url;
    img.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);max-width:94vw;max-height:90vh;border-radius:6px;z-index:9001;object-fit:contain;';
    d.body.appendChild(mask); d.body.appendChild(img);
    function close() { mask.remove(); img.remove(); }
    mask.onclick = close; img.onclick = close;
  };

  /* ---------- 底部弹层 ---------- */
  CC.sheet = function (title, html) {
    var mask = d.createElement('div'); mask.className = 'mask show';
    var box = d.createElement('div'); box.className = 'sheet';
    box.innerHTML = '<div class="sheet-hd"><h3>' + CC.esc(title || '') + '</h3><button class="close">✕</button></div>' +
      '<div class="sheet-body">' + html + '</div>';
    d.body.appendChild(mask); d.body.appendChild(box);
    requestAnimationFrame(function () { box.classList.add('show'); });
    function close() { box.classList.remove('show'); mask.classList.remove('show'); setTimeout(function () { mask.remove(); box.remove(); }, 220); }
    mask.onclick = close;
    box.querySelector('.close').onclick = close;
    return { el: box, close: close };
  };

  /* ---------- 长按 ---------- */
  CC.longPress = function (el, fn) {
    var timer = null, moved = false;
    function start(e) {
      moved = false;
      timer = setTimeout(function () { if (!moved) fn(e); }, 480);
    }
    function cancel() { clearTimeout(timer); }
    el.addEventListener('touchstart', start, { passive: true });
    el.addEventListener('touchmove', function () { moved = true; cancel(); }, { passive: true });
    el.addEventListener('touchend', cancel);
    el.addEventListener('touchcancel', cancel);
    el.addEventListener('mousedown', start);
    el.addEventListener('mouseup', cancel);
    el.addEventListener('mouseleave', cancel);
    el.addEventListener('contextmenu', function (e) { e.preventDefault(); fn(e); });
  };

  /* ---------- 主题 ---------- */
  CC.applyTheme = function () {
    var th = localStorage.getItem('app_theme');
    if (th === 'dark') d.documentElement.classList.add('dark-theme');
    else if (th === 'light') d.documentElement.classList.remove('dark-theme');
  };
  CC.setTheme = function (th) {
    localStorage.setItem('app_theme', th);
    d.documentElement.classList.toggle('dark-theme', th === 'dark');
  };

  /* ---------- 深链参数 ---------- */
  CC.qs = function (k, def) {
    var m = new URLSearchParams(location.search);
    return m.has(k) ? m.get(k) : (def === undefined ? '' : def);
  };
  CC.go = function (url) { location.href = url; };

  /* ---------- 全员未读轮询（非聊天页） ---------- */
  CC.startBadgePoll = function (interval) {
    function tick() {
      CC.ajax('unread_total', {}, { silent: true }).then(function (r) {
        if (!r || r.code !== 0) return;
        var n = r.data.chat + r.data.friend_req + r.data.group_req;
        d.querySelectorAll('[data-badge="chat"]').forEach(function (el) {
          if (n > 0) { el.textContent = n > 99 ? '99+' : n; el.classList.remove('hidden'); }
          else el.classList.add('hidden');
        });
        d.querySelectorAll('[data-badge="notice"]').forEach(function (el) {
          var c = r.data.notice || 0;
          if (c > 0) { el.textContent = c; el.classList.remove('hidden'); } else el.classList.add('hidden');
        });
      }).catch(function () { });
    }
    tick();
    setInterval(tick, interval || 20000);
  };

  CC.applyTheme();

  /* ---------- 添加到主屏幕提示（仅移动端浏览器，且只提示一次） ---------- */
  CC.installHint = function () {
    try {
      if (localStorage.getItem('cc_install_hint') === '1') return;
      var ua = navigator.userAgent || '';
      var mobile = /iPhone|iPad|iPod|Android/i.test(ua);
      var standalone = window.navigator.standalone === true ||
        (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
      if (!mobile || standalone) return;
      if (d.getElementById('ccInstallPop')) return;

      var isIOS = /iPhone|iPad|iPod/i.test(ua);
      var css = '#ccInstallPop{position:fixed;left:0;right:0;bottom:0;z-index:9990;padding:14px 16px calc(16px + env(safe-area-inset-bottom));'
        + 'background:#20242E;color:#fff;border-radius:16px 16px 0 0;box-shadow:0 -10px 40px rgba(0,0,0,.3);'
        + 'display:flex;align-items:flex-start;gap:12px;font-size:13px;line-height:1.7;animation:ccInUp .24s ease-out}'
        + '@keyframes ccInUp{from{transform:translateY(100%)}to{transform:translateY(0)}}'
        + '#ccInstallPop .ci-txt{flex:1}'
        + '#ccInstallPop .ci-ok{flex:0 0 auto;color:#7FD6A5;font-weight:600;padding:2px 4px}';
      var st = d.createElement('style'); st.id = 'ccInstallCss'; st.textContent = css; d.head.appendChild(st);

      var box = d.createElement('div');
      box.id = 'ccInstallPop';
      box.innerHTML = '<div class="ci-txt">可当 App 使用：点底部 '
        + (isIOS ? '分享 ⤴ → 添加到主屏幕' : '浏览器菜单 → 添加到主屏幕')
        + '，之后全屏打开、无需重新登录。</div><button class="ci-ok" id="ccInstallOk">知道了</button>';
      d.body.appendChild(box);
      d.getElementById('ccInstallOk').onclick = function () {
        try { localStorage.setItem('cc_install_hint', '1'); } catch (e) {}
        box.parentNode && box.parentNode.removeChild(box);
        st.parentNode && st.parentNode.removeChild(st);
      };
    } catch (e) {}
  };
})(window, document);
