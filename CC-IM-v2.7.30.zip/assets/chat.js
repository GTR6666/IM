/* ============================================================
   CC商聊 - 聊天核心
   ============================================================ */
(function (w, d) {
  var CC = w.CC;
  var S = {
    convs: [], cur: null, lastId: 0, polling: false, stopped: false,
    emojis: { system: [], mine: [] }, voiceMode: false, plusOpen: false, emojiOpen: false,
    recorder: null, chunks: [], recording: false, recStart: 0,
    msgMap: {}, selected: [], selectMode: false
  };
  w.CHAT = S;
  w.openChat = openChat;

  var $ = function (id) { return d.getElementById(id); };
  var esc = CC.esc;

  /* =========================================================
   * 会话列表
   * ========================================================= */
  function loadConvs() {
    return CC.ajax('conv_list', {}).then(function (res) {
      if (res.code !== 0) return;
      S.convs = res.data.list || [];
      renderConvs();
      updateBadge();
    }).catch(function () { });
  }

  function updateBadge() {
    var n = 0;
    S.convs.forEach(function (c) { if (!c.muted) n += c.unread || 0; });
    var badge = d.querySelector('[data-badge="chat"]');
    if (badge) {
      if (n > 0) { badge.textContent = n > 99 ? '99+' : n; badge.classList.remove('hidden'); }
      else badge.classList.add('hidden');
    }
  }

  function renderConvs() {
    var box = $('convList');
    if (!S.convs.length) {
      box.innerHTML = '';
      $('convEmpty').style.display = 'block';
      return;
    }
    $('convEmpty').style.display = 'none';
    box.innerHTML = S.convs.map(function (c) {
      var unread = c.unread || 0;
      var badge = '';
      if (unread > 0) badge = c.muted ? '<span class="conv-badge mute dot-only"></span>'
        : '<span class="conv-badge">' + (unread > 99 ? '99+' : unread) + '</span>';
      // 标识顺序：靓号 → 会员(VIP/SVIP) → 官方
      var tags = '';
      if (c.pretty) tags += '<span class="tag-pretty" title="' + (c.ctype === 2 ? '群靓号' : CC.T('pretty','靓号')) + '">靓 ' + esc(c.pretty) + '</span>';
      if (c.vip_level > 0 && c.ctype === 1) tags += CC.vipTag(c.vip_level);
      if (c.is_bot) tags += '<span class="tag-official">官方</span>';
      return '<div class="conv-item ' + (c.pinned ? 'pinned' : '') + '" data-key="' + c.ctype + ':' + c.peer + '">' +
        '<span class="pinned-tag"></span>' +
        CC.avatarHtml({ avatar: c.avatar, nickname: c.name }) +
        '<div class="conv-main">' +
          '<div class="conv-top"><span class="conv-name">' + esc(c.name) +
            (c.ctype === 2 ? '<span style="font-size:11px;color:#9AA0AC;font-weight:400;margin-left:5px">(' + (c.members || 0) + ')</span>' : '') +
            tags +
            (c.muted ? '<span style="font-size:11px;color:#9AA0AC;margin-left:4px">🔕</span>' : '') +
          '</span><span class="conv-time">' + CC.fmtTime(c.last_time) + '</span></div>' +
          '<div class="conv-bottom"><span class="conv-msg">' + esc(c.last_msg || '') + '</span>' + badge + '</div>' +
        '</div></div>';
    }).join('');
    box.querySelectorAll('.conv-item').forEach(function (el) {
      var key = el.getAttribute('data-key');
      el.onclick = function () {
        var p = key.split(':');
        var c = S.convs.find(function (x) { return x.ctype == p[0] && x.peer == p[1]; });
        if (c) openChat(c.ctype, c.peer, c);
      };
      CC.longPress(el, function () {
        var p = key.split(':');
        var c = S.convs.find(function (x) { return x.ctype == p[0] && x.peer == p[1]; });
        convMenu(c);
      });
    });
  }

  function convMenu(c) {
    if (!c) return;
    var sh = CC.sheet(c.name, '');
    sh.el.querySelector('.sheet-body').innerHTML =
      '<div class="sheet-item" data-a="pin">' + (c.pinned ? '取消置顶' : '置顶聊天') + '</div>' +
      '<div class="sheet-item" data-a="mute">' + (c.muted ? '取消免打扰' : '消息免打扰') + '</div>' +
      '<div class="sheet-item danger" data-a="del">删除会话</div>';
    sh.el.querySelectorAll('.sheet-item').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        sh.close();
        if (a === 'pin') CC.api('conv_pin', { ctype: c.ctype, peer: c.peer, pinned: c.pinned ? 0 : 1 }).then(loadConvs);
        if (a === 'mute') CC.api('conv_mute', { ctype: c.ctype, peer: c.peer, muted: c.muted ? 0 : 1 }).then(loadConvs);
        if (a === 'del') CC.confirm({ title: '删除会话', text: '删除后聊天记录仍会保留' }).then(function (okv) {
          if (okv) CC.api('conv_delete', { ctype: c.ctype, peer: c.peer }).then(loadConvs);
        });
      };
    });
  }

  /* =========================================================
   * 打开聊天
   * ========================================================= */
  /** 名称后的身份标识：靓号 → 会员 → 官方 */
  function nameTags(d) {
    if (!d) return '';
    var h = '';
    if (d.pretty) h += '<span class="tag-pretty" title="靓号">靓 ' + esc(d.pretty) + '</span>';
    if (d.ctype === 1 && parseInt(d.vip_level, 10) > 0) h += CC.vipTag(d.vip_level);
    if (d.is_bot) h += '<span class="tag-official">官方</span>';
    return h;
  }

  function openChat(ctype, peer, info) {
    ctype = parseInt(ctype, 10); peer = parseInt(peer, 10);
    info = info || {};
    S.cur = { ctype: ctype, peer: peer, name: info.name || '', avatar: info.avatar || '', extra: info };
    S.curRole = ctype === 2 ? parseInt(info.role || 0, 10) || 0 : 0;
    $('listPage').style.display = 'none';
    $('chatPage').style.display = 'flex';
    $('chatName').innerHTML = CC.esc(S.cur.name || '聊天') + nameTags(info);
    $('chatSub').textContent = ctype === 2 ? ((info.members || '') ? info.members + ' 人' : '群聊') : (info.online ? '在线' : '');
    $('chatBody').innerHTML = '<div class="loading"><span class="spin"></span></div>';
    history.replaceState(null, '', 'index.php?' + (ctype === 1 ? 'to=' + peer : 'gid=' + peer));
    loadMsgs(true);
    convClearUnread(ctype, peer);
    // 群聊：加载置顶消息
    if (ctype === 2 && typeof loadPinned === 'function') { loadPinned(); } else { hidePinned(); }
    setTimeout(function () { var i = $('msgInput'); if (i) i.focus(); }, 180);
    // 头像/名称/在线状态补齐（新会话、分享卡片进入时 info 可能为空）
    CC.ajax('peer_info', { ctype: ctype, peer: peer }, { silent: true }).then(function (r) {
      if (!r || r.code !== 0 || !S.cur) return;
      var d = r.data;
      S.cur.name = d.name; S.cur.avatar = d.avatar; S.cur.extra = d;
      if (ctype === 2) S.curRole = parseInt(d.role || 0, 10) || 0;
      $('chatName').innerHTML = CC.esc(d.name) + nameTags(d);
      $('chatSub').textContent = ctype === 2 ? ((d.show_gid ? '群号 ' + d.show_gid + ' · ' : '') + d.members + ' 人') : (d.online ? '在线' : '离线');
    });
  }

  function closeChat() {
    S.cur = null;
    $('chatPage').style.display = 'none';
    $('listPage').style.display = 'flex';
    history.replaceState(null, '', 'index.php');
    loadConvs();
  }

  function convClearUnread(ctype, peer) {
    CC.ajax('mark_read', { ctype: ctype, peer: peer });
    var c = S.convs.find(function (x) { return x.ctype == ctype && x.peer == peer; });
    if (c) { c.unread = 0; renderConvs(); updateBadge(); }
  }

  /* =========================================================
   * 消息加载 / 渲染
   * ========================================================= */
  function loadMsgs(reset) {
    if (!S.cur) return;
    var params = { ctype: S.cur.ctype, peer: S.cur.peer, limit: 30 };
    if (!reset) {
      var first = $('chatBody').querySelector('.msg-row');
      if (first && first.dataset.id) params.before_id = first.dataset.id;
    }
    return CC.ajax('msg_list', params).then(function (res) {
      if (res.code !== 0) { CC.toast(res.msg || '加载失败'); return; }
      var list = res.data.list || [];
      var body = $('chatBody');
      if (reset) {
        body.innerHTML = '';
        S.msgMap = {};
        if (!list.length) body.innerHTML = '<div class="empty" style="padding:40px 0;font-size:12px">还没有消息，打个招呼吧</div>';
      }
      var html = '';
      var lastTime = 0;
      var existing = reset ? body.querySelectorAll('.msg-row') : null;
      if (!reset && existing && existing.length) {
        lastTime = parseInt(existing[existing.length - 1].dataset.t || 0, 10);
      }
      var frag = d.createDocumentFragment();
      var temp = d.createElement('div');
      temp.innerHTML = list.map(function (m) {
        if (m.created_at - lastTime > 300) {
          lastTime = m.created_at;
          return '<div class="time-divider">' + CC.fmtChatTime(m.created_at) + '</div>' + renderMsg(m);
        }
        lastTime = Math.max(lastTime, m.created_at);
        return renderMsg(m);
      }).join('');
      while (temp.firstChild) frag.appendChild(temp.firstChild);
      if (reset) {
        body.innerHTML = '';
        if (!list.length) {
          body.innerHTML = '<div class="empty" style="padding:40px 0;font-size:12px">还没有消息，打个招呼吧</div>';
          return;
        }
      }
      if (reset) body.appendChild(frag);
      else body.insertBefore(frag, body.firstChild);
      list.forEach(function (m) { S.msgMap[m.id] = m; });
      if (!S.lastId) S.lastId = list.length ? list[list.length - 1].id : 0;
      if (reset) setTimeout(function () { body.scrollTop = body.scrollHeight; }, 30);
      bindMsgEvents();
    });
  }

  function renderMsg(m) {
    if (m.type === 20) return '<div class="system-msg">' + esc(m.content) + '</div>';
    if (m.type === 11) return '<div class="system-msg">' + esc(m.content) + '</div>';
    var me = !!m.mine;
    var sender = m.sender || {};
    var inner = renderContent(m);
    var nameLine = '';
    if (!me && S.cur && S.cur.ctype === 2) {
      nameLine = '<div class="msg-name">' + esc(m.group_nick || sender.nickname || '') + '</div>';
    }
    return '<div class="msg-row ' + (me ? 'me' : '') + '" data-id="' + m.id + '" data-t="' + m.created_at + '" data-type="' + m.type + '">' +
      '<span class="msg-av">' + CC.avatarHtml({ avatar: sender.avatar, nickname: sender.nickname }) + '</span>' +
      '<div class="msg-content">' + nameLine + '<div class="bubble-wrap">' + inner + '</div></div></div>';
  }

  function bubble(html, cls) {
    return '<div class="bubble ' + (cls || '') + '">' + html + '</div>';
  }

  function parseJson(s) {
    if (!s) return {};
    if (typeof s === 'object') return s;
    try { return JSON.parse(s) || {}; } catch (e) { return {}; }
  }

  function renderContent(m) {
    var type = parseInt(m.type, 10);
    var c = m.content || '';
    var ex = m.extra || {};
    switch (type) {
      case 1:
        return bubble(linkify(esc(c)));
      case 30: {
        // 图文消息：文字在上，图片在下（多图九宫格）
        var rj = parseJson(c);
        var rtext = String(rj.text || '').trim();
        var rimgs = (rj.images || []).filter(function (u) { return !!u; }).slice(0, 9);
        var h = '';
        if (rtext) h += '<div class="rich-text">' + linkify(esc(rtext)) + '</div>';
        if (rimgs.length) {
          var cls = rimgs.length === 1 ? 'n1' : (rimgs.length === 2 ? 'n2' : 'n3');
          h += '<div class="rich-imgs ' + cls + '">' + rimgs.map(function (u) {
            return '<img src="' + esc(u) + '" data-preview="' + esc(u) + '" loading="lazy" alt="">';
          }).join('') + '</div>';
        }
        if (!h) h = '<div class="rich-text" style="color:var(--t3)">[图文消息]</div>';
        return '<div class="bubble rich">' + h + '</div>';
      }
      case 5: {
        var j = parseJson(c);
        var url = j.url || c;
        var w = j.w || 220, h = j.h || 0;
        return '<div class="bubble media"><img src="' + esc(url) + '" data-preview="' + esc(url) + '" ' +
          (h ? 'style="width:' + Math.min(220, w) + 'px;height:auto"' : '') + ' loading="lazy" alt=""></div>';
      }
      case 6: {
        var v = parseJson(c);
        var dur = parseInt(v.duration || v.dur || 0, 10);
        return '<div class="bubble voice" data-voice="' + esc(v.url || c) + '">' +
          '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>' +
          '<span class="v-wave">' + (dur ? dur + '″' : '语音') + '</span></div>';
      }
      case 7: case 21: {
        var rp = parseJson(c);
        return '<div class="redpacket" data-rp="' + (rp.pid || 0) + '">' +
          '<div class="rp-title">🧧 ' + esc(rp.blessing || '恭喜发财，大吉大利') + '</div>' +
          '<div class="rp-sub">' + (parseInt(rp.rp_type, 10) === 2 ? '拼手气红包' : '普通红包') + ' · ' + (rp.count || 1) + ' 个 · ' + (rp.coin || 0) + ' ' + CC.T('coin','CC币') + '</div></div>';
      }
      case 8: case 22: {
        var tr = parseJson(c);
        return '<div class="transfer" data-transfer=\'' + esc(JSON.stringify(tr)) + '\'>' +
          '<div class="rp-title">💸 转账 ' + (tr.coin || 0) + ' ' + CC.T('coin','CC币') + '</div>' +
          '<div class="rp-sub">' + esc(tr.note || '转账') + '</div></div>';
      }
      case 9: case 23: {
        var g = parseJson(c);
        return bubble('<div style="text-align:center;min-width:110px"><div style="font-size:40px;line-height:1.1">' +
          esc(g.icon || '🎁') + '</div><div style="font-size:13px;font-weight:600;margin-top:4px">' + esc(g.name || '礼物') +
          ' x' + (g.count || 1) + '</div><div style="font-size:11px;opacity:.75">' + (g.coin || 0) + ' ' + CC.T('coin','CC币') + '</div></div>', 'card');
      }
      case 12: {
        var card = parseJson(c);
        return '<div class="bubble card" data-card-uid="' + (card.uid || card.id || 0) + '">' +
          '<div class="card-row">' + CC.avatarHtml({ avatar: card.avatar, nickname: card.nickname }) +
          '<div><div class="card-title">' + esc(card.nickname || '用户名片') + '</div>' +
          '<div class="card-sub">' + CC.T('id','CC号') + '：' + esc(card.yx_id || '') + '</div></div></div>' +
          '<div class="card-foot">个人名片</div></div>';
      }
      case 13: {
        var gc = parseJson(c);
        return '<div class="bubble card" data-card-gid="' + (gc.gid || 0) + '">' +
          '<div class="card-row">' + CC.avatarHtml({ avatar: gc.avatar, nickname: gc.name }) +
          '<div><div class="card-title">' + esc(gc.name || '群聊') + '</div>' +
          '<div class="card-sub">群号：' + esc(gc.gid || '') + ' · ' + (gc.members || 0) + ' 人</div></div></div>' +
          '<div class="card-foot">群聊名片</div></div>';
      }
      case 14: {
        var call = parseJson(c);
        var icon = parseInt(call.media, 10) === 2 ? '📹' : '📞';
        return bubble('<div style="min-width:130px"><div style="font-size:13px">' + icon + ' ' + esc(call.label || '通话') + '</div>' +
          '<div style="font-size:11px;opacity:.7;margin-top:3px">' + esc(callStateText(call.state)) + '</div></div>');
      }
      case 15: {
        var vd = parseJson(c);
        var vurl = vd.url || c;
        return '<div class="bubble media"><video src="' + esc(vurl) + '" controls preload="metadata" playsinline style="max-width:220px;border-radius:10px"></video></div>';
      }
      case 16: {
        var mo = parseJson(c);
        var imgs = mo.images || [];
        return '<div class="bubble card" data-moment="' + (mo.mid || 0) + '">' +
          '<div class="card-title">' + esc(mo.text || '分享了一条动态') + '</div>' +
          (imgs.length ? '<div class="moment-imgs" style="grid-template-columns:repeat(3,1fr)">' + imgs.slice(0, 3).map(function (u) {
            return '<img src="' + esc(u) + '" alt="">';
          }).join('') + '</div>' : '') +
          '<div class="card-foot">朋友圈动态</div></div>';
      }
      case 17: {
        var cl = parseJson(c);
        var items = cl.items || [];
        var lines = items.slice(0, 3).map(function (it) {
          return '<div class="card-sub">' + esc(it.u || '') + '：' + esc(msgText(it)) + '</div>';
        }).join('');
        return '<div class="bubble card" data-chatlog=\'' + esc(JSON.stringify(cl)) + '\'>' +
          '<div class="card-title">' + esc(cl.title || '聊天记录') + '</div>' + lines +
          '<div class="card-foot">聊天记录</div></div>';
      }
      case 18: {
        var f = parseJson(c);
        return '<div class="bubble card" data-file="' + esc(f.url || '') + '" data-name="' + esc(f.name || '文件') + '">' +
          '<div class="card-row"><div style="font-size:30px">📄</div><div>' +
          '<div class="card-title" style="word-break:break-all">' + esc(f.name || '文件') + '</div>' +
          '<div class="card-sub">' + fmtSize(f.size || 0) + '</div></div></div>' +
          '<div class="card-foot">点击下载</div></div>';
      }
      case 19: {
        var lv = parseJson(c);
        return '<div class="bubble card" data-live="' + esc(lv.room_no || '') + '">' +
          '<div class="card-row"><div style="font-size:30px">📡</div><div>' +
          '<div class="card-title">' + esc(lv.title || '直播') + '</div>' +
          '<div class="card-sub">' + esc(lv.name || '') + ' 正在直播</div></div></div>' +
          '<div class="card-foot">点击进入直播间</div></div>';
      }
      default:
        return bubble(esc(c));
    }
  }

  function callStateText(s) {
    return ({ calling: '正在呼叫…', group_calling: '群通话邀请', answered: '已接通', rejected: '已拒绝', ended: '已结束', missed: '未接听' })[s] || '';
  }
  function msgText(it) {
    var t = parseInt(it && it.ty, 10) || 1;
    var map = { 5: '[图片]', 6: '[语音]', 7: '[红包]', 8: '[转账]', 9: '[礼物]', 12: '[名片]', 13: '[群名片]', 14: '[通话]', 15: '[视频]', 16: '[动态]', 17: '[聊天记录]', 18: '[文件]', 19: '[直播]' };
    return map[t] || (it && it.c) || '';
  }
  function fmtSize(n) {
    n = parseInt(n, 10) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }
  function linkify(s) {
    return String(s).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline">$1</a>');
  }

  /* =========================================================
   * 消息交互
   * ========================================================= */
  function bindMsgEvents() {
    var body = $('chatBody');
    body.querySelectorAll('[data-preview]').forEach(function (img) {
      img.onclick = function () { CC.previewImage(img.getAttribute('data-preview')); };
    });
    body.querySelectorAll('[data-voice]').forEach(function (el) {
      el.onclick = function () {
        var a = new Audio(el.getAttribute('data-voice'));
        a.play().catch(function () { CC.toast('无法播放语音'); });
      };
    });
    body.querySelectorAll('[data-rp]').forEach(function (el) {
      el.onclick = function () { openRedPacket(parseInt(el.getAttribute('data-rp'), 10)); };
    });
    body.querySelectorAll('[data-transfer]').forEach(function (el) {
      el.onclick = function () {
        try { showTransfer(JSON.parse(el.getAttribute('data-transfer'))); } catch (e) { }
      };
    });
    body.querySelectorAll('[data-card-uid]').forEach(function (el) {
      el.onclick = function () { location.href = 'user.php?uid=' + el.getAttribute('data-card-uid'); };
    });
    body.querySelectorAll('[data-card-gid]').forEach(function (el) {
      el.onclick = function () { location.href = 'group_card.php?gid=' + el.getAttribute('data-card-gid'); };
    });
    body.querySelectorAll('[data-live]').forEach(function (el) {
      el.onclick = function () { location.href = 'live.php?room_no=' + el.getAttribute('data-live'); };
    });
    body.querySelectorAll('[data-file]').forEach(function (el) {
      el.onclick = function () {
        var a = d.createElement('a');
        a.href = el.getAttribute('data-file');
        a.download = el.getAttribute('data-name') || 'file';
        abody.appendChild(a); a.click(); a.remove();
      };
    });
    body.querySelectorAll('[data-chatlog]').forEach(function (el) {
      el.onclick = function () { showChatLog(el.getAttribute('data-chatlog')); };
    });
    body.querySelectorAll('.msg-row').forEach(function (row) {
      CC.longPress(row, function () {
        var id = parseInt(row.dataset.id, 10);
        if (id) msgMenu(id);
      });
      row.querySelector('.msg-av .avatar').onclick = function () {
        var m = S.msgMap[row.dataset.id];
        if (m && m.from_uid) location.href = 'user.php?uid=' + m.from_uid;
      };
    });
  }
  var abody = d.body;

  /* ---------- 群消息置顶（多条，可折叠） ---------- */
  S.pins = [];

  function hidePinned() {
    var wrap = $('pinnedBar');
    if (wrap) wrap.classList.add('hidden');
    var list = $('pinList');
    if (list) list.classList.add('hidden');
    S.pins = [];
  }

  function renderPins(data) {
    var wrap = $('pinnedBar');
    if (!wrap) return;
    var list = (data && data.list) || [];
    S.pins = list;
    if (!list.length) { hidePinned(); return; }

    var role = parseInt((data && data.role) || 0, 10);
    S.pinRole = role;

    // 摘要条
    var first = list[0];
    $('pinnedText').innerHTML = '<b>置顶' + (list.length > 1 ? '（' + list.length + '）' : '') + '</b>　' + esc(first.preview || '');
    wrap.classList.remove('hidden');

    // 折叠面板
    var box = $('pinList');
    if (box) {
      box.innerHTML = '<div class="pl-head">群置顶消息 · ' + list.length + ' 条<button class="pl-close" id="pinListClose">收起</button></div>'
        + list.map(function (p, i) {
          return '<div class="pl-item" data-jump="' + p.msg_id + '">'
            + '<div class="pl-idx">' + (i + 1) + '</div>'
            + '<div class="pl-main"><div class="pl-txt">' + esc(p.preview || '') + '</div>'
            + '<div class="pl-sub">' + esc(p.sender || '成员') + '</div></div>'
            + (role >= 1 ? '<button class="pl-del" data-unpin="' + p.msg_id + '" title="取消置顶">✕</button>' : '')
            + '</div>';
        }).join('');
      box.querySelectorAll('[data-jump]').forEach(function (el) {
        el.onclick = function (e) {
          if (e.target.closest('[data-unpin]')) return;
          jumpToPinned(parseInt(el.getAttribute('data-jump'), 10));
          box.classList.add('hidden');
        };
      });
      box.querySelectorAll('[data-unpin]').forEach(function (b) {
        b.onclick = function (e) {
          e.stopPropagation();
          var mid = parseInt(b.getAttribute('data-unpin'), 10);
          CC.api('group_pin_msg', { gid: S.cur.peer, msg_id: mid, act: 'unpin' }).then(function () {
            CC.toast('已取消置顶'); loadPinned();
          }).catch(function (err) { CC.toast(err.message); });
        };
      });
      var cb = box.querySelector('#pinListClose');
      if (cb) cb.onclick = function (e) { e.stopPropagation(); box.classList.add('hidden'); };
    }
  }

  function loadPinned() {
    if (!S.cur || S.cur.ctype !== 2) { hidePinned(); return; }
    CC.ajax('group_pinned', { gid: S.cur.peer }, { silent: true }).then(function (res) {
      if (!S.cur || S.cur.ctype !== 2) return;
      if (res && res.code === 0) renderPins(res.data || {});
      else hidePinned();
    }).catch(function () {});
  }

  /** 点击置顶：滚动到指定消息；未加载则向前翻页查找 */
  function jumpToPinned(mid) {
    mid = parseInt(mid, 10) || 0;
    if (!mid) return;
    var row = $('chatBody').querySelector('.msg-row[data-id="' + mid + '"]');
    if (row) { scrollToRow(row); return; }
    var times = 0;
    (function again() {
      if (times++ >= 3) { CC.toast('消息较久远，请向上翻页查看'); return; }
      var first = $('chatBody').querySelector('.msg-row[data-id]');
      var before = first ? parseInt(first.getAttribute('data-id'), 10) : 0;
      if (!before) return;
      CC.ajax('msg_list', { ctype: 2, peer: S.cur.peer, before_id: before, limit: 50 }).then(function (res) {
        if (!res || res.code !== 0) return;
        if (!((res.data && res.data.list) || []).length) { CC.toast('已到达最早消息'); return; }
        loadMsgs(true);
        setTimeout(function () {
          var r2 = $('chatBody').querySelector('.msg-row[data-id="' + mid + '"]');
          if (r2) scrollToRow(r2); else again();
        }, 260);
      }).catch(function () {});
    })();
  }

  function scrollToRow(row) {
    var body = $('chatBody');
    var top = row.offsetTop - body.clientHeight / 2 + row.offsetHeight / 2;
    body.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
    row.classList.add('msg-flash');
    setTimeout(function () { row.classList.remove('msg-flash'); }, 1600);
  }

  /* 置顶条交互：点摘要展开/收起列表 */
  (function bindPinnedBar() {
    var bar = $('pinnedBar');
    if (!bar || bar._bound) return;
    bar._bound = true;
    bar.onclick = function (e) {
      if (e.target.closest('#pinnedUnpin')) return;
      var box = $('pinList');
      if (!box) return;
      if (S.pins.length > 1) {
        box.classList.toggle('hidden');
      } else {
        jumpToPinned(S.pins.length ? S.pins[0].msg_id : 0);
      }
    };
    var btn = $('pinnedUnpin');
    if (btn) btn.onclick = function (e) {
      e.stopPropagation();
      if (parseInt(S.pinRole || 0, 10) < 1) return;
      CC.confirm({ title: '清空置顶', text: '确定移除本群全部置顶消息？', danger: true }).then(function (yes) {
        if (!yes) return;
        CC.api('group_pin_msg', { gid: S.cur.peer, act: 'clear' }).then(function () {
          CC.toast('已清空置顶'); hidePinned();
        }).catch(function (err) { CC.toast(err.message); });
      });
    };
  })();

  function msgMenu(id) {
    var m = S.msgMap[id];
    if (!m) return;
    var sh = CC.sheet('消息操作', '');
    var items = [];
    if (m.type === 1) items.push(['copy', '复制']);
    items.push(['forward', '转发']);
    items.push(['fav', '收藏']);
    if (m.type === 1) items.push(['quote', '引用']);
    // 群主/管理员才能置顶（角色来自 conv_list / peer_info 的 role 字段）
    if (S.cur && S.cur.ctype === 2 && parseInt(S.curRole || 0, 10) >= 1) {
      var pinnedIds = (S.pins || []).map(function (p) { return parseInt(p.msg_id, 10); });
      var thisId = parseInt(id, 10);
      if (pinnedIds.indexOf(thisId) >= 0) items.push(['unpin', '取消置顶']);
      else items.push(['pin', '置顶消息']);
    }
    if (m.mine) {
      if (m.type !== 20 && Date.now() / 1000 - m.created_at < 120) items.push(['recall', '撤回']);
      items.push(['del', '删除']);
    }
    items.push(['report', '举报']);
    sh.el.querySelector('.sheet-body').innerHTML = items.map(function (it) {
      return '<div class="sheet-item ' + (it[0] === 'del' || it[0] === 'report' ? 'danger' : '') + '" data-a="' + it[0] + '">' + it[1] + '</div>';
    }).join('');
    sh.el.querySelectorAll('.sheet-item').forEach(function (el) {
      el.onclick = function () {
        var a = el.getAttribute('data-a');
        sh.close();
        if (a === 'copy') { copyText(m.content); }
        if (a === 'fav') CC.api('favorite_add', { mtype: m.type, content: m.content }).then(function () { CC.toast('已收藏'); });
        if (a === 'quote') { $('msgInput').value = '「' + m.sender.nickname + '：' + msgText({ ty: m.type, c: m.content }) + '」\n'; $('msgInput').focus(); }
        if (a === 'forward') { pickForward([m.id]); }
        if (a === 'recall') {
          CC.api('recall', { id: id }).then(function (d) {
            removeMsg(id);
            if (d && d.sys) appendLocal(d.sys);
          }).catch(function (e) { CC.toast(e.message); });
        }
        if (a === 'del') { CC.api('delete_msg', { id: id }).then(function () { removeMsg(id); }); }
        if (a === 'pin') {
          CC.api('group_pin_msg', { gid: S.cur.peer, msg_id: id, act: 'pin' }).then(function () {
            CC.toast('已置顶'); loadPinned();
          }).catch(function (e) { CC.toast(e.message); });
        }
        if (a === 'unpin') {
          CC.api('group_pin_msg', { gid: S.cur.peer, msg_id: id, act: 'unpin' }).then(function () {
            CC.toast('已取消置顶'); loadPinned();
          }).catch(function (e) { CC.toast(e.message); });
        }
        if (a === 'report') { reportDialog(id); }
      };
    });
  }

  function copyText(t) {
    if (navigator.clipboard) navigator.clipboard.writeText(t).then(function () { CC.toast('已复制'); });
    else {
      var ta = d.createElement('textarea'); ta.value = t; d.body.appendChild(ta); ta.select();
      d.execCommand('copy'); ta.remove(); CC.toast('已复制');
    }
  }
  function refreshMsg(id) {
    var row = $('chatBody').querySelector('.msg-row[data-id="' + id + '"]');
    if (!row) return;
    var m = S.msgMap[id];
    if (m) { m.type = 20; m.content = (m.mine ? '你' : m.sender.nickname) + ' 撤回了一条消息'; }
    row.outerHTML = '<div class="system-msg">' + esc((m && m.mine ? '你' : (m ? m.sender.nickname : '')) + ' 撤回了一条消息') + '</div>';
  }
  function removeMsg(id) {
    var row = $('chatBody').querySelector('.msg-row[data-id="' + id + '"]');
    if (row) row.remove();
  }

  /* =========================================================
   * 发送
   * ========================================================= */
  function sendPayload(type, content, extra) {
    if (!S.cur) return Promise.reject(new Error('未打开会话'));
    return CC.ajax('send', {
      ctype: S.cur.ctype, to: S.cur.peer, type: type,
      content: typeof content === 'string' ? content : JSON.stringify(content),
      extra: extra ? JSON.stringify(extra) : ''
    }).then(function (res) {
      if (res.code !== 0) { CC.toast(res.msg || '发送失败'); throw new Error(res.msg); }
      appendLocal(res.data);
      return res.data;
    });
  }

  function appendLocal(m) {
    if (!S.cur) return;
    if (!m || !m.id) return;
    if (S.msgMap[m.id]) return;          // 去重：轮询与发送响应可能同时带回同一条
    var body = $('chatBody');
    var empty = body.querySelector('.empty');
    if (empty) empty.remove();
    var t = d.createElement('div');
    t.innerHTML = renderMsg(m);
    var node = t.firstChild;
    body.appendChild(node);
    S.msgMap[m.id] = m;
    S.lastId = Math.max(S.lastId, m.id);
    body.scrollTop = body.scrollHeight;
    bindMsgEvents();
  }

  function sendText() {
    // 有暂存图片时走图文合并逻辑
    sendRich();
  }

  function autoGrow() {
    var i = $('msgInput');
    i.style.height = 'auto';
    i.style.height = Math.min(110, i.scrollHeight) + 'px';
    $('btnSend').disabled = i.value.trim() === '';
  }

  /* =========================================================
   * 上传
   * ========================================================= */
  function pickImage() { $('filePickImage').click(); }

  /* ---------- 图文消息：选图后暂存，随文字一起发送 ---------- */
  S.staged = [];   // [{url,w,h}]

  function renderStaged() {
    var box = $('stagedImgs');
    if (!box) return;
    if (!S.staged.length) { box.classList.add('hidden'); box.innerHTML = ''; refreshSendBtn(); return; }
    box.classList.remove('hidden');
    box.innerHTML = S.staged.map(function (it, i) {
      return '<div class="si"><img src="' + esc(it.url) + '" alt="">'
        + '<button class="del" data-si="' + i + '">✕</button></div>';
    }).join('');
    box.querySelectorAll('[data-si]').forEach(function (b) {
      b.onclick = function (e) {
        e.stopPropagation();
        S.staged.splice(parseInt(b.getAttribute('data-si'), 10), 1);
        renderStaged();
      };
    });
    refreshSendBtn();
  }

  function refreshSendBtn() {
    var btn = $('btnSend');
    var input = $('msgInput');
    if (!btn || !input) return;
    btn.disabled = !input.value.trim() && !S.staged.length;
  }

  function stageImages(files) {
    files = Array.prototype.slice.call(files || []);
    if (!files.length) return;
    var room = 9 - S.staged.length;
    if (room <= 0) { CC.toast('最多 9 张图片'); return; }
    files = files.slice(0, room);
    var done = 0;
    files.forEach(function (f) {
      var holder = null;
      CC.upload('upload_image', f).then(function (d) {
        S.staged.push({ url: d.url, w: d.w || 0, h: d.h || 0 });
        renderStaged();
      }).catch(function (e) {
        CC.toast(e.message || '上传失败');
      }).then(function () {
        done++;
        if (done === files.length) CC.toast('已添加 ' + files.length + ' 张图片');
      });
    });
  }

  /** 图文合并发送：有图则发 type=30（文字可选），无图则发文字 */
  function sendRich() {
    var input = $('msgInput');
    var text = input.value.trim();
    var imgs = S.staged.slice();
    if (!text && !imgs.length) return;

    input.value = ''; autoGrow();
    S.staged = []; renderStaged();
    $('btnSend').disabled = true;

    if (!imgs.length) { sendPayload(1, text).catch(function () {}); return; }

    var payload = JSON.stringify({
      text: text,
      images: imgs.map(function (x) { return x.url; })
    });
    sendPayload(30, payload).catch(function () {});
  }
  function doUploadVideo(file) {
    CC.toast('视频上传中…');
    CC.upload('upload_video', file).then(function (data) {
      sendPayload(15, JSON.stringify({ url: data.url, size: data.size }));
    }).catch(function (e) { CC.toast(e.message); });
  }
  function doUploadFile(file) {
    CC.toast('文件上传中…');
    CC.upload('upload_file', file, { name: file.name }).then(function (data) {
      sendPayload(18, JSON.stringify({ url: data.url, name: data.name || file.name, size: data.size }));
    }).catch(function (e) { CC.toast(e.message); });
  }

  /* ---------- 语音 ---------- */
  function startRecord(e) {
    if (e) e.preventDefault();
    if (S.recording) return;
    if (!navigator.mediaDevices || !w.MediaRecorder) { CC.toast('当前浏览器不支持录音'); return; }
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      S.chunks = [];
      var mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : '';
      S.recorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      S.recStart = Date.now();
      S.recording = true;
      $('holdBtn').classList.add('recording');
      $('holdBtn').textContent = '松开发送 0″';
      S.recTimer = setInterval(function () {
        $('holdBtn').textContent = '松开发送 ' + Math.floor((Date.now() - S.recStart) / 1000) + '″';
      }, 300);
      S.recorder.ondataavailable = function (ev) { if (ev.data && ev.data.size) S.chunks.push(ev.data); };
      S.recorder.onstop = function () {
        clearInterval(S.recTimer);
        stream.getTracks().forEach(function (t) { t.stop(); });
        var dur = Math.max(1, Math.round((Date.now() - S.recStart) / 1000));
        S.recording = false;
        $('holdBtn').classList.remove('recording');
        $('holdBtn').textContent = '按住 说话';
        if (S.cancelled) { S.cancelled = false; return; }
        if (!S.chunks.length) return;
        var blob = new Blob(S.chunks, { type: 'audio/webm' });
        var file = new File([blob], 'voice_' + Date.now() + '.webm', { type: 'audio/webm' });
        CC.toast('语音上传中…');
        CC.upload('upload_voice', file, { duration: dur }).then(function (data) {
          sendPayload(6, JSON.stringify({ url: data.url, duration: dur }));
        }).catch(function (e) { CC.toast(e.message); });
      };
      S.recorder.start();
    }).catch(function () { CC.toast('无法访问麦克风'); });
  }
  function stopRecord(cancel) {
    if (!S.recording || !S.recorder) return;
    S.cancelled = !!cancel;
    try { S.recorder.stop(); } catch (e) { }
  }

  /* =========================================================
   * 红包 / 转账 / 礼物 / 名片
   * ========================================================= */
  function openRedPacket(pid) {
    if (!pid) return;
    CC.api('redpacket_info', { pid: pid }).then(function (info) {
      if (info.opened) {
        CC.confirm({
          title: '红包详情', ok: '知道了', cancel: '关闭',
          html: '<p>' + esc(info.from.nickname) + ' 的红包</p><p style="font-size:22px;color:#F5642E;font-weight:700">' + info.my_coin + ' ' + CC.T('coin','CC币') + '</p><p>' + esc(info.blessing) + '</p>'
        });
        return;
      }
      CC.confirm({ title: '🧧 ' + info.from.nickname + ' 的红包', text: info.blessing + '\n' + (info.rp_type === 2 ? '拼手气红包' : '普通红包') + ' · ' + info.count + ' 个' }).then(function (okv) {
        if (!okv) return;
        CC.api('redpacket_open', { pid: pid }).then(function (r) {
          CC.confirm({ title: '领取成功', ok: '收下', cancel: '关闭', html: '<p style="font-size:24px;color:#F5642E;font-weight:700">' + r.coin + ' ' + CC.T('coin','CC币') + '</p><p>已存入你的 ' + CC.T('coin','CC币') + '钱包</p>' });
        }).catch(function (e) { CC.toast(e.message); });
      });
    }).catch(function (e) { CC.toast(e.message); });
  }

  function showTransfer(t) {
    CC.confirm({ title: '💸 转账', ok: '知道了', cancel: '关闭', html: '<p style="font-size:26px;color:#FF8A00;font-weight:700">' + (t.coin || 0) + ' ' + CC.T('coin','CC币') + '</p><p>' + esc(t.note || '') + '</p>' });
  }

  function createRedPacket() {
    var isGroup = S.cur && S.cur.ctype === 2;
    var html = '<div class="field-row" style="padding-left:0;padding-right:0"><label>金额</label><input id="rpCoin" type="number" inputmode="numeric" placeholder="' + CC.T('coin','CC币') + '"></div>' +
      (isGroup ? '<div class="field-row" style="padding-left:0;padding-right:0"><label>个数</label><input id="rpCount" type="number" inputmode="numeric" value="1"></div>' +
        '<div class="field-row" style="padding-left:0;padding-right:0"><label>类型</label><select id="rpType" style="flex:1;text-align:right;background:none;border:0;color:inherit"><option value="1">普通红包</option><option value="2">拼手气红包</option></select></div>' : '') +
      '<div class="field-row" style="padding-left:0;padding-right:0"><label>祝福语</label><input id="rpBless" type="text" value="恭喜发财，大吉大利" maxlength="30"></div>' +
      '<div class="field-row" style="padding-left:0;padding-right:0"><label>支付密码</label><input id="rpPwd" type="password" maxlength="6" inputmode="numeric" placeholder="6 位数字"></div>' +
      '<button class="btn mt12" id="rpGo">塞钱进红包</button>';
    var sh = CC.sheet('发红包', html);
    sh.el.querySelector('#rpGo').onclick = function () {
      var coin = parseInt(sh.el.querySelector('#rpCoin').value, 10) || 0;
      var count = isGroup ? (parseInt(sh.el.querySelector('#rpCount').value, 10) || 1) : 1;
      var rpType = isGroup ? parseInt(sh.el.querySelector('#rpType').value, 10) : 1;
      var bless = sh.el.querySelector('#rpBless').value.trim();
      var pwd = sh.el.querySelector('#rpPwd').value;
      if (coin <= 0) { CC.toast('请输入金额'); return; }
      CC.api('redpacket_create', {
        ctype: S.cur.ctype, to: S.cur.peer, coin: coin, count: count, rp_type: rpType, blessing: bless, pay_password: pwd
      }).then(function (m) { sh.close(); appendLocal(m); }).catch(function (e) { CC.toast(e.message); });
    };
  }

  function createTransfer() {
    var html = '<div class="field-row" style="padding-left:0;padding-right:0"><label>金额</label><input id="tfCoin" type="number" inputmode="numeric" placeholder="' + CC.T('coin','CC币') + '"></div>' +
      '<div class="field-row" style="padding-left:0;padding-right:0"><label>备注</label><input id="tfNote" type="text" maxlength="30" placeholder="选填"></div>' +
      '<div class="field-row" style="padding-left:0;padding-right:0"><label>支付密码</label><input id="tfPwd" type="password" maxlength="6" inputmode="numeric" placeholder="6 位数字"></div>' +
      '<button class="btn mt12" id="tfGo">确认转账</button>';
    var sh = CC.sheet('转账', html);
    sh.el.querySelector('#tfGo').onclick = function () {
      var coin = parseInt(sh.el.querySelector('#tfCoin').value, 10) || 0;
      if (coin <= 0) { CC.toast('请输入金额'); return; }
      CC.api('transfer_create', { to: S.cur.peer, coin: coin, note: sh.el.querySelector('#tfNote').value.trim(), pay_password: sh.el.querySelector('#tfPwd').value })
        .then(function () { sh.close(); loadMsgs(true); }).catch(function (e) { CC.toast(e.message); });
    };
  }

  function showGifts() {
    CC.api('gift_list', {}).then(function (data) {
      var list = data.list || [];
      var html = '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">' +
        list.map(function (g, i) {
          return '<div class="gift-cell" data-i="' + i + '" style="text-align:center;padding:8px 2px;border-radius:10px;background:var(--bg);cursor:pointer">' +
            '<div style="font-size:28px">' + esc(g.icon) + '</div><div style="font-size:11.5px;margin-top:2px">' + esc(g.name) + '</div>' +
            '<div style="font-size:10.5px;color:#F5A623">' + g.price + ' ' + CC.T('coin','CC币') + '</div></div>';
        }).join('') + '</div>' +
        '<div class="field-row mt12" style="padding-left:0;padding-right:0"><label>数量</label><input id="giftCount" type="number" value="1" min="1" style="text-align:right"></div>' +
        '<div class="field-row" style="padding-left:0;padding-right:0"><label>支付密码</label><input id="giftPwd" type="password" maxlength="6" inputmode="numeric"></div>' +
        '<button class="btn mt12" id="giftGo" disabled>赠送</button>';
      var sh = CC.sheet('送礼物', html);
      var picked = null;
      sh.el.querySelectorAll('.gift-cell').forEach(function (cell) {
        cell.onclick = function () {
          sh.el.querySelectorAll('.gift-cell').forEach(function (c) { c.style.outline = ''; });
          cell.style.outline = '2px solid var(--brand)';
          picked = list[parseInt(cell.getAttribute('data-i'), 10)];
          sh.el.querySelector('#giftGo').disabled = false;
        };
      });
      sh.el.querySelector('#giftGo').onclick = function () {
        if (!picked) return;
        CC.api('gift_send', {
          gift_id: picked.id, count: parseInt(sh.el.querySelector('#giftCount').value, 10) || 1,
          ctype: S.cur.ctype, to: S.cur.peer, pay_password: sh.el.querySelector('#giftPwd').value
        }).then(function (m) { sh.close(); appendLocal(m); }).catch(function (e) { CC.toast(e.message); });
      };
    }).catch(function (e) { CC.toast(e.message); });
  }

  function shareCard() {
    CC.api('share_targets', {}).then(function (data) {
      var friends = data.friends || [];
      var html = '<div class="picker-list">' + friends.map(function (f) {
        return '<div class="picker-item" data-uid="' + f.id + '">' + CC.avatarHtml(f, 'sm') +
          '<div class="flex1"><div>' + esc(f.name) + '</div><div class="t3 small">CC号 ' + esc(f.yx_id) + '</div></div></div>';
      }).join('') + '</div>';
      var sh = CC.sheet('选择名片', html);
      sh.el.querySelectorAll('.picker-item').forEach(function (it) {
        it.onclick = function () {
          var uid = it.getAttribute('data-uid');
          var f = friends.find(function (x) { return String(x.id) === uid; });
          sh.close();
          sendPayload(12, JSON.stringify({ uid: f.id, nickname: f.name, avatar: f.avatar, yx_id: f.yx_id }));
        };
      });
    });
  }

  /* =========================================================
   * 转发
   * ========================================================= */
  function pickForward(ids) {
    CC.api('share_targets', {}).then(function (data) {
      var html = '<div class="picker-list"><div class="group-title" style="padding-left:0">好友</div>' +
        (data.friends || []).map(function (f) {
          return '<div class="picker-item fw" data-ctype="1" data-peer="' + f.id + '">' + CC.avatarHtml(f, 'sm') + '<div class="flex1">' + esc(f.name) + '</div></div>';
        }).join('') +
        '<div class="group-title" style="padding-left:0">群聊</div>' +
        (data.groups || []).map(function (g) {
          return '<div class="picker-item fw" data-ctype="2" data-peer="' + g.gid + '">' + CC.avatarHtml({ avatar: g.avatar, nickname: g.name }, 'sm') + '<div class="flex1">' + esc(g.name) + '</div></div>';
        }).join('') + '</div>';
      var sh = CC.sheet('转发给', html);
      sh.el.querySelectorAll('.fw').forEach(function (it) {
        it.onclick = function () {
          var ctype = parseInt(it.getAttribute('data-ctype'), 10);
          var peer = parseInt(it.getAttribute('data-peer'), 10);
          CC.api('forward', { ids: ids, targets: [{ ctype: ctype, peer: peer }] }).then(function (r) {
            sh.close(); CC.toast('已转发');
            if (S.cur && S.cur.ctype === ctype && S.cur.peer === peer) loadMsgs(true);
          }).catch(function (e) { CC.toast(e.message); });
        };
      });
    });
  }

  function showChatLog(jsonStr) {
    var j = {};
    try { j = JSON.parse(jsonStr); } catch (e) { }
    var items = j.items || [];
    var html = '<div style="max-height:60vh;overflow-y:auto">' + items.map(function (it) {
      return '<div style="padding:9px 0;border-bottom:1px solid var(--line)"><div class="t3 small">' + esc(it.u || '') + ' · ' + CC.fmtFull(it.t) + '</div>' +
        '<div style="margin-top:3px">' + esc(msgText(it)) + '</div></div>';
    }).join('') + '</div>';
    CC.sheet(j.title || '聊天记录', html);
  }

  /* =========================================================
   * 举报
   * ========================================================= */
  function reportDialog(mid) {
    var html = '<div class="field-row" style="padding-left:0"><label>原因</label><select id="rptReason" style="flex:1;text-align:right;background:none;border:0;color:inherit">' +
      ['垃圾广告', '色情低俗', '诈骗', '辱骂骚扰', '违法违规', '其他'].map(function (r) { return '<option>' + r + '</option>'; }).join('') + '</select></div>' +
      '<textarea id="rptDetail" placeholder="补充说明（选填）" maxlength="300" style="width:100%;min-height:80px;background:var(--bg);border-radius:10px;padding:10px;margin-top:8px"></textarea>' +
      '<button class="btn mt12" id="rptGo">提交举报</button>';
    var sh = CC.sheet('举报消息', html);
    sh.el.querySelector('#rptGo').onclick = function () {
      CC.api('report_submit', {
        target_type: 'message', target_id: mid,
        reason: sh.el.querySelector('#rptReason').value,
        detail: sh.el.querySelector('#rptDetail').value
      }).then(function () { sh.close(); CC.toast('举报已提交'); }).catch(function (e) { CC.toast(e.message); });
    };
  }

  /* =========================================================
   * 表情
   * ========================================================= */
  function loadEmojis() {
    CC.api('emoji_list', {}).then(function (data) {
      S.emojis = data;
      renderEmojis();
    }).catch(function () { });
  }
  function renderEmojis() {
    var p = $('emojiPanel');
    var html = '<div class="emoji-tabs"><button class="active" data-t="system">常用</button><button data-t="mine">我的表情</button>' +
      '<button id="emojiAdd" style="margin-left:auto">＋ 添加</button></div>';
    html += '<div class="emoji-grid" id="emojiGrid">' + (S.emojis.system || []).map(function (e) {
      return '<div class="emoji-cell" data-url="' + esc(e.url) + '" data-name="' + esc(e.name) + '">' + (e.url.indexOf('emoji:') === 0 ? e.url.slice(6) : '🙂') + '</div>';
    }).join('') + '</div>';
    p.innerHTML = html;
    p.querySelectorAll('.emoji-cell').forEach(function (c) {
      c.onclick = function () {
        var url = c.getAttribute('data-url');
        if (url.indexOf('emoji:') === 0) {
          $('msgInput').value += url.slice(6);
          autoGrow();
        } else {
          sendPayload(5, JSON.stringify({ url: url, w: 120, h: 120 }));
        }
      };
    });
    p.querySelectorAll('.emoji-tabs button[data-t]').forEach(function (b) {
      b.onclick = function () {
        p.querySelectorAll('.emoji-tabs button').forEach(function (x) { x.classList.remove('active'); });
        b.classList.add('active');
        var t = b.getAttribute('data-t');
        var list = t === 'mine' ? (S.emojis.mine || []) : (S.emojis.system || []);
        var grid = $('emojiGrid');
        if (t === 'mine') {
          grid.innerHTML = list.map(function (e) {
            return '<div class="emoji-cell" data-url="' + esc(e.url) + '" data-id="' + e.id + '"><img src="' + esc(e.url) + '" style="width:34px;height:34px;object-fit:cover;border-radius:6px"></div>';
          }).join('') + '<div class="emoji-cell" id="emojiAdd2" style="font-size:26px;color:#9AA0AC">＋</div>';
          grid.querySelectorAll('.emoji-cell[data-url]').forEach(function (c) {
            c.onclick = function () { sendPayload(5, JSON.stringify({ url: c.getAttribute('data-url'), w: 120, h: 120 })); };
          });
          var a2 = $('emojiAdd2');
          if (a2) a2.onclick = addEmoji;
        } else {
          grid.innerHTML = (S.emojis.system || []).map(function (e) {
            return '<div class="emoji-cell" data-url="' + esc(e.url) + '">' + (e.url.indexOf('emoji:') === 0 ? e.url.slice(6) : '🙂') + '</div>';
          }).join('');
          grid.querySelectorAll('.emoji-cell').forEach(function (c) {
            c.onclick = function () {
              var url = c.getAttribute('data-url');
              if (url.indexOf('emoji:') === 0) { $('msgInput').value += url.slice(6); autoGrow(); }
              else sendPayload(5, JSON.stringify({ url: url, w: 120, h: 120 }));
            };
          });
        }
      };
    });
    var addBtn = $('emojiAdd');
    if (addBtn) addBtn.onclick = addEmoji;
  }
  function addEmoji() {
    var inp = d.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*';
    inp.onchange = function () {
      if (!inp.files[0]) return;
      CC.upload('emoji_add', inp.files[0], { name: '我的表情' }).then(function () {
        CC.toast('已添加'); loadEmojis();
      }).catch(function (e) { CC.toast(e.message); });
    };
    inp.click();
  }

  /* =========================================================
   * 长轮询
   * ========================================================= */
  function poll() {
    if (S.stopped) return;
    CC.ajax('long_poll', { last_id: S.lastId, wait: 8 }, { silent: true }).then(function (res) {
      if (!res || res.code !== 0) { setTimeout(poll, 2500); return; }
      var data = res.data;
      if (data.last_id) S.lastId = Math.max(S.lastId, data.last_id);
      if (data.conversations) {
        S.convs = data.conversations;
        if (!S.cur) renderConvs();
        updateBadge();
      }
      (data.messages || []).forEach(function (m) {
        handleIncoming(m);
      });
      if (data.incoming_call) showIncomingCall(data.incoming_call);
      poll();
    }).catch(function () {
      setTimeout(poll, 3000);
    });
  }

  function handleIncoming(m) {
    if (m.type === 20) {
      // 撤回
      if (S.cur && ((S.cur.ctype === 1 && (m.from_uid === S.cur.peer || m.to_uid === S.cur.peer)) || (S.cur.ctype === 2 && m.gid === S.cur.peer))) {
        var mid = (m.extra && m.extra.mid) || 0;
        if (mid) removeMsg(mid);
      }
      return;
    }
    if (S.cur && ((S.cur.ctype === 1 && m.ctype === 1 && (m.from_uid === S.cur.peer || m.to_uid === S.cur.peer)) ||
      (S.cur.ctype === 2 && m.ctype === 2 && m.gid === S.cur.peer))) {
      appendLocal(m);
      CC.ajax('mark_read', { ctype: S.cur.ctype, peer: S.cur.peer });
    } else {
      // 提示音/角标由会话列表刷新
      if (m.ctype === 1 && m.from_uid !== ME.id) maybeNotify(m);
    }
  }

  function maybeNotify(m) {
    var c = S.convs.find(function (x) { return x.ctype === 1 && x.peer === m.from_uid; });
    if (c && c.muted) return;
    try {
      var ctx = null;
      if (!w._akAudio) w._akAudio = new Audio('data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=');
    } catch (e) { }
  }

  function showIncomingCall(c) {
    if (w._callDialogShown === c.call_id) return;
    w._callDialogShown = c.call_id;
    CC.confirm({
      title: (c.media === 2 ? '视频' : '语音') + '通话邀请',
      text: (c.from_name || '对方') + ' 邀请你进行' + (c.media === 2 ? '视频' : '语音') + '通话',
      ok: '接听', cancel: '拒绝'
    }).then(function (okv) {
      if (okv) location.href = 'call.php?call_id=' + encodeURIComponent(c.call_id);
      else CC.api('call_reject', { call_id: c.call_id }).catch(function () { });
    });
  }

  /* =========================================================
   * 菜单与面板
   * ========================================================= */
  function plusMenu() {
    var html = '<div class="sheet-item" data-a="group">👥 发起群聊</div>' +
      '<div class="sheet-item" data-a="add">➕ 加好友/群</div>' +
      '<div class="sheet-item" data-a="scan">📷 扫一扫</div>' +
      '<div class="sheet-item" data-a="read">✓ 一键已读</div>';
    var sh = CC.sheet('', html);
    sh.el.querySelectorAll('.sheet-item').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        sh.close();
        if (a === 'group') location.href = 'group_create.php';
        if (a === 'add') location.href = 'add.php';
        if (a === 'scan') location.href = 'scan.php';
        if (a === 'read') CC.api('mark_all_read', {}).then(function () { loadConvs(); CC.toast('已全部已读'); });
      };
    });
  }

  function chatMore() {
    if (!S.cur) return;
    var items = '';
    if (S.cur.ctype === 1) {
      items += '<div class="sheet-item" data-a="profile">👤 查看资料</div>';
      items += '<div class="sheet-item" data-a="call">📞 语音通话</div>';
      items += '<div class="sheet-item" data-a="vcall">📹 视频通话</div>';
      items += '<div class="sheet-item" data-a="report">🚩 投诉</div>';
    } else {
      items += '<div class="sheet-item" data-a="ginfo">👥 群聊信息</div>';
      items += '<div class="sheet-item" data-a="gcall">📞 群语音</div>';
      items += '<div class="sheet-item" data-a="gvideo">📹 群视频</div>';
      items += '<div class="sheet-item" data-a="live">📡 发起直播</div>';
      items += '<div class="sheet-item" data-a="report">🚩 投诉群聊</div>';
    }
    items += '<div class="sheet-item danger" data-a="clear">🧹 清空聊天记录</div>';
    var sh = CC.sheet('', items);
    sh.el.querySelectorAll('.sheet-item').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        sh.close();
        if (a === 'profile') location.href = 'user.php?uid=' + S.cur.peer;
        if (a === 'ginfo') location.href = 'group_info.php?gid=' + S.cur.peer;
        if (a === 'call') startCall(1);
        if (a === 'vcall') startCall(2);
        if (a === 'gcall') startCall(1, true);
        if (a === 'gvideo') startCall(2, true);
        if (a === 'live') createLive();
        if (a === 'report') reportDialog(0);
        if (a === 'clear') CC.confirm({ title: '清空聊天记录', text: '仅清空本地显示，不影响对方' }).then(function (okv) {
          if (okv) $('chatBody').innerHTML = '';
        });
      };
    });
  }

  function startCall(media, group) {
    if (!CFG.callEnabled) { CC.toast('通话功能已关闭'); return; }
    if (group) {
      CC.api('call_invite', { ctype: 2, to: S.cur.peer, media: media }).then(function (d) {
        location.href = 'call.php?call_id=' + d.call_id + '&host=1';
      }).catch(function (e) { CC.toast(e.message); });
    } else {
      location.href = 'call.php?to=' + S.cur.peer + '&media=' + media;
    }
  }

  function createLive() {
    if (!CFG.liveEnabled) { CC.toast('直播功能已关闭'); return; }
    CC.prompt({ title: '直播标题', value: ME.nickname + ' 的直播', max: 40 }).then(function (title) {
      if (!title) return;
      CC.api('live_create', { title: title, gid: S.cur && S.cur.ctype === 2 ? S.cur.peer : 0 }).then(function (d) {
        location.href = 'live.php?room_no=' + d.room.room_no + '&host=1';
      }).catch(function (e) { CC.toast(e.message); });
    });
  }

  /* =========================================================
   * @ 群成员
   * ========================================================= */
  var mentionOpen = false;
  function maybeMention(val) {
    if (!S.cur || S.cur.ctype !== 2) return;
    if (mentionOpen) return;
    if (!/(^|\s)@$/.test(val)) return;
    mentionOpen = true;
    CC.api('group_members', { gid: S.cur.peer }).then(function (data) {
      var list = (data.list || []).slice(0, 60);
      var html = '<div class="picker-list"><div class="picker-item" data-nick="所有人">' +
        '<span class="avatar sm" style="background:#07C160">@</span><div class="flex1">所有人</div></div>' +
        list.map(function (m) {
          return '<div class="picker-item" data-nick="' + esc(m.user_nickname || m.nickname || m.name) + '">' +
            CC.avatarHtml({ avatar: m.avatar, nickname: m.name }, 'sm') +
            '<div class="flex1">' + esc(m.name || m.user_nickname) + (m.role === 2 ? ' <span class="badge">群主</span>' : '') + '</div></div>';
        }).join('') + '</div>';
      var sh = CC.sheet('选择提醒的人', html);
      sh.el.querySelectorAll('.picker-item').forEach(function (it) {
        it.onclick = function () {
          var nick = it.getAttribute('data-nick');
          var i = $('msgInput');
          i.value = i.value.replace(/@$/, '@' + nick + ' ');
          i.focus(); autoGrow();
          sh.close(); mentionOpen = false;
        };
      });
      var closeFn = sh.close;
      sh.close = function () { mentionOpen = false; closeFn(); };
    }).catch(function () { mentionOpen = false; });
  }

  /* =========================================================
   * 初始化
   * ========================================================= */
  function bind() {
    $('btnSend').onclick = sendText;
    $('msgInput').addEventListener('input', function (e) {
      autoGrow();
      maybeMention(e.target.value);
    });
    $('msgInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendText(); }
    });
    $('btnEmoji').onclick = function () {
      S.emojiOpen = !S.emojiOpen;
      $('emojiPanel').classList.toggle('show', S.emojiOpen);
      if (S.emojiOpen) { $('plusPanel').classList.remove('show'); S.plusOpen = false; }
    };
    $('btnPlus2').onclick = function () {
      S.plusOpen = !S.plusOpen;
      $('plusPanel').classList.toggle('show', S.plusOpen);
      $('emojiPanel').classList.remove('show'); S.emojiOpen = false;
    };
    $('btnVoice').onclick = function () {
      S.voiceMode = !S.voiceMode;
      $('holdBtn').style.display = S.voiceMode ? 'block' : 'none';
      $('msgInput').style.display = S.voiceMode ? 'none' : 'block';
      this.style.color = S.voiceMode ? '#07C160' : '';
    };
    var hold = $('holdBtn');
    hold.addEventListener('touchstart', startRecord, { passive: false });
    hold.addEventListener('touchend', function (e) { e.preventDefault(); stopRecord(false); });
    hold.addEventListener('touchmove', function (e) {
      if (!S.recording) return;
      var t = e.touches[0];
      var r = hold.getBoundingClientRect();
      if (r.top - t.clientY > 60) { S.cancelled = true; stopRecord(true); CC.toast('已取消'); }
    }, { passive: true });
    hold.addEventListener('mousedown', startRecord);
    hold.addEventListener('mouseup', function () { stopRecord(false); });
    hold.addEventListener('mouseleave', function () { if (S.recording) stopRecord(true); });

    $('chatBack').onclick = closeChat;
    $('chatMore').onclick = chatMore;
    $('btnSearch').onclick = function () { location.href = 'search.php'; };
    $('btnPlus').onclick = plusMenu;
    $('chatTitleWrap').onclick = function () {
      if (!S.cur) return;
      location.href = S.cur.ctype === 1 ? 'user.php?uid=' + S.cur.peer : 'group_info.php?gid=' + S.cur.peer;
    };

    $('plusPanel').querySelectorAll('.plus-item').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-act');
        $('plusPanel').classList.remove('show'); S.plusOpen = false;
        if (a === 'image') pickImage();
        if (a === 'camera') $('filePickCamera').click();
        if (a === 'video') $('filePickVideo').click();
        if (a === 'file') $('filePickFile').click();
        if (a === 'call') startCall(1);
        if (a === 'redpacket') createRedPacket();
        if (a === 'transfer') createTransfer();
        if (a === 'gift') showGifts();
        if (a === 'card') shareCard();
        if (a === 'favorite') location.href = 'me.php?tab=favorite';
        if (a === 'live') createLive();
        if (a === 'location') { CC.toast('请在手机端使用位置分享'); }
      };
    });
    // 相册/拍照：暂存到输入框上方，随文字一起发送（图文合并为一条消息）
    $('filePickImage').onchange = function () {
      if (this.files && this.files.length) stageImages(this.files);
      this.value = '';
    };
    $('filePickCamera').onchange = function () {
      if (this.files && this.files.length) stageImages(this.files);
      this.value = '';
    };
    $('filePickVideo').onchange = function () { if (this.files[0]) doUploadVideo(this.files[0]); this.value = ''; };
    $('filePickFile').onchange = function () { if (this.files[0]) doUploadFile(this.files[0]); this.value = ''; };

    $('chatBody').addEventListener('scroll', function () {
      if (this.scrollTop < 30 && S.cur) loadMsgs(false);
    });
    d.addEventListener('visibilitychange', function () {
      if (!d.hidden && S.cur) loadMsgs(true);
    });
  }

  function boot() {
    bind();
    loadEmojis();
    loadConvs().then(function () {
      var to = CC.qs('to'), gid = CC.qs('gid');
      if (to) openChat(1, parseInt(to, 10), {});
      else if (gid) openChat(2, parseInt(gid, 10), {});
    });
    // 先取水位再开始轮询，避免历史消息被重复追加
    CC.ajax('long_poll', { last_id: -1, wait: 0 }, { silent: true }).then(function (r) {
      if (r && r.code === 0 && r.data && r.data.last_id) S.lastId = r.data.last_id;
      poll();
    }).catch(function () { poll(); });
  }

  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot);
  else boot();

})(window, document);
