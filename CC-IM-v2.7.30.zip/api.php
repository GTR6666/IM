<?php
/**
 * CC商聊 - 统一 API 入口
 * 所有前端请求：api.php?action=xxx（POST/GET 均可，字段同名）
 * 返回：{"code":0,"msg":"ok","data":...}
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require_once __DIR__ . '/lib/mailer.php';

/**
 * iSH 等环境下 require 偶发失败（句柄瞬时耗尽），这里做进程内重试。
 * 注意：必须在【全局作用域】调用，否则被包含文件里的顶层变量（$API_CORE 等）
 * 会变成函数局部变量，导致后续 array_merge 找不到它们。
 */
function cc_require_lib(string $file): void
{
    $path = __DIR__ . '/lib/' . $file;
    for ($i = 0; $i < 5; $i++) {
        $ok = @include_once $path;
        if ($ok !== false) return;
        usleep(120000);
    }
    throw new RuntimeException('无法加载 ' . $file);
}

// ---- 全局作用域逐行加载（保持变量为全局） ----
foreach (['api_core.php', 'api_chat.php', 'api_group.php', 'api_moment.php',
          'api_wallet.php', 'api_usdt.php', 'api_rtc.php'] as $__lib) {
    $__path = __DIR__ . '/lib/' . $__lib;
    $__loaded = false;
    for ($__i = 0; $__i < 5; $__i++) {
        if (!is_file($__path) || !is_readable($__path)) { usleep(120000); continue; }
        include_once $__path;   // 全局作用域执行，$API_* 变量保持在全局
        $__loaded = true;
        break;
    }
    if (!$__loaded) {
        http_response_code(503);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['code' => 503, 'msg' => '服务繁忙，请稍后重试', 'data' => null], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 各页面可扩展接口：定义 $API_EXTRA = ['action'=>fn]，自动合并
$API_EXTRA = [];
foreach (glob(__DIR__ . '/lib/api_extra_*.php') ?: [] as $__f) {
    require_once $__f;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? ''));
if ($action === '') {
    // 兼容 JSON body 提交
    $j = body_json();
    $action = trim((string)($j['action'] ?? ''));
}

$PUBLIC = [
    'login', 'register', 'check_account', 'send_code', 'reset_password', 'appeal_submit',
    'site_info', 'ping',
    // 多账号：凭 token 校验/切换，属于免密凭据本身，无需已登录
    'account_check', 'account_switch',
];

if (!in_array($action, $PUBLIC, true)) {
    $me = require_user_api();
} else {
    $me = null;
}

$handlers = array_merge($API_CORE, $API_CHAT, $API_GROUP, $API_MOMENT, $API_WALLET, $API_USDT, $API_RTC, $API_EXTRA);

if (!isset($handlers[$action])) {
    fail('未知接口: ' . $action, 404);
}

try {
    $handlers[$action]($me);
} catch (RuntimeException $e) {
    // 业务异常（如文件类型被拒、余额不足）返回可读提示，不暴露内部路径
    fail($e->getMessage());
} catch (Throwable $e) {
    if (cfg('app.debug')) {
        fail($e->getMessage() . ' @' . $e->getFile() . ':' . $e->getLine(), 500);
    }
    fail('服务器开小差了，请稍后再试', 500);
}
