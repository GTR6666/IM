<?php
/**
 * CC商聊 - 个人资料
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$meFresh = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]) ?: $me;
$showYxid = $meFresh['pretty_yxid'] ?: ($meFresh['yx_id'] ?: $meFresh['account']);
$hasPay = !empty($meFresh['pay_password']);
$gender = max(0, min(2, (int)$meFresh['gender']));
$email = trim((string)$meFresh['email']);
$phone = trim((string)$meFresh['phone']);
$settings = json_decode_arr($meFresh['settings'] ?? '');
cc_head('个人资料', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('个人资料', 'me.php', '<button class="tb-btn" id="btnSaveTop" style="font-size:13.5px;color:var(--brand);font-weight:600;width:auto;padding:0 6px">保存</button>'); ?>

    <div class="page-body no-tab">
      <div class="card" style="display:flex;align-items:center;gap:16px;padding:18px 16px">
        <span id="avatarWrap" style="position:relative;cursor:pointer">
          <?php if ($meFresh['avatar']): ?>
          <span class="avatar xl"><img src="<?= e($meFresh['avatar']) ?>" alt=""></span>
          <?php else: ?>
          <span class="avatar xl" style="background:var(--brand)"><?= e(mb_substr($meFresh['nickname'] ?: 'U', 0, 1)) ?></span>
          <?php endif; ?>
          <span style="position:absolute;right:-2px;bottom:-2px;width:26px;height:26px;border-radius:50%;background:var(--brand);color:#fff;display:flex;align-items:center;justify-content:center;border:2px solid var(--card)">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 6v12M6 12h12"/></svg>
          </span>
        </span>
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:600">更换头像</div>
          <div class="t3 small" style="margin-top:5px">支持 JPG / PNG / GIF，建议正方形</div>
          <button class="btn small outline mt12" id="btnPickAvatar">从相册选择</button>
        </div>
        <input type="file" id="avatarFile" accept="image/*" style="display:none">
      </div>

      <div class="group-title">基本资料</div>
      <div class="cell-group">
        <div class="field-row">
          <label>昵称</label>
          <input id="fNickname" type="text" maxlength="20" placeholder="请输入昵称" value="<?= e($meFresh['nickname']) ?>">
        </div>
        <div class="field-row" style="align-items:flex-start">
          <label style="padding-top:6px">个性签名</label>
          <textarea id="fBio" maxlength="100" placeholder="写一句介绍自己" style="min-height:58px"><?= e($meFresh['bio']) ?></textarea>
        </div>
        <div class="field-row">
          <label>性别</label>
          <div class="gap8" style="flex:1;justify-content:flex-end" id="genderBox">
            <?php foreach ([0 => '保密', 1 => '男', 2 => '女'] as $gv => $gt): ?>
            <button class="badge <?= $gender === $gv ? '' : 'gray' ?>" data-gender="<?= $gv ?>" style="padding:5px 14px;border-radius:20px;font-size:12px"><?= e($gt) ?></button>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="field-row">
          <label>地区</label>
          <input id="fRegion" type="text" maxlength="20" placeholder="如：广东 深圳" value="<?= e($meFresh['region']) ?>">
        </div>
      </div>

      <div class="group-title">账号信息</div>
      <div class="cell-group">
        <div class="cell" id="cellYxid">
          <div class="c-title">CC号</div>
          <div class="c-value">
            <?= pretty_number_html((string)$showYxid, (string)($meFresh['pretty_yxid'] ?? '')) ?><span class="badge gray" style="margin-left:6px">复制</span>
          </div>
        </div>
        <div class="cell" style="cursor:default">
          <div class="c-title">邮箱</div>
          <div class="c-value">
            <?php if ($email !== ''): ?>
            <span class="nowrap" style="max-width:170px"><?= e($email) ?></span><span class="badge">已绑定</span>
            <?php else: ?>
            <span class="badge gray">未绑定</span>
            <?php endif; ?>
          </div>
        </div>
        <div class="cell" style="cursor:default">
          <div class="c-title">手机号</div>
          <div class="c-value">
            <?php if ($phone !== ''): ?>
            <span><?= e(substr($phone, 0, 3) . '****' . substr($phone, -4)) ?></span><span class="badge">已绑定</span>
            <?php else: ?>
            <span class="badge gray">未绑定</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="group-title" id="security">安全设置</div>
      <div class="cell-group">
        <div class="cell" id="cellPwd">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
          </div>
          <div class="c-title">修改登录密码</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" id="cellPay">
          <div class="c-icon" style="background:rgba(245,166,35,.14);color:var(--gold)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="13" rx="2.4"/><path d="M3 10.5h18M7 15h4"/></svg>
          </div>
          <div class="c-title"><?= $hasPay ? '修改支付密码' : '设置支付密码' ?></div>
          <div class="c-value"><?= $hasPay ? '<span class="badge">已设置</span>' : '<span class="badge gray">未设置</span>' ?></div>
          <span class="arrow">›</span>
        </div>
      </div>

      <div style="padding:16px 12px 30px">
        <button class="btn" id="btnSave">保存资料</button>
      </div>
    </div>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
window.PROFILE = {
  hasPay: <?= $hasPay ? 1 : 0 ?>,
  yxid: <?= json_encode($showYxid, JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var P = window.PROFILE;
  var gender = <?= $gender ?>;

  function copyText(text){
    if (navigator.clipboard && window.isSecureContext){
      navigator.clipboard.writeText(text).then(function(){ CC.toast('已复制'); }, function(){ fb(); });
    } else fb();
    function fb(){
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); CC.toast('已复制'); } catch (e) { CC.toast('复制失败'); }
      ta.remove();
    }
  }

  /* ---------- 头像 ---------- */
  var file = document.getElementById('avatarFile');
  document.getElementById('btnPickAvatar').onclick = function(){ file.click(); };
  document.getElementById('avatarWrap').onclick = function(){ file.click(); };
  file.onchange = function(){
    var f = file.files && file.files[0];
    if (!f) return;
    if (!/^image\//.test(f.type)){ CC.toast('请选择图片文件'); return; }
    CC.toast('上传中…');
    CC.upload('upload_avatar', f).then(function(d){
      var wrap = document.getElementById('avatarWrap');
      wrap.innerHTML = '<span class="avatar xl"><img src="' + CC.esc(d.url) + '" alt=""></span>'
        + '<span style="position:absolute;right:-2px;bottom:-2px;width:26px;height:26px;border-radius:50%;background:var(--brand);color:#fff;display:flex;align-items:center;justify-content:center;border:2px solid var(--card)">'
        + '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 6v12M6 12h12"/></svg></span>';
      wrap.onclick = function(){ file.click(); };
      if (window.ME) window.ME.avatar = d.url;
      CC.toast('头像已更新');
    }).catch(function(e){ CC.toast(e.message || '上传失败'); });
    file.value = '';
  };

  /* ---------- 性别 ---------- */
  document.querySelectorAll('[data-gender]').forEach(function(b){
    b.onclick = function(){
      gender = parseInt(b.getAttribute('data-gender'), 10);
      document.querySelectorAll('[data-gender]').forEach(function(x){
        x.className = 'badge ' + (parseInt(x.getAttribute('data-gender'), 10) === gender ? '' : 'gray');
        x.style.padding = '5px 14px'; x.style.borderRadius = '20px'; x.style.fontSize = '12px';
      });
    };
  });

  /* ---------- 保存 ---------- */
  function save(){
    var nickname = document.getElementById('fNickname').value.trim();
    if (!nickname){ CC.toast('昵称不能为空'); return; }
    var btn = document.getElementById('btnSave');
    btn.disabled = true;
    CC.api('save_profile', {
      nickname: nickname,
      bio: document.getElementById('fBio').value.trim(),
      region: document.getElementById('fRegion').value.trim(),
      gender: gender
    }).then(function(u){
      btn.disabled = false;
      if (window.ME && u){ window.ME.nickname = u.nickname; window.ME.bio = u.bio; }
      CC.toast('已保存');
    }).catch(function(e){ btn.disabled = false; CC.toast(e.message); });
  }
  document.getElementById('btnSave').onclick = save;
  document.getElementById('btnSaveTop').onclick = save;

  document.getElementById('cellYxid').onclick = function(){ copyText(P.yxid); };

  /* ---------- 修改登录密码 ---------- */
  document.getElementById('cellPwd').onclick = function(){
    var s = CC.sheet('修改登录密码', '')
    , box = s.el.querySelector('.sheet-body');
    box.innerHTML = '<div class="field" style="background:var(--bg);margin-top:6px"><input id="pOld" type="password" maxlength="32" placeholder="当前密码"></div>'
      + '<div class="field" style="background:var(--bg)"><input id="pNew" type="password" maxlength="32" placeholder="新密码（至少 6 位）"></div>'
      + '<div class="field" style="background:var(--bg)"><input id="pNew2" type="password" maxlength="32" placeholder="再次输入新密码"></div>'
      + '<button class="btn" id="pOk">确认修改</button>'
      + '<div class="t3 small center" style="margin:10px 0 4px">修改成功后需要重新登录</div>';
    box.querySelector('#pOk').onclick = function(){
      var oldP = box.querySelector('#pOld').value
        , n1 = box.querySelector('#pNew').value
        , n2 = box.querySelector('#pNew2').value;
      if (!oldP || !n1){ CC.toast('请填写完整'); return; }
      if (n1.length < 6){ CC.toast('新密码至少 6 位'); return; }
      if (n1 !== n2){ CC.toast('两次输入不一致'); return; }
      this.disabled = true;
      CC.api('change_password', { old: oldP, new: n1 }).then(function(){
        CC.toast('密码已修改，请重新登录');
        s.close();
        setTimeout(function(){ location.replace('logout.php'); }, 900);
      }).catch(function(e){ box.querySelector('#pOk').disabled = false; CC.toast(e.message); });
    };
  };

  /* ---------- 支付密码 ---------- */
  document.getElementById('cellPay').onclick = function(){
    var s = CC.sheet(P.hasPay ? '修改支付密码' : '设置支付密码', '')
    , box = s.el.querySelector('.sheet-body');
    box.innerHTML = (P.hasPay
        ? '<div class="field" style="background:var(--bg);margin-top:6px"><input id="ppOld" type="password" inputmode="numeric" maxlength="6" placeholder="原支付密码"></div>'
        : '')
      + '<div class="field" style="background:var(--bg)"><input id="ppNew" type="password" inputmode="numeric" maxlength="6" placeholder="6 位数字支付密码"></div>'
      + '<div class="field" style="background:var(--bg)"><input id="ppNew2" type="password" inputmode="numeric" maxlength="6" placeholder="再次输入"></div>'
      + '<button class="btn" id="ppOk">确认</button>'
      + '<div class="t3 small center" style="margin:10px 0 4px">支付密码用于转账、发红包、购买靓号等</div>';
    box.querySelector('#ppOk').onclick = function(){
      var n1 = box.querySelector('#ppNew').value.trim()
        , n2 = box.querySelector('#ppNew2').value.trim()
        , oldP = P.hasPay ? box.querySelector('#ppOld').value.trim() : '';
      if (!/^\d{6}$/.test(n1)){ CC.toast('支付密码需为 6 位数字'); return; }
      if (n1 !== n2){ CC.toast('两次输入不一致'); return; }
      if (P.hasPay && !oldP){ CC.toast('请输入原支付密码'); return; }
      this.disabled = true;
      CC.api('set_pay_password', { password: n1, old: oldP }).then(function(){
        CC.toast('支付密码已设置');
        s.close();
        P.hasPay = 1;
        document.querySelector('#cellPay .c-value').innerHTML = '<span class="badge">已设置</span>';
        document.querySelector('#cellPay .c-title').textContent = '修改支付密码';
      }).catch(function(e){ box.querySelector('#ppOk').disabled = false; CC.toast(e.message); });
    };
  };

  /* ---------- 锚点 ---------- */
  if (location.hash === '#security'){
    setTimeout(function(){
      var el = document.getElementById('security');
      if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' });
    }, 120);
  }
})();
</script>
<?php cc_foot(); ?>
