<?php
/**
 * CC商聊 - 注册
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
if (current_uid() && current_user() && (int)current_user()['status'] !== 1) {
    header('Location: index.php');
    exit;
}
$invite = (string)($_GET['invite'] ?? '');
$site = setting('site_name', 'CC商聊');
$idLen = reg_id_len();
$needEmail = email_verify_register();   // 后台是否开启注册邮箱验证
cc_head('注册', ['index' => true, 'desc' => '注册' . setting('site_name', 'CC商聊') . '账号，系统自动分配专属' . term_id() . '。支持邀请码注册、群聊、朋友圈与语音视频通话，免费使用。', 'body_class' => 'login-body', 'css' => '
html{background:#F5F6F8;min-height:100%;}
body{background:#F5F6F8;min-height:100vh;min-height:100dvh;}
.wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 22px;}
.card{width:100%;max-width:420px;}
.auth-logo{width:76px;height:76px;border-radius:24px;background:linear-gradient(135deg,#07C160,#06AD56);color:#fff;font-size:26px;font-weight:800;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;box-shadow:0 16px 32px rgba(7,193,96,.32);overflow:hidden}
.auth-logo img{width:100%;height:100%;object-fit:cover}
h1{font-size:23px;text-align:center;margin:0}
.sub{text-align:center;color:#9AA0AC;font-size:12.5px;margin:8px 0 24px}
.field{height:52px;border-radius:13px;background:#fff;border:1.5px solid transparent;box-shadow:0 2px 10px rgba(26,32,60,.03);margin-bottom:11px;}
.field:focus-within{border-color:#B9EBD0;box-shadow:0 0 0 4px rgba(7,193,96,.1);}
.field input{font-size:14.5px}
.small-tip{font-size:11.5px;color:#9AA0AC;margin:-4px 2px 12px;line-height:1.6}
.foot{text-align:center;font-size:13px;color:#9AA0AC;margin-top:20px}
.foot a{color:#07C160;font-weight:600}
.code-row{display:flex;gap:8px}
.code-row .field{flex:1;margin-bottom:0}
.code-btn{height:52px;padding:0 14px;border-radius:13px;background:#fff;color:#07C160;font-size:13px;font-weight:600;box-shadow:0 2px 10px rgba(26,32,60,.03)}
.agree{display:flex;gap:8px;align-items:flex-start;font-size:12px;color:#9AA0AC;margin:8px 2px 18px;line-height:1.6}
']); ?>

<div class="wrap">
  <div class="card">
    <div class="auth-logo">
      <?php if (is_file(CC_ROOT . '/icons/icon-192.png')): ?><img src="icons/icon-192.png" alt=""><?php else: ?><?= e(setting('brand', 'CC')) ?><?php endif; ?>
    </div>
    <h1>创建账号</h1>
    <p class="sub">加入 <?= e($site) ?>，和商业伙伴保持连接</p>

    <div class="field" style="height:auto;padding:13px 14px;background:#fff">
      <div style="display:flex;align-items:flex-start;gap:10px">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#07C160" stroke-width="1.9" stroke-linecap="round" style="flex:0 0 auto;margin-top:2px"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>
        <div>
          <div style="font-size:13.5px;color:#1A2030;font-weight:600">CC号由系统随机分配（<?= $idLen ?> 位）</div>
          <div style="font-size:11.5px;color:#9AA0AC;margin-top:4px;line-height:1.6">注册成功后自动获得一个 <?= $idLen ?> 位纯数字 CC号，不可自定义；可在「我的」中查看与复制。</div>
        </div>
      </div>
    </div>
    <div class="field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/></svg>
      <input id="nickname" type="text" maxlength="16" placeholder="昵称">
    </div>
    <div class="field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
      <input id="password" type="password" maxlength="32" placeholder="密码（至少 6 位）">
    </div>
    <div class="field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
      <input id="password2" type="password" maxlength="32" placeholder="确认密码">
    </div>
    <div class="field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><path d="M4 6h16v12H4z"/><path d="M4 7l8 6 8-6"/></svg>
      <input id="email" type="email" maxlength="64" placeholder="<?= $needEmail ? '邮箱（必填，需验证）' : '邮箱（选填，用于找回密码）' ?>">
    </div>
<?php if ($needEmail): ?>
    <div class="code-row" style="margin-bottom:11px">
      <div class="field" style="margin-bottom:0">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg>
        <input id="code" type="text" maxlength="6" inputmode="numeric" placeholder="邮箱验证码">
      </div>
      <button class="code-btn" id="btnCode" type="button">获取验证码</button>
    </div>
<?php endif; ?>
    <div class="field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#9AA0AC" stroke-width="1.9" stroke-linecap="round"><path d="M12 2l3 6 6 .9-4.5 4.3 1 6-5.5-3-5.5 3 1-6L3 8.9 9 8z"/></svg>
      <input id="invite" type="text" maxlength="16" placeholder="邀请码（选填）" value="<?= e($invite) ?>">
    </div>
    <?php if ($invite): ?><div class="small-tip">使用邀请码注册成功后，邀请人可累计邀请人数并解锁阶梯奖励</div><?php endif; ?>

    <label class="agree"><input type="checkbox" id="agree" checked> 我已阅读并同意《用户协议》与《隐私政策》，承诺不发布违法违规内容</label>
    <button class="btn" id="btnReg">注 册</button>
    <div class="foot">已有账号？<a href="login.php">立即登录</a></div>
  </div>
</div>

<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var btn = document.getElementById('btnReg');
  var btnCode = document.getElementById('btnCode');
  if (btnCode){
    btnCode.onclick = function(){
      var email = document.getElementById('email').value.trim();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { CC.toast('请先填写正确的邮箱'); return; }
      btnCode.disabled = true; var raw = btnCode.textContent; btnCode.textContent = '发送中…';
      CC.ajax('send_code', { target: email, purpose: 'register' }).then(function(res){
        if (res.code === 0){
          CC.toast('验证码已发送，请查收邮件');
          var left = 60;
          var t = setInterval(function(){
            left--;
            if (left <= 0) { clearInterval(t); btnCode.disabled = false; btnCode.textContent = raw; }
            else btnCode.textContent = left + 's';
          }, 1000);
        } else {
          btnCode.disabled = false; btnCode.textContent = raw;
          CC.toast(res.msg || '发送失败');
        }
      }).catch(function(){ btnCode.disabled = false; btnCode.textContent = raw; CC.toast('网络异常'); });
    };
  }
  btn.onclick = function(){
    var codeEl = document.getElementById('code');
    var d = {
      nickname: document.getElementById('nickname').value.trim(),
      password: document.getElementById('password').value,
      password2: document.getElementById('password2').value,
      email: document.getElementById('email').value.trim(),
      invite: document.getElementById('invite').value.trim(),
      code: codeEl ? codeEl.value.trim() : ''
    };
    if (!d.nickname) { CC.toast('请填写昵称'); return; }
    if (d.password.length < 6) { CC.toast('密码至少 6 位'); return; }
    if (d.password !== d.password2) { CC.toast('两次密码不一致'); return; }
    <?php if ($needEmail): ?>
    if (!d.email) { CC.toast('请填写邮箱'); return; }
    if (!d.code) { CC.toast('请填写邮箱验证码'); return; }
    <?php endif; ?>
    if (!document.getElementById('agree').checked) { CC.toast('请先同意用户协议'); return; }
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span> 注册中…';
    CC.ajax('register', d).then(function(res){
      if (res.code === 0){
        var uid = (res.data && res.data.yx_id) || '';
        // 明确告知系统分配的 CC号，避免用户错过
        CC.confirm({
          title: '注册成功',
          single: true,
          html: '<p style="margin:0 0 6px">系统已为您分配 CC号</p>'
            + '<div style="font-size:26px;font-weight:800;letter-spacing:2px;color:#07C160;margin:6px 0 12px">' + CC.esc(uid) + '</div>'
            + '<p style="margin:0">请牢记该号码，登录与添加好友都需要它<br>可在「我的」页面随时查看与复制</p>',
          ok: '知道了'
        }).then(function(){ location.replace('index.php'); });
        return;
      }
      btn.disabled = false; btn.textContent = '注 册';
      CC.toast(res.msg || '注册失败');
    }).catch(function(){ btn.disabled = false; btn.textContent = '注 册'; CC.toast('网络异常'); });
  };
})();
</script>
</body>
</html>
