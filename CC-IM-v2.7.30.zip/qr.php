<?php
/**
 * CC商聊 - 二维码图片输出（SVG）
 * 用法： qr.php?d=<urlencode 内容>&s=220
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/qr.php';

$data = (string)($_GET['d'] ?? ($_GET['u'] ?? ''));
if ($data === '') $data = site_url('register.php');
$sizePx = max(80, min(600, (int)($_GET['s'] ?? 220)));

// 内容过长（>122 字节）时给出占位图
try {
    $matrix = qr_matrix($data);
} catch (Throwable $e) {
    header('Content-Type: image/svg+xml; charset=utf-8');
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="' . $sizePx . '" height="' . $sizePx . '">'
        . '<rect width="100%" height="100%" fill="#fff"/>'
        . '<text x="50%" y="50%" font-size="12" fill="#999" text-anchor="middle">链接过长</text></svg>';
    exit;
}

$n = count($matrix);
$quiet = 4;
$total = $n + $quiet * 2;
$scale = $sizePx / $total;
$path = '';
for ($y = 0; $y < $n; $y++) {
    for ($x = 0; $x < $n; $x++) {
        if (!$matrix[$y][$x]) continue;
        $px = ($x + $quiet) * $scale;
        $py = ($y + $quiet) * $scale;
        $path .= 'M' . round($px, 2) . ' ' . round($py, 2)
            . 'h' . round($scale, 2) . 'v' . round($scale, 2)
            . 'h-' . round($scale, 2) . 'z';
    }
}

$fmt = strtolower((string)($_GET['f'] ?? 'svg'));

// PNG 输出（更清晰，扫码识别率更高）
if ($fmt === 'png' && function_exists('imagecreatetruecolor')) {
    $px = $sizePx * 2;                  // 2 倍分辨率抗锯齿
    $im = imagecreatetruecolor($px, $px);
    $white = imagecolorallocate($im, 255, 255, 255);
    $black = imagecolorallocate($im, 0, 0, 0);
    imagefilledrectangle($im, 0, 0, $px, $px, $white);
    $cell = $px / $total;
    for ($y = 0; $y < $n; $y++) {
        for ($x = 0; $x < $n; $x++) {
            if (!$matrix[$y][$x]) continue;
            $x1 = (int)floor(($x + $quiet) * $cell);
            $y1 = (int)floor(($y + $quiet) * $cell);
            $x2 = (int)ceil(($x + $quiet + 1) * $cell) - 1;
            $y2 = (int)ceil(($y + $quiet + 1) * $cell) - 1;
            imagefilledrectangle($im, $x1, $y1, $x2, $y2, $black);
        }
    }
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=604800');
    imagepng($im);
    imagedestroy($im);
    exit;
}

header('Content-Type: image/svg+xml; charset=utf-8');
header('Cache-Control: public, max-age=604800');
echo '<svg xmlns="http://www.w3.org/2000/svg" width="' . $sizePx . '" height="' . $sizePx . '" viewBox="0 0 ' . $sizePx . ' ' . $sizePx . '" shape-rendering="crispEdges">'
    . '<rect width="100%" height="100%" fill="#ffffff"/>'
    . '<path d="' . $path . '" fill="#000000"/>'
    . '</svg>';
