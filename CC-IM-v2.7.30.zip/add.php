<?php
/**
 * CC商聊 - 添加朋友
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myYxid = $me['pretty_yxid'] ?: ($me['yx_id'] ?: $me['account']);
$kw0 = trim((string)($_GET['kw'] ?? ''));
cc_head('添加朋友', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('添加朋友', 'contacts.php'); ?>

    <div class="page-body no-tab">
      <div class="card" style="display:flex;align-items:center;gap:14px">
        <div class="flex1" style="min-width:0">
          <div class="t3 small">我的 CC号</div>
          <div style="font-size:22px;font-weight:700;letter-spacing:.6px;margin-top:3px" id="myYxid"><?= e($myYxid) ?></div>
          <div class="t3 small" style="margin-top:4px">把 CC号 告诉好友，对方就能精确找到你</div>
        </div>
        <button class="btn small outline" id="btnCopyYxid" style="flex:0 0 auto">复制</button>
      </div>

      <div style="padding:6px 12px 0">
        <div class="field" style="margin-bottom:0">
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" style="color:var(--t3)"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
          <input id="kw" type="text" placeholder="CC号 / 靓号 / 邮箱 / 群号 / 群名" autocomplete="off">
          <button class="btn small" id="btnSearch" style="flex:0 0 auto">搜索</button>
        </div>
      </div>

      <div id="searchBox" style="padding-top:6px"></div>

      <div class="group-title" style="display:flex;align-items:center;justify-content:space-between">
        <span>新的朋友</span>
        <span class="t3 small" id="reqCount"></span>
      </div>
      <div class="cell-group" id="reqBox"><div class="loading"><span class="spin"></span> 加载中…</div></div>
      <div style="height:24px"></div>
    </div>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var ME = window.ME || {};
  var kwEl = document.getElementById('kw');
  var box = document.getElementById('searchBox');
  var reqBox = document.getElementById('reqBox');

  function copyText(text){
    if (navigator.clipboard && window.isSecureContext){
      navigator.clipboard.writeText(text).then(function(){ CC.toast('已复制'); }, function(){ fallback(text); });
    } else fallback(text);
  }
  function fallback(text){
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); CC.toast('已复制'); } catch (e) { CC.toast('复制失败，请长按选择'); }
    ta.remove();
  }

  document.getElementById('btnCopyYxid').onclick = function(){ copyText(document.getElementById('myYxid').textContent.trim()); };

  /* ---------- 搜索结果 ---------- */
  function userRow(u){
    var isMe = parseInt(u.id, 10) === parseInt(ME.id, 10);
    var right = '';
    if (isMe) right = '<span class="badge gray">这是我</span>';
    else if (parseInt(u.is_friend, 10)) right = '<button class="btn small ghost" data-msg="' + u.id + '">发消息</button>';
    else if (parseInt(u.req_id, 10)) right = '<button class="btn small" data-accept="' + u.req_id + '">同意</button>';
    else if (parseInt(u.req_sent, 10)) right = '<button class="btn small ghost" disabled>已申请</button>';
    else right = '<button class="btn small" data-add="' + u.id + '" data-name="' + CC.esc(u.nickname) + '">加好友</button>';
    return '<div class="cell">'
      + CC.avatarHtml(u, 'sm')
      + '<div class="c-title" style="min-width:0"><div class="name-row"><span class="name-txt">' + CC.esc(u.nickname)
      + '</span><span class="name-tags">' + CC.prettyBadge(u.pretty) + CC.vipTag(u.vip_level) + '</span></div>'
      + '<div class="c-desc">CC号 ' + CC.esc(u.pretty || u.yx_id || u.account || '') + '</div></div>'
      + right + '</div>';
  }
  function groupRow(g){
    var right = parseInt(g.joined, 10)
      ? '<button class="btn small ghost" data-goto-group="' + g.gid + '">进入</button>'
      : '<button class="btn small" data-join="' + g.gid + '">加入</button>';
    return '<div class="cell">'
      + CC.avatarHtml({ nickname: g.name, avatar: g.avatar }, 'sm')
      + '<div class="c-title" style="min-width:0"><div class="nowrap">' + CC.esc(g.name) + '</div>'
      + '<div class="c-desc">群号 ' + g.gid + ' · ' + (g.members || 0) + '人</div></div>'
      + right + '</div>';
  }

  function paintResults(data, kw){
    var users = (data && data.users) || [], groups = (data && data.groups) || [];
    if (!users.length && !groups.length){
      box.innerHTML = '<div class="empty" style="padding:34px 16px"><div class="ico">🔍</div>'
        + '<div>没有找到「' + CC.esc(kw) + '」</div>'
        + '<div style="font-size:12px;margin-top:4px">CC号 / 靓号 / 邮箱 / 群号 需要完整精确输入</div></div>';
      return;
    }
    var html = '';
    if (users.length){
      html += '<div class="group-title">用户</div><div class="cell-group">' + users.map(userRow).join('') + '</div>';
    }
    if (groups.length){
      html += '<div class="group-title">群聊</div><div class="cell-group">' + groups.map(groupRow).join('') + '</div>';
    }
    box.innerHTML = html;
    bindResultActions();
  }

  function bindResultActions(){
    box.querySelectorAll('[data-add]').forEach(function(b){
      b.onclick = function(){
        var uid = b.getAttribute('data-add'), name = b.getAttribute('data-name');
        CC.prompt({ title: '添加好友', text: '向 ' + name + ' 发送好友申请', placeholder: '填写申请理由', value: '我是 ' + (ME.nickname || ''), max: 50 })
          .then(function(reason){
            if (reason === null) return;
            if (!reason){ CC.toast('请填写申请理由'); return; }
            b.disabled = true;
            CC.api('send_friend_request', { to_uid: uid, reason: reason }).then(function(){
              CC.toast('申请已发送');
              b.textContent = '已申请'; b.disabled = true;
            }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
          });
      };
    });
    box.querySelectorAll('[data-accept]').forEach(function(b){
      b.onclick = function(){
        b.disabled = true;
        CC.api('handle_req', { id: b.getAttribute('data-accept'), act: 'accept' }).then(function(){
          CC.toast('已添加为好友');
          b.textContent = '已添加';
        }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
      };
    });
    box.querySelectorAll('[data-msg]').forEach(function(b){
      b.onclick = function(){ location.href = 'index.php?to=' + b.getAttribute('data-msg'); };
    });
    box.querySelectorAll('[data-join]').forEach(function(b){
      b.onclick = function(){
        b.disabled = true;
        CC.api('group_join', { gid: b.getAttribute('data-join') }).then(function(d){
          if (d && d.pending){ CC.toast('申请已提交，等待群主处理'); b.textContent = '待审核'; }
          else { CC.toast('已加入群聊'); b.textContent = '进入'; b.disabled = false; b.setAttribute('data-goto-group', b.getAttribute('data-join')); b.removeAttribute('data-join'); bindResultActions(); }
        }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
      };
    });
    box.querySelectorAll('[data-goto-group]').forEach(function(b){
      b.onclick = function(){ location.href = 'group_info.php?gid=' + b.getAttribute('data-goto-group'); };
    });
  }

  function doSearch(){
    var kw = kwEl.value.trim();
    if (!kw){ CC.toast('请输入 CC号 / 群号'); kwEl.focus(); return; }
    box.innerHTML = '<div class="loading"><span class="spin"></span> 搜索中…</div>';
    CC.ajax('search', { keyword: kw, type: 'all' }).then(function(res){
      if (res.code !== 0){ paintResults({ users: [], groups: [] }, kw); return; }
      paintResults(res.data || {}, kw);
    }).catch(function(){ paintResults({ users: [], groups: [] }, kw); });
  }
  document.getElementById('btnSearch').onclick = doSearch;
  kwEl.addEventListener('keydown', function(e){ if (e.key === 'Enter') doSearch(); });

  /* ---------- 新的朋友 ---------- */
  function loadBoard(){
    CC.ajax('friend_board', {}).then(function(res){
      if (res.code !== 0){ reqBox.innerHTML = '<div class="cell"><div class="c-title t3 small">加载失败</div></div>'; return; }
      var list = (res.data && res.data.list) || [];
      document.getElementById('reqCount').textContent = list.length ? ('共 ' + list.length + ' 条') : '';
      if (!list.length){
        reqBox.innerHTML = '<div class="cell"><div class="c-title" style="color:var(--t3);font-size:13px">暂无新的朋友申请</div></div>';
        return;
      }
      reqBox.innerHTML = list.map(function(r){
        var right;
        if (parseInt(r.status, 10) === 0){
          right = '<div class="gap8"><button class="btn small ghost" data-req="' + r.id + '" data-act="reject">拒绝</button>'
            + '<button class="btn small" data-req="' + r.id + '" data-act="accept">同意</button></div>';
        } else if (parseInt(r.status, 10) === 1){
          right = '<span class="badge">已添加</span>';
        } else {
          right = '<span class="badge gray">已拒绝</span>';
        }
        return '<div class="cell" style="align-items:flex-start">'
          + CC.avatarHtml({ nickname: r.nickname, avatar: r.avatar }, 'sm')
          + '<div class="c-title" style="min-width:0"><div class="nowrap">' + CC.esc(r.nickname) + '</div>'
          + '<div class="c-desc">' + CC.esc(r.reason || '请求添加你为好友') + '</div>'
          + '<div class="c-desc" style="font-size:11px">' + (parseInt(r.status, 10) === 0 ? '待处理' : '') + '</div></div>'
          + right + '</div>';
      }).join('');
      reqBox.querySelectorAll('[data-req]').forEach(function(b){
        b.onclick = function(){
          b.disabled = true;
          CC.api('handle_req', { id: b.getAttribute('data-req'), act: b.getAttribute('data-act') }).then(function(){
            CC.toast(b.getAttribute('data-act') === 'accept' ? '已添加为好友' : '已拒绝');
            loadBoard();
          }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
        };
      });
    }).catch(function(){ reqBox.innerHTML = '<div class="cell"><div class="c-title t3 small">加载失败</div></div>'; });
  }

  loadBoard();
  var pre = <?= json_encode($kw0, JSON_UNESCAPED_UNICODE) ?>;
  if (pre){ kwEl.value = pre; doSearch(); } else { kwEl.focus(); }
})();
</script>
<?php cc_foot(); ?>
