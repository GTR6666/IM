<?php
/**
 * CC商聊 - 安装向导 / 数据初始化
 * 浏览器访问 install.php，或命令行 php install.php
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/schema.php';

$isCli = (PHP_SAPI === 'cli');
$force = $isCli ? in_array('--force', $argv ?? [], true) : isset($_GET['force']);
$log = [];

/* 已安装保护：网页端只有已登录管理员才能执行，防止任意访客重装/重置 */
if (!$isCli) {
    $installed = false;
    try {
        $installed = (int)val('SELECT COUNT(*) FROM settings') > 0;
    } catch (Throwable $e) {
        $installed = false;
    }
    if ($installed) {
        require_once __DIR__ . '/admin/lib.php';
        $admin = admin_current();
        if (!$admin) {
            http_response_code(403);
            echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><title>系统已安装</title>'
                . '<style>body{font-family:-apple-system,"Microsoft YaHei",sans-serif;background:#0F1420;color:#E7ECF5;display:flex;height:100vh;align-items:center;justify-content:center;margin:0}'
                . '.b{max-width:460px;padding:36px;border-radius:18px;background:rgba(23,29,44,.85);border:1px solid rgba(255,255,255,.08);line-height:1.9}'
                . 'h1{font-size:20px;margin:0 0 10px}p{color:#9AA3B8;font-size:13.5px;margin:6px 0}a{color:#07C160}</style></head><body>'
                . '<div class="b"><h1>系统已安装</h1>'
                . '<p>为避免数据被覆盖，安装向导已锁定。</p>'
                . '<p>如需重置数据，请先登录 <a href="admin/login.php">管理后台</a>，再带 <code>?force=1</code> 访问本页。</p>'
                . '<p>生产环境建议直接删除 install.php。</p></div></body></html>';
            exit;
        }
        if (!$force) {
            echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><title>系统已安装</title>'
                . '<style>body{font-family:-apple-system,"Microsoft YaHei",sans-serif;background:#0F1420;color:#E7ECF5;display:flex;height:100vh;align-items:center;justify-content:center;margin:0}'
                . '.b{max-width:460px;padding:36px;border-radius:18px;background:rgba(23,29,44,.85);border:1px solid rgba(255,255,255,.08);line-height:1.9}'
                . 'a{color:#07C160}</style></head><body><div class="b"><h1>系统已安装</h1>'
                . '<p>当前不会重复写入种子数据。</p>'
                . '<p>如确需补齐默认数据，请访问 <a href="?force=1">install.php?force=1</a>；该操作不会清空已有数据。</p>'
                . '<p><a href="index.php">返回前台</a> · <a href="admin/index.php">进入后台</a></p></div></body></html>';
            exit;
        }
    }
}

try {
    cc_install_schema();
    $log[] = '数据表已创建（' . (is_mysql() ? 'MySQL' : 'SQLite') . '）';
    ensure_default_assets();
    $migrated = brand_migrate();
    try { set_setting('brand_ver', '2'); } catch (Throwable $e) {}
    if ($migrated > 0) $log[] = '历史数据品牌字样已升级为 CC（' . $migrated . ' 条记录）';
} catch (Throwable $e) {
    $msg = '数据库初始化失败：' . $e->getMessage();
    if ($isCli) {
        fwrite(STDERR, $msg . "\n");
        exit(1);
    }
    http_response_code(500);
    echo '<pre style="padding:20px;font:14px/1.6 monospace">' . e($msg) . '</pre>';
    exit;
}

$hasUsers = (int)val('SELECT COUNT(*) FROM users') > 0;
if ($hasUsers && !$force) {
    $log[] = '检测到已有数据，跳过初始化种子（如需重置：install.php?force=1）';
} else {
    $now = now();

    /* ---------- 基础设置 ---------- */
    $defaults = [
        'site_name'        => 'CC商聊',
        'site_slogan'      => '连接每一次商机',
        'site_logo'        => 'icons/icon-192.png',
        'service_contact'  => '',
        'service_uid'      => '10086',
        'official_gid'     => '666666',
        'notice_title'     => 'CC商聊平台规则与邀请有礼',
        'notice_content'   => "欢迎来到 CC商聊！为了让大家有安全、顺畅的交流环境，请花一分钟了解平台规则与新人福利。\n\n【平台规则】\n1. 文明交流，禁止发布违法违规、色情低俗、诈骗赌博等内容；\n2. 禁止恶意骚扰、冒充官方、倒卖账号；\n3. 充值、提现均通过官方客服或 USDT 通道，谨防私下交易诈骗。\n\n【新人福利】\n邀请好友注册，双方均可获得 CC币奖励，详情见「广场 → 邀请有礼」。",
        'invite_reward'    => '0',
        'withdraw_min'     => '100',
        'group_max_limit'  => '2000',
        'register_open'    => '1',
        'reg_id_len'       => '8',
        'svip_min_level'   => '4',
        'smtp_enabled'     => '0',
        'smtp_host'        => '',
        'smtp_port'        => '465',
        'smtp_secure'      => 'ssl',
        'smtp_user'        => '',
        'smtp_pass'        => '',
        'smtp_from'        => '',
        'smtp_name'        => '',
        'email_verify'     => '0',
        'live_enabled'     => '1',
        'call_enabled'     => '1',
        'usdt_network'     => 'TRC20',
        'usdt_address'     => (string)cfg('usdt.address'),
        'usdt_rate'        => (string)cfg('usdt.rate'),
        'usdt_min_coin'    => (string)cfg('usdt.min_coin'),
        'usdt_auto_check'  => '1',
        'usdt_trongrid_key'=> (string)cfg('usdt.trongrid_key'),
        'usdt_expire'      => '1800',
        'app_version'      => CC_VERSION,
        'app_download_url' => '',
    ];
    foreach ($defaults as $k => $v) set_setting($k, $v);
    $log[] = '站点设置已写入';

    /* ---------- 管理员 ---------- */
    if (!val('SELECT id FROM admins LIMIT 1')) {
        q('INSERT INTO admins (username,password,role,status,created_at) VALUES (?,?,?,?,?)', [
            'admin', password_hash('admin123456', PASSWORD_DEFAULT), 'super', 0, $now,
        ]);
        $log[] = '管理员已创建：admin / admin123456（请立即修改）';
    }

    /* ---------- 内置账号 ---------- */
    $mk = function (string $account, string $nick, string $pwd, array $extra = []) use ($now) {
        $exists = one('SELECT * FROM users WHERE account=?', [$account]);
        if ($exists) return $exists;
        $base = [
            'account' => $account, 'yx_id' => $account, 'nickname' => $nick,
            'password' => password_hash($pwd, PASSWORD_DEFAULT),
            // 邀请码直接使用 CC号，便于记忆与分享
            'invite_code' => (string)$account,
            'created_at' => $now, 'last_active_at' => $now, 'online' => 0,
            'avatar' => '', 'bio' => '', 'gender' => 0, 'region' => '中国',
            'email' => '', 'phone' => '', 'coin' => 0, 'vip_level' => 0, 'vip_expire_at' => 0,
            'is_developer' => 0, 'status' => 0, 'ban_reason' => '', 'ban_until' => 0, 'ban_forever' => 0,
            'pay_password' => '', 'settings' => '{}',
        ];
        $row = array_merge($base, $extra);
        $cols = array_keys($row);
        $sql = 'INSERT INTO users (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')';
        q($sql, array_values($row));
        $id = last_id();
        return one('SELECT * FROM users WHERE id=?', [$id]);
    };

    $bot = $mk('990375', 'CC商聊机器人', bin2hex(random_bytes(8)), [
        'bio' => '官方 AI 助手，随时为你解答使用问题', 'is_developer' => 1, 'vip_level' => 3,
        'vip_expire_at' => $now + 86400 * 3650,
    ]);
    $svc = $mk('10086', 'CC商聊官方客服', bin2hex(random_bytes(8)), [
        'bio' => '充值、提现、账号问题，随时找我', 'vip_level' => 3,
        'vip_expire_at' => $now + 86400 * 3650, 'region' => '官方',
    ]);
    $demo = $mk('740999800', '哈哈', 'aa123456', [
        'email' => 'roe888@foxmail.com', 'bio' => '', 'coin' => 888,
    ]);
    $log[] = '内置账号：机器人 990375 / 官方客服 10086 / 演示账号 740999800（密码 aa123456）';

    /* ---------- 官方群 ---------- */
    if (!val('SELECT id FROM groups LIMIT 1')) {
        q('INSERT INTO groups (gid,name,avatar,intro,owner_uid,member_limit,join_mode,is_public,mute_all,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', [
            666666, 'CC官方群聊', '', 'CC商聊官方交流群，欢迎加入', (int)$svc['id'], 2000, 0, 1, 0, 1, $now,
        ]);
        $gid = 666666;
        foreach ([[$svc['id'], 2], [$bot['id'], 1], [$demo['id'], 0]] as $gm) {
            q('INSERT INTO group_members (gid,uid,role,nickname,mute_until,joined_at,last_read_id,pinned) VALUES (?,?,?,?,0,?,0,0)', [
                $gid, (int)$gm[0], (int)$gm[1], '', $now,
            ]);
        }
        q('INSERT INTO conversations (uid,ctype,peer_id,last_msg,last_time,unread,pinned,muted,visible) VALUES (?,2,?,?,?,0,1,0,1)', [
            (int)$demo['id'], 666666, '[图片]', $now - 600,
        ]);
        $log[] = '官方群已创建：666666';
    }

    /* ---------- 好友关系 ---------- */
    $beFriend = function (int $a, int $b) use ($now) {
        if (!val('SELECT id FROM friends WHERE uid=? AND fid=?', [$a, $b])) {
            q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [$a, $b, '', 1, $now]);
        }
        if (!val('SELECT id FROM friends WHERE uid=? AND fid=?', [$b, $a])) {
            q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [$b, $a, '', 1, $now]);
        }
    };
    $beFriend((int)$demo['id'], (int)$bot['id']);
    $beFriend((int)$demo['id'], (int)$svc['id']);

    /* ---------- 公告 ---------- */
    if (!val('SELECT id FROM notices LIMIT 1')) {
        q('INSERT INTO notices (title,content,is_top,status,created_at,updated_at) VALUES (?,?,?,?,?,?)', [
            (string)setting('notice_title'), (string)setting('notice_content'), 1, 1, $now, $now,
        ]);
    }

    /* ---------- 礼物 ---------- */
    if (!val('SELECT id FROM gifts LIMIT 1')) {
        $gifts = [
            ['玫瑰', '🌹', 10], ['棒棒糖', '🍭', 20], ['奶茶', '🧋', 50], ['蛋糕', '🎂', 100],
            ['皇冠', '👑', 520], ['跑车', '🏎️', 1314], ['火箭', '🚀', 5200], ['城堡', '🏰', 13140],
        ];
        foreach ($gifts as $i => $g) {
            q('INSERT INTO gifts (name,icon,price,status,sort) VALUES (?,?,?,1,?)', [$g[0], $g[1], $g[2], $i]);
        }
    }

    /* ---------- VIP 套餐 ---------- */
    if (!val('SELECT id FROM vip_plans LIMIT 1')) {
        $plans = [
            ['VIP 周卡', 7, 680, 1], ['VIP 月卡', 30, 1980, 2], ['VIP 季卡', 90, 4980, 3], ['SVIP 年卡', 365, 16800, 4],
        ];
        foreach ($plans as $i => $p) {
            q('INSERT INTO vip_plans (name,days,price,level,status,sort) VALUES (?,?,?,?,1,?)', [$p[0], $p[1], $p[2], $p[3], $i]);
        }
    }

    /* ---------- 邀请阶梯奖励 ---------- */
    if (!val('SELECT id FROM invite_rewards LIMIT 1')) {
        $rw = [
            ['VIP 月卡',   '💎', 'vip',    1, 30, 0, 20, 0],
            ['SVIP 月卡',  '👑', 'svip',   4, 30, 0, 30, 1],
            ['ABBBBC 靓号', '🔢', 'pretty', 1, 0,  0, 50, 2],
        ];
        foreach ($rw as $g) {
            q('INSERT INTO invite_rewards (name,icon,type,level,days,coin,need_count,sort,status) VALUES (?,?,?,?,?,?,?,?,1)',
                [$g[0], $g[1], $g[2], $g[3], $g[4], $g[5], $g[6], $g[7]]);
        }
    }

    /* ---------- 靓号 ---------- */
    if (!val('SELECT id FROM pretty_ids LIMIT 1')) {
        $ids = ['10086' => 8888, '666666' => 66666, '888888' => 88888, '520520' => 5200, '1314520' => 13140, '100000' => 50000];
        foreach ($ids as $n => $price) {
            q('INSERT INTO pretty_ids (yx_id,price,status,created_at) VALUES (?,?,0,?)', [(string)$n, $price, $now]);
        }
    }

    /* ---------- 表情 ---------- */
    if (!val('SELECT id FROM emojis LIMIT 1')) {
        $es = ['微笑' => '😊', '大笑' => '😄', '偷笑' => '🤭', '酷' => '😎', '亲亲' => '😘', '害羞' => '😳',
               '流泪' => '😭', '笑哭' => '😂', '生气' => '😡', '爱心' => '❤️', '点赞' => '👍', '鼓掌' => '👏',
               'ok' => '👌', '握手' => '🤝', '抱拳' => '🙏', '玫瑰' => '🌹', '蛋糕' => '🎂', '红包' => '🧧'];
        foreach ($es as $n => $ch) {
            q('INSERT INTO emojis (uid,name,url,created_at) VALUES (0,?,?,?)', [$n, 'emoji:' . $ch, $now]);
        }
    }

    /* ---------- 官方欢迎消息 ---------- */
    if (!val('SELECT id FROM messages LIMIT 1')) {
        foreach ([[1, (int)$bot['id'], (int)$demo['id'], 0, 1, '你好，我是 CC商聊机器人，可以帮你解答使用中的问题。发送「帮助」查看更多玩法。'],
                  [1, (int)$svc['id'], (int)$demo['id'], 0, 1, '充值支持微信、支付宝、USDT（TRC20），需要帮助随时联系我。']] as $m) {
            q('INSERT INTO messages (ctype,from_uid,to_uid,gid,type,content,extra,created_at) VALUES (?,?,?,?,?,?,?,?)', [
                $m[0], $m[1], $m[2], $m[3], $m[4], $m[5], '', $now - 3600,
            ]);
        }
        // 私聊会话
        foreach ([[$bot['id'], '你好，我是 CC商聊机器人，可以帮你解答使用中的问题。'], [$svc['id'], '充值支持微信、支付宝、USDT（TRC20），需要帮助随时联系我。']] as $c) {
            conv_touch((int)$demo['id'], 1, (int)$c[0], $c[1], $now - 3600, 0);
            conv_touch((int)$c[0], 1, (int)$demo['id'], $c[1], $now - 3600, 0);
        }
        conv_touch((int)$demo['id'], 2, 666666, '欢迎加入 CC官方群聊', $now - 600, 0);
    }

    $log[] = '种子数据初始化完成';
}

$title = 'CC商聊 · 安装';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",Arial,sans-serif;background:linear-gradient(135deg,#0B0F19,#131A2A);color:#E7ECF5;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{width:100%;max-width:560px;background:rgba(23,29,44,.8);border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:34px;box-shadow:0 30px 80px rgba(0,0,0,.5)}
h1{font-size:22px;margin-bottom:6px}
p.sub{color:#8A94AB;font-size:13px;margin-bottom:22px}
ul{list-style:none;display:flex;flex-direction:column;gap:10px}
li{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:12px 14px;font-size:13.5px;color:#C9D3E5;display:flex;gap:8px}
li::before{content:"✓";color:#22C55E;font-weight:700}
.actions{display:flex;gap:10px;margin-top:24px;flex-wrap:wrap}
a.btn{display:inline-flex;align-items:center;justify-content:center;height:46px;padding:0 22px;border-radius:12px;background:linear-gradient(135deg,#07C160,#06AD56);color:#fff;text-decoration:none;font-weight:600;font-size:14px}
a.btn.ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:#C9D3E5}
.note{margin-top:18px;font-size:12px;color:#6B7590;line-height:1.8}
code{color:#7AA2FF}
</style>
</head>
<body>
<div class="card">
  <h1>CC商聊 · 安装完成</h1>
  <p class="sub">企业级即时通讯系统 · 版本 <?= e(CC_VERSION) ?></p>
  <ul>
    <?php foreach ($log as $l): ?>
      <li><?= e($l) ?></li>
    <?php endforeach; ?>
  </ul>
  <div class="actions">
    <a class="btn" href="index.php">进入前台</a>
    <a class="btn ghost" href="admin/login.php">管理后台</a>
    <a class="btn ghost" href="login.php">登录页</a>
  </div>
  <p class="note">
    管理后台默认账号：<code>admin</code> / <code>admin123456</code>（登录后请立即在「系统设置 → 管理员」中修改）<br>
    演示账号：<code>740999800</code> / <code>aa123456</code><br>
    USDT 收款地址、汇率、自动核对开关在「后台 → 充值管理 → USDT 设置」中配置。
  </p>
</div>
</body>
</html>
