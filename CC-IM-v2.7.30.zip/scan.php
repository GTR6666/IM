<?php
/**
 * CC商聊 - 扫一扫
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
cc_head('扫一扫', ['body_class' => 'app-body', 'css' => '
.scan-stage{position:relative;flex:1;background:#000;overflow:hidden;display:flex;align-items:center;justify-content:center;min-height:0}
.scan-stage video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.scan-frame{position:relative;width:min(64vw,250px);height:min(64vw,250px);border-radius:18px;box-shadow:0 0 0 100vmax rgba(0,0,0,.45);z-index:2}
.scan-frame i{position:absolute;width:26px;height:26px;border:3px solid #07C160;border-radius:4px}
.scan-frame i:nth-child(1){left:-2px;top:-2px;border-right:0;border-bottom:0;border-top-left-radius:10px}
.scan-frame i:nth-child(2){right:-2px;top:-2px;border-left:0;border-bottom:0;border-top-right-radius:10px}
.scan-frame i:nth-child(3){left:-2px;bottom:-2px;border-right:0;border-top:0;border-bottom-left-radius:10px}
.scan-frame i:nth-child(4){right:-2px;bottom:-2px;border-left:0;border-top:0;border-bottom-right-radius:10px}
.scan-line{position:absolute;left:8%;right:8%;height:2px;background:linear-gradient(90deg,transparent,#07C160,transparent);animation:scanmv 2.2s ease-in-out infinite;z-index:3}
@keyframes scanmv{0%{top:8%}50%{top:92%}100%{top:8%}}
.scan-hint{position:absolute;left:0;right:0;bottom:calc(18px + var(--safe-b));text-align:center;color:#fff;font-size:12.5px;z-index:3;text-shadow:0 1px 4px rgba(0,0,0,.6)}
']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('扫一扫', 'me.php'); ?>

    <div class="scan-stage" id="stage">
      <video id="cam" playsinline muted autoplay></video>
      <div class="scan-frame" id="frame">
        <i></i><i></i><i></i><i></i>
        <div class="scan-line" id="scanLine"></div>
      </div>
      <div class="scan-hint" id="hint">将二维码放入框内，即可自动识别</div>
    </div>

    <div style="background:var(--card);border-top:1px solid var(--line);padding:14px 12px calc(16px + var(--safe-b))">
      <div class="gap8">
        <button class="btn ghost" id="btnAlbum" style="flex:1">从相册选择</button>
        <button class="btn" id="btnManual" style="flex:1">手动输入</button>
      </div>
      <div class="t3 small center" style="margin-top:10px;line-height:1.6" id="tipLine">
        支持二维码 / 条形码，识别 CC号、群号、邀请链接
      </div>
    </div>
  </div>
</div>

<input type="file" id="albumFile" accept="image/*" style="display:none">

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var video = document.getElementById('cam');
  var stage = document.getElementById('stage');
  var hint = document.getElementById('hint');
  var stream = null, detecting = false, stopped = false, detector = null;

  function stopCam(){
    stopped = true;
    detecting = false;
    if (stream){
      stream.getTracks().forEach(function(t){ try { t.stop(); } catch (e) {} });
      stream = null;
    }
    try { video.srcObject = null; } catch (e) {}
  }

  /* ---------- 跳转规则 ---------- */
  function parseTarget(raw){
    var text = String(raw || '').trim();
    if (!text) return null;
    var gid = '', uid = '';
    try {
      if (/^https?:\/\//i.test(text)){
        var u = new URL(text);
        var sp = u.searchParams;
        gid = sp.get('gid') || '';
        uid = sp.get('uid') || '';
        if (!gid && !uid){
          // 兼容 hash 路由：/x#/group?gid=123
          var h = u.hash || '';
          var mg = /gid=(\d+)/.exec(h), mu = /uid=(\d+)/.exec(h);
          if (mg) gid = mg[1];
          if (mu) uid = mu[1];
          if (!gid && !uid) text = u.href;
        }
      }
    } catch (e) {}
    if (!gid){
      var g2 = /[?&#]gid=(\d+)/.exec(text);
      if (g2) gid = g2[1];
    }
    if (!uid){
      var u2 = /[?&#]uid=(\d+)/.exec(text);
      if (u2) uid = u2[1];
    }
    if (gid) return { type: 'group', value: gid };
    if (uid) return { type: 'user', value: uid };
    if (/^\d{7}$/.test(text)) return { type: 'group', value: text };
    if (/^[A-Za-z0-9_\-]{3,32}$/.test(text)) return { type: 'ak', value: text };
    return { type: 'ak', value: text };
  }

  function go(target){
    if (!target) return;
    stopCam();
    var url;
    if (target.type === 'group') url = 'group_card.php?gid=' + encodeURIComponent(target.value);
    else if (target.type === 'user') url = 'user.php?uid=' + encodeURIComponent(target.value);
    else url = 'add.php?kw=' + encodeURIComponent(target.value);
    hint.textContent = '识别成功，正在打开…';
    setTimeout(function(){ location.href = url; }, 380);
  }

  function onCode(raw){
    if (stopped) return;
    var t = parseTarget(raw);
    if (!t) return;
    stopCam();
    CC.toast('识别成功：' + raw);
    go(t);
  }

  /* ---------- 摄像头 ---------- */
  function startCam(){
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      cameraFail('当前浏览器不支持摄像头调用');
      return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 1280 } }, audio: false })
      .then(function(s){
        stream = s;
        video.srcObject = s;
        video.setAttribute('playsinline', '');
        var p = video.play();
        if (p && p.catch) p.catch(function(){});
        startDetect();
      })
      .catch(function(err){
        var msg = '无法访问摄像头';
        if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) msg = '摄像头权限被拒绝';
        else if (err && err.name === 'NotFoundError') msg = '未检测到可用摄像头';
        cameraFail(msg);
      });
  }

  function cameraFail(msg){
    stopCam();
    var frame = document.getElementById('frame');
    if (frame) frame.style.display = 'none';
    stage.style.background = 'var(--bg)';
    hint.style.color = 'var(--t3)';
    hint.style.textShadow = 'none';
    hint.innerHTML = CC.esc(msg) + '<br><span style="font-size:11.5px">可改用相册图片或手动输入</span>';
    document.getElementById('tipLine').textContent = '识别到的 CC号 / 群号 会自动跳转，跳转前请确认来源';
  }

  function startDetect(){
    if (!('BarcodeDetector' in window)){
      hint.textContent = '当前浏览器不支持自动识别，请手动输入或从相册选择';
      return;
    }
    try {
      detector = new BarcodeDetector({ formats: ['qr_code', 'ean_13', 'ean_8', 'code_128', 'code_39', 'itf'] });
    } catch (e) {
      try { detector = new BarcodeDetector(); } catch (e2) { detector = null; }
    }
    if (!detector){
      hint.textContent = '当前浏览器不支持自动识别，请手动输入';
      return;
    }
    detecting = true;
    var loop = function(){
      if (!detecting || stopped) return;
      if (video.readyState >= 2 && !video.paused){
        detector.detect(video).then(function(codes){
          if (codes && codes.length){
            var val = codes[0].rawValue || '';
            if (val) onCode(val);
          }
        }).catch(function(){});
      }
      setTimeout(loop, 320);
    };
    loop();
  }

  /* ---------- 相册 ---------- */
  var album = document.getElementById('albumFile');
  document.getElementById('btnAlbum').onclick = function(){ album.click(); };
  album.onchange = function(){
    var f = album.files && album.files[0];
    album.value = '';
    if (!f) return;
    if (!/^image\//.test(f.type)){ CC.toast('请选择图片文件'); return; }
    var url = URL.createObjectURL(f);
    var img = new Image();
    img.onload = function(){
      var run = function(det){
        if (!det){ manualFallback('浏览器不支持本地识别，请手动输入二维码内容'); return; }
        det.detect(img).then(function(codes){
          URL.revokeObjectURL(url);
          if (codes && codes.length && codes[0].rawValue){
            onCode(codes[0].rawValue);
          } else {
            manualFallback('暂不支持本地识别该图片，可手动输入');
          }
        }).catch(function(){
          URL.revokeObjectURL(url);
          manualFallback('暂不支持本地识别该图片，可手动输入');
        });
      };
      if ('BarcodeDetector' in window){
        try { run(new BarcodeDetector({ formats: ['qr_code', 'ean_13', 'code_128', 'code_39'] })); }
        catch (e) {
          try { run(new BarcodeDetector()); } catch (e2) { run(null); }
        }
      } else run(null);
    };
    img.onerror = function(){ URL.revokeObjectURL(url); manualFallback('图片读取失败，请重新选择'); };
    img.src = url;
  };

  /* ---------- 手动输入 ---------- */
  function manualFallback(msg){
    if (msg) CC.toast(msg);
    CC.prompt({ title: '手动输入', text: msg || '', placeholder: 'CC号 / 群号 / 链接', max: 200 })
      .then(function(v){
        if (v === null || v === '') return;
        var t = parseTarget(v);
        if (!t){ CC.toast('无法识别该内容'); return; }
        go(t);
      });
  }
  document.getElementById('btnManual').onclick = function(){ manualFallback(''); };

  document.addEventListener('visibilitychange', function(){
    if (document.hidden && stream && stream.getTracks){
      stream.getTracks().forEach(function(t){ try { t.pause ? t.pause() : t.stop(); } catch (e) {} });
    }
  });
  window.addEventListener('pagehide', stopCam);

  var pre = CC.qs('text');
  if (pre){ setTimeout(function(){ onCode(pre); }, 200); }
  else startCam();
})();
</script>
<?php cc_foot(); ?>
