<?php
/**
 * CC商聊 - 我的群组（已加入 / 我创建的）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

cc_head('我的群组');
?>
<div class="app">
  <div class="page">
    <?php cc_topbar('我的群组', 'index.php', '<a href="group_create.php" style="color:var(--brand);font-size:13.5px;font-weight:500;padding:4px 0">创建群聊</a>'); ?>
    <div class="tabs">
      <button class="active" data-tab="joined">已加入的群</button>
      <button data-tab="created">我创建的群</button>
    </div>
    <div class="page-body no-tab" style="padding-top:2px">
      <div class="loading" id="loading"><span class="spin"></span> 加载中…</div>
      <div class="conv-list" id="listJoined"></div>
      <div class="conv-list hidden" id="listCreated"></div>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
document.addEventListener('DOMContentLoaded', function () {
  var DATA = { joined: [], created: [] };
  var cur = 'joined';
  var listJoined = document.getElementById('listJoined');
  var listCreated = document.getElementById('listCreated');
  var loading = document.getElementById('loading');

  function row(g) {
    var unread = parseInt(g.unread || 0, 10);
    return '<a class="conv-item" href="group_info.php?gid=' + g.gid + '">' +
      CC.avatarHtml({ avatar: g.avatar, nickname: g.name }) +
      '<div class="conv-main">' +
        '<div class="conv-top"><div class="conv-name">' + CC.esc(g.name) + '</div>' +
          '<div class="conv-time">' + (g.members || 0) + '/' + (g.member_limit || 0) + ' 人</div></div>' +
        '<div class="conv-bottom"><div class="conv-msg">群号 ' + g.gid + '</div>' +
          (unread > 0 ? '<span class="conv-badge">' + (unread > 99 ? '99+' : unread) + '</span>' : '') +
        '</div>' +
      '</div></a>';
  }

  function emptyBox(text, href, label) {
    return '<div class="empty"><div class="ico">👥</div><div>' + text + '</div>' +
      '<div style="font-size:12px;margin-top:6px"><a href="' + href + '" style="color:var(--brand)">' + label + '</a></div></div>';
  }

  function paint() {
    var isJoined = cur === 'joined';
    var arr = DATA[cur] || [];
    var el = isJoined ? listJoined : listCreated;
    el.innerHTML = arr.length ? arr.map(row).join('') : (isJoined
      ? emptyBox('还没有加入任何群聊', 'group_join.php', '去加入群聊')
      : emptyBox('还没有创建过群聊', 'group_create.php', '创建群聊'));
  }

  document.querySelectorAll('.tabs button').forEach(function (b) {
    b.onclick = function () {
      document.querySelectorAll('.tabs button').forEach(function (x) { x.classList.remove('active'); });
      b.classList.add('active');
      cur = b.getAttribute('data-tab');
      listJoined.classList.toggle('hidden', cur !== 'joined');
      listCreated.classList.toggle('hidden', cur !== 'created');
      paint();
    };
  });

  CC.api('group_list').then(function (d) {
    DATA.joined = d.joined || [];
    DATA.created = d.created || [];
    loading.classList.add('hidden');
    paint();
  }).catch(function (e) {
    loading.classList.add('hidden');
    CC.toast(e.message || '加载失败');
  });
});
</script>
<?php cc_foot(); ?>
