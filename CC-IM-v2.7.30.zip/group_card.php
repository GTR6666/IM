<?php
/**
 * CC商聊 - 群名片（从分享卡片进入，未加入也可查看）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myUid = (int)$me['id'];

function p_av(string $avatar, string $name, string $cls = ''): string
{
    if ($avatar !== '') return '<span class="avatar ' . $cls . '"><img src="' . e($avatar) . '" alt=""></span>';
    return '<span class="avatar ' . $cls . '" style="background:var(--brand)">' . e(mb_substr($name !== '' ? $name : '?', 0, 1)) . '</span>';
}

$gid = (int)($_GET['gid'] ?? 0);
$g = $gid > 0 ? group_by_gid($gid) : null;
$alive = $g && (int)$g['status'] === 1;

if (!$alive) {
    cc_head('群名片');
    ?>
    <div class="app">
      <div class="page">
        <?php cc_topbar('群名片', 'index.php'); ?>
        <div class="page-body no-tab">
          <div class="empty">
            <div class="ico">👥</div>
            <div>群聊不存在或已解散</div>
            <div style="margin-top:14px"><a class="btn" href="group_list.php" style="max-width:200px;margin:0 auto">返回我的群组</a></div>
          </div>
        </div>
      </div>
    </div>
    <?php
    cc_foot();
    exit;
}

$role = group_role($gid, $myUid);
$joined = $role >= 0;
$members = (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid]);
$owner = one('SELECT id,nickname,avatar,yx_id FROM users WHERE id=?', [(int)$g['owner_uid']]);
$pending = (int)val('SELECT COUNT(*) FROM group_join_requests WHERE gid=? AND uid=? AND status=0', [$gid, $myUid]);
$joinMode = (int)$g['join_mode'];
$modeText = $joinMode === 1 ? '需审核加入' : ($joinMode === 2 ? '不允许加入' : '自由加入');

cc_head('群名片');
?>
<div class="app">
  <div class="page">
    <?php cc_topbar('群名片', 'index.php'); ?>
    <div class="page-body no-tab">

      <div class="card" style="text-align:center;padding:26px 16px 20px">
        <div style="display:inline-block"><?= p_av((string)$g['avatar'], (string)$g['name'], 'xl') ?></div>
        <div style="font-size:19px;font-weight:600;margin-top:12px"><?= e($g['name']) ?></div>
        <div class="t3 small" style="margin-top:4px">群号 <?= (int)$g['gid'] ?></div>
        <div style="display:flex;justify-content:center;gap:8px;margin-top:12px;flex-wrap:wrap">
          <span class="pill"><?= $members ?>/<?= (int)$g['member_limit'] ?> 人</span>
          <span class="pill"><?= e($modeText) ?></span>
          <?php if ((int)$g['mute_all'] === 1): ?><span class="pill" style="color:var(--red)">全员禁言</span><?php endif; ?>
        </div>
      </div>

      <?php if (trim((string)$g['intro']) !== ''): ?>
      <div class="card">
        <div style="font-weight:600;margin-bottom:6px">群简介</div>
        <div style="font-size:13.5px;line-height:1.75;color:var(--t2);white-space:pre-wrap;word-break:break-word"><?= e($g['intro']) ?></div>
      </div>
      <?php endif; ?>

      <div class="cell-group">
        <?php if ($owner): ?>
        <a class="cell" href="user.php?uid=<?= (int)$owner['id'] ?>">
          <div class="c-title">群主</div>
          <div class="c-value">
            <?= p_av((string)$owner['avatar'], (string)$owner['nickname'], 'sm') ?>
            <span style="margin-left:6px"><?= e($owner['nickname']) ?></span>
          </div>
          <span class="arrow">›</span>
        </a>
        <?php endif; ?>
        <div class="cell" id="cellCopy">
          <div class="c-title">群号</div>
          <div class="c-value"><?= (int)$g['gid'] ?> <span class="badge">复制</span></div>
        </div>
        <a class="cell" href="group_info.php?gid=<?= $gid ?>">
          <div class="c-title">群资料</div>
          <div class="c-value">成员与公告</div>
          <span class="arrow">›</span>
        </a>
      </div>

      <div style="padding:16px 12px 8px">
        <?php if ($joined): ?>
          <a class="btn" href="index.php?gid=<?= $gid ?>">进入群聊</a>
        <?php elseif ($pending): ?>
          <button class="btn ghost" id="btnJoin" disabled>已申请，等待群主审核</button>
        <?php elseif ($joinMode === 2): ?>
          <button class="btn ghost" disabled>该群不允许加入</button>
        <?php elseif ($members >= (int)$g['member_limit']): ?>
          <button class="btn ghost" disabled>群成员已满</button>
        <?php else: ?>
          <button class="btn" id="btnJoin">加入群聊</button>
        <?php endif; ?>
      </div>
      <div style="padding:0 12px 24px">
        <button class="btn ghost" id="btnShare">分享群号</button>
      </div>

      <?php if (!$joined): ?>
      <div class="empty" style="padding:8px 20px 28px;font-size:12px">加入后可查看群成员和群公告</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
document.addEventListener('DOMContentLoaded', function () {
  var GID = <?= $gid ?>;

  function copyText(t) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      CC.toast(ok ? '已复制' : '复制失败，请长按群号复制');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () { CC.toast('已复制'); }, fallback);
    } else {
      fallback();
    }
  }

  document.getElementById('cellCopy').onclick = function () { copyText(String(GID)); };
  document.getElementById('btnShare').onclick = function () { copyText(String(GID)); };

  var joinBtn = document.getElementById('btnJoin');
  if (joinBtn && !joinBtn.disabled) {
    joinBtn.onclick = function () {
      joinBtn.disabled = true;
      CC.api('group_join', { gid: GID }).then(function (d) {
        if (d && d.pending) {
          joinBtn.textContent = '已申请，等待群主审核';
          joinBtn.className = 'btn ghost';
          CC.toast('已提交申请');
        } else {
          CC.toast('已加入群聊');
          setTimeout(function () { location.href = 'index.php?gid=' + GID; }, 600);
        }
      }).catch(function (e) {
        CC.toast(e.message || '加入失败');
        joinBtn.disabled = false;
      });
    };
  }
});
</script>
<?php cc_foot(); ?>
