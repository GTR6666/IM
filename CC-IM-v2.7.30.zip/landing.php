<?php
/**
 * CC商聊 - 宣传落地页（公开、可被搜索引擎收录）
 * 内容与显示开关全部来自后台「运营 → 落地页」的配置。
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';

/* ---------- 读取配置 ---------- */
$LC = landing_config();
if (empty($LC['enabled'])) {
    // 未开放：直接跳登录页
    header('Location: login.php');
    exit;
}

$site   = (string)setting('site_name', 'CC商聊');
$slogan = (string)setting('site_slogan', '连接每一次商机');
$brand  = term_brand();
$idTerm = term_id();
$coin   = term_coin();
$base   = rtrim(site_url(''), '/');

$h = $LC['hero'];
$feat = $LC['features'];
$stats = $LC['stats'];
$dl = $LC['download'];
$faq = $LC['faq'];
$cta = $LC['cta'];
$foot = $LC['footer'];
$shots = $LC['shots'];

/* ---------- SEO ---------- */
$title = $h['title'] !== '' ? $h['title'] : ($brand . ' - ' . $slogan);
$desc  = $h['subtitle'] !== '' ? mb_substr($h['subtitle'], 0, 150)
     : ($brand . '是一款支持私聊、群聊、朋友圈、语音视频通话与群直播的即时通讯软件，注册即得专属' . $idTerm . '，支持手机与电脑多端使用。');
$kw    = mb_substr($brand . ',即时通讯软件,聊天软件,群聊,语音通话,视频通话,朋友圈,群直播,' . $idTerm . ',' . $coin, 0, 100);
$canonical = $base . '/landing.php';

/* JSON-LD：Organization + WebSite + SoftwareApplication (+ FAQPage) */
$ld = [
    '@context' => 'https://schema.org',
    '@graph'   => [
        [
            '@type' => 'Organization',
            '@id'   => $base . '/#org',
            'name'  => $brand,
            'url'   => $base . '/',
            'logo'  => $base . '/icons/icon-192.png',
        ],
        [
            '@type'     => 'WebSite',
            '@id'       => $base . '/#site',
            'name'      => $brand,
            'url'       => $base . '/',
            'inLanguage'=> 'zh-CN',
            'publisher' => ['@id' => $base . '/#org'],
        ],
        [
            '@type'               => 'SoftwareApplication',
            'name'                => $brand,
            'applicationCategory' => 'CommunicationApplication',
            'operatingSystem'     => 'iOS, Android, Web',
            'description'         => $desc,
            'url'                 => $canonical,
            'offers'              => ['@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'CNY'],
        ],
    ],
];
if (!empty($faq['show']) && $faq['items']) {
    $qa = [];
    foreach ($faq['items'] as $it) {
        if ($it['q'] === '' || $it['a'] === '') continue;
        $qa[] = ['@type' => 'Question', 'name' => $it['q'],
                 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $it['a']]];
    }
    if ($qa) $ld['@graph'][] = ['@type' => 'FAQPage', 'mainEntity' => $qa];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover">
<meta name="theme-color" content="#07C160">
<title><?= e($title) ?><?= $title !== $brand ? ' - ' . e($brand) : '' ?></title>
<meta name="description" content="<?= e($desc) ?>">
<meta name="keywords" content="<?= e($kw) ?>">
<meta name="robots" content="index,follow,max-image-preview:large">
<link rel="canonical" href="<?= e($canonical) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e($brand) ?>">
<meta property="og:title" content="<?= e($title) ?>">
<meta property="og:description" content="<?= e($desc) ?>">
<meta property="og:url" content="<?= e($canonical) ?>">
<meta property="og:image" content="<?= e($base) ?>/icons/icon-192.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($title) ?>">
<meta name="twitter:description" content="<?= e($desc) ?>">
<link rel="icon" type="image/png" href="icons/icon-192.png">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<link rel="manifest" href="manifest.php?v=<?= CC_VERSION ?>">
<script type="application/ld+json"><?= json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<style>
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{
  font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Helvetica Neue","Microsoft YaHei",sans-serif;
  color:#111A26;background:#fff;line-height:1.65;-webkit-font-smoothing:antialiased;
}
a{color:inherit;text-decoration:none}
img{max-width:100%;display:block}
.lp-wrap{max-width:1120px;margin:0 auto;padding:0 20px}
/* 顶栏 */
.lp-nav{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);backdrop-filter:saturate(180%) blur(14px);border-bottom:1px solid #EDF0F4}
.lp-nav .lp-wrap{display:flex;align-items:center;justify-content:space-between;height:62px}
.lp-logo{display:flex;align-items:center;gap:10px;font-weight:700;font-size:17px}
.lp-logo img{width:32px;height:32px;border-radius:9px}
.lp-nav-links{display:flex;align-items:center;gap:22px;font-size:14px;color:#4B5563}
.lp-nav-links a:hover{color:#07C160}
.lp-nav-cta{height:38px;padding:0 18px;border-radius:19px;background:#07C160;color:#fff;font-weight:600;display:inline-flex;align-items:center}
/* Hero */
.lp-hero{background:linear-gradient(160deg,#07C160 0%,#0AA86B 45%,#0B7A9E 100%);color:#fff;padding:70px 0 80px;position:relative;overflow:hidden}
.lp-hero::after{content:"";position:absolute;width:520px;height:520px;border-radius:50%;background:rgba(255,255,255,.08);right:-160px;top:-200px}
.lp-hero .lp-wrap{position:relative;z-index:1;text-align:center}
.lp-badge{display:inline-block;font-size:12.5px;padding:5px 14px;border-radius:999px;background:rgba(255,255,255,.18);margin-bottom:20px;letter-spacing:.5px}
.lp-hero h1{font-size:40px;line-height:1.25;margin:0 0 16px;font-weight:800;letter-spacing:-.5px}
.lp-hero p{font-size:17px;margin:0 auto 32px;max-width:660px;color:rgba(255,255,255,.9)}
.lp-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.lp-btn{height:52px;padding:0 30px;border-radius:26px;display:inline-flex;align-items:center;justify-content:center;font-size:16px;font-weight:600;transition:.18s}
.lp-btn-primary{background:#fff;color:#059669;box-shadow:0 10px 26px rgba(0,0,0,.16)}
.lp-btn-primary:hover{transform:translateY(-2px)}
.lp-btn-ghost{border:1.5px solid rgba(255,255,255,.6);color:#fff}
.lp-btn-ghost:hover{background:rgba(255,255,255,.12)}
/* 区块 */
.lp-sec{padding:72px 0}
.lp-sec-alt{background:#F7F9FC}
.lp-h2{font-size:30px;font-weight:800;text-align:center;margin:0 0 12px;letter-spacing:-.3px}
.lp-sub{text-align:center;color:#6B7280;font-size:15px;margin:0 auto 44px;max-width:620px}
/* 功能卡 */
.lp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}
.lp-card{background:#fff;border:1px solid #EDF0F4;border-radius:16px;padding:26px 22px;transition:.2s}
.lp-card:hover{box-shadow:0 12px 30px rgba(17,26,38,.07);transform:translateY(-2px);border-color:#DFF5E9}
.lp-ico{width:46px;height:46px;border-radius:13px;background:#E8F9F0;color:#07A65A;display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:14px}
.lp-card h3{font-size:17px;margin:0 0 8px;font-weight:700}
.lp-card p{margin:0;color:#6B7280;font-size:14px}
/* 数据带 */
.lp-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:30px;text-align:center}
.lp-stats b{display:block;font-size:36px;font-weight:800;color:#07A65A;line-height:1.2}
.lp-stats span{font-size:14px;color:#6B7280}
/* 截图 */
.lp-shots{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px}
.lp-shot{border-radius:18px;overflow:hidden;border:1px solid #EDF0F4;background:#F7F9FC}
.lp-shot img{width:100%;height:auto;object-fit:cover}
/* 下载 */
.lp-dl{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-top:8px}
.lp-dl a{display:inline-flex;align-items:center;gap:9px;height:54px;padding:0 26px;border-radius:14px;background:#111A26;color:#fff;font-weight:600;font-size:15px}
.lp-dl a:hover{background:#243043}
.lp-dl .tip{margin-top:16px;text-align:center;color:#6B7280;font-size:13px}
/* FAQ */
.lp-faq{max-width:820px;margin:0 auto}
.lp-faq details{border-bottom:1px solid #EDF0F4;padding:18px 0}
.lp-faq summary{cursor:pointer;font-weight:600;font-size:16px;list-style:none;display:flex;justify-content:space-between;gap:12px}
.lp-faq summary::-webkit-details-marker{display:none}
.lp-faq summary::after{content:"+";color:#07C160;font-weight:700;font-size:20px;line-height:1}
.lp-faq details[open] summary::after{content:"−"}
.lp-faq p{margin:12px 0 0;color:#6B7280;font-size:14.5px;line-height:1.8}
/* CTA */
.lp-cta{background:linear-gradient(135deg,#07C160,#059669);border-radius:22px;padding:52px 28px;text-align:center;color:#fff}
.lp-cta h2{font-size:28px;margin:0 0 10px;font-weight:800}
.lp-cta p{margin:0 0 26px;color:rgba(255,255,255,.9)}
/* 页脚 */
.lp-foot{background:#0E1620;color:#9AA5B1;padding:44px 0 32px;font-size:13.5px}
.lp-foot .lp-wrap{display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap;align-items:flex-start}
.lp-foot a{color:#9AA5B1}
.lp-foot a:hover{color:#fff}
.lp-foot .lp-copy{margin-top:24px;padding-top:18px;border-top:1px solid #1E2A38;text-align:center;color:#69727E;font-size:12.5px}
@media (max-width:640px){
  .lp-hero{padding:52px 0 62px}
  .lp-hero h1{font-size:28px}
  .lp-hero p{font-size:15px}
  .lp-sec{padding:52px 0}
  .lp-h2{font-size:23px}
  .lp-nav-links a:not(.lp-nav-cta){display:none}
  .lp-stats b{font-size:28px}
}
</style>
</head>
<body>

<header class="lp-nav">
  <div class="lp-wrap">
    <a class="lp-logo" href="landing.php">
      <img src="icons/icon-192.png" alt="<?= e($brand) ?> 应用图标" width="32" height="32">
      <span><?= e($brand) ?></span>
    </a>
    <nav class="lp-nav-links">
      <?php if (!empty($feat['show'])): ?><a href="#features">功能特色</a><?php endif; ?>
      <?php if (!empty($dl['show'])): ?><a href="#download">下载 App</a><?php endif; ?>
      <?php if (!empty($faq['show'])): ?><a href="#faq">常见问题</a><?php endif; ?>
      <a href="login.php">登录</a>
      <a class="lp-nav-cta" href="<?= e($h['btn1_url'] ?: 'register.php') ?>"><?= e($h['btn1'] ?: '免费注册') ?></a>
    </nav>
  </div>
</header>

<?php if (!empty($h['show'])): ?>
<section class="lp-hero">
  <div class="lp-wrap">
    <?php if ($h['badge'] !== ''): ?><div class="lp-badge"><?= e($h['badge']) ?></div><?php endif; ?>
    <h1><?= e($h['title']) ?></h1>
    <?php if ($h['subtitle'] !== ''): ?><p><?= e($h['subtitle']) ?></p><?php endif; ?>
    <div class="lp-btns">
      <a class="lp-btn lp-btn-primary" href="<?= e($h['btn1_url'] ?: 'register.php') ?>"><?= e($h['btn1'] ?: '免费注册') ?></a>
      <?php if ($h['btn2'] !== ''): ?>
      <a class="lp-btn lp-btn-ghost" href="<?= e($h['btn2_url'] ?: 'login.php') ?>"><?= e($h['btn2']) ?></a>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($stats['show']) && $stats['items']): ?>
<section class="lp-sec lp-sec-alt">
  <div class="lp-wrap">
    <div class="lp-stats">
      <?php foreach ($stats['items'] as $it): if ($it['num'] === '' && $it['label'] === '') continue; ?>
      <div><b><?= e($it['num']) ?></b><span><?= e($it['label']) ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($feat['show']) && $feat['items']): ?>
<section class="lp-sec" id="features">
  <div class="lp-wrap">
    <h2 class="lp-h2"><?= e($feat['title']) ?></h2>
    <?php if ($feat['subtitle'] !== ''): ?><p class="lp-sub"><?= e($feat['subtitle']) ?></p><?php endif; ?>
    <div class="lp-grid">
      <?php foreach ($feat['items'] as $it): ?>
      <article class="lp-card">
        <div class="lp-ico" aria-hidden="true"><?= e($it['icon']) ?></div>
        <h3><?= e($it['title']) ?></h3>
        <p><?= e($it['desc']) ?></p>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($shots['show']) && $shots['items']): ?>
<section class="lp-sec lp-sec-alt">
  <div class="lp-wrap">
    <h2 class="lp-h2"><?= e($shots['title']) ?></h2>
    <?php if ($shots['subtitle'] !== ''): ?><p class="lp-sub"><?= e($shots['subtitle']) ?></p><?php endif; ?>
    <div class="lp-shots">
      <?php foreach ($shots['items'] as $it): if ($it['img'] === '') continue; ?>
      <figure class="lp-shot" style="margin:0">
        <img src="<?= e($it['img']) ?>" alt="<?= e($it['alt'] ?: ($brand . ' 界面截图')) ?>" loading="lazy">
      </figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($dl['show'])): ?>
<section class="lp-sec" id="download">
  <div class="lp-wrap">
    <h2 class="lp-h2"><?= e($dl['title']) ?></h2>
    <?php if ($dl['subtitle'] !== ''): ?><p class="lp-sub"><?= e($dl['subtitle']) ?></p><?php endif; ?>
    <div class="lp-dl">
      <?php if ($dl['android'] !== ''): ?><a href="<?= e($dl['android']) ?>" rel="nofollow noopener">📱 Android 下载</a><?php endif; ?>
      <?php if ($dl['ios'] !== ''): ?><a href="<?= e($dl['ios']) ?>" rel="nofollow noopener">🍎 iOS 下载</a><?php endif; ?>
      <?php if ($dl['android'] === '' && $dl['ios'] === ''): ?>
      <a href="register.php">🌐 直接使用网页版</a>
      <?php endif; ?>
    </div>
    <?php if ($dl['tip'] !== ''): ?><div class="tip"><?= e($dl['tip']) ?></div><?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($faq['show']) && $faq['items']): ?>
<section class="lp-sec lp-sec-alt" id="faq">
  <div class="lp-wrap">
    <h2 class="lp-h2"><?= e($faq['title']) ?></h2>
    <?php if ($faq['subtitle'] !== ''): ?><p class="lp-sub"><?= e($faq['subtitle']) ?></p><?php endif; ?>
    <div class="lp-faq">
      <?php foreach ($faq['items'] as $it): if ($it['q'] === '') continue; ?>
      <details>
        <summary><?= e($it['q']) ?></summary>
        <p><?= e($it['a']) ?></p>
      </details>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($cta['show'])): ?>
<section class="lp-sec">
  <div class="lp-wrap">
    <div class="lp-cta">
      <h2><?= e($cta['title']) ?></h2>
      <?php if ($cta['desc'] !== ''): ?><p><?= e($cta['desc']) ?></p><?php endif; ?>
      <a class="lp-btn lp-btn-primary" href="<?= e($cta['btn_url'] ?: 'register.php') ?>"><?= e($cta['btn'] ?: '免费注册') ?></a>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($foot['show'])): ?>
<footer class="lp-foot">
  <div class="lp-wrap">
    <div>
      <div style="color:#fff;font-weight:700;font-size:15px;margin-bottom:8px"><?= e($brand) ?></div>
      <div><?= e($foot['text']) ?></div>
    </div>
    <div style="display:flex;gap:26px;flex-wrap:wrap">
      <a href="login.php">登录</a>
      <a href="register.php">注册</a>
      <?php if (!empty($faq['show'])): ?><a href="#faq">常见问题</a><?php endif; ?>
      <?php if ($foot['contact'] !== ''): ?><a href="<?= e(strpos($foot['contact'], 'http') === 0 ? $foot['contact'] : '#') ?>">联系我们</a><?php endif; ?>
    </div>
  </div>
  <div class="lp-copy">
    <?= e($foot['icp'] !== '' ? $foot['icp'] . '　' : '') ?>© <?= date('Y') ?> <?= e($brand) ?> 保留所有权利
  </div>
</footer>
<?php endif; ?>

</body>
</html>
