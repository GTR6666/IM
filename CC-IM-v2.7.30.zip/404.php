<?php
/**
 * CC商聊 - 404 页面（需由 Nginx error_page 指向，返回真正的 404 状态码）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';

http_response_code(404);
cc_head('页面不存在', ['desc' => '抱歉，你访问的页面不存在或已被移除。']);
?>
<div class="app">
  <div class="page">
    <?php cc_topbar('页面不存在', 'login.php'); ?>
    <div class="page-body no-tab">
      <div class="empty" style="padding-top:110px">
        <div class="ico">🔍</div>
        <div style="font-size:16px;font-weight:600;color:var(--text)">页面走丢了</div>
        <div style="font-size:12.5px;margin-top:8px;line-height:1.8">
          你访问的地址不存在或已被移除。<br>
          如果是从群邀请链接进入，请联系邀请人重新获取。
        </div>
        <div style="margin-top:22px;display:flex;gap:10px;justify-content:center">
          <a class="btn small ghost" style="display:inline-flex" href="login.php">返回登录</a>
          <a class="btn small" style="display:inline-flex" href="register.php">去注册</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php cc_foot(); ?>
