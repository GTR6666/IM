<?php
/**
 * CC商聊 - 我的
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$meFresh = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]) ?: $me;
$settings = json_decode_arr($meFresh['settings'] ?? '');
$tab = (string)($_GET['tab'] ?? '');
$showYxid = $meFresh['pretty_yxid'] ?: ($meFresh['yx_id'] ?: $meFresh['account']);
$vip = is_vip($meFresh);
$vipLevel = $vip ? (int)$meFresh['vip_level'] : 0;
$coin = (int)$meFresh['coin'];
$site = setting('site_name', 'CC商聊');

/** 收藏条目展示 */
function fav_kind(array $r): string
{
    $c = (string)$r['content'];
    if (preg_match('#^(https?://|uploads/)#', $c) || preg_match('/^\{.*\}$/s', $c)) return 'media';
    return 'text';
}

/* =========================================================
 * 我的收藏
 * ========================================================= */
if ($tab === 'favorite') {
    $favs = all('SELECT * FROM favorites WHERE uid=? ORDER BY id DESC LIMIT 200', [(int)$me['id']]);
    cc_head('我的收藏', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('我的收藏', 'me.php'); ?>
    <div class="page-body no-tab">
      <div id="favBox">
        <?php if (!$favs): ?>
        <div class="empty"><div class="ico">⭐</div><div>还没有收藏</div>
          <div style="font-size:12px;margin-top:4px">聊天中长按消息可以收藏</div></div>
        <?php else: ?>
        <div class="cell-group" style="margin-top:4px">
          <?php foreach ($favs as $fv):
              $c = (string)$fv['content'];
              $isMedia = false;
              $url = '';
              if (preg_match('#^(https?://|uploads/)#', $c)) { $isMedia = true; $url = $c; }
              elseif (preg_match('/^\{/', $c)) {
                  $j = json_decode_arr($c);
                  if (!empty($j['url'])) { $isMedia = true; $url = (string)$j['url']; }
              }
          ?>
          <div class="cell" data-fav="<?= (int)$fv['id'] ?>" style="align-items:flex-start">
            <?php if ($isMedia && preg_match('#\.(jpg|jpeg|png|gif|webp|bmp)$#i', $url)): ?>
            <span class="avatar sm" onclick="CC.previewImage('<?= e($url) ?>')"><img src="<?= e($url) ?>" alt=""></span>
            <?php else: ?>
            <div class="c-icon" style="background:rgba(245,166,35,.14);color:var(--gold)">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1.1 5.9L12 16.9l-5.3 2.8 1.1-5.9L3.5 9.7l5.9-.8z"/></svg>
            </div>
            <?php endif; ?>
            <div class="c-title" style="min-width:0">
              <div style="font-size:13.5px;line-height:1.55;word-break:break-word;white-space:pre-wrap"><?= e(mb_substr($c, 0, 200)) ?></div>
              <div class="c-desc"><?= e(fmt_time((int)$fv['created_at'])) ?></div>
            </div>
            <button class="btn small ghost" data-del="<?= (int)$fv['id'] ?>">删除</button>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
      <div style="height:20px"></div>
    </div>
  </div>
</div>
<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  document.querySelectorAll('[data-del]').forEach(function(b){
    b.onclick = function(e){
      e.stopPropagation();
      CC.confirm({ title: '删除收藏', text: '删除后不可恢复', ok: '删除', danger: true }).then(function(yes){
        if (!yes) return;
        b.disabled = true;
        CC.api('favorite_del', { id: b.getAttribute('data-del') }).then(function(){
          var cell = b.closest('.cell');
          if (cell) cell.remove();
          CC.toast('已删除');
          var box = document.getElementById('favBox');
          if (box && !box.querySelector('.cell[data-fav]')){
            box.innerHTML = '<div class="empty"><div class="ico">⭐</div><div>还没有收藏</div><div style="font-size:12px;margin-top:4px">聊天中长按消息可以收藏</div></div>';
          }
        }).catch(function(err){ b.disabled = false; CC.toast(err.message); });
      });
    };
  });
})();
</script>
<?php cc_foot();
    exit;
}

/* =========================================================
 * 我的（主界面）
 * ========================================================= */
$vipDays = $vip ? max(0, (int)ceil(((int)$meFresh['vip_expire_at'] - now()) / 86400)) : 0;
cc_head('我的', ['body_class' => 'app-body', 'css' => '
.me-head{padding:calc(var(--safe-t) + 14px) 16px 10px;display:flex;align-items:flex-start;justify-content:center;position:relative}
.me-head .scan-btn{position:absolute;right:14px;top:calc(var(--safe-t) + 10px);width:38px;height:38px;border-radius:12px;background:var(--card);display:flex;align-items:center;justify-content:center;box-shadow:0 3px 10px rgba(26,32,60,.06)}
.me-ava{width:84px;height:84px;border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:600;color:#fff;background:linear-gradient(135deg,#7C6CF0,#6C5CF0);box-shadow:0 12px 26px rgba(108,92,240,.28)}
.me-ava img{width:100%;height:100%;object-fit:cover}
.me-name{text-align:center;margin-top:12px}
.me-name .n{font-size:19px;font-weight:700;display:inline-flex;align-items:center;gap:6px;justify-content:center;max-width:80vw}
.me-code{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:9px;font-size:12.5px;color:var(--t3);flex-wrap:wrap}
.me-code b{color:var(--t2);font-weight:500;letter-spacing:.3px}
.me-code svg{opacity:.7}
.vip-banner{margin:14px 12px 0;border-radius:16px;padding:16px 16px;display:flex;align-items:center;gap:12px;color:#fff;
  background:linear-gradient(120deg,#2B2E7A 0%,#4A2E8F 48%,#6B2FA0 100%);box-shadow:0 14px 30px rgba(58,42,140,.3);position:relative;overflow:hidden}
.vip-banner::after{content:"";position:absolute;right:-30px;top:-40px;width:130px;height:130px;border-radius:50%;background:rgba(255,255,255,.09)}
.vip-banner .vb-ico{width:34px;height:34px;border-radius:11px;background:rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.vip-banner .vb-t{font-size:17px;font-weight:800;letter-spacing:.6px}
.vip-banner .vb-s{font-size:11px;opacity:.78;margin-top:3px}
.vip-banner .vb-btn{margin-left:auto;height:34px;padding:0 16px;border-radius:18px;background:#fff;color:#3B2E86;font-size:13px;font-weight:700;display:flex;align-items:center;flex:0 0 auto}
.me-stats{display:flex;align-items:center;background:var(--card);border-radius:16px;margin:12px 12px 0;padding:16px 8px;box-shadow:0 4px 14px rgba(26,32,60,.04)}
.me-stats .ms-i{flex:1;text-align:center}
.me-stats .ms-v{font-size:22px;font-weight:800;color:var(--brand);font-variant-numeric:tabular-nums;letter-spacing:.3px}
.me-stats .ms-v small{font-size:12px;font-weight:600;margin-left:2px}
.me-stats .ms-l{font-size:11.5px;color:var(--t3);margin-top:5px;display:flex;align-items:center;justify-content:center;gap:4px}
.me-stats .ms-line{width:1px;height:34px;background:var(--line)}
.quad{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin:12px 12px 0}
.quad .q-item{background:var(--card);border-radius:14px;padding:13px 4px 11px;display:flex;flex-direction:column;align-items:center;gap:8px;font-size:11.5px;color:var(--text);box-shadow:0 3px 12px rgba(26,32,60,.04)}
.quad .q-ico{width:40px;height:40px;border-radius:13px;display:flex;align-items:center;justify-content:center;color:#fff}
.quad .q-ico.a{background:linear-gradient(135deg,#FFA62B,#F59E0B)}
.quad .q-ico.b{background:linear-gradient(135deg,#12C99B,#07C160)}
.quad .q-ico.c{background:linear-gradient(135deg,#5AC8FA,#3B82F6)}
.quad .q-ico.d{background:linear-gradient(135deg,#9B8CFF,#7C3AED)}
.sec-title{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--t3);padding:18px 18px 8px;font-weight:600;letter-spacing:.3px}
.sec-title::before{content:"";width:3px;height:12px;border-radius:2px;background:var(--brand)}
.logout-btn{margin:22px 12px 8px;width:calc(100% - 24px);height:48px;border-radius:24px;background:#FFF5F6;color:#FF4757;font-size:15.5px;font-weight:600;
  display:flex;align-items:center;justify-content:center;gap:8px;
  border:1.5px solid rgba(255,71,87,.35);box-shadow:0 4px 16px rgba(255,71,87,.12);transition:.15s}
.logout-btn:active{background:#FFE9EC;border-color:rgba(255,71,87,.55)}
']); ?>
<div class="app">
  <div class="page">
    <div class="page-body" style="padding-bottom:calc(90px + var(--safe-b))">
      <div class="me-head">
        <button class="scan-btn" id="btnScan" aria-label="我的二维码">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="6" height="6" rx="1.2"/><rect x="14.5" y="3.5" width="6" height="6" rx="1.2"/><rect x="3.5" y="14.5" width="6" height="6" rx="1.2"/><path d="M14.5 14.5h2.5v2.5h-2.5zM20.5 14.5v2.5M14.5 20.5h6"/></svg>
        </button>
        <div style="width:100%">
          <div style="display:flex;justify-content:center">
            <div class="me-ava" id="cardMe">
              <?php if ($meFresh['avatar']): ?><img src="<?= e($meFresh['avatar']) ?>" alt="">
              <?php else: ?><?= e(mb_substr($meFresh['nickname'] ?: 'U', 0, 1)) ?><?php endif; ?>
            </div>
          </div>
          <div class="me-name">
            <div class="n">
              <span class="nowrap" style="max-width:60vw"><?= e($meFresh['nickname'] ?: ('用户' . $meFresh['account'])) ?></span>
              <?= $vipLevel > 0 ? vip_badge($vipLevel) : '' ?>
            </div>
            <div class="me-code" id="cellCopyId" title="点击复制号码">
              <span><?= e(pretty_number_label((string)($meFresh['pretty_yxid'] ?? ''))) ?>：<?= pretty_number_html((string)$showYxid, (string)($meFresh['pretty_yxid'] ?? '')) ?></span>
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/></svg>
            </div>
          </div>
        </div>
      </div>

      <div class="vip-banner" data-go="wallet.php?tab=vip">
        <div class="vb-ico">
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v6c0 4.4-3 7.6-7 9-4-1.4-7-4.6-7-9V6z"/><path d="M9.5 12l1.8 1.8L15 10"/></svg>
        </div>
        <div>
          <div class="vb-t">VIP / SVIP</div>
          <div class="vb-s"><?= $vip ? e(vip_label($vipLevel)) . ' · ' . e(date('Y-m-d', (int)$meFresh['vip_expire_at'])) . ' 到期' : '解锁靓号标识、群人数升级等特权' ?></div>
        </div>
        <div class="vb-btn" id="cardVip"><?= $vip ? '续费' : '立即开通' ?></div>
      </div>

      <div class="me-stats">
        <div class="ms-i" id="cardCoin">
          <div class="ms-v"><?= number_format($coin) ?></div>
          <div class="ms-l">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.6h4.8M9.6 12h4.8M12 9.6v4.8"/></svg>
            CC币余额
          </div>
        </div>
        <div class="ms-line"></div>
        <div class="ms-i" data-go="wallet.php?tab=vip">
          <div class="ms-v"><?= $vip ? $vipDays : 0 ?><small>天</small></div>
          <div class="ms-l">
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>
            会员剩余
          </div>
        </div>
      </div>

      <div class="quad">
        <button class="q-item" data-go="wallet.php?tab=pretty">
          <span class="q-ico a"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h16v3H4zM5 11h14v9H5zM9 15h6"/></svg></span>
          靓号商城
        </button>
        <button class="q-item" data-go="wallet.php?tab=vip">
          <span class="q-ico b"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8l4 9 4-11 4 11 4-9"/></svg></span>
          VIP 会员
        </button>
        <button class="q-item" data-go="wallet.php">
          <span class="q-ico c"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="13" rx="2.4"/><path d="M3 10.5h18"/></svg></span>
          CC币钱包
        </button>
        <button class="q-item" data-go="me.php?tab=favorite">
          <span class="q-ico d"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1.1 5.9L12 16.9l-5.3 2.8 1.1-5.9L3.5 9.7l5.9-.8z"/></svg></span>
          我的收藏
        </button>
      </div>

      <div class="sec-title">账号与安全</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="cell" data-go="profile.php">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.4"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/></svg>
          </div>
          <div class="c-title">个人资料</div>
          <div class="c-value">编辑</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-go="privacy.php">
          <div class="c-icon" style="background:rgba(16,185,129,.12);color:#10B981">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
          </div>
          <div class="c-title">隐私设置</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-go="notify.php">
          <div class="c-icon" style="background:rgba(245,158,11,.14);color:#F59E0B">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5v5a1 1 0 0 0 1 1h3l5 3.5v-14L8 8.5H5a1 1 0 0 0-1 1z"/><path d="M17 9a4.5 4.5 0 0 1 0 6"/></svg>
          </div>
          <div class="c-title">通知设置</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-go="profile.php#security">
          <div class="c-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v6c0 4.4-3 7.6-7 9-4-1.4-7-4.6-7-9V6z"/><path d="M9.5 12l1.8 1.8L15 10"/></svg>
          </div>
          <div class="c-title">账号安全</div>
          <div class="c-value"><?= !empty($meFresh['pay_password']) ? '支付密码已设' : '未设支付密码' ?></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" id="cellSwitch">
          <div class="c-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4.5h10a2 2 0 0 1 2 2v3"/><path d="M17 19.5H7a2 2 0 0 1-2-2v-3"/><path d="M4.5 7l2.5-2.5L9.5 7"/><path d="M19.5 17L17 19.5 14.5 17"/></svg>
          </div>
          <div class="c-title">切换账号</div>
          <div class="c-value" id="accCount"></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" id="cellDevice">
          <div class="c-icon" style="background:rgba(255,71,87,.12);color:var(--red)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2.5" width="12" height="19" rx="2.4"/><path d="M10.5 18.5h3"/></svg>
          </div>
          <div class="c-title">登录设备管理</div>
          <div class="c-value" style="color:var(--brand)">在线</div>
          <span class="arrow">›</span>
        </div>
      </div>

      <div class="sec-title">我的服务</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="cell" data-go="notice.php">
          <div class="c-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5h16v13H4z"/><path d="M7.5 9.5h9M7.5 13h6"/></svg>
          </div>
          <div class="c-title">官方公告</div>
          <div class="c-value" id="noticeUnread"></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-go="service.php">
          <div class="c-icon" style="background:rgba(7,193,96,.12);color:var(--brand)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 1 3 6.2L4 20z"/><path d="M9.5 11a2.5 2.5 0 1 1 3.2 2.4c-.5.2-.7.6-.7 1.1"/></svg>
          </div>
          <div class="c-title">联系客服</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-go="invite.php">
          <div class="c-icon" style="background:rgba(245,166,35,.14);color:var(--gold)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8.5" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M18.5 6.5v6M15.5 9.5h6"/></svg>
          </div>
          <div class="c-title">邀请好友</div>
          <div class="c-value"><span class="badge" style="background:linear-gradient(135deg,#FFB020,#FF7A00);color:#fff">得会员 · 靓号</span></div>
          <span class="arrow">›</span>
        </div>
      </div>

      <div class="sec-title">偏好设置</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="cell" id="cellTheme">
          <div class="c-icon" style="background:rgba(108,92,240,.14);color:var(--purple)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13.5A8.5 8.5 0 0 1 10.5 4a8.5 8.5 0 1 0 9.5 9.5z"/></svg>
          </div>
          <div class="c-title">深色模式</div>
          <div class="c-value"><span class="badge gray" id="themeState">关</span></div>
        </div>
        <div class="cell" id="cellAbout">
          <div class="c-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 8v.5"/></svg>
          </div>
          <div class="c-title">关于 <?= e($site) ?></div>
          <div class="c-value">v<?= e(CC_VERSION) ?></div>
          <span class="arrow">›</span>
        </div>
      </div>

      <button class="logout-btn" id="cellLogout">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 8V5.5A1.5 1.5 0 0 0 13.5 4H6a1.5 1.5 0 0 0-1.5 1.5v13A1.5 1.5 0 0 0 6 20h7.5A1.5 1.5 0 0 0 15 18.5V16"/><path d="M10 12h10M17.5 9l3 3-3 3"/></svg>
        退出登录
      </button>
      <div style="height:18px"></div>
    </div>
    <?php cc_tabbar('me'); ?>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
window.MY_SETTINGS = <?= json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
window.SITE = {
  name: <?= json_encode($site, JSON_UNESCAPED_UNICODE) ?>,
  version: <?= json_encode(CC_VERSION, JSON_UNESCAPED_UNICODE) ?>,
  appVersion: <?= json_encode((string)setting('app_version', CC_VERSION), JSON_UNESCAPED_UNICODE) ?>,
  download: <?= json_encode((string)setting('app_download_url', ''), JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var S = window.MY_SETTINGS || {};
  var ME = window.ME || {};

  document.querySelectorAll('[data-go]').forEach(function(el){
    el.onclick = function(){ location.href = el.getAttribute('data-go'); };
  });
  document.getElementById('cardMe').onclick = function(){ location.href = 'profile.php'; };
  var copyId = document.getElementById('cellCopyId');
  if (copyId) copyId.onclick = function(){
    var t = <?= json_encode((string)$showYxid) ?>;
    if (navigator.clipboard) navigator.clipboard.writeText(t).then(function(){ CC.toast('已复制 CC号 ' + t); }, function(){ CC.toast('复制失败，请长按选择'); });
    else CC.toast('请长按选择复制');
  };
  var cardVip = document.getElementById('cardVip');
  if (cardVip) cardVip.onclick = function(e){ e.stopPropagation(); location.href = 'wallet.php?tab=vip'; };
  document.getElementById('cardCoin').onclick = function(e){
    if (e.target && e.target.closest && e.target.closest('button')) return;
    location.href = 'wallet.php';
  };

  /* ---------- 开关行 ---------- */
  function toggleSheet(title, items, done){
    var s = CC.sheet(title, '');
    var box = s.el.querySelector('.sheet-body');
    function paint(){
      box.innerHTML = items.map(function(it, i){
        var on = String(it.value) === '1';
        return '<div class="row-between" style="padding:13px 2px;border-bottom:1px solid var(--line)">'
          + '<div><div style="font-size:14.5px">' + CC.esc(it.label) + '</div>'
          + (it.desc ? '<div class="t3 small" style="margin-top:3px;line-height:1.5">' + CC.esc(it.desc) + '</div>' : '')
          + '</div>'
          + '<button class="badge ' + (on ? '' : 'gray') + '" data-i="' + i + '" style="padding:4px 12px;border-radius:20px;font-size:11.5px">' + (on ? '已开启' : '已关闭') + '</button></div>';
      }).join('');
      box.querySelectorAll('[data-i]').forEach(function(b){
        b.onclick = function(){
          var it = items[parseInt(b.getAttribute('data-i'), 10)];
          it.value = String(it.value) === '1' ? '0' : '1';
          var payload = {};
          payload[it.key] = it.value;
        CC.api('update_settings', payload).then(function(){
            paint();
            if (done) done(it.key, it.value);
            CC.toast(it.value === '1' ? '已开启' : '已关闭');
          }).catch(function(e){ CC.toast(e.message); });
        };
      });
    }
    paint();
  }


  /* ---------- 切换账号 ---------- */
  var ACC_KEY = 'cc_accounts';
  var MAX_ACC = 3;
  function getAccounts(){
    try { return JSON.parse(localStorage.getItem(ACC_KEY) || '[]') || []; } catch (e) { return []; }
  }
  function setAccounts(list){
    try { localStorage.setItem(ACC_KEY, JSON.stringify(list.slice(0, MAX_ACC))); } catch (e) {}
    paintAccCount();
  }
  function paintAccCount(){
    var el = document.getElementById('accCount');
    if (el) {
      var n = getAccounts().length;
      el.textContent = n > 1 ? (n + '/' + MAX_ACC + ' 个') : '';
    }
  }
  paintAccCount();

  document.getElementById('cellSwitch').onclick = function(){
    var s = CC.sheet('切换账号', '<div id="accBox"><div class="loading"><span class="spin"></span> 加载中…</div></div>');
    var box = s.el.querySelector('#accBox');
    var local = getAccounts();
    if (!local.length){
      // 首次使用：把当前账号记下来（需要 token，从后端取）
      CC.ajax('account_current_token', {}).then(function(res){
        if (res.code === 0 && res.data && res.data.token){
          local = [{ uid: ME.id, token: res.data.token }];
          setAccounts(local);
          render();
        } else render();
      }).catch(function(){ render(); });
    } else render();

    function render(){
      if (!local.length){
        box.innerHTML = '<div class="empty" style="padding:26px 16px"><div class="ico">👥</div><div>还没有保存的账号</div></div>'
          + addBtn();
        bindAdd();
        return;
      }
      // 校验令牌有效性并拉取最新资料
      CC.ajax('account_check', { tokens: JSON.stringify(local) }).then(function(res){
        var list = (res.code === 0 && res.data && res.data.list) || [];
        setAccounts(list.map(function(a){ return { uid: a.uid, token: a.token }; }));
        var html = list.map(function(a){
          var cur = parseInt(a.uid, 10) === parseInt(ME.id, 10);
          return '<div class="row-between" data-acc="' + a.uid + '" style="padding:12px;border:1.5px solid ' + (cur ? 'var(--brand)' : 'var(--line)')
            + ';border-radius:14px;margin-bottom:10px;background:' + (cur ? 'var(--brand-soft)' : 'var(--card)') + ';cursor:pointer;gap:10px">'
            + '<div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">'
            + CC.avatarHtml({ nickname: a.name, avatar: a.avatar }, 'sm')
            + '<div style="min-width:0"><div class="nowrap" style="font-size:15px;font-weight:600">' + CC.esc(a.name)
            + (cur ? ' <span class="badge">当前</span>' : '') + '</div>'
            + '<div class="t3 small" style="margin-top:2px">' + CC.esc(a.account) + '</div></div></div>'
            + (cur ? '' : '<button class="btn small ghost" data-del="' + a.uid + '">移除</button>')
            + '</div>';
        }).join('');
        if (!list.length) html = '<div class="empty" style="padding:22px 16px;font-size:12.5px">保存的账号均已失效</div>';
        box.innerHTML = html + addBtn() + '<div class="hint-line">最多可保存 ' + MAX_ACC + ' 个账号</div>';
        box.querySelectorAll('[data-acc]').forEach(function(row){
          row.onclick = function(e){
            if (e.target.closest('[data-del]')) return;
            var uid = parseInt(row.getAttribute('data-acc'), 10);
            if (uid === parseInt(ME.id, 10)) { CC.toast('当前已是该账号'); return; }
            var acc = list.find(function(x){ return parseInt(x.uid, 10) === uid; });
            if (!acc) return;
            CC.api('account_switch', { token: acc.token }).then(function(){
              CC.toast('已切换为 ' + acc.name);
              setTimeout(function(){ location.replace('index.php'); }, 500);
            }).catch(function(err){ CC.toast(err.message); });
          };
        });
        box.querySelectorAll('[data-del]').forEach(function(b){
          b.onclick = function(e){
            e.stopPropagation();
            var uid = b.getAttribute('data-del');
            setAccounts(getAccounts().filter(function(x){ return String(x.uid) !== String(uid); }));
            render();
          };
        });
        bindAdd();
      }).catch(function(){ box.innerHTML = '<div class="empty" style="padding:26px">加载失败</div>' + addBtn(); bindAdd(); });
    }
    function addBtn(){
      var full = getAccounts().length >= MAX_ACC;
      return '<div style="margin-top:4px;height:48px;border-radius:14px;background:var(--brand-soft);color:var(--brand);'
        + 'display:flex;align-items:center;justify-content:center;gap:6px;font-size:14.5px;font-weight:600;cursor:pointer" id="accAdd">'
        + (full ? '已达上限（' + MAX_ACC + ' 个）' : '＋ 添加或登录另一个账号') + '</div>';
    }
    function bindAdd(){
      var b = document.getElementById('accAdd');
      if (!b) return;
      b.onclick = function(){
        if (getAccounts().length >= MAX_ACC){ CC.toast('最多保存 ' + MAX_ACC + ' 个账号'); return; }
        saveCurrentThenGo();
      };
    }
    function saveCurrentThenGo(){
      CC.ajax('account_current_token', {}).then(function(res){
        if (res.code === 0 && res.data && res.data.token){
          var list = getAccounts().filter(function(x){ return parseInt(x.uid, 10) !== parseInt(ME.id, 10); });
          list.unshift({ uid: ME.id, token: res.data.token });
          setAccounts(list);
        }
        location.href = 'login.php?add=1';
      }).catch(function(){ location.href = 'login.php?add=1'; });
    }
  };

  /* ---------- 登录设备 ---------- */
  document.getElementById('cellDevice').onclick = function(){
    CC.ajax('device_list', {}).then(function(res){
      if (res.code !== 0){ CC.toast(res.msg || '加载失败'); return; }
      var list = (res.data && res.data.list) || [];
      var s = CC.sheet('登录设备管理', '<div id="devBox"></div>');
      var box = s.el.querySelector('#devBox');
      if (!list.length){
        box.innerHTML = '<div class="empty" style="padding:30px 10px">暂无登录记录</div>';
        return;
      }
      box.innerHTML = list.map(function(d){
        return '<div class="cell" style="padding-left:0;padding-right:0;border-bottom:1px solid var(--line)">'
          + '<div class="c-icon" style="background:rgba(7,193,96,.1);color:var(--brand)">'
          + '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2.5" width="12" height="19" rx="2.4"/><path d="M10.5 18.5h3"/></svg></div>'
          + '<div class="c-title" style="min-width:0"><div class="nowrap small" style="color:var(--text)">' + CC.esc(d.ua || '未知设备') + '</div>'
          + '<div class="c-desc">' + CC.esc(d.ip || '') + ' · ' + CC.fmtFull(d.last_active_at) + '</div></div>'
          + (parseInt(d.current, 10) ? '<span class="badge">本机</span>'
            : '<button class="btn small ghost" data-kick="' + d.id + '">下线</button>')
          + '</div>';
      }).join('');
      box.querySelectorAll('[data-kick]').forEach(function(b){
        b.onclick = function(){
          CC.confirm({ title: '下线设备', text: '该设备将立即退出登录', ok: '下线', danger: true }).then(function(yes){
            if (!yes) return;
            b.disabled = true;
            CC.api('device_kick', { id: b.getAttribute('data-kick') }).then(function(){
              var row = b.closest('.cell');
              if (row) row.remove();
              CC.toast('已下线该设备');
            }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
          });
        };
      });
    }).catch(function(){ CC.toast('加载失败'); });
  };

  /* ---------- 深色模式 ---------- */
  var themeState = document.getElementById('themeState');
  function paintTheme(){
    var dark = document.documentElement.classList.contains('dark-theme');
    themeState.textContent = dark ? '开' : '关';
    themeState.className = 'badge ' + (dark ? '' : 'gray');
  }
  paintTheme();
  document.getElementById('cellTheme').onclick = function(){
    var dark = !document.documentElement.classList.contains('dark-theme');
    CC.setTheme(dark ? 'dark' : 'light');
    paintTheme();
    CC.api('update_settings', { theme: dark ? 'dark' : 'light' }).then(function(){ S.theme = dark ? 'dark' : 'light'; }).catch(function(){});
  };

  /* ---------- 关于 ---------- */
  document.getElementById('cellAbout').onclick = function(){
    var st = window.SITE;
    CC.confirm({
      title: '关于 ' + st.name,
      html: '<p style="text-align:left;line-height:1.85;font-size:13px">'
        + '版本：v' + CC.esc(st.version) + '<br>'
        + 'CC号：' + CC.esc(ME.yx_id || '') + '<br>'
        + '应用版本：' + CC.esc(st.appVersion || st.version) + '<br>'
        + (st.download ? '官网：' + CC.esc(st.download) : '')
        + '</p>',
      ok: '知道了', cancel: '关闭'
    });
  };

  /* ---------- 退出登录 ---------- */
  document.getElementById('cellLogout').onclick = function(){
    CC.confirm({ title: '退出登录', text: '确定退出当前账号？', ok: '退出', danger: true }).then(function(yes){
      if (!yes) return;
      try { localStorage.removeItem('cc_login_keyword'); } catch (e) {}
      location.replace('logout.php');
    });
  };

  /* ---------- 未读公告 ---------- */
  CC.ajax('contacts_unread', {}).then(function(res){
    if (res.code !== 0) return;
    var n = (res.data && res.data.notice) || 0;
    var el = document.getElementById('noticeUnread');
    if (el && n > 0) el.innerHTML = '<span class="badge red">' + n + '</span>';
  }).catch(function(){});

  document.getElementById('btnScan').onclick = function(){ location.href = 'invite.php'; };
})();
</script>
<?php cc_foot(); ?>
