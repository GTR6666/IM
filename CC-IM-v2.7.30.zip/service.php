<?php
/**
 * CC商聊 - 联系客服
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$serviceAcc = (string)setting('service_uid', '10086');
$svc = one('SELECT * FROM users WHERE account=? OR id=?', [$serviceAcc, (int)$serviceAcc])
    ?: one('SELECT * FROM users WHERE id=?', [(int)$serviceAcc]);
$svcId = $svc ? (int)$svc['id'] : 0;
$svcName = $svc ? ($svc['nickname'] ?: '官方客服') : '官方客服';
$svcYxid = $svc ? ($svc['pretty_yxid'] ?: ($svc['yx_id'] ?: $svc['account'])) : $serviceAcc;
$svcVip = $svc && is_vip($svc) ? (int)$svc['vip_level'] : 0;
$svcPretty = $svc ? (string)($svc['pretty_yxid'] ?? '') : '';
$svcOnline = $svc ? (int)$svc['online'] : 0;

$gid = (int)setting('official_gid', '666666');
$group = group_by_gid($gid);
$joined = $group ? (group_member($gid, (int)$me['id']) ? 1 : 0) : 0;
$members = $group ? (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid]) : 0;
$contact = trim((string)setting('service_contact', ''));

$faqs = [
    ['充值多久到账？', "USDT 充值：转账后提交 TXID，系统自动核对，一般 1-5 分钟到账；若长时间未到账请在钱包 → 充值记录中点击「补单」。\n其他方式充值请联系客服，并提供订单号与付款截图。"],
    ['提现多久处理？', '提现申请在工作时间内一般 2 小时内处理，单笔最低 ' . (int)setting('withdraw_min', '100') . " CC币。\n请确认收款账号填写正确，提交后不可自行修改；被驳回的提现会原路退回 CC币余额。"],
    ['买的靓号会掉吗？', '靓号购买后永久绑定当前账号，不会因为 VIP 到期而失效。\n购买前请确认 CC号 后再付款，成交后不支持退款或更换。'],
    ['VIP 有哪些特权？', "VIP 可解锁专属标识、群成员上限提升、好友上限提升、靓号折扣等权益。\nVIP 为按期订阅，到期后特权自动失效，续费从到期日顺延。数字越高权益越多。"],
    ['账号被限制/封禁怎么办？', '若提示违规被封禁，可在登录页点击「提交申诉」，填写封禁原因与联系方式；\n也可在本页联系客服，提供 CC号 与处理诉求，客服会在 24 小时内回复。'],
];
cc_head('联系客服', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('联系客服', 'me.php'); ?>

    <div class="page-body no-tab">
      <div class="card" style="display:flex;gap:14px;align-items:center;padding:18px 16px">
        <?php if ($svc && $svc['avatar']): ?>
        <span class="avatar lg"><img src="<?= e($svc['avatar']) ?>" alt=""></span>
        <?php else: ?>
        <span class="avatar lg" style="background:var(--brand)">
          <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 1 3 6.2L4 20z"/><path d="M9.5 11a2.5 2.5 0 1 1 3.2 2.4c-.5.2-.7.6-.7 1.1"/></svg>
        </span>
        <?php endif; ?>
        <div style="flex:1;min-width:0">
          <div style="font-size:17px;font-weight:600;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            <span class="nowrap" style="max-width:160px"><?= e($svcName) ?></span>
            <?php if ($svcVip > 0): ?><?= vip_badge($svcVip) ?><?php endif; ?>
            <span class="badge purple">官方</span>
          </div>
          <div class="t3 small" style="margin-top:5px;display:flex;align-items:center;gap:5px">
            <?= e(pretty_number_label((string)($svcPretty ?? ''), 'CC号', '靓号')) ?>：<?= pretty_number_html((string)$svcYxid, (string)($svcPretty ?? '')) ?>
          </div>
          <div class="small" style="margin-top:5px;display:flex;align-items:center;gap:6px">
            <?php if ($svcOnline): ?>
            <span class="tag-online"></span><span class="green-text">在线 · 通常 5 分钟内回复</span>
            <?php else: ?>
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--t3)"></span>
            <span class="t3">离线 · 留言后会尽快回复</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div style="padding:2px 12px 0">
        <button class="btn" id="btnConsult" <?= $svcId ? '' : 'disabled' ?>>立即咨询</button>
      </div>

      <?php if ($group): ?>
      <div class="group-title">官方群</div>
      <div class="cell-group">
        <div class="cell" id="cellGroup">
          <?= '' ?>
          <?php if ($group['avatar']): ?>
          <span class="avatar sm"><img src="<?= e($group['avatar']) ?>" alt=""></span>
          <?php else: ?>
          <span class="avatar sm" style="background:var(--purple)">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><path d="M16.5 7.5a2.6 2.6 0 0 1 0 5"/><path d="M17.5 19a4.5 4.5 0 0 0-2-3.7"/></svg>
          </span>
          <?php endif; ?>
          <div class="c-title" style="min-width:0">
            <div class="nowrap"><?= e($group['name']) ?></div>
            <div class="c-desc">群号 <?= (int)$group['gid'] ?> · <?= $members ?>人</div>
          </div>
          <?php if ($joined): ?>
          <button class="btn small ghost" id="btnGroup">进入</button>
          <?php else: ?>
          <button class="btn small" id="btnGroup">加入</button>
          <?php endif; ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($contact !== ''): ?>
      <div class="group-title">联系方式</div>
      <div class="card" style="padding:14px 16px">
        <div style="font-size:14px;line-height:1.9;white-space:pre-wrap;word-break:break-word" id="contactText"><?= e($contact) ?></div>
        <button class="btn small outline mt12" id="btnCopyContact">复制联系方式</button>
      </div>
      <?php endif; ?>

      <div class="group-title">常见问题</div>
      <div class="cell-group" id="faqBox">
        <?php foreach ($faqs as $i => $f): ?>
        <div class="cell" data-faq="<?= $i ?>" style="align-items:flex-start;flex-direction:column;gap:0">
          <div class="row-between" style="width:100%">
            <div class="c-title" style="font-size:14px"><?= e($f[0]) ?></div>
            <span class="arrow" data-flip="<?= $i ?>" style="transition:transform .2s">›</span>
          </div>
          <div class="faq-body" style="display:none;font-size:13px;color:var(--t2);line-height:1.8;margin-top:8px;white-space:pre-wrap;word-break:break-word;width:100%"><?= e($f[1]) ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <div class="t3 small center" style="padding:18px 20px 30px;line-height:1.7">
        客服在线时间 09:00 - 23:00<br>涉及资金问题请务必通过官方客服核实，谨防冒充
      </div>
    </div>
  </div>
</div>

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var SVC = { id: <?= $svcId ?>, name: <?= json_encode($svcName, JSON_UNESCAPED_UNICODE) ?>, gid: <?= $gid ?>, joined: <?= $joined ?> };
  var contact = document.getElementById('contactText');

  function copyText(text){
    if (navigator.clipboard && window.isSecureContext){
      navigator.clipboard.writeText(text).then(function(){ CC.toast('已复制'); }, function(){ fb(); });
    } else fb();
    function fb(){
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); CC.toast('已复制'); } catch (e) { CC.toast('复制失败'); }
      ta.remove();
    }
  }

  document.getElementById('btnConsult').onclick = function(){
    if (!SVC.id){ CC.toast('客服暂未配置'); return; }
    location.href = 'index.php?to=' + SVC.id;
  };

  var btnGroup = document.getElementById('btnGroup');
  if (btnGroup){
    btnGroup.onclick = function(e){
      e.stopPropagation();
      if (SVC.joined){ location.href = 'group_card.php?gid=' + SVC.gid; return; }
      btnGroup.disabled = true;
      CC.api('group_join', { gid: SVC.gid }).then(function(d){
        if (d && d.pending){ CC.toast('申请已提交，等待群主处理'); btnGroup.textContent = '待审核'; }
        else { SVC.joined = 1; CC.toast('已加入官方群'); btnGroup.textContent = '进入'; btnGroup.disabled = false; }
      }).catch(function(err){ btnGroup.disabled = false; CC.toast(err.message); });
    };
  }
  var cellGroup = document.getElementById('cellGroup');
  if (cellGroup){
    cellGroup.onclick = function(){
      if (SVC.joined) location.href = 'group_card.php?gid=' + SVC.gid;
      else if (btnGroup) btnGroup.click();
    };
  }

  var copyBtn = document.getElementById('btnCopyContact');
  if (copyBtn) copyBtn.onclick = function(){ copyText(contact.textContent.trim()); };

  document.querySelectorAll('[data-faq]').forEach(function(cell){
    cell.onclick = function(){
      var body = cell.querySelector('.faq-body');
      var arrow = cell.querySelector('[data-flip]');
      var open = body.style.display === 'block';
      document.querySelectorAll('.faq-body').forEach(function(b){ b.style.display = 'none'; });
      document.querySelectorAll('[data-flip]').forEach(function(a){ a.style.transform = ''; });
      if (!open){
        body.style.display = 'block';
        if (arrow) arrow.style.transform = 'rotate(90deg)';
      }
    };
  });
})();
</script>
<?php cc_foot(); ?>
