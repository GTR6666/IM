<?php
/**
 * CC商聊 - 定时任务（建议每 10 分钟执行一次）
 * php cron.php
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';

$now = time();
$log = [];

/* 1. 过期未支付的 USDT 订单置为已过期（status=4） */
$expire = (int)setting('usdt_expire', '1800');
$n = ex('UPDATE recharge_orders SET status=4, remark=? WHERE status=0 AND network<>? AND created_at<?', [
    '订单超时关闭', '客服', $now - $expire,
]);
$log[] = "过期订单: $n";

/* 2. 清理 7 天前的验证码 */
$n = ex('DELETE FROM verify_codes WHERE created_at<?', [$now - 86400 * 7]);
$log[] = "清理验证码: $n";

/* 3. 清理 30 天前的限流文件 */
foreach (glob(CC_ROOT . '/data/rl/*.json') ?: [] as $f) {
    if (filemtime($f) < $now - 86400 * 30) @unlink($f);
}

/* 4. 过期红包标记 */
$n = ex('UPDATE red_packets SET status=2 WHERE status=0 AND expire_at<?', [$now]);
$log[] = "过期红包: $n";

/* 5. 长时间未活跃用户下线 */
$n = ex('UPDATE users SET online=0 WHERE online=1 AND last_active_at<?', [$now - 300]);
$log[] = "下线用户: $n";

/* 6. 清理 90 天前的登录日志 */
$n = ex('DELETE FROM login_logs WHERE created_at<?', [$now - 86400 * 90]);
$log[] = "清理登录日志: $n";

$line = date('Y-m-d H:i:s') . '  ' . implode(' | ', $log) . PHP_EOL;
@file_put_contents(CC_ROOT . '/data/cron.log', $line, FILE_APPEND);
echo $line;
