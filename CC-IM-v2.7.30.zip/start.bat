@echo off
chcp 65001 >nul
title CC商聊 - 本地开发服务器
cd /d "%~dp0"

set PHP_BIN=%~dp0..\tools\php\php.exe
if not exist "%PHP_BIN%" set PHP_BIN=php

set PHP_CLI_SERVER_WORKERS=8
echo ============================================
echo   CC商聊 本地服务启动中...
echo   前台: http://127.0.0.1:8899/login.php
echo   后台: http://127.0.0.1:8899/admin/login.php
echo   安装: http://127.0.0.1:8899/install.php
echo   演示账号: 740999800 / aa123456
echo   管理员:   admin / admin123456
echo ============================================
"%PHP_BIN%" -S 127.0.0.1:8899 -t "%~dp0"
pause
