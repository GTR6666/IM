<?php
/**
 * CC商聊 - USDT 充值（TRC20）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
if (!$u) {
    header('Location: login.php');
    exit;
}

$coin    = (int)$u['coin'];
$rate    = max(1, (int)setting('usdt_rate', '7'));
$minCoin = max(1, (int)setting('usdt_min_coin', '10'));
$network = (string)setting('usdt_network', 'TRC20');
$expire  = max(60, (int)setting('usdt_expire', '1800'));
$svcUid  = (int)val('SELECT id FROM users WHERE account=?', [(string)setting('service_uid', '10086')]);
$hasAddr = (string)setting('usdt_address', '') !== '';

$css = <<<CSS
.fm-label{display:flex;align-items:center;justify-content:space-between;font-size:13px;color:var(--t2);margin:0 0 8px}
.fm-input{width:100%;height:48px;border-radius:11px;background:var(--bg);padding:0 14px;font-size:16px}
.fm-input::placeholder{color:var(--t3)}
.chips{display:flex;gap:8px;margin-top:10px}
.chips button{flex:1;height:34px;border-radius:9px;background:var(--bg);color:var(--t2);font-size:13px}
.chips button:active{background:var(--line)}
.rate-line{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12.5px;color:var(--t3);margin-top:14px}
.rate-line b{color:var(--brand)}
.cs-card{display:flex;align-items:center;gap:12px;margin-top:12px;padding:15px 16px}
.cs-ico{width:40px;height:40px;border-radius:12px;background:rgba(16,185,129,.12);color:#10B981;display:flex;align-items:center;justify-content:center;flex:0 0 auto}
.cs-main{flex:1;min-width:0}
.cs-t{font-size:14px;font-weight:600}
.cs-s{font-size:11.5px;color:var(--t3);margin-top:3px;line-height:1.6}
.cs-btn{flex:0 0 auto;height:32px;padding:0 14px;border-radius:16px;background:var(--brand);color:#fff;font-size:12.5px;font-weight:600;display:flex;align-items:center}
.preview-line{margin-top:8px;background:var(--brand-soft);border-radius:10px;padding:10px 12px;font-size:13px;color:var(--text);display:flex;justify-content:space-between;align-items:center}
.preview-line b{color:var(--brand);font-size:16px}
.pay-label{font-size:12.5px;color:var(--t2)}
.pay-amount{font-size:30px;font-weight:700;letter-spacing:.5px;margin:4px 0 0;word-break:break-all}
.pay-amount small{font-size:13px;font-weight:500;color:var(--t3);margin-left:5px}
.pay-meta{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px;font-size:11.5px;color:var(--t3);word-break:break-all}
.addr-box{background:var(--bg);border-radius:11px;padding:11px 12px;margin-top:14px}
.addr-box .ab-label{font-size:11.5px;color:var(--t3)}
.addr-box .ab-val{font-family:'SF Mono',Menlo,Consolas,monospace;font-size:12.5px;word-break:break-all;margin-top:5px;line-height:1.5}
.ab-copy{display:inline-flex;align-items:center;gap:4px;margin-top:9px;font-size:12.5px;font-weight:600;color:var(--brand)}
.pay-cd{display:flex;align-items:center;justify-content:space-between;font-size:12.5px;color:var(--t2);margin-top:14px}
.pay-cd b{color:var(--gold);font-size:15px;font-variant-numeric:tabular-nums}
.notes{background:rgba(245,166,35,.12);color:var(--gold);border-radius:11px;padding:11px 12px;font-size:12.5px;line-height:1.75;margin-top:14px}
.notes b{font-size:12.5px}
.notes ol{margin:4px 0 0;padding-left:18px}
.notes li{margin-top:2px}
.ord{display:flex;align-items:flex-start;gap:10px;padding:13px 16px;border-bottom:1px solid var(--line)}
.ord:last-child{border-bottom:0}
.ord .ord-l{flex:1;min-width:0}
.ord .ord-l b{font-size:14.5px}
.ord .ord-l span{display:block;font-size:11.5px;color:var(--t3);margin-top:3px;word-break:break-all}
.ord .ord-r{flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:7px}
.ord-empty{text-align:center;color:var(--t3);font-size:12.5px;padding:26px 16px}
.tip-line{text-align:center;font-size:11.5px;color:var(--t3);margin-top:12px;line-height:1.6}
.chk-mask{position:fixed;inset:0;z-index:900;background:rgba(16,20,30,.5);backdrop-filter:blur(2px);display:none;align-items:center;justify-content:center;padding:0 26px}
.chk-mask.show{display:flex}
.chk-box{width:100%;max-width:322px;background:var(--card);border-radius:16px;padding:22px 20px 16px;text-align:center;box-shadow:var(--shadow)}
.chk-ico{height:44px;display:flex;align-items:center;justify-content:center}
.chk-title{font-size:16px;font-weight:600;margin-top:8px}
.chk-steps{margin-top:12px;text-align:left;font-size:12.5px;color:var(--t3);line-height:1.85;max-height:150px;overflow-y:auto}
.chk-steps div::before{content:'· ';color:var(--t3)}
.chk-steps div.ok{color:var(--brand)}
.chk-steps div.ok::before{content:'✓ '}
.chk-steps div.err{color:var(--red)}
.chk-steps div.err::before{content:'! '}
.chk-actions{margin-top:14px;display:flex;flex-direction:column;gap:8px}
.chk-actions .btn{height:42px;font-size:14.5px;letter-spacing:0}
CSS;
cc_head('充值 CC币', ['body_class' => 'app-body', 'css' => $css]);
?>
<div class="app">
  <div class="page">
    <div class="topbar">
      <button class="tb-back" id="btnBack" aria-label="返回">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <div class="tb-title">充值 CC币</div>
      <div class="tb-right"><span class="badge"><?= e($network) ?></span></div>
    </div>

    <div class="page-body no-tab">

      <div class="card" id="formBox">
        <div class="fm-label">
          <span>充值 CC币数量</span>
          <span style="font-size:11.5px;color:var(--t3)">最少 <?= $minCoin ?> CC币</span>
        </div>
        <input class="fm-input" id="coinInput" type="number" inputmode="numeric" min="<?= $minCoin ?>" placeholder="最少 <?= $minCoin ?> CC币">
        <div class="chips" id="quickCoin">
          <button type="button" data-amt="100">100</button>
          <button type="button" data-amt="500">500</button>
          <button type="button" data-amt="1000">1000</button>
          <button type="button" data-amt="5000">5000</button>
        </div>
        <div class="rate-line">
          <span>当前汇率：1 USDT = <b id="rateText"><?= $rate ?></b> CC币</span>
          <span>当前余额 <b style="color:var(--text)" id="coinNow"><?= $coin ?></b> CC币</span>
        </div>
        <div class="preview-line">
          <span>预计应付</span>
          <b><span id="previewUsdt">0.00</span> <small style="font-size:12px;color:var(--t3);font-weight:500">USDT</small></b>
        </div>
        <?php if (!$hasAddr): ?>
        <div class="notes" style="margin-top:14px"><b>收款地址未配置</b>
          <div style="margin-top:4px">暂时无法生成订单，请联系客服充值。</div>
        </div>
        <?php endif; ?>
        <button class="btn" id="btnCreate" type="button" style="margin-top:16px" <?= $hasAddr ? '' : 'disabled' ?>>生成充值订单</button>
        <p class="tip-line">生成订单后请按页面金额精确转账，系统自动核对链上记录</p>
      </div>

      <div class="card cs-card">
        <div class="cs-ico">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 13v-1a7.5 7.5 0 0 1 15 0v1"/><rect x="2.8" y="12.6" width="4" height="6.2" rx="2"/><rect x="17.2" y="12.6" width="4" height="6.2" rx="2"/><path d="M19.2 18.8v.7a2.6 2.6 0 0 1-2.6 2.6H13"/></svg>
        </div>
        <div class="cs-main">
          <div class="cs-t">也可以联系客服充值</div>
          <div class="cs-s">微信 / 支付宝 / 银行卡均可，客服确认后立即加币</div>
        </div>
        <a class="cs-btn" href="service.php">去联系</a>
      </div>

      <div class="card hidden" id="payBox">
        <div class="pay-label">请转账以下金额（务必精确到最后两位）</div>
        <div class="pay-amount"><span id="payAmount">0.00</span><small>USDT</small></div>
        <div class="pay-meta">
          <span id="payOrderNo">订单号 -</span>
          <span class="badge gold" id="payNetwork"><?= e($network) ?></span>
        </div>

        <div class="addr-box">
          <div class="ab-label">收款地址（<span id="payNet2"><?= e($network) ?></span>）</div>
          <div class="ab-val" id="payAddr">-</div>
          <button class="ab-copy" id="btnCopyAddr" type="button">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M15 5.5A1.5 1.5 0 0 0 13.5 4H6a2 2 0 0 0-2 2v7.5A1.5 1.5 0 0 0 5.5 15"/></svg>
            复制收款地址
          </button>
        </div>

        <div class="pay-cd">
          <span>剩余支付时间</span>
          <b id="countdown">--:--</b>
        </div>

        <div class="notes">
          <b>注意事项</b>
          <ol>
            <li>必须使用 <b>TRC20</b> 网络转账，其他网络无法到账。</li>
            <li>必须转账 <b id="noteAmount">0.00</b> USDT，金额不一致无法自动识别。</li>
            <li>转账完成后点击下方按钮，系统自动查询链上记录。</li>
          </ol>
        </div>

        <button class="btn" id="btnCheck" type="button" style="margin-top:16px">我已转账，立即核对</button>
        <button class="btn ghost" id="btnCancelPay" type="button" style="margin-top:10px">返回修改金额</button>
      </div>

      <div class="card" style="padding:0;overflow:hidden">
        <div class="row-between" style="padding:14px 16px 12px">
          <b style="font-size:15px">我的充值记录</b>
          <button class="btn small ghost" id="btnRefreshOrders" type="button" style="width:auto">刷新</button>
        </div>
        <div id="orderList"><div class="loading">加载中…</div></div>
      </div>

      <p class="tip-line">充值未到账？在订单上提交交易哈希，客服会人工核对</p>
    </div>
  </div>
</div>

<div class="chk-mask" id="chkMask">
  <div class="chk-box">
    <div class="chk-ico" id="chkIcon"><span class="spin" style="width:38px;height:38px;border-width:3px"></span></div>
    <div class="chk-title" id="chkTitle">正在核对链上转账</div>
    <div class="chk-steps" id="chkSteps"></div>
    <div class="chk-actions" id="chkActions"></div>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
window.USDT_CFG = {
  rate: <?= $rate ?>,
  min: <?= $minCoin ?>,
  network: <?= json_encode($network, JSON_UNESCAPED_UNICODE) ?>,
  coin: <?= $coin ?>,
  svcUid: <?= $svcUid ?>,
  hasAddr: <?= $hasAddr ? 1 : 0 ?>
};
</script>
<script>
(function () {
  var CFG = window.USDT_CFG;
  var S = { rate: CFG.rate, min: CFG.min, coin: CFG.coin, svcUid: CFG.svcUid, order: null, tries: 0 };
  var MAX = 30, GAP = 3000;

  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return CC.esc(s); }
  function toast(m) { CC.toast(m); }
  function api(action, data) {
    return CC.ajax(action, data, { silent: true }).then(function (res) {
      if (res.code === 401) { location.href = 'login.php'; throw new Error('401'); }
      return res;
    });
  }
  function money(n) { return (Math.round((parseFloat(n) || 0) * 100) / 100).toFixed(2); }
  function pad2(n) { return n < 10 ? '0' + n : '' + n; }

  /* ---------- 汇率与预览 ---------- */
  var coinInput = $('#coinInput');
  function refreshPreview() {
    var c = parseInt(coinInput.value, 10) || 0;
    $('#previewUsdt').textContent = c > 0 ? money(c / S.rate) : '0.00';
  }
  coinInput.addEventListener('input', refreshPreview);
  $('#quickCoin').onclick = function (e) {
    var b = e.target.closest('button[data-amt]');
    if (!b) return;
    coinInput.value = b.getAttribute('data-amt');
    refreshPreview();
  };

  api('wallet_info', {}).then(function (res) {
    if (res.code !== 0 || !res.data) return;
    S.rate = parseInt(res.data.usdt && res.data.usdt.rate, 10) || S.rate;
    S.min = parseInt(res.data.usdt && res.data.usdt.min_coin, 10) || S.min;
    S.coin = parseInt(res.data.coin, 10) || 0;
    $('#rateText').textContent = S.rate;
    $('#coinNow').textContent = S.coin;
    coinInput.setAttribute('min', S.min);
    coinInput.setAttribute('placeholder', '最少 ' + S.min + ' CC币');
    refreshPreview();
  }).catch(function () { });

  /* ---------- 生成订单 ---------- */
  var formBox = $('#formBox'), payBox = $('#payBox');
  var btnCreate = $('#btnCreate');

  btnCreate.onclick = function () {
    var c = parseInt(coinInput.value, 10) || 0;
    if (!c) return toast('请输入充值 CC币 数量');
    if (c < S.min) return toast('最少充值 ' + S.min + ' CC币');
    btnCreate.disabled = true;
    btnCreate.textContent = '生成中…';
    api('create', { coin: c }).then(function (res) {
      btnCreate.disabled = false;
      btnCreate.textContent = '生成充值订单';
      if (res.code !== 0) return toast(res.msg || '生成订单失败');
      S.order = res.data;
      renderPay(res.data);
    }).catch(function () {
      btnCreate.disabled = false;
      btnCreate.textContent = '生成充值订单';
      toast('网络异常，请重试');
    });
  };

  function renderPay(d) {
    $('#payAmount').textContent = money(d.amount_usdt);
    $('#noteAmount').textContent = money(d.amount_usdt);
    $('#payAddr').textContent = d.address || '';
    $('#payOrderNo').textContent = '订单号 ' + (d.order_no || '-');
    $('#payNetwork').textContent = d.network || CFG.network;
    $('#payNet2').textContent = d.network || CFG.network;
    formBox.classList.add('hidden');
    payBox.classList.remove('hidden');
    startCountdown();
    window.scrollTo(0, 0);
    var pb = $('.page-body'); if (pb) pb.scrollTop = 0;
    loadOrders();
  }

  $('#btnCancelPay').onclick = function () {
    stopCountdown();
    S.order = null;
    payBox.classList.add('hidden');
    formBox.classList.remove('hidden');
    refreshPreview();
  };

  /* ---------- 复制地址 ---------- */
  $('#btnCopyAddr').onclick = function () {
    var txt = $('#payAddr').textContent.trim();
    if (!txt || txt === '-') return;
    var done = function () { toast('收款地址已复制'); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(txt).then(done).catch(function () { fallbackCopy(txt, done); });
    } else fallbackCopy(txt, done);
  };
  function fallbackCopy(txt, done) {
    try {
      var ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      done();
    } catch (e) { toast('复制失败，请长按选择'); }
  }

  /* ---------- 倒计时 ---------- */
  var cdTimer = null;
  function startCountdown() {
    stopCountdown();
    tickCd();
    cdTimer = setInterval(tickCd, 1000);
  }
  function stopCountdown() {
    if (cdTimer) { clearInterval(cdTimer); cdTimer = null; }
  }
  function tickCd() {
    if (!S.order) return;
    var left = parseInt(S.order.expire_at, 10) - Math.floor(Date.now() / 1000);
    if (left <= 0) {
      $('#countdown').textContent = '已过期';
      stopCountdown();
      return;
    }
    var h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = left % 60;
    $('#countdown').textContent = (h > 0 ? pad2(h) + ':' : '') + pad2(m) + ':' + pad2(s);
  }

  /* ---------- 链上核对浮层 ---------- */
  var chkMask = $('#chkMask'), chkIcon = $('#chkIcon'), chkTitle = $('#chkTitle');
  var chkSteps = $('#chkSteps'), chkActions = $('#chkActions');
  var chkTimer = null;

  function chkReset(title) {
    chkTitle.textContent = title || '正在核对链上转账';
    chkIcon.innerHTML = '<span class="spin" style="width:38px;height:38px;border-width:3px"></span>';
    chkSteps.innerHTML = '';
    chkActions.innerHTML = '';
    chkMask.classList.add('show');
  }
  function chkStep(text, cls) {
    var d = document.createElement('div');
    d.textContent = text;
    if (cls) d.className = cls;
    chkSteps.appendChild(d);
    chkSteps.scrollTop = chkSteps.scrollHeight;
  }
  function chkSuccess(d) {
    chkIcon.innerHTML = '<svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="var(--brand)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M7.5 12.4l3 3 6-6"/></svg>';
    chkTitle.textContent = '充值成功';
    chkStep('已匹配链上转账 ' + money(d.amount) + ' USDT', 'ok');
    chkStep('CC币 +' + parseInt(d.coin, 10) + '，已到账', 'ok');
    S.coin += parseInt(d.coin, 10) || 0;
    $('#coinNow').textContent = S.coin;
    chkActions.innerHTML = '<button class="btn" id="chkDone" type="button">完成</button>';
    $('#chkDone').onclick = function () { location.reload(); };
    stopCountdown();
    loadOrders();
  }
  function chkFail(msg) {
    chkIcon.innerHTML = '<svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="var(--red)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 7.5v6M12 16.6h.01"/></svg>';
    chkTitle.textContent = '暂未匹配到转账';
    if (msg) chkStep(msg, 'err');
    chkActions.innerHTML =
      '<button class="btn" id="chkRetry" type="button">重新核对</button>' +
      '<button class="btn ghost" id="chkSvc" type="button">联系客服</button>' +
      '<button class="btn ghost" id="chkClose" type="button">关闭</button>';
    $('#chkRetry').onclick = startCheck;
    $('#chkSvc').onclick = function () {
      if (S.svcUid) location.href = 'index.php?to=' + S.svcUid;
      else { chkMask.classList.remove('show'); toast('客服暂未配置'); }
    };
    $('#chkClose').onclick = function () { chkMask.classList.remove('show'); };
  }

  function startCheck() {
    if (!S.order) return;
    if (chkTimer) { clearTimeout(chkTimer); chkTimer = null; }
    S.tries = 0;
    chkReset();
    chkStep('正在连接 TRON 网络…');
    tick();
  }
  function tick() {
    S.tries++;
    api('check_pay', { id: S.order.id }).then(function (res) {
      if (res.code === 0 && res.data && res.data.status === 'ok') {
        chkSuccess(res.data);
        return;
      }
      if (res.code !== 0) {
        var msg = res.msg || '查询失败';
        chkStep(msg, 'err');
        if (/拒绝|不存在/.test(msg)) { chkFail(''); return; }
      } else {
        var m = (res.data && res.data.msg) || '暂未查询到匹配的到账记录';
        if (S.tries === 1 || S.tries % 5 === 0) chkStep('第 ' + S.tries + ' 次核对：' + m);
      }
      if (S.tries >= MAX) { chkFail('已核对 ' + Math.round(MAX * GAP / 1000) + ' 秒仍未匹配到转账，请确认金额与网络后重试'); return; }
      chkTimer = setTimeout(tick, GAP);
    }).catch(function () {
      if (S.tries >= MAX) { chkFail('网络异常，未能完成核对'); return; }
      chkTimer = setTimeout(tick, GAP);
    });
  }
  $('#btnCheck').onclick = startCheck;

  /* ---------- 充值记录 ---------- */
  var ST_TXT = ['待支付', '待审核', '已到账', '已拒绝'];
  function stBadge(st) {
    if (st === 2) return 'badge';
    if (st === 1) return 'badge gold';
    if (st === 3) return 'badge red';
    return 'badge gray';
  }
  function loadOrders() {
    var box = $('#orderList');
    box.innerHTML = '<div class="loading">加载中…</div>';
    api('usdt_orders', {}).then(function (res) {
      if (res.code !== 0) {
        box.innerHTML = '<div class="ord-empty">' + esc(res.msg || '加载失败') + '</div>';
        return;
      }
      var list = (res.data.list || []).filter(function (o) { return String(o.network || '') !== '客服'; });
      if (!list.length) {
        box.innerHTML = '<div class="ord-empty"><div>暂无充值记录</div><div style="margin-top:4px">生成订单后会显示在这里</div></div>';
        return;
      }
      box.innerHTML = list.map(function (o) {
        var st = parseInt(o.status, 10);
        if (st < 0 || st > 3) st = 0;
        var sub = [CC.fmtFull(o.created_at)];
        sub.push('订单号 ' + o.order_no);
        if (parseFloat(o.amount_usdt) > 0) sub.push(money(o.amount_usdt) + ' USDT');
        sub.push('汇率 ' + (parseInt(o.rate, 10) || S.rate));
        if (o.remark) sub.push(o.remark);
        var act = '';
        if (st === 0) act = '<button class="btn small" type="button" data-txid="' + parseInt(o.id, 10) + '" data-coin="' + parseInt(o.coin, 10) + '">我已完成转账</button>';
        else if (st === 1) act = '<span style="font-size:11px;color:var(--t3)">等待人工核对</span>';
        return '<div class="ord">' +
          '<div class="ord-l"><b>+' + parseInt(o.coin, 10) + ' CC币</b><span>' + sub.map(esc).join(' · ') + '</span></div>' +
          '<div class="ord-r"><span class="' + stBadge(st) + '">' + ST_TXT[st] + '</span>' + act + '</div>' +
          '</div>';
      }).join('');
    }).catch(function () {
      box.innerHTML = '<div class="ord-empty">加载失败，请点击刷新重试</div>';
    });
  }
  $('#btnRefreshOrders').onclick = loadOrders;

  $('#orderList').onclick = function (e) {
    var b = e.target.closest('[data-txid]');
    if (!b) return;
    var id = parseInt(b.getAttribute('data-txid'), 10);
    CC.prompt({
      title: '填写交易哈希',
      text: '在钱包的转账记录中复制 TXID（64 位哈希）',
      placeholder: '64 位交易哈希',
      multiline: true,
      max: 64
    }).then(function (v) {
      if (v === null) return;
      var txid = String(v).trim();
      if (!/^[0-9a-fA-F]{64}$/.test(txid)) return toast('交易哈希应为 64 位十六进制字符');
      api('submit_txid', { id: id, txid: txid }).then(function (res) {
        if (res.code !== 0) return toast(res.msg || '提交失败');
        toast('已提交，等待客服核对');
        loadOrders();
      }).catch(function () { toast('网络异常，请重试'); });
    });
  };

  /* ---------- 返回 ---------- */
  $('#btnBack').onclick = function () {
    if (S.order && !payBox.classList.contains('hidden')) {
      payBox.classList.add('hidden');
      formBox.classList.remove('hidden');
      stopCountdown();
      return;
    }
    location.href = 'wallet.php';
  };

  loadOrders();
  refreshPreview();
})();
</script>
<?php cc_foot(); ?>
