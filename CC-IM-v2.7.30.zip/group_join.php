<?php
/**
 * CC商聊 - 加入群聊 / 入群申请处理
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myUid = (int)$me['id'];

function p_av(string $avatar, string $name, string $cls = ''): string
{
    if ($avatar !== '') return '<span class="avatar ' . $cls . '"><img src="' . e($avatar) . '" alt=""></span>';
    return '<span class="avatar ' . $cls . '" style="background:var(--brand)">' . e(mb_substr($name !== '' ? $name : '?', 0, 1)) . '</span>';
}

$kw = trim((string)($_GET['kw'] ?? ''));
$results = [];
if ($kw !== '') {
    if (preg_match('/^\d{3,}$/', $kw)) {
        $rows = all('SELECT g.*, (SELECT COUNT(*) FROM group_members gm WHERE gm.gid=g.gid) AS members FROM groups g WHERE g.status=1 AND g.gid=? LIMIT 5', [(int)$kw]);
    } else {
        $rows = all('SELECT g.*, (SELECT COUNT(*) FROM group_members gm WHERE gm.gid=g.gid) AS members FROM groups g WHERE g.status=1 AND g.is_public=1 AND g.name LIKE ? ORDER BY g.id DESC LIMIT 20', ['%' . $kw . '%']);
    }
    foreach ($rows as $g) {
        $gid = (int)$g['gid'];
        $role = group_role($gid, $myUid);
        $results[] = [
            'gid' => $gid,
            'name' => (string)$g['name'],
            'avatar' => (string)$g['avatar'],
            'intro' => (string)$g['intro'],
            'members' => (int)$g['members'],
            'member_limit' => (int)$g['member_limit'],
            'join_mode' => (int)$g['join_mode'],
            'joined' => $role >= 0 ? 1 : 0,
            'pending' => (int)val('SELECT COUNT(*) FROM group_join_requests WHERE gid=? AND uid=? AND status=0', [$gid, $myUid]),
        ];
    }
}

// 我收到的入群申请：我任群主或管理员的所有群
$reqs = all('SELECT r.id, r.gid, r.uid, r.reason, r.created_at, u.nickname, u.avatar, g.name AS gname
    FROM group_join_requests r
    JOIN users u ON u.id=r.uid
    JOIN groups g ON g.gid=r.gid
    JOIN group_members gm ON gm.gid=r.gid AND gm.uid=?
    WHERE r.status=0 AND gm.role>=1 AND g.status=1
    ORDER BY r.id DESC LIMIT 100', [$myUid]);

cc_head('加入群聊');
?>
<div class="app">
  <div class="page">
    <?php cc_topbar('加入群聊', 'group_list.php'); ?>
    <div class="page-body no-tab">
      <form method="get" action="group_join.php" style="padding:12px 12px 0">
        <div class="field" style="margin-bottom:8px">
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="var(--t3)" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
          <input type="search" name="kw" value="<?= e($kw) ?>" placeholder="输入群号或群名称" autocomplete="off">
          <button type="submit" class="btn small" style="height:32px">搜索</button>
        </div>
      </form>

      <?php if ($kw !== ''): ?>
        <?php if (!$results): ?>
          <div class="empty" style="padding:36px 20px">
            <div class="ico">🔍</div>
            <div>没有找到「<?= e($kw) ?>」相关的群</div>
            <div style="font-size:12px;margin-top:4px">试试完整的群号，或换个群名称关键词</div>
          </div>
        <?php else: ?>
          <div class="group-title">搜索结果（<?= count($results) ?>）</div>
          <?php foreach ($results as $r): ?>
          <div class="card">
            <div class="card-row">
              <?= p_av($r['avatar'], $r['name']) ?>
              <div class="flex1" style="min-width:0">
                <div style="font-weight:600;font-size:15px" class="nowrap"><?= e($r['name']) ?></div>
                <div class="t3 small" style="margin-top:2px">群号 <?= $r['gid'] ?> · <?= $r['members'] ?>/<?= $r['member_limit'] ?> 人</div>
              </div>
              <?php if ($r['joined']): ?>
                <a class="btn small" href="index.php?gid=<?= $r['gid'] ?>">进入</a>
              <?php elseif ($r['pending']): ?>
                <span class="pill">已申请</span>
              <?php elseif ($r['join_mode'] === 2): ?>
                <span class="pill">不可加入</span>
              <?php elseif ($r['members'] >= $r['member_limit']): ?>
                <span class="pill">已满员</span>
              <?php else: ?>
                <button class="btn small" data-join="<?= $r['gid'] ?>">加入</button>
              <?php endif; ?>
            </div>
            <?php if ($r['intro'] !== ''): ?>
            <div class="t3 small" style="margin-top:8px;line-height:1.6"><?= e($r['intro']) ?></div>
            <?php endif; ?>
            <div style="margin-top:10px">
              <a href="group_card.php?gid=<?= $r['gid'] ?>" class="small" style="color:var(--brand)">查看群名片 ›</a>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      <?php else: ?>
        <div class="card" style="text-align:center;padding:18px 16px">
          <div style="font-size:13.5px;color:var(--t2);line-height:1.8">输入 7 位群号可以直接找到群聊<br>也可以输入群名称关键词搜索</div>
        </div>
      <?php endif; ?>

      <div class="row-between" style="padding:18px 16px 6px">
        <span style="font-size:13px;color:var(--t3)">我收到的入群申请</span>
        <?php if ($reqs): ?><span class="badge red"><?= count($reqs) ?></span><?php endif; ?>
      </div>

      <div class="cell-group" id="reqList">
        <?php if (!$reqs): ?>
        <div class="empty" style="padding:26px 20px;font-size:12.5px">暂无待处理的入群申请</div>
        <?php else: foreach ($reqs as $r): ?>
        <div class="cell" data-req="<?= (int)$r['id'] ?>" style="cursor:default">
          <?= p_av((string)$r['avatar'], (string)$r['nickname'], 'sm') ?>
          <div class="c-title" style="min-width:0">
            <div class="nowrap"><?= e($r['nickname']) ?></div>
            <div class="c-desc nowrap">申请加入「<?= e($r['gname']) ?>」<?= $r['reason'] !== '' ? ' · ' . e($r['reason']) : '' ?></div>
            <div class="c-desc"><?= fmt_time((int)$r['created_at']) ?></div>
          </div>
          <div class="gap8">
            <button class="btn small ghost" data-act="reject" data-id="<?= (int)$r['id'] ?>">拒绝</button>
            <button class="btn small" data-act="accept" data-id="<?= (int)$r['id'] ?>">同意</button>
          </div>
        </div>
        <?php endforeach; endif; ?>
      </div>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-join]').forEach(function (b) {
    b.onclick = function () {
      var gid = parseInt(b.getAttribute('data-join'), 10);
      b.disabled = true;
      CC.api('group_join', { gid: gid }).then(function (d) {
        if (d && d.pending) {
          b.textContent = '已申请';
          b.className = 'btn small ghost';
          CC.toast('已提交申请，等待群主审核');
        } else {
          b.textContent = '已加入';
          b.className = 'btn small ghost';
          CC.toast('已加入群聊');
        }
      }).catch(function (e) {
        CC.toast(e.message || '加入失败');
        b.disabled = false;
      });
    };
  });

  document.querySelectorAll('[data-act]').forEach(function (b) {
    b.onclick = function () {
      var act = b.getAttribute('data-act');
      var id = parseInt(b.getAttribute('data-id'), 10);
      var cell = b.closest('[data-req]');
      b.disabled = true;
      CC.api('group_handle_join', { id: id, act: act }).then(function () {
        CC.toast(act === 'accept' ? '已同意' : '已拒绝');
        if (cell) cell.remove();
        if (!document.querySelector('[data-req]')) {
          document.getElementById('reqList').innerHTML = '<div class="empty" style="padding:26px 20px;font-size:12.5px">暂无待处理的入群申请</div>';
        }
      }).catch(function (e) {
        CC.toast(e.message || '操作失败');
        b.disabled = false;
      });
    };
  });
});
</script>
<?php cc_foot(); ?>
