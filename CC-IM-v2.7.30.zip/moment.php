<?php
/**
 * CC商聊 - 朋友圈（广场动态）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myUid = (int)$me['id'];

function p_av(string $avatar, string $name, string $cls = ''): string
{
    if ($avatar !== '') return '<span class="avatar ' . $cls . '"><img src="' . e($avatar) . '" alt=""></span>';
    return '<span class="avatar ' . $cls . '" style="background:var(--brand)">' . e(mb_substr($name !== '' ? $name : '?', 0, 1)) . '</span>';
}

$uidParam = (int)($_GET['uid'] ?? 0);
$viewUid = $uidParam > 0 ? $uidParam : $myUid;
$isSelf = $viewUid === $myUid;
$viewUser = $isSelf ? $me : one('SELECT * FROM users WHERE id=?', [$viewUid]);
if (!$viewUser) {
    cc_head('朋友圈');
    ?>
    <div class="app"><div class="page">
      <?php cc_topbar('朋友圈', 'discover.php'); ?>
      <div class="page-body no-tab">
        <div class="empty"><div class="ico">🌤️</div><div>用户不存在</div>
          <div style="margin-top:14px"><a class="btn" href="discover.php" style="max-width:200px;margin:0 auto">返回广场</a></div>
        </div>
      </div>
    </div></div>
    <?php
    cc_foot();
    exit;
}

$feed = [];
if ($uidParam > 0) {
    require_once __DIR__ . '/lib/api_moment.php'; // 复用 moment_row，字段与 feed_list 对齐
    $isFriend = (bool)one('SELECT id FROM friends WHERE uid=? AND fid=? AND status=1', [$myUid, $viewUid]);
    $visWhere = $isSelf ? '1=1' : ($isFriend ? 'm.visibility<2' : 'm.visibility=0');
    $rows = all('SELECT m.* FROM moment m WHERE m.uid=? AND m.deleted=0 AND ' . $visWhere . ' ORDER BY m.id DESC LIMIT 50', [$viewUid]);
    foreach ($rows as $r) $feed[] = moment_row($r, $myUid);
}

$lastRead = (int)val('SELECT last_read_at FROM moment_reads WHERE uid=?', [$myUid]);
$unreadLikes = (int)val('SELECT COUNT(*) FROM moment_likes l JOIN moment m ON m.id=l.mid WHERE m.uid=? AND l.uid<>? AND l.created_at>?', [$myUid, $myUid, $lastRead]);
$unreadComments = (int)val('SELECT COUNT(*) FROM moment_comments c JOIN moment m ON m.id=c.mid WHERE m.uid=? AND c.uid<>? AND c.created_at>? AND c.deleted=0', [$myUid, $myUid, $lastRead]);
$likeNotifies = all('SELECT l.created_at AS created_at, u.id AS uid, u.nickname, u.avatar, m.id AS mid, m.content
    FROM moment_likes l JOIN users u ON u.id=l.uid JOIN moment m ON m.id=l.mid
    WHERE m.uid=? AND l.uid<>? AND l.created_at>? ORDER BY l.id DESC LIMIT 30', [$myUid, $myUid, $lastRead]);

$displayName = $viewUser['nickname'] ?: ('用户' . substr((string)$viewUser['account'], -4));
$myDisplayName = $me['nickname'] ?: ('用户' . substr((string)$me['account'], -4));
$feedCount = $uidParam > 0 ? count($feed) : -1;

cc_head('朋友圈');
?>
<style>
.moment-comment .reply-to{color:var(--t3);font-size:12px;}
.moment-comment .del-c{color:var(--t3);font-size:11px;margin-left:6px;vertical-align:1px;}
.mo-thumb{position:relative;}
.mo-thumb img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;display:block;}
.mo-thumb button{position:absolute;top:-6px;right:-6px;width:22px;height:22px;border-radius:50%;background:rgba(0,0,0,.62);color:#fff;font-size:13px;line-height:22px;text-align:center;}
</style>
<div class="app">
  <div class="page">
    <div class="topbar">
      <button class="tb-back" id="btnBack" aria-label="返回">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <div class="tb-title">朋友圈</div>
      <div class="tb-right">
        <button class="tb-btn" id="btnPost" aria-label="发表动态">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5A2.5 2.5 0 0 1 5.5 6h1.6l1.2-1.7h6.4L15.9 6h2.6A2.5 2.5 0 0 1 21 8.5v9A2.5 2.5 0 0 1 18.5 20h-13A2.5 2.5 0 0 1 3 17.5z"/><circle cx="12" cy="12.6" r="3.6"/></svg>
        </button>
        <button class="tb-btn" id="btnNotify" aria-label="朋友圈消息" style="position:relative">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6"/><path d="M10.3 19a2 2 0 0 0 3.4 0"/></svg>
          <span id="msgDot" class="dot <?= ($unreadLikes + $unreadComments) > 0 ? '' : 'hidden' ?>" style="position:absolute;top:3px;right:3px;min-width:8px;width:8px;height:8px;padding:0;border-radius:50%;background:var(--red);display:block"></span>
        </button>
      </div>
    </div>

    <div class="page-body no-tab" style="padding-bottom:calc(20px + var(--safe-b))">
      <div style="position:relative;margin-bottom:10px">
        <div style="height:136px;background:linear-gradient(135deg,#07C160 0%,#06AD56 45%,#3B82F6 100%)"></div>
        <div style="display:flex;align-items:flex-end;gap:12px;padding:0 16px;margin-top:-30px;position:relative">
          <span style="display:inline-block;border-radius:22px;box-shadow:0 4px 14px rgba(0,0,0,.18)"><?= p_av((string)$viewUser['avatar'], $displayName, 'xl') ?></span>
          <div style="padding-bottom:8px;min-width:0;flex:1">
            <div style="font-size:17px;font-weight:600" class="nowrap"><?= e($displayName) ?></div>
            <div class="t3 small"><?= $isSelf ? '我的朋友圈' : 'TA 的朋友圈' ?></div>
          </div>
        </div>
      </div>

      <div id="feed"></div>
      <div class="loading" id="loading"><span class="spin"></span> 加载中…</div>
      <div class="empty hidden" id="emptyBox">
        <div class="ico">🌤️</div>
        <div><?= $isSelf ? '还没有发过动态' : 'TA 还没有发过动态' ?></div>
        <?php if ($isSelf): ?><div style="font-size:12px;margin-top:4px">点右上角相机，发一条吧</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
window.PAGE = {
  uid: <?= $uidParam ?>,
  feed: <?= json_encode($feed, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  likes: <?= json_encode($likeNotifies, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  myUid: <?= $myUid ?>,
  myName: <?= json_encode($myDisplayName, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  myAvatar: <?= json_encode((string)$me['avatar'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  myAvatarFallback: <?= json_encode(mb_substr($me['nickname'] ?: '我', 0, 1), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>
};
document.addEventListener('DOMContentLoaded', function () {
  var PAGE = window.PAGE;
  var FEED = [];
  var viewOther = PAGE.uid > 0;
  var feedEl = document.getElementById('feed');
  var loading = document.getElementById('loading');
  var emptyBox = document.getElementById('emptyBox');

  function copyText(t) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      CC.toast(ok ? '已复制' : '复制失败，请手动选择复制');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () { CC.toast('已复制'); }, fallback);
    } else {
      fallback();
    }
  }

  function itemHtml(m) {
    var imgs = m.images || [];
    var h = '<div class="moment" data-mid="' + m.id + '">';
    h += '<a href="user.php?uid=' + m.uid + '" style="flex:0 0 auto">' + CC.avatarHtml(m.author || {}) + '</a>';
    h += '<div class="moment-body">';
    h += '<a class="moment-name" href="user.php?uid=' + m.uid + '">' + CC.esc((m.author && m.author.nickname) || '用户') + '</a>';
    if (m.content) h += '<div class="moment-text">' + CC.esc(m.content) + '</div>';
    if (imgs.length === 1) {
      h += '<div class="moment-imgs single"><img src="' + CC.esc(imgs[0]) + '" data-img="' + CC.esc(imgs[0]) + '" alt=""></div>';
    } else if (imgs.length > 1) {
      h += '<div class="moment-imgs">' + imgs.slice(0, 9).map(function (u) {
        return '<img src="' + CC.esc(u) + '" data-img="' + CC.esc(u) + '" alt="">';
      }).join('') + '</div>';
    }
    if (m.video) {
      h += '<video src="' + CC.esc(m.video) + '" controls playsinline preload="metadata" style="width:100%;max-height:280px;border-radius:8px;margin-top:8px;background:#000"></video>';
    }
    h += '<div class="moment-foot"><span>' + CC.timeAgo(m.created_at) + '</span>' +
      '<div class="moment-actions">' +
      '<button data-act="like">' + (m.liked ? '取消' : '赞') + '</button>' +
      '<button data-act="comment">评论</button>' +
      '<button data-act="more">···</button>' +
      '</div></div>';
    var likes = m.likes || [];
    if (likes.length) {
      h += '<div class="moment-likes">❤ ' + likes.map(function (l) { return CC.esc(l.nickname); }).join('、') + '</div>';
    }
    var cs = m.comments || [];
    if (cs.length) {
      h += '<div class="moment-comments">' + cs.map(function (c) {
        return '<div class="moment-comment" data-cid="' + c.id + '">' +
          '<b data-uid="' + c.uid + '" data-name="' + CC.esc(c.nickname) + '">' + CC.esc(c.nickname) + '</b>' +
          (c.reply_name ? '<span class="reply-to"> 回复 ' + CC.esc(c.reply_name) + '</span>' : '') +
          '：' + CC.esc(c.content) +
          (c.mine ? '<button class="del-c" data-act="delcomment" data-cid="' + c.id + '">删除</button>' : '') +
          '</div>';
      }).join('') + '</div>';
    }
    h += '</div></div>';
    return h;
  }

  function findM(mid) {
    for (var i = 0; i < FEED.length; i++) if (parseInt(FEED[i].id, 10) === mid) return FEED[i];
    return null;
  }

  function paint() {
    feedEl.innerHTML = FEED.map(itemHtml).join('');
    emptyBox.classList.toggle('hidden', FEED.length > 0);
  }

  function update(mid) {
    var node = feedEl.querySelector('.moment[data-mid="' + mid + '"]');
    var m = findM(mid);
    if (node && m) node.outerHTML = itemHtml(m);
    else if (m) paint();
  }

  function loadFeed() {
    if (viewOther) {
      FEED = PAGE.feed || [];
      loading.classList.add('hidden');
      paint();
      return;
    }
    CC.api('feed_list', {}).then(function (d) {
      FEED = d.list || [];
      loading.classList.add('hidden');
      paint();
    }).catch(function (e) {
      loading.classList.add('hidden');
      CC.toast(e.message || '加载失败');
      paint();
    });
  }

  function goMyFeed() {
    location.href = 'moment.php';
  }

  function doLike(m) {
    CC.api('like', { id: m.id }).then(function (d) {
      if (d && d.liked) {
        m.liked = 1;
        m.likes = (m.likes || []).concat([{ uid: PAGE.myUid, nickname: PAGE.myName }]);
      } else {
        m.liked = 0;
        m.likes = (m.likes || []).filter(function (l) { return parseInt(l.uid, 10) !== PAGE.myUid; });
      }
      update(m.id);
    }).catch(function (e) { CC.toast(e.message || '操作失败'); });
  }

  function doComment(m, replyUid, replyName) {
    CC.prompt({
      title: replyUid ? ('回复 ' + replyName) : '评论',
      multiline: true,
      max: 500,
      placeholder: '说点什么…'
    }).then(function (t) {
      if (!t) return;
      CC.api('comment', { id: m.id, content: t, reply_uid: replyUid || 0 }).then(function (d) {
        m.comments = (m.comments || []).concat([{
          id: d.id, uid: PAGE.myUid, nickname: PAGE.myName, avatar: PAGE.myAvatar,
          reply_uid: replyUid || 0, reply_name: replyName || '', content: t,
          created_at: Math.floor(Date.now() / 1000), mine: 1
        }]);
        update(m.id);
        CC.toast('评论成功');
      }).catch(function (e) { CC.toast(e.message || '评论失败'); });
    });
  }

  function delComment(m, cid) {
    cid = parseInt(cid, 10);
    CC.confirm({ title: '删除评论', text: '确定删除这条评论？', danger: true, ok: '删除' }).then(function (yes) {
      if (!yes) return;
      CC.api('delete_comment', { id: cid }).then(function () {
        m.comments = (m.comments || []).filter(function (c) { return parseInt(c.id, 10) !== cid; });
        update(m.id);
        CC.toast('已删除');
      }).catch(function (e) { CC.toast(e.message || '删除失败'); });
    });
  }

  function delMoment(m) {
    CC.confirm({ title: '删除动态', text: '删除后不可恢复，确定删除？', danger: true, ok: '删除' }).then(function (yes) {
      if (!yes) return;
      CC.api('delete_moment', { id: m.id }).then(function () {
        FEED = FEED.filter(function (x) { return parseInt(x.id, 10) !== parseInt(m.id, 10); });
        paint();
        CC.toast('已删除');
      }).catch(function (e) { CC.toast(e.message || '删除失败'); });
    });
  }

  function openRepost(m) {
    var s = CC.sheet('转发', '<div class="sheet-item" data-a="feed">转发到我的动态</div>' +
      '<div class="sheet-item" data-a="chat">发送给好友</div>');
    s.el.querySelectorAll('[data-a]').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        s.close();
        if (a === 'feed') {
          CC.api('repost', { id: m.id }).then(function () {
            CC.toast('已转发到我的动态');
            setTimeout(goMyFeed, 500);
          }).catch(function (e) { CC.toast(e.message || '转发失败'); });
        } else {
          pickFriends('发送给好友', function (ids) {
            var i = 0;
            (function next() {
              if (i >= ids.length) { CC.toast('已发送'); return; }
              CC.api('repost', { id: m.id, to: ids[i++] }).then(function () { next(); }).catch(function () { next(); });
            })();
          });
        }
      };
    });
  }

  function openMore(m) {
    var html = '<div class="sheet-item" data-a="repost">转发</div>' +
      '<div class="sheet-item" data-a="copy">复制文字</div>';
    if (m.mine) html += '<div class="sheet-item danger" data-a="delete">删除</div>';
    var s = CC.sheet('操作', html);
    s.el.querySelectorAll('[data-a]').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        s.close();
        if (a === 'repost') openRepost(m);
        else if (a === 'copy') copyText(m.content || '');
        else if (a === 'delete') delMoment(m);
      };
    });
  }

  function pickFriends(title, onDone) {
    CC.api('share_targets').then(function (d) {
      var friends = d.friends || [];
      if (!friends.length) { CC.toast('还没有好友，先去通讯录添加吧'); return; }
      var html = '<div class="picker-list">' + friends.map(function (f) {
        return '<div class="picker-item" data-uid="' + f.id + '">' +
          '<span class="check">✓</span>' + CC.avatarHtml({ avatar: f.avatar, nickname: f.name }, 'sm') +
          '<div class="flex1 nowrap">' + CC.esc(f.name) + '</div></div>';
      }).join('') + '</div><div style="padding:12px 0 4px"><button class="btn" id="pickOk">确定发送</button></div>';
      var s = CC.sheet(title, html);
      s.el.querySelectorAll('.picker-item').forEach(function (el) {
        el.onclick = function () { el.classList.toggle('selected'); };
      });
      s.el.querySelector('#pickOk').onclick = function () {
        var ids = [];
        s.el.querySelectorAll('.picker-item.selected').forEach(function (el) {
          ids.push(parseInt(el.getAttribute('data-uid'), 10));
        });
        if (!ids.length) { CC.toast('请选择好友'); return; }
        s.close();
        onDone(ids);
      };
    }).catch(function (e) { CC.toast(e.message || '加载好友失败'); });
  }

  feedEl.addEventListener('click', function (e) {
    var img = e.target.closest('[data-img]');
    if (img) { CC.previewImage(img.getAttribute('data-img')); return; }
    var nameEl = e.target.closest('.moment-comment b[data-uid]');
    var actEl = e.target.closest('[data-act]');
    if (actEl) {
      var mid = parseInt(actEl.closest('.moment').getAttribute('data-mid'), 10);
      var m = findM(mid);
      if (!m) return;
      var act = actEl.getAttribute('data-act');
      if (act === 'like') doLike(m);
      else if (act === 'comment') doComment(m, 0, '');
      else if (act === 'more') openMore(m);
      else if (act === 'delcomment') delComment(m, actEl.getAttribute('data-cid'));
      return;
    }
    if (nameEl) {
      var mid2 = parseInt(nameEl.closest('.moment').getAttribute('data-mid'), 10);
      var m2 = findM(mid2);
      if (!m2) return;
      doComment(m2, parseInt(nameEl.getAttribute('data-uid'), 10), nameEl.getAttribute('data-name') || '');
    }
  });

  function openComposer() {
    var imgs = [];
    var vis = 0;
    var html = '<textarea id="moText" maxlength="1000" placeholder="这一刻的想法…" style="display:block;width:100%;min-height:104px;background:var(--bg);border-radius:12px;padding:12px;font-size:15px;line-height:1.6;resize:none"></textarea>' +
      '<div class="row-between" style="margin-top:6px"><span></span><span class="t3 small" id="moCount">0/1000</span></div>' +
      '<div id="moImgs" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px"></div>' +
      '<button id="moAdd" style="width:100%;height:46px;border-radius:10px;background:var(--bg);color:var(--t2);margin-top:8px;font-size:13.5px">＋ 添加图片（最多 9 张）</button>' +
      '<div class="row-between" style="margin-top:16px"><span class="t2">谁可以看</span><div class="gap8" id="moVis">' +
      '<button class="pill" data-v="0">公开</button><button class="pill" data-v="1">仅好友</button><button class="pill" data-v="2">仅自己</button>' +
      '</div></div>' +
      '<button class="btn" id="moSend" style="margin-top:16px">发表</button>';
    var s = CC.sheet('发表动态', html);
    var txt = s.el.querySelector('#moText');
    var cnt = s.el.querySelector('#moCount');
    var imgBox = s.el.querySelector('#moImgs');
    var addBtn = s.el.querySelector('#moAdd');
    var sendBtn = s.el.querySelector('#moSend');
    var visBox = s.el.querySelector('#moVis');

    function paintVis() {
      visBox.querySelectorAll('[data-v]').forEach(function (b) {
        var on = parseInt(b.getAttribute('data-v'), 10) === vis;
        b.style.background = on ? 'var(--brand)' : 'var(--bg)';
        b.style.color = on ? '#fff' : 'var(--t2)';
      });
    }

    function paintImgs() {
      imgBox.innerHTML = imgs.map(function (u, i) {
        return '<div class="mo-thumb"><img src="' + CC.esc(u) + '" alt="" data-i="' + i + '">' +
          '<button data-del="' + i + '">×</button></div>';
      }).join('');
      addBtn.textContent = imgs.length >= 9 ? '最多 9 张图片' : '＋ 添加图片（' + imgs.length + '/9）';
    }

    paintVis();
    paintImgs();

    txt.addEventListener('input', function () { cnt.textContent = txt.value.length + '/1000'; });
    visBox.querySelectorAll('[data-v]').forEach(function (b) {
      b.onclick = function () { vis = parseInt(b.getAttribute('data-v'), 10); paintVis(); };
    });
    imgBox.addEventListener('click', function (e) {
      var d = e.target.closest('[data-del]');
      if (d) { imgs.splice(parseInt(d.getAttribute('data-del'), 10), 1); paintImgs(); return; }
      var im = e.target.closest('img[data-i]');
      if (im) CC.previewImage(im.getAttribute('src'));
    });
    addBtn.onclick = function () {
      if (imgs.length >= 9) { CC.toast('最多 9 张图片'); return; }
      var inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = 'image/*';
      inp.multiple = true;
      // iOS 要求 input 必须挂在文档中，否则 click() 会被静默忽略
      inp.style.cssText = 'position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0';
      document.body.appendChild(inp);
      inp.onchange = function () {
        var files = Array.prototype.slice.call(inp.files || []);
        (function next(i) {
          if (i >= files.length) return;
          if (imgs.length >= 9) { CC.toast('最多 9 张图片'); return; }
          CC.toast('上传中…');
          CC.upload('upload_cover', files[i]).then(function (d) {
            imgs.push(d.url);
            paintImgs();
            next(i + 1);
          }).catch(function (e) {
            CC.toast(e.message || '上传失败');
            next(i + 1);
          });
        })(0);
      };
      inp.click();
      // 部分浏览器不触发 change（用户取消），延迟回收避免内存泄漏
      setTimeout(function(){ if (inp.parentNode) inp.parentNode.removeChild(inp); }, 60000);
    };
    sendBtn.onclick = function () {
      var content = txt.value.trim();
      if (!content && !imgs.length) { CC.toast('说点什么吧'); txt.focus(); return; }
      sendBtn.disabled = true;
      CC.api('send_moment', { content: content, images: imgs, visibility: vis }).then(function () {
        s.close();
        CC.toast('发布成功');
        setTimeout(goMyFeed, 400);
      }).catch(function (e) {
        sendBtn.disabled = false;
        CC.toast(e.message || '发布失败');
      });
    };
  }

  function openNotify() {
    CC.api('moment_notify_unread').then(function (d) {
      var list = d.list || [];
      var html = '';
      if (list.length) {
        html += '<div class="group-title" style="padding:2px 4px 6px">评论（' + list.length + '）</div>';
        html += list.map(function (c) {
          return '<div class="picker-item" style="cursor:default">' +
            CC.avatarHtml({ avatar: c.avatar, nickname: c.nickname }, 'sm') +
            '<div class="flex1" style="min-width:0">' +
            '<div style="font-size:13.5px"><b>' + CC.esc(c.nickname) + '</b> 评论了我的动态</div>' +
            '<div class="t3 small nowrap">' + CC.esc(c.content || '') + '</div>' +
            '<div class="t3 small">' + CC.fmtTime(c.created_at) + '</div>' +
            '</div></div>';
        }).join('');
      } else {
        html += '<div class="group-title" style="padding:2px 4px 6px">评论</div>';
        html += '<div class="t3 small" style="padding:0 4px 8px">暂无新的评论</div>';
      }
      var likes = PAGE.likes || [];
      if (likes.length) {
        html += '<div class="group-title" style="padding:12px 4px 6px">赞（' + likes.length + '）</div>';
        html += likes.map(function (l) {
          return '<div class="picker-item" style="cursor:default">' +
            CC.avatarHtml({ avatar: l.avatar, nickname: l.nickname }, 'sm') +
            '<div class="flex1" style="min-width:0">' +
            '<div style="font-size:13.5px"><b>' + CC.esc(l.nickname) + '</b> 赞了我的动态</div>' +
            '<div class="t3 small nowrap">' + CC.esc((l.content || '').slice(0, 40)) + '</div>' +
            '<div class="t3 small">' + CC.fmtTime(l.created_at) + '</div>' +
            '</div></div>';
        }).join('');
      }
      CC.sheet('朋友圈消息', html);
      CC.api('moment_mark_read').then(function () {
        document.getElementById('msgDot').classList.add('hidden');
        PAGE.likes = [];
      }).catch(function () { });
    }).catch(function (e) { CC.toast(e.message || '加载失败'); });
  }

  document.getElementById('btnBack').onclick = function () {
    if (history.length > 1) history.back();
    else location.href = 'discover.php';
  };
  document.getElementById('btnPost').onclick = openComposer;
  document.getElementById('btnNotify').onclick = openNotify;

  loadFeed();
});
</script>
<?php cc_foot(); ?>
