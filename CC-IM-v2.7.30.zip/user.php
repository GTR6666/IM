<?php
/**
 * CC商聊 - 用户资料
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$uid = (int)($_GET['uid'] ?? 0);
if ($uid <= 0) { header('Location: contacts.php'); exit; }
if ($uid === (int)$me['id']) { header('Location: profile.php'); exit; }

$u = one('SELECT * FROM users WHERE id=?', [$uid]);
// 群内查看他人资料：若群主关闭了「成员信息可查看」，仅群主/管理员可被查看
$fromGid = (int)($_GET['gid'] ?? 0);
if ($u && $fromGid > 0) {
    $g = group_by_gid($fromGid);
    if ($g && (int)($g['hide_member_info'] ?? 0) === 1) {
        $myRole  = group_role($fromGid, (int)$me['id']);
        $hisRole = group_role($fromGid, (int)$uid);
        // 群主/管理员资料始终可看；访问者本身是群主/管理员也可看
        if ($hisRole < 1 && $myRole < 1) {
            cc_head('用户资料', ['body_class' => 'app-body']);
            echo '<div class="app"><div class="page">';
            cc_topbar('群成员资料', 'group_info.php?gid=' . $fromGid);
            echo '<div class="page-body no-tab"><div class="empty" style="padding-top:120px">'
                . '<div class="ico">🔒</div><div>群主已关闭成员信息查看</div>'
                . '<div style="font-size:12.5px;margin-top:8px;color:var(--t3)">群主与管理员的信息仍可查看</div>'
                . '<div style="margin-top:18px"><a class="btn small ghost" style="display:inline-flex" href="index.php?gid=' . $fromGid . '">返回群聊</a></div>'
                . '</div></div></div></div>';
            cc_foot();
            exit;
        }
    }
}
if (!$u) {
    cc_head('用户不存在', ['body_class' => 'app-body']);
    echo '<div class="app"><div class="page">';
    cc_topbar('用户资料', 'contacts.php');
    echo '<div class="page-body no-tab"><div class="empty"><div class="ico">👤</div><div>用户不存在或已注销</div>'
        . '<div class="mt16"><button class="btn small ghost" onclick="location.href=\'contacts.php\'" style="margin:0 auto">返回通讯录</button></div></div></div>';
    echo '</div></div>';
    cc_foot();
    exit;
}

$pub = user_public($u, true);
$isVip = is_vip($u);
$vipLevel = $isVip ? (int)$u['vip_level'] : 0;
$showYxid = $u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account']);
$f = one('SELECT * FROM friends WHERE uid=? AND fid=? AND status=1', [(int)$me['id'], $uid]);
$isFriend = $f ? 1 : 0;
$remark = $f ? (string)$f['remark'] : '';
$name = $remark !== '' ? $remark : $pub['nickname'];
$online = (int)$u['online'];
$lastActive = (int)$u['last_active_at'];
$momentPage = is_file(CC_ROOT . '/moment.php');
$callPage = is_file(CC_ROOT . '/call.php');
$callEnabled = (string)setting('call_enabled', '1') === '1' && $callPage;
$region = trim((string)$u['region']);
$bio = trim((string)$u['bio']);
$genderTxt = [0 => '', 1 => '男', 2 => '女'][max(0, min(2, (int)$u['gender']))] ?? '';
$joined = (int)$u['created_at'] > 0 ? date('Y-m-d', (int)$u['created_at']) : '';

cc_head($name, ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('用户资料', 'contacts.php'); ?>

    <div class="page-body no-tab">
      <div class="card" style="display:flex;gap:16px;align-items:center;padding:20px 16px">
        <?php if ($pub['avatar'] !== ''): ?>
        <span class="avatar xl" style="flex:0 0 auto"><img src="<?= e($pub['avatar']) ?>" alt=""></span>
        <?php else: ?>
        <span class="avatar xl" style="flex:0 0 auto;background:var(--brand)"><?= e(mb_substr($pub['nickname'], 0, 1)) ?></span>
        <?php endif; ?>
        <div style="flex:1;min-width:0">
          <div style="font-size:20px;font-weight:600;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            <span class="nowrap" style="max-width:190px"><?= e($name) ?></span>
            <?php if ($vipLevel > 0): ?><?= vip_badge($vipLevel) ?><?php endif; ?>
            <?php if ($pub['is_developer']): ?><span class="badge purple">官方</span><?php endif; ?>
          </div>
          <div class="t3 small" style="margin-top:6px;display:flex;align-items:center;gap:5px">
            <?= e(pretty_number_label((string)($pub['pretty_yxid'] ?? ''), 'CC号', '靓号')) ?>：<?= pretty_number_html((string)$showYxid, (string)($pub['pretty_yxid'] ?? '')) ?>
          </div>
          <div class="small" style="margin-top:6px;display:flex;align-items:center;gap:6px">
            <?php if ($online): ?>
            <span class="tag-online"></span><span class="green-text">在线</span>
            <?php else: ?>
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--t3)"></span>
            <span class="t3">离线<?= $lastActive > 0 ? ' · ' . e(fmt_time($lastActive)) : '' ?></span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="cell-group">
        <div class="cell" style="cursor:default;align-items:flex-start">
          <div class="c-icon" style="background:rgba(7,193,96,.1);color:var(--brand)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h10"/></svg>
          </div>
          <div class="c-title" style="font-size:13.5px;color:var(--t2);white-space:pre-wrap;word-break:break-word"><?= $bio !== '' ? e($bio) : '这个人很懒，什么都没写' ?></div>
        </div>
        <?php if ($region !== ''): ?>
        <div class="cell" style="cursor:default">
          <div class="c-icon" style="background:rgba(59,130,246,.12);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>
          </div>
          <div class="c-title"><?= e($region) ?><?= $genderTxt !== '' ? ' · ' . e($genderTxt) : '' ?></div>
        </div>
        <?php endif; ?>
        <?php if ($remark !== ''): ?>
        <div class="cell" style="cursor:default">
          <div class="c-title small t2">昵称</div>
          <div class="c-value"><?= e($pub['nickname']) ?></div>
        </div>
        <?php endif; ?>
        <?php if ($joined !== ''): ?>
        <div class="cell" style="cursor:default">
          <div class="c-title small t2">加入时间</div>
          <div class="c-value"><?= e($joined) ?></div>
        </div>
        <?php endif; ?>
      </div>

      <div class="card" style="padding:12px;display:flex;gap:8px">
        <button class="btn" id="btnChat" style="flex:1">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px"><path d="M4 5.5h16a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 20 17.5H9l-5 3.5v-3.5H4A1.5 1.5 0 0 1 2.5 16V7A1.5 1.5 0 0 1 4 5.5z"/></svg>
          发消息
        </button>
        <button class="btn ghost" id="btnVoice" style="flex:0 0 62px;padding:0" title="语音通话">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 3.5l3 .5 1 4-2 1.5a12 12 0 0 0 6 6l1.5-2 4 1 .5 3a2 2 0 0 1-2.2 2A17 17 0 0 1 4.5 5.7 2 2 0 0 1 6.5 3.5z"/></svg>
        </button>
        <button class="btn ghost" id="btnVideo" style="flex:0 0 62px;padding:0" title="视频通话">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="12" height="12" rx="2.4"/><path d="M15 10.5l5-3v9l-5-3z"/></svg>
        </button>
      </div>

      <div class="cell-group">
        <?php if ($isFriend): ?>
        <div class="cell" id="cellRemark">
          <div class="c-title">设置备注</div>
          <div class="c-value"><?= $remark !== '' ? e($remark) : '未设置' ?><span class="arrow">›</span></div>
        </div>
        <?php else: ?>
        <div class="cell" id="cellAddFriend">
          <div class="c-icon" style="background:var(--brand-soft);color:var(--brand)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="9.5" cy="8" r="3.4"/><path d="M3.5 19.5a6 6 0 0 1 12 0"/><path d="M18 8v6M15 11h6"/></svg>
          </div>
          <div class="c-title">加为好友</div>
          <span class="arrow">›</span>
        </div>
        <?php endif; ?>
        <?php if ($momentPage): ?>
        <div class="cell" id="cellMoment">
          <div class="c-icon" style="background:rgba(245,166,35,.14);color:var(--gold)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.2"/></svg>
          </div>
          <div class="c-title">朋友圈</div>
          <span class="arrow">›</span>
        </div>
        <?php endif; ?>
        <?php if ($isFriend): ?>
        <div class="cell danger" id="cellDelFriend">
          <div class="c-title">删除好友</div>
          <span class="arrow">›</span>
        </div>
        <?php endif; ?>
      </div>

      <div class="cell-group" style="margin-bottom:26px">
        <div class="cell" id="cellReport">
          <div class="c-icon" style="background:rgba(255,71,87,.12);color:var(--red)">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M12 3l9 16H3z"/><path d="M12 9v4M12 16.5v.5"/></svg>
          </div>
          <div class="c-title">举报 / 投诉</div>
          <span class="arrow">›</span>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
window.TARGET = <?= json_encode(['uid' => $uid, 'name' => $name, 'remark' => $remark, 'is_friend' => $isFriend], JSON_UNESCAPED_UNICODE) ?>;
window.CFG = { callEnabled: <?= $callEnabled ? 1 : 0 ?>, momentPage: <?= $momentPage ? 1 : 0 ?> };
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var T = window.TARGET, CFG = window.CFG;
  var ME = window.ME || {};

  function go(url){ location.href = url; }

  document.getElementById('btnChat').onclick = function(){ go('index.php?to=' + T.uid); };

  function call(media){
    if (!CFG.callEnabled){ CC.toast('语音视频功能暂未开放'); return; }
    go('call.php?to=' + T.uid + '&media=' + media);
  }
  document.getElementById('btnVoice').onclick = function(){ call(1); };
  document.getElementById('btnVideo').onclick = function(){ call(2); };

  var cellRemark = document.getElementById('cellRemark');
  if (cellRemark){
    cellRemark.onclick = function(){
      CC.prompt({ title: '设置备注', placeholder: '给好友一个备注名', value: T.remark || '', max: 32 }).then(function(v){
        if (v === null) return;
        CC.api('set_remark', { fid: T.uid, remark: v }).then(function(){
          CC.toast('已保存');
          setTimeout(function(){ location.reload(); }, 420);
        }).catch(function(e){ CC.toast(e.message); });
      });
    };
  }

  var cellAdd = document.getElementById('cellAddFriend');
  if (cellAdd){
    cellAdd.onclick = function(){
      CC.prompt({ title: '添加好友', text: '向 ' + T.name + ' 发送好友申请', placeholder: '填写申请理由', value: '我是 ' + (ME.nickname || ''), max: 50 })
        .then(function(reason){
          if (reason === null) return;
          if (!reason){ CC.toast('请填写申请理由'); return; }
          CC.api('send_friend_request', { to_uid: T.uid, reason: reason }).then(function(){
            CC.toast('申请已发送');
          }).catch(function(e){ CC.toast(e.message); });
        });
    };
  }

  var cellMoment = document.getElementById('cellMoment');
  if (cellMoment) cellMoment.onclick = function(){ go('moment.php?uid=' + T.uid); };

  var cellDel = document.getElementById('cellDelFriend');
  if (cellDel){
    cellDel.onclick = function(){
      CC.confirm({ title: '删除好友', text: '删除后将同时清除聊天会话，且不再收到对方消息。', ok: '删除', danger: true }).then(function(yes){
        if (!yes) return;
        CC.api('delete_friend', { fid: T.uid }).then(function(){
          CC.toast('已删除好友');
          setTimeout(function(){ go('contacts.php'); }, 500);
        }).catch(function(e){ CC.toast(e.message); });
      });
    };
  }

  /* ---------- 举报 ---------- */
  var REASONS = ['欺诈 / 诈骗', '色情低俗', '骚扰辱骂', '侵权盗号', '发布违禁内容', '其他'];
  document.getElementById('cellReport').onclick = function(){
    var s = CC.sheet('举报 / 投诉', '')
    , box = s.el.querySelector('.sheet-body');
    box.innerHTML = '<div id="rpReasons">' + REASONS.map(function(r, i){
        return '<div class="sheet-item" data-r="' + i + '"><span style="flex:1">' + CC.esc(r) + '</span><span class="rpTick t3" style="display:none">✓</span></div>';
      }).join('') + '</div>'
      + '<textarea id="rpDetail" placeholder="补充说明（选填，最多 200 字）" maxlength="200" style="width:100%;min-height:74px;background:var(--bg);border-radius:10px;padding:10px 12px;font-size:14px;margin-top:10px;resize:none"></textarea>'
      + '<button class="btn" id="rpSubmit" style="margin-top:12px">提交举报</button>'
      + '<div class="t3 small center" style="margin-top:8px">我们会在 24 小时内核实处理</div>';
    var picked = -1;
    box.querySelectorAll('[data-r]').forEach(function(el){
      el.onclick = function(){
        picked = parseInt(el.getAttribute('data-r'), 10);
        box.querySelectorAll('[data-r]').forEach(function(x){
          var t = x.querySelector('.rpTick');
          var on = x === el;
          t.style.display = on ? 'inline' : 'none';
          x.style.color = on ? 'var(--brand)' : '';
        });
      };
    });
    box.querySelector('#rpSubmit').onclick = function(){
      if (picked < 0){ CC.toast('请选择举报原因'); return; }
      var btn = this; btn.disabled = true;
      CC.api('report_submit', { target_type: 'user', target_id: T.uid, reason: REASONS[picked], detail: box.querySelector('#rpDetail').value.trim() })
        .then(function(){ CC.toast('举报已提交'); s.close(); })
        .catch(function(e){ btn.disabled = false; CC.toast(e.message); });
    };
  };
})();
</script>
<?php cc_foot(); ?>
