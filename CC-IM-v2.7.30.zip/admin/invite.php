<?php
/**
 * CC商聊 - 后台：邀请奖励（阶梯奖励 + 邀请记录）
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function inv_allow(): array
{
    $a = admin_current();
    if (!$a) { header('Location: login.php'); exit; }
    if (in_array($a['role'], ['super', 'ops'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'invite');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号没有邀请奖励管理权限。</div></div>';
    admin_foot();
    exit;
}

function inv_back(): void
{
    header('Location: invite.php');
    exit;
}

function inv_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    inv_back();
}

function inv_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    inv_back();
}

function inv_type_label(array $r): string
{
    switch ((string)$r['type']) {
        case 'vip':
        case 'svip':
            return vip_label((int)$r['level']) . ' · ' . (int)$r['days'] . ' 天';
        case 'coin':
            return number_format((int)$r['coin']) . ' CC币';
        case 'pretty':
            return '自动分配未售出靓号';
    }
    return '';
}

$admin = inv_allow();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            case 'save':
                $id       = (int)($_POST['id'] ?? 0);
                $name     = trim((string)($_POST['name'] ?? ''));
                $icon     = trim((string)($_POST['icon'] ?? '🎁'));
                $type     = (string)($_POST['type'] ?? 'vip');
                $level    = (int)($_POST['level'] ?? 1);
                $days     = (int)($_POST['days'] ?? 30);
                $coin     = (int)($_POST['coin'] ?? 0);
                $need     = (int)($_POST['need_count'] ?? 10);
                $sort     = (int)($_POST['sort'] ?? 0);
                $status   = (int)($_POST['status'] ?? 1) === 1 ? 1 : 0;
                if (!in_array($type, ['vip', 'svip', 'coin', 'pretty'], true)) inv_err('奖励类型不正确');
                if ($name === '') inv_err('请填写奖励名称');
                if (mb_strlen($name) > 40) inv_err('奖励名称过长');
                if ($need < 1 || $need > 100000) inv_err('所需邀请人数需在 1 - 100000 之间');
                if ($level < 1 || $level > 20) $level = 1;
                if ($days < 1 || $days > 3650) $days = 30;
                if ($coin < 0) $coin = 0;
                if ($icon === '') $icon = '🎁';
                if ($id > 0) {
                    if (!one('SELECT id FROM invite_rewards WHERE id=?', [$id])) inv_err('奖励不存在');
                    q('UPDATE invite_rewards SET name=?,icon=?,type=?,level=?,days=?,coin=?,need_count=?,sort=?,status=? WHERE id=?',
                        [$name, $icon, $type, $level, $days, $coin, $need, $sort, $status, $id]);
                    admin_log('invite_reward_edit', '#' . $id . ' ' . $name . ' need=' . $need);
                    inv_done('奖励已更新');
                }
                q('INSERT INTO invite_rewards (name,icon,type,level,days,coin,need_count,sort,status) VALUES (?,?,?,?,?,?,?,?,?)',
                    [$name, $icon, $type, $level, $days, $coin, $need, $sort, $status]);
                admin_log('invite_reward_add', $name . ' need=' . $need);
                inv_done('奖励已添加');

            case 'toggle':
                $id = (int)($_POST['id'] ?? 0);
                $r = one('SELECT * FROM invite_rewards WHERE id=?', [$id]);
                if (!$r) inv_err('奖励不存在');
                $st = (int)$r['status'] === 1 ? 0 : 1;
                q('UPDATE invite_rewards SET status=? WHERE id=?', [$st, $id]);
                admin_log('invite_reward_toggle', '#' . $id . ' status=' . $st);
                inv_done($st ? '已上架' : '已下架');

            case 'del':
                $id = (int)($_POST['id'] ?? 0);
                if (!one('SELECT id FROM invite_rewards WHERE id=?', [$id])) inv_err('奖励不存在');
                q('DELETE FROM invite_rewards WHERE id=?', [$id]);
                admin_log('invite_reward_del', '#' . $id);
                inv_done('奖励已删除');

            case 'reset_claim':
                $id = (int)($_POST['id'] ?? 0);
                q('DELETE FROM invite_claims WHERE reward_id=?', [$id]);
                admin_log('invite_claim_reset', 'reward=' . $id);
                inv_done('该奖励的所有领取记录已清空');

            default:
                inv_err('未知操作');
        }
    } catch (Throwable $e) {
        inv_err('操作失败：' . $e->getMessage());
    }
}

$flash = (string)($_SESSION['adm_flash'] ?? '');
unset($_SESSION['adm_flash']);

$rows = all('SELECT * FROM invite_rewards ORDER BY need_count ASC, sort ASC, id ASC');
$claimCounts = [];
foreach (all('SELECT reward_id, COUNT(*) AS n FROM invite_claims GROUP BY reward_id') as $r) {
    $claimCounts[(int)$r['reward_id']] = (int)$r['n'];
}

$page = max(1, (int)($_GET['page'] ?? 1));
$per = 20;
$kw = trim((string)($_GET['kw'] ?? ''));
$where = '1=1';
$args = [];
if ($kw !== '') {
    $where .= ' AND (u.account LIKE ? OR u.nickname LIKE ? OR iu.account LIKE ? OR iu.nickname LIKE ?)';
    $args = ['%' . $kw . '%', '%' . $kw . '%', '%' . $kw . '%', '%' . $kw . '%'];
}
$total = (int)val('SELECT COUNT(*) FROM invites i JOIN users u ON u.id=i.uid LEFT JOIN users iu ON iu.id=i.invitee_uid WHERE ' . $where, $args);
$logs = all(
    'SELECT i.*, u.account, u.nickname, u.avatar, u.yx_id, iu.account AS i_account, iu.nickname AS i_nickname, iu.avatar AS i_avatar
     FROM invites i JOIN users u ON u.id=i.uid LEFT JOIN users iu ON iu.id=i.invitee_uid
     WHERE ' . $where . ' ORDER BY i.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per),
    $args
);
$totalInvites = (int)val('SELECT COUNT(*) FROM invites');
$inviterCount = (int)val('SELECT COUNT(DISTINCT uid) FROM invites');
$claimTotal = (int)val('SELECT COUNT(*) FROM invite_claims');
$jsRows = [];
foreach ($rows as $r) {
    $jsRows[(int)$r['id']] = [
        'id' => (int)$r['id'], 'name' => (string)$r['name'], 'icon' => (string)$r['icon'],
        'type' => (string)$r['type'], 'level' => (int)$r['level'], 'days' => (int)$r['days'],
        'coin' => (int)$r['coin'], 'need' => (int)$r['need_count'], 'sort' => (int)$r['sort'],
        'status' => (int)$r['status'],
    ];
}

$title = '邀请奖励';
admin_head($title, 'invite');
?>
<?php if ($flash !== ''): ?><script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script><?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat">
    <div class="st-ico"><?= admin_icon('invite') ?></div>
    <div class="st-label">累计邀请</div>
    <div class="st-value"><?= number_format($totalInvites) ?></div>
    <div class="st-sub">成功注册的邀请人数</div>
  </div>
  <div class="adm-stat blue">
    <div class="st-ico"><?= admin_icon('users') ?></div>
    <div class="st-label">邀请人</div>
    <div class="st-value"><?= number_format($inviterCount) ?></div>
    <div class="st-sub">产生过邀请的用户</div>
  </div>
  <div class="adm-stat orange">
    <div class="st-ico"><?= admin_icon('products') ?></div>
    <div class="st-label">奖励档位</div>
    <div class="st-value"><?= number_format(count($rows)) ?></div>
    <div class="st-sub">阶梯奖励规则数</div>
  </div>
  <div class="adm-stat purple">
    <div class="st-ico"><?= admin_icon('recharge') ?></div>
    <div class="st-label">已领取</div>
    <div class="st-value"><?= number_format($claimTotal) ?></div>
    <div class="st-sub">奖励领取总次数</div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>阶梯奖励规则</h2>
    <span class="sub">达到邀请人数后用户可在「广场 → 邀请有礼」自助领取</span>
    <div class="spacer"></div>
    <button class="adm-btn" type="button" onclick="invEdit(0)">+ 新增奖励</button>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
      <tr><th>ID</th><th>奖励</th><th>类型</th><th>需邀请</th><th>已领取</th><th>排序</th><th>状态</th><th>操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8"><div class="adm-empty">还没有奖励规则，点击右上角「新增奖励」创建</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar" style="background:#F3F6FC;font-size:16px"><?= e((string)$r['icon']) ?></div>
              <div>
                <div class="nm"><?= e((string)$r['name']) ?></div>
                <div class="sub"><?= e(inv_type_label($r)) ?></div>
              </div>
            </div>
          </td>
          <td><span class="tag <?= $r['type'] === 'svip' ? 'purple' : ($r['type'] === 'pretty' ? 'blue' : ($r['type'] === 'coin' ? 'orange' : 'green')) ?>">
            <?= $r['type'] === 'vip' ? 'VIP' : ($r['type'] === 'svip' ? 'SVIP' : ($r['type'] === 'pretty' ? '靓号' : 'CC币')) ?>
          </span></td>
          <td class="num"><?= (int)$r['need_count'] ?> 人</td>
          <td class="num"><?= (int)($claimCounts[(int)$r['id']] ?? 0) ?></td>
          <td class="sub"><?= (int)$r['sort'] ?></td>
          <td><span class="tag <?= (int)$r['status'] === 1 ? 'green' : 'gray' ?>"><?= (int)$r['status'] === 1 ? '上架' : '下架' ?></span></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" type="button" onclick="invEdit(<?= (int)$r['id'] ?>)">编辑</button>
              <button class="adm-btn sm ghost" type="button" onclick="invAct('toggle',<?= (int)$r['id'] ?>)"><?= (int)$r['status'] === 1 ? '下架' : '上架' ?></button>
              <button class="adm-btn sm danger" type="button" onclick="invAct('del',<?= (int)$r['id'] ?>,'删除该奖励规则？已领取记录会保留')">删除</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>邀请记录</h2>
    <div class="spacer"></div>
    <form method="get" class="adm-toolbar">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="邀请人 / 被邀请人 CC号或昵称">
      <button class="adm-btn ghost" type="submit">搜索</button>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th>邀请人</th><th>被邀请人</th><th>奖励 CC币</th><th>时间</th></tr></thead>
      <tbody>
      <?php if (!$logs): ?>
        <tr><td colspan="4"><div class="adm-empty">暂无邀请记录</div></td></tr>
      <?php endif; ?>
      <?php foreach ($logs as $l): ?>
        <tr>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if ($l['avatar']): ?><img src="../<?= e((string)$l['avatar']) ?>" alt=""><?php else: ?><?= e(mb_substr((string)($l['nickname'] ?: 'U'), 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e((string)($l['nickname'] ?: '-')) ?></div>
                <div class="sub">CC号 <?= e((string)($l['yx_id'] ?: $l['account'])) ?></div>
              </div>
            </div>
          </td>
          <td>
            <?php if ($l['i_account']): ?>
            <div class="nm"><?= e((string)$l['i_nickname']) ?></div>
            <div class="sub">CC号 <?= e((string)$l['i_account']) ?></div>
            <?php else: ?><span class="sub">已注销</span><?php endif; ?>
          </td>
          <td class="num"><?= (int)$l['reward_coin'] > 0 ? number_format((int)$l['reward_coin']) : '-' ?></td>
          <td class="sub"><?= e(date('Y-m-d H:i', (int)$l['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, 'invite.php?' . ($kw !== '' ? 'kw=' . urlencode($kw) . '&' : '')) ?>
</div>

<script>
window.INV_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
window.ADM_SVIP_MIN = <?= (int)svip_min_level() ?>;

function invAct(act, id, confirmText){
  function go(){
    var fd = new FormData();
    fd.append('act', act); fd.append('id', id); fd.append('ajax', '1');
    fetch(location.pathname, { method:'POST', body: fd, credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(res){
        ADM.toast(res.msg || '操作完成');
        if (res.code === 0) setTimeout(function(){ location.reload(); }, 420);
      })
      .catch(function(){ ADM.toast('网络异常'); });
  }
  if (confirmText) ADM.confirm({ title:'确认操作', text: confirmText, ok:'确定', danger:true }).then(function(y){ if (y) go(); });
  else go();
}

function invEdit(id){
  var r = id ? window.INV_ROWS[id] : { id:0, name:'', icon:'🎁', type:'vip', level:1, days:30, coin:0, need:10, sort:0, status:1 };
  var typeOpts = [['vip','VIP 会员'],['svip','SVIP 会员'],['pretty','靓号'],['coin','CC币']];
  var html = '<form id="invForm">' +
    '<input type="hidden" name="id" value="' + (r.id || 0) + '">' +
    '<div class="adm-form">' +
      '<div class="adm-field"><label>奖励名称</label><input class="adm-input" name="name" maxlength="40" value="' + ADM.esc(r.name) + '" placeholder="如：VIP 月卡"></div>' +
      '<div class="adm-field"><label>图标（emoji）</label><input class="adm-input" name="icon" maxlength="8" value="' + ADM.esc(r.icon) + '" placeholder="🎁"></div>' +
      '<div class="adm-field"><label>奖励类型</label><select class="adm-select" name="type">' +
        typeOpts.map(function(t){ return '<option value="' + t[0] + '"' + (r.type === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') +
      '</select></div>' +
      '<div class="adm-field"><label>需邀请人数</label><input class="adm-input" type="number" min="1" max="100000" name="need_count" value="' + r.need + '"></div>' +
      '<div class="adm-field"><label>会员等级（仅会员）</label><input class="adm-input" type="number" min="1" max="20" name="level" value="' + r.level + '"><div class="adm-hint">≥ SVIP 起始等级时按 SVIP 发放</div></div>' +
      '<div class="adm-field"><label>天数额度（仅会员）</label><input class="adm-input" type="number" min="1" max="3650" name="days" value="' + r.days + '"></div>' +
      '<div class="adm-field"><label>CC币数量（仅 CC币奖励）</label><input class="adm-input" type="number" min="0" name="coin" value="' + r.coin + '"></div>' +
      '<div class="adm-field"><label>排序</label><input class="adm-input" type="number" name="sort" value="' + r.sort + '"></div>' +
      '<div class="adm-field"><label>状态</label><select class="adm-select" name="status"><option value="1"' + (r.status === 1 ? ' selected' : '') + '>上架</option><option value="0"' + (r.status !== 1 ? ' selected' : '') + '>下架</option></select></div>' +
    '</div>' +
    '<div class="adm-hint" style="margin-top:12px">靓号奖励会从「商品与套餐 → 靓号」中未售出的号码里自动分配一个。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
      '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
      '<button type="submit" class="adm-btn">保存</button>' +
    '</div></form>';
  var m = ADM.modal({ title: id ? '编辑奖励' : '新增奖励', html: html });
  m.el.querySelector('#invForm').onsubmit = function(ev){
    ev.preventDefault();
    var fd = new FormData(ev.target);
    fd.append('act', 'save'); fd.append('ajax', '1');
    fetch(location.pathname, { method:'POST', body: fd, credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(res){
        ADM.toast(res.msg || '已保存');
        if (res.code === 0) setTimeout(function(){ location.reload(); }, 420);
      })
      .catch(function(){ ADM.toast('网络异常'); });
    return false;
  };
}

if (window.__admFlash) ADM.toast(window.__admFlash);
</script>
<?php admin_foot(); ?>

