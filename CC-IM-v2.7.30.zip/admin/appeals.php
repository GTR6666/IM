<?php
/**
 * CC商聊 - 后台：申诉与举报
 * tab=appeal 封禁申诉 / tab=report 用户举报
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function apl_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'ops', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'appeals');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有申诉/举报处理权限。</div></div>';
    admin_foot();
    exit;
}

function apl_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'appeals.php'));
    exit;
}

function apl_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    apl_back();
}

function apl_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    apl_back();
}

function apl_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

function apl_type_name(string $t): string
{
    $map = ['message' => '聊天消息', 'user' => '用户', 'group' => '群组', 'moment' => '动态', 'live' => '直播'];
    return $map[$t] ?? ($t !== '' ? $t : '未知');
}

$admin = apl_allow();

/* =========================================================
 * 查看举报目标（GET JSON）
 * ========================================================= */
if (($_GET['act'] ?? '') === 'view') {
    $tt = (string)($_GET['type'] ?? '');
    $tid = (int)($_GET['id'] ?? 0);
    $title = apl_type_name($tt) . ' #' . $tid;
    $html = '';
    try {
        if ($tt === 'message') {
            $m = one('SELECT m.*, u.nickname, u.account FROM messages m LEFT JOIN users u ON u.id=m.from_uid WHERE m.id=?', [$tid]);
            if (!$m) apl_err('消息不存在或已删除');
            $body = (string)$m['content'];
            $digest = msg_digest((int)$m['type'], $body);
            $html = '<table style="width:100%;font-size:13px;border-collapse:collapse">'
                . '<tr><td style="color:#6B7280;padding:5px 0;width:88px">发送人</td><td>' . e((string)($m['nickname'] ?? '-')) . '（CC ' . e((string)($m['account'] ?? '-')) . '）</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">会话</td><td>' . ((int)$m['ctype'] === 2 ? '群聊 ' . (int)$m['gid'] : '私聊 → UID ' . (int)$m['to_uid']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">类型</td><td>' . (int)$m['type'] . ' · ' . e($digest) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">时间</td><td>' . e(date('Y-m-d H:i:s', (int)$m['created_at'])) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">状态</td><td>' . ((int)$m['deleted'] === 1 ? '已删除' : ((int)$m['recalled'] === 1 ? '已撤回' : '正常')) . '</td></tr>'
                . '</table><div style="margin-top:12px;padding:12px;background:#F8FAFD;border:1px solid #EBEEF4;border-radius:10px;white-space:pre-wrap;word-break:break-all;font-size:13px">' . e($body) . '</div>';
            if (!empty($m['extra'])) {
                $html .= '<div class="adm-hint" style="margin-top:8px;word-break:break-all">extra: ' . e(mb_substr((string)$m['extra'], 0, 400)) . '</div>';
            }
        } elseif ($tt === 'user') {
            $u = one('SELECT * FROM users WHERE id=?', [$tid]);
            if (!$u) apl_err('用户不存在');
            $html = '<table style="width:100%;font-size:13px;border-collapse:collapse">'
                . '<tr><td style="color:#6B7280;padding:5px 0;width:88px">CC号</td><td>' . e((string)$u['account']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">昵称</td><td>' . e((string)$u['nickname']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">状态</td><td>' . ((int)$u['status'] === 1 ? '已封禁' : '正常') . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">CC币</td><td>' . number_format((int)$u['coin']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">注册时间</td><td>' . e(date('Y-m-d H:i', (int)$u['created_at'])) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">简介</td><td>' . e((string)$u['bio']) . '</td></tr>'
                . '</table><div style="margin-top:12px"><a class="adm-btn sm ghost" href="users.php?kw=' . e(rawurlencode((string)$u['account'])) . '">打开用户管理</a></div>';
        } elseif ($tt === 'group') {
            $g = one('SELECT * FROM groups WHERE gid=?', [$tid]);
            if (!$g) apl_err('群组不存在');
            $members = (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$tid]);
            $html = '<table style="width:100%;font-size:13px;border-collapse:collapse">'
                . '<tr><td style="color:#6B7280;padding:5px 0;width:88px">群号</td><td>' . (int)$g['gid'] . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">群名</td><td>' . e((string)$g['name']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">成员</td><td>' . number_format($members) . ' / ' . number_format((int)$g['member_limit']) . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">简介</td><td>' . e((string)$g['intro']) . '</td></tr>'
                . '</table>';
        } elseif ($tt === 'moment') {
            $mo = one('SELECT * FROM moment WHERE id=?', [$tid]);
            if (!$mo) apl_err('动态不存在');
            $html = '<table style="width:100%;font-size:13px;border-collapse:collapse">'
                . '<tr><td style="color:#6B7280;padding:5px 0;width:88px">UID</td><td>' . (int)$mo['uid'] . '</td></tr>'
                . '<tr><td style="color:#6B7280;padding:5px 0">时间</td><td>' . e(date('Y-m-d H:i', (int)$mo['created_at'])) . '</td></tr>'
                . '</table><div style="margin-top:12px;padding:12px;background:#F8FAFD;border:1px solid #EBEEF4;border-radius:10px;white-space:pre-wrap;word-break:break-all;font-size:13px">' . e((string)$mo['content']) . '</div>';
        } else {
            apl_err('暂不支持查看该类型的目标');
        }
    } catch (Throwable $e) {
        apl_err('读取失败：' . $e->getMessage());
    }
    ok(['title' => $title, 'html' => $html]);
    exit;
}

/* =========================================================
 * POST
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            /* ---------- 申诉 ---------- */
            case 'appeal_handle': {
                $id = (int)($_POST['id'] ?? 0);
                $a = one('SELECT * FROM appeals WHERE id=?', [$id]);
                if (!$a) apl_err('申诉不存在');
                q('UPDATE appeals SET status=1, handled_at=? WHERE id=?', [now(), $id]);
                admin_log('申诉处理', '#' . $id . ' 账号 ' . $a['account']);
                apl_done('已标记为已处理');
                break;
            }
            case 'appeal_ban': {
                $id = (int)($_POST['id'] ?? 0);
                $a = one('SELECT * FROM appeals WHERE id=?', [$id]);
                if (!$a) apl_err('申诉不存在');
                $acc = trim((string)$a['account']);
                q('UPDATE appeals SET status=1, handled_at=? WHERE id=?', [now(), $id]);
                admin_log('申诉转封禁', '#' . $id . ' 账号 ' . $acc . '，跳转用户管理');
                $url = 'users.php?kw=' . rawurlencode($acc);
                if (isset($_POST['ajax'])) ok(['redirect' => $url], '已标记处理，正在打开用户管理');
                header('Location: ' . $url);
                exit;
            }
            /* ---------- 举报 ---------- */
            case 'report_handle': {
                $id = (int)($_POST['id'] ?? 0);
                $r = one('SELECT * FROM reports WHERE id=?', [$id]);
                if (!$r) apl_err('举报不存在');
                q('UPDATE reports SET status=1 WHERE id=?', [$id]);
                admin_log('举报处理', '#' . $id . ' ' . $r['target_type'] . '#' . $r['target_id'] . ' ' . $r['reason']);
                apl_done('举报已标记为已处理');
                break;
            }
            case 'report_ignore': {
                $id = (int)($_POST['id'] ?? 0);
                $r = one('SELECT * FROM reports WHERE id=?', [$id]);
                if (!$r) apl_err('举报不存在');
                q('UPDATE reports SET status=2 WHERE id=?', [$id]);
                admin_log('举报忽略', '#' . $id . ' ' . $r['target_type'] . '#' . $r['target_id']);
                apl_done('举报已忽略');
                break;
            }
            default:
                apl_err('未知操作');
        }
    } catch (Throwable $e) {
        apl_err('操作失败：' . $e->getMessage());
    }
}

/* =========================================================
 * 列表
 * ========================================================= */
$tab = (string)($_GET['tab'] ?? 'appeal');
if (!in_array($tab, ['appeal', 'report'], true)) $tab = 'appeal';
$fStatus = (string)($_GET['status'] ?? '');
$kw = trim((string)($_GET['kw'] ?? ''));

$w = [];
$p = [];
if ($fStatus === '0' || $fStatus === '1' || $fStatus === '2') {
    $w[] = 'x.status=?';
    $p[] = (int)$fStatus;
}
if ($kw !== '') {
    if ($tab === 'appeal') {
        $w[] = '(a.account LIKE ? OR a.reason LIKE ? OR a.contact LIKE ?)';
        $like = '%' . $kw . '%';
        foreach ([1, 2, 3] as $_) $p[] = $like;
    } else {
        $w[] = '(u.account LIKE ? OR u.nickname LIKE ? OR r.reason LIKE ? OR r.detail LIKE ?)';
        $like = '%' . $kw . '%';
        foreach ([1, 2, 3, 4] as $_) $p[] = $like;
    }
}
$where = $w ? (' WHERE ' . implode(' AND ', $w)) : '';

$per = 20;
$page = max(1, (int)($_GET['page'] ?? 1));

if ($tab === 'appeal') {
    $sqlFrom = ' FROM appeals a' . $where;
    $total = (int)val('SELECT COUNT(*)' . $sqlFrom, $p);
    $pages = max(1, (int)ceil($total / $per));
    if ($page > $pages) $page = $pages;
    $offset = ($page - 1) * $per;
    $rows = all('SELECT a.*' . $sqlFrom . ' ORDER BY a.status ASC, a.id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);
    $jsRows = [];
    foreach ($rows as $r) {
        $jsRows[(int)$r['id']] = [
            'account' => (string)$r['account'],
            'reason'  => (string)$r['reason'],
            'contact' => (string)$r['contact'],
            'status'  => (int)$r['status'],
            'created' => (int)$r['created_at'],
            'handled' => (int)$r['handled_at'],
            'uid'     => (int)$r['uid'],
        ];
    }
} else {
    $sqlFrom = ' FROM reports r LEFT JOIN users u ON u.id=r.from_uid' . $where;
    $total = (int)val('SELECT COUNT(*)' . $sqlFrom, $p);
    $pages = max(1, (int)ceil($total / $per));
    if ($page > $pages) $page = $pages;
    $offset = ($page - 1) * $per;
    $rows = all('SELECT r.*, u.account AS u_account, u.nickname' . $sqlFrom . ' ORDER BY r.status ASC, r.id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);
    $jsRows = [];
    foreach ($rows as $r) {
        $jsRows[(int)$r['id']] = [
            'reporter' => (string)($r['u_account'] ?? '') . (($r['nickname'] ?? '') !== '' ? ' / ' . $r['nickname'] : ''),
            'type'     => (string)$r['target_type'],
            'target'   => (int)$r['target_id'],
            'reason'   => (string)$r['reason'],
            'detail'   => (string)$r['detail'],
            'status'   => (int)$r['status'],
            'created'  => (int)$r['created_at'],
        ];
    }
}

$fq = $_GET;
unset($fq['page']);
$qs = http_build_query($fq);
$baseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

$cntAppeal = (int)val('SELECT COUNT(*) FROM appeals WHERE status=0');
$cntReport = (int)val('SELECT COUNT(*) FROM reports WHERE status=0');

$flash = apl_flash();
$title = '申诉 / 举报';
admin_head($title, 'appeals');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-panel">
  <div class="adm-panel-head" style="padding-bottom:0;border-bottom:0">
    <div class="adm-toolbar" style="gap:4px">
      <a class="adm-btn <?= $tab === 'appeal' ? '' : 'ghost' ?> sm" href="appeals.php?tab=appeal">封禁申诉 <span style="opacity:.75"><?= $cntAppeal > 0 ? '(' . $cntAppeal . ')' : '' ?></span></a>
      <a class="adm-btn <?= $tab === 'report' ? '' : 'ghost' ?> sm" href="appeals.php?tab=report">用户举报 <span style="opacity:.75"><?= $cntReport > 0 ? '(' . $cntReport . ')' : '' ?></span></a>
    </div>
    <form method="get" class="adm-toolbar">
      <input type="hidden" name="tab" value="<?= e($tab) ?>">
      <select class="adm-select" name="status" onchange="this.form.submit()">
        <option value="">全部状态</option>
        <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>待处理</option>
        <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>已处理</option>
        <?php if ($tab === 'report'): ?>
          <option value="2" <?= $fStatus === '2' ? 'selected' : '' ?>>已忽略</option>
        <?php endif; ?>
      </select>
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="<?= $tab === 'appeal' ? '账号 / 理由 / 联系方式' : '举报人 / 原因 / 详情' ?>" style="min-width:180px">
      <button class="adm-btn sm" type="submit">搜索</button>
    </form>
  </div>
</div>

<?php if ($tab === 'appeal'): ?>
<div class="adm-panel">
  <div class="adm-panel-head"><h2>封禁申诉<span class="sub">共 <?= number_format($total) ?> 条</span></h2></div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>账号</th><th>申诉理由</th><th>联系方式</th><th>状态</th><th>时间</th><th style="width:230px">操作</th></tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7"><div class="adm-empty">没有申诉记录</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td>
            <div class="nm"><?= e((string)$r['account'] ?: '（未填）') ?></div>
            <div class="sub">UID <?= (int)$r['uid'] ?: '未匹配' ?></div>
          </td>
          <td style="max-width:340px"><span style="font-size:12.5px;color:#374151;white-space:normal;word-break:break-word"><?= e((string)$r['reason']) ?></span></td>
          <td><span class="sub"><?= e((string)$r['contact'] ?: '-') ?></span></td>
          <td><span class="tag <?= (int)$r['status'] === 1 ? 'green' : 'orange' ?>"><?= (int)$r['status'] === 1 ? '已处理' : '待处理' ?></span></td>
          <td><span class="sub"><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></span></td>
          <td>
            <div class="actions">
              <?php if ((int)$r['status'] !== 1): ?>
                <button class="adm-btn sm ghost" onclick="aplAppeal('handle', <?= (int)$r['id'] ?>)">标记已处理</button>
                <button class="adm-btn sm danger" onclick="aplAppeal('ban', <?= (int)$r['id'] ?>)">封禁该账号</button>
              <?php else: ?>
                <a class="adm-btn sm ghost" href="users.php?kw=<?= e(rawurlencode((string)$r['account'])) ?>">查看用户</a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>
<?php else: ?>
<div class="adm-panel">
  <div class="adm-panel-head"><h2>用户举报<span class="sub">共 <?= number_format($total) ?> 条</span></h2></div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>举报人</th><th>类型</th><th>目标</th><th>原因 / 详情</th><th>状态</th><th>时间</th><th style="width:250px">操作</th></tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8"><div class="adm-empty">没有举报记录</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <?php
        $st = (int)$r['status'];
        $stMap = [0 => ['待处理', 'orange'], 1 => ['已处理', 'green'], 2 => ['已忽略', 'gray']];
        $stx = $stMap[$st] ?? ['未知', 'gray'];
        ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td>
            <div class="nm"><?= e((string)($r['nickname'] ?? '未知用户')) ?></div>
            <div class="sub">CC <?= e((string)($r['u_account'] ?? '-')) ?></div>
          </td>
          <td><span class="tag blue"><?= e(apl_type_name((string)$r['target_type'])) ?></span></td>
          <td class="num">#<?= (int)$r['target_id'] ?></td>
          <td style="max-width:320px">
            <div class="nm" style="font-size:12.5px"><?= e((string)$r['reason']) ?></div>
            <?php if ((string)$r['detail'] !== ''): ?><div class="sub" style="white-space:normal;word-break:break-word"><?= e(mb_substr((string)$r['detail'], 0, 80)) ?></div><?php endif; ?>
          </td>
          <td><span class="tag <?= $stx[1] ?>"><?= e($stx[0]) ?></span></td>
          <td><span class="sub"><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></span></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm blue" onclick="aplView(<?= (int)$r['id'] ?>)">查看内容</button>
              <?php if ($st === 0): ?>
                <button class="adm-btn sm ghost" onclick="aplReport('handle', <?= (int)$r['id'] ?>)">已处理</button>
                <button class="adm-btn sm danger" onclick="aplReport('ignore', <?= (int)$r['id'] ?>)">忽略</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>
<?php endif; ?>

<script>
var APL_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
function aplAppeal(act, id) {
  if (act === 'handle') {
    ADM.confirm({title:'标记已处理', text:'确认该申诉已处理完毕？', ok:'确认'})
      .then(function (y) { if (y) ADM.postForm('appeal_handle', {id:id}); });
    return;
  }
  ADM.confirm({title:'封禁该账号', danger:true, ok:'前往用户管理',
    html:'<p style="margin:0 0 8px;color:#6B7280">将把申诉标记为已处理，并跳转到「用户管理」按该账号搜索，由你确认封禁操作。</p><p style="margin:0"><b>' + ADM.esc((APL_ROWS[id] || {}).account || '') + '</b></p>'
  }).then(function (y) {
    if (!y) return;
    ADM.postForm('appeal_ban', {id:id}).then(function (d) {
      if (d && d.redirect) setTimeout(function () { location.href = d.redirect; }, 400);
    });
  });
}
function aplReport(act, id) {
  var label = act === 'handle' ? '标记已处理' : '忽略举报';
  var txt = act === 'handle' ? '确认该举报已处理完毕？' : '确认忽略该举报？';
  ADM.confirm({title:label, text:txt, ok:'确认', danger: act !== 'handle'}).then(function (y) {
    if (y) ADM.postForm(act === 'handle' ? 'report_handle' : 'report_ignore', {id:id});
  });
}
function aplView(id) {
  var r = APL_ROWS[id];
  if (!r) return;
  var et = document.createElement('div');
  ADM.toast('加载中…', 900);
  fetch(location.pathname + '?act=view&type=' + encodeURIComponent(r.type) + '&id=' + r.target, {credentials:'same-origin', cache:'no-store'})
    .then(function (x) { return x.json(); })
    .then(function (res) {
      if (res.code !== 0) { ADM.toast(res.msg || '读取失败'); return; }
      ADM.modal({title: (res.data && res.data.title) || '目标内容', html: (res.data && res.data.html) || ''});
    })
    .catch(function () { ADM.toast('读取失败'); });
  return et;
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
