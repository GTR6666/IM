<?php
/**
 * CC商聊 - 用户管理
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'users');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;
$newPwd = '';

/* ---------- 写操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    $uid = (int)($_POST['uid'] ?? 0);
    $u = $uid > 0 ? one('SELECT * FROM users WHERE id=?', [$uid]) : null;
    try {
        if (!$u) throw new RuntimeException('用户不存在');
        switch ($act) {
            case 'ban':
                $reason = mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 200);
                if ($reason === '') $reason = '违反平台规定';
                $days = (int)($_POST['days'] ?? 1);
                $forever = $days <= 0 ? 1 : 0;
                $until = $forever ? 0 : now() + $days * 86400;
                q('UPDATE users SET status=1, ban_reason=?, ban_until=?, ban_forever=?, online=0 WHERE id=?', [$reason, $until, $forever, $uid]);
                q('DELETE FROM devices WHERE uid=?', [$uid]);
                admin_log('ban_user', 'uid=' . $uid . ' account=' . $u['account'] . ' days=' . ($forever ? '永久' : $days) . ' reason=' . $reason);
                $msg = '已封禁用户 ' . $u['account'] . '（' . ($forever ? '永久' : $days . ' 天') . '）';
                break;
            case 'unban':
                q('UPDATE users SET status=0, ban_reason="", ban_until=0, ban_forever=0 WHERE id=?', [$uid]);
                admin_log('unban_user', 'uid=' . $uid . ' account=' . $u['account']);
                $msg = '已解封用户 ' . $u['account'];
                break;
            case 'restore':
                q('UPDATE users SET status=0 WHERE id=?', [$uid]);
                admin_log('restore_user', 'uid=' . $uid . ' account=' . $u['account']);
                $msg = '已恢复用户 ' . $u['account'];
                break;
            case 'coin':
                $dir = (string)($_POST['dir'] ?? 'add');
                $num = abs((int)($_POST['amount'] ?? 0));
                $remark = mb_substr(trim((string)($_POST['remark'] ?? '')), 0, 100);
                if ($remark === '') $remark = '管理员调整';
                if ($num <= 0) throw new RuntimeException('CC币数量必须大于 0');
                $delta = $dir === 'sub' ? -$num : $num;
                $bal = add_coin($uid, $delta, 'admin', 0, $remark);
                admin_log('coin_adjust', 'uid=' . $uid . ' account=' . $u['account'] . ' delta=' . $delta . ' balance=' . $bal . ' remark=' . $remark);
                $msg = '已' . ($delta > 0 ? '增加' : '扣除') . ' ' . $num . ' CC币，当前余额 ' . $bal;
                break;
            case 'vip':
                $level = max(1, min(9, (int)($_POST['level'] ?? 1)));
                $days = max(1, min(3650, (int)($_POST['days'] ?? 30)));
                $base = max(now(), (int)$u['vip_expire_at']);
                $expire = $base + $days * 86400;
                q('UPDATE users SET vip_level=?, vip_expire_at=? WHERE id=?', [$level, $expire, $uid]);
                admin_log('set_vip', 'uid=' . $uid . ' account=' . $u['account'] . ' level=' . $level . ' days=' . $days);
                $msg = '已设置 VIP' . $level . '，到期 ' . date('Y-m-d H:i', $expire);
                break;
            case 'vip_cancel':
                q('UPDATE users SET vip_level=0, vip_expire_at=0 WHERE id=?', [$uid]);
                admin_log('cancel_vip', 'uid=' . $uid . ' account=' . $u['account']);
                $msg = '已取消该用户 VIP';
                break;
            case 'reset_pwd':
                $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
                $plain = '';
                for ($i = 0; $i < 10; $i++) $plain .= $chars[random_int(0, strlen($chars) - 1)];
                q('UPDATE users SET password=? WHERE id=?', [password_hash($plain, PASSWORD_DEFAULT), $uid]);
                admin_log('reset_user_password', 'uid=' . $uid . ' account=' . $u['account']);
                $newPwd = $plain;
                $msg = '已重置 ' . $u['account'] . ' 的登录密码';
                break;
            case 'dev':
                $to = (int)$u['is_developer'] === 1 ? 0 : 1;
                q('UPDATE users SET is_developer=? WHERE id=?', [$to, $uid]);
                admin_log('set_developer', 'uid=' . $uid . ' account=' . $u['account'] . ' dev=' . $to);
                $msg = $to ? '已设为开发号' : '已取消开发号';
                break;
            case 'hard_delete':
                // 仅超级管理员可彻底删除
                if (($admin['role'] ?? '') !== 'super') throw new RuntimeException('仅超级管理员可彻底删除数据');
                $dissolve = (int)($_POST['dissolve_groups'] ?? 1) === 1;
                $st = admin_purge_user($uid, $dissolve);
                $total = 0;
                foreach ($st as $k => $v) { if (is_int($v)) $total += $v; }
                admin_log('hard_delete_user', 'uid=' . $uid . ' account=' . $u['account'] . ' rows=' . $total);
                $msg = '已彻底删除用户 ' . $u['account'] . '（共清理 ' . $total . ' 条数据）';
                break;
            case 'delete':
                q('UPDATE users SET status=2, online=0 WHERE id=?', [$uid]);
                q('UPDATE conversations SET visible=0 WHERE uid=? OR (ctype=1 AND peer_id=?)', [$uid, $uid]);
                q('DELETE FROM devices WHERE uid=?', [$uid]);
                admin_log('delete_user', 'uid=' . $uid . ' account=' . $u['account'] . ' 软删除');
                $msg = '已删除用户 ' . $u['account'] . '（软删除，会话列表已隐藏）';
                break;
            default:
                $msg = '未知操作';
                $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 列表查询 ---------- */
$kw = trim((string)($_GET['kw'] ?? ''));
$fStatus = (string)($_GET['status'] ?? '');
$fVip = (string)($_GET['vip'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 20;

$where = [];
$par = [];
if ($kw !== '') {
    $where[] = '(account LIKE ? OR nickname LIKE ? OR email LIKE ? OR yx_id LIKE ? OR pretty_yxid LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($par, $like, $like, $like, $like, $like);
}
if (in_array($fStatus, ['0', '1', '2'], true)) {
    $where[] = 'status=?';
    $par[] = (int)$fStatus;
}
if ($fVip === '1') {
    $where[] = '(vip_level>0 AND vip_expire_at>?)';
    $par[] = now();
} elseif ($fVip === '0') {
    $where[] = '(vip_level<=0 OR vip_expire_at<=?)';
    $par[] = now();
}
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$total = (int)val('SELECT COUNT(*) FROM users' . $w, $par);
$rows = all('SELECT * FROM users' . $w . ' ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);

/* ---------- 详情数据 ---------- */
$detail = [];
if ($rows) {
    $ids = array_map(static fn($r) => (int)$r['id'], $rows);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $devs = all('SELECT uid,ua,ip,last_active_at,created_at FROM devices WHERE uid IN (' . $in . ') ORDER BY id DESC', $ids);
    $logs = all('SELECT uid,ip,ua,created_at FROM login_logs WHERE uid IN (' . $in . ') ORDER BY id DESC LIMIT 500', $ids);
    $dmap = [];
    $lmap = [];
    foreach ($devs as $d) $dmap[(int)$d['uid']][] = $d;
    foreach ($logs as $l) {
        $lu = (int)$l['uid'];
        if (count($lmap[$lu] ?? []) < 10) $lmap[$lu][] = $l;
    }
    foreach ($rows as $u) {
        $id = (int)$u['id'];
        $detail[$id] = [
            'id' => $id,
            'account' => (string)$u['account'],
            'yx_id' => (string)($u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account'])),
            'nickname' => (string)$u['nickname'],
            'avatar' => (string)$u['avatar'],
            'email' => (string)$u['email'],
            'phone' => (string)$u['phone'],
            'invite_code' => (string)$u['invite_code'],
            'invited_by' => (int)$u['invited_by'],
            'bio' => (string)$u['bio'],
            'region' => (string)$u['region'],
            'gender' => (int)$u['gender'],
            'coin' => (int)$u['coin'],
            'vip_level' => (int)$u['vip_level'],
            'vip_expire_at' => (int)$u['vip_expire_at'],
            'is_developer' => (int)$u['is_developer'],
            'status' => (int)$u['status'],
            'ban_reason' => (string)$u['ban_reason'],
            'ban_until' => (int)$u['ban_until'],
            'ban_forever' => (int)$u['ban_forever'],
            'device_id' => (string)$u['device_id'],
            'created_at' => (int)$u['created_at'],
            'last_active_at' => (int)$u['last_active_at'],
            'devices' => array_map(static fn($d) => [
                'ua' => (string)$d['ua'], 'ip' => (string)$d['ip'],
                'last' => (int)$d['last_active_at'], 'created' => (int)$d['created_at'],
            ], $dmap[$id] ?? []),
            'logins' => array_map(static fn($l) => [
                'ip' => (string)$l['ip'], 'ua' => (string)$l['ua'], 't' => (int)$l['created_at'],
            ], $lmap[$id] ?? []),
        ];
    }
}

$postUrl = 'users.php?' . admin_qs();
$pagerUrl = 'users.php?' . admin_qs();

admin_head('用户管理', 'users');
?>
<?php if ($msg !== ''): ?>
<div class="adm-panel" style="border-left:4px solid <?= $msgOk ? '#07C160' : '#EF4444' ?>">
  <div class="adm-panel-body" style="padding:12px 18px;color:<?= $msgOk ? '#059669' : '#DC2626' ?>;font-size:13px"><?= e($msg) ?></div>
</div>
<?php endif; ?>
<?php if ($newPwd !== ''): ?>
<div class="adm-panel" style="border-left:4px solid #3B82F6">
  <div class="adm-panel-body">
    <div style="font-size:13px;color:#374151">新密码（仅显示一次，请立即复制交给用户）</div>
    <div style="margin-top:10px;display:flex;gap:10px;align-items:center">
      <code id="newPwdBox" style="font-size:17px;letter-spacing:2px;background:#F2F5FA;padding:8px 14px;border-radius:8px;font-family:ui-monospace,Consolas,monospace"><?= e($newPwd) ?></code>
      <button class="adm-btn sm blue" type="button" onclick="ADM.copy(document.getElementById('newPwdBox').textContent)">复制密码</button>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>用户列表 <span class="sub">共 <?= admin_money($total) ?> 人</span></h2>
    <form class="adm-toolbar" method="get" action="users.php">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="CC号 / 昵称 / 邮箱" style="width:210px">
      <select class="adm-select" name="status">
        <option value="">全部状态</option>
        <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>正常</option>
        <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>封禁</option>
        <option value="2" <?= $fStatus === '2' ? 'selected' : '' ?>>已删除</option>
      </select>
      <select class="adm-select" name="vip">
        <option value="">VIP 全部</option>
        <option value="1" <?= $fVip === '1' ? 'selected' : '' ?>>VIP 用户</option>
        <option value="0" <?= $fVip === '0' ? 'selected' : '' ?>>非 VIP</option>
      </select>
      <button class="adm-btn" type="submit">搜索</button>
      <?php if ($kw !== '' || $fStatus !== '' || $fVip !== ''): ?>
        <a class="adm-btn ghost" href="users.php">重置</a>
      <?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr>
          <th>ID</th><th>用户</th><th>CC号</th><th>CC币</th><th>VIP</th><th>状态</th><th>注册时间</th><th>最后活跃</th><th>操作</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="9"><div class="adm-empty">没有匹配的用户</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $u): ?>
        <?php
          $id = (int)$u['id'];
          $yxid = $u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account']);
          $st = (int)$u['status'];
          $vip = (int)$u['vip_level'] > 0 && (int)$u['vip_expire_at'] > now();
          $stText = $st === 1 ? '封禁' : ($st === 2 ? '已删除' : '正常');
          $stTag = $st === 1 ? 'red' : ($st === 2 ? 'gray' : 'green');
        ?>
        <tr>
          <td><?= $id ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if ($u['avatar']): ?><img src="<?= e('../' . $u['avatar']) ?>" alt=""><?php else: ?><?= e(mb_substr($u['nickname'] ?: 'U', 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e($u['nickname'] ?: '未设置昵称') ?><?php if ((int)$u['is_developer'] === 1): ?> <span class="tag purple">开发</span><?php endif; ?></div>
                <div class="sub"><?= (int)$u['online'] === 1 ? '<span style="color:#059669">在线</span>' : '离线' ?><?= $u['email'] ? ' · ' . e($u['email']) : '' ?></div>
              </div>
            </div>
          </td>
          <td><span style="font-variant-numeric:tabular-nums"><?= e($yxid) ?></span><?= pretty_badge((string)($u['pretty_yxid'] ?? '')) ?></td>
          <td class="num"><?= admin_money((int)$u['coin']) ?></td>
          <td>
            <?php if ($vip): ?>
              <span class="tag <?= vip_tier((int)$u['vip_level']) === 'SVIP' ? 'purple' : 'orange' ?>"><?= e(vip_label((int)$u['vip_level'])) ?></span>
              <div class="sub"><?= e(date('Y-m-d', (int)$u['vip_expire_at'])) ?> 到期</div>
            <?php else: ?>
              <span class="tag gray">普通</span>
            <?php endif; ?>
          </td>
          <td><span class="tag <?= $stTag ?>"><?= $stText ?></span>
            <?php if ($st === 1): ?><div class="sub"><?= (int)$u['ban_forever'] === 1 ? '永久' : e(date('Y-m-d H:i', (int)$u['ban_until'])) ?></div><?php endif; ?>
          </td>
          <td><?= e(date('Y-m-d H:i', (int)$u['created_at'])) ?></td>
          <td><?= (int)$u['last_active_at'] ? e(fmt_time((int)$u['last_active_at'])) : '-' ?></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" type="button" onclick="openUser(<?= $id ?>)">详情</button>
              <?php if ($st === 0): ?>
                <button class="adm-btn sm danger" type="button" onclick="openBan(<?= $id ?>)">封禁</button>
              <?php elseif ($st === 1): ?>
                <button class="adm-btn sm" type="button" onclick="doAct('unban',<?= $id ?>,'确认解封该用户？')">解封</button>
              <?php else: ?>
                <button class="adm-btn sm blue" type="button" onclick="doAct('restore',<?= $id ?>,'确认恢复该用户？')">恢复</button>
              <?php endif; ?>
              <button class="adm-btn sm ghost" type="button" onclick="openCoin(<?= $id ?>)">改CC币</button>
              <button class="adm-btn sm ghost" type="button" onclick="openVip(<?= $id ?>)">设VIP</button>
              <button class="adm-btn sm ghost" type="button" onclick="doAct('reset_pwd',<?= $id ?>,'确认重置该用户登录密码？')">重置密码</button>
              <button class="adm-btn sm ghost" type="button" onclick="doAct('dev',<?= $id ?>,'<?= (int)$u['is_developer'] === 1 ? '确认取消开发号？' : '确认设为开发号？' ?>')"><?= (int)$u['is_developer'] === 1 ? '取消开发' : '设开发号' ?></button>
              <?php if ($st !== 2): ?>
                <button class="adm-btn sm danger" type="button" onclick="doAct('delete',<?= $id ?>,'删除后该用户将被软删除，会话列表隐藏。确认删除？')">软删除</button>
              <?php endif; ?>
              <?php if (($admin['role'] ?? '') === 'super'): ?>
                <button class="adm-btn sm danger" type="button" onclick="openPurge(<?= $id ?>)" style="background:#7F1D1D">彻底删除</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $pagerUrl) ?>
</div>

<form id="actForm" method="post" action="<?= e($postUrl) ?>" style="display:none"></form>

<script>
var UDATA = <?= json_encode($detail, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var POST_URL = <?= json_encode($postUrl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

function esc(s){ return ADM.esc(s == null ? '' : s); }
function t(ts){ return ts ? ADM.fmt(ts) : '-'; }

function submitAct(act, uid, extra) {
  var h = '<input type="hidden" name="act" value="' + esc(act) + '">' +
          '<input type="hidden" name="uid" value="' + esc(uid) + '">';
  Object.keys(extra || {}).forEach(function (k) {
    h += '<input type="hidden" name="' + esc(k) + '" value="' + esc(extra[k]) + '">';
  });
  var f = document.getElementById('actForm');
  f.innerHTML = h;
  f.submit();
}

function doAct(act, uid, text) {
  ADM.confirm({ title: '确认操作', text: text, danger: act === 'delete', ok: '确定' }).then(function (v) {
    if (v) submitAct(act, uid, {});
  });
}

function row(label, val) {
  return '<div style="display:flex;gap:12px;padding:7px 0;border-bottom:1px solid #F2F4F8;font-size:13px">' +
    '<div style="width:96px;color:#9AA0AC;flex:0 0 auto">' + esc(label) + '</div>' +
    '<div style="flex:1;word-break:break-all">' + (val === '' || val == null ? '<span style="color:#C3C9D4">-</span>' : esc(val)) + '</div></div>';
}

function openUser(id) {
  var u = UDATA[id];
  if (!u) { ADM.toast('数据已过期，请刷新页面'); return; }
  var html = '';
  var vip = u.vip_level > 0 && u.vip_expire_at > <?= now() ?>;
  html += row('用户 ID', u.id);
  html += row('CC号', u.yx_id);
  html += row('昵称', u.nickname);
  html += row('邮箱', u.email);
  html += row('手机号', u.phone);
  html += row('邀请码', u.invite_code);
  html += row('邀请人 UID', u.invited_by ? u.invited_by : '');
  html += row('CC币余额', u.coin);
  html += row('会员', vip ? (ADM.vipLabel(u.vip_level) + '（' + t(u.vip_expire_at) + ' 到期）') : '普通用户');
  html += row('开发号', u.is_developer === 1 ? '是' : '否');
  html += row('状态', u.status === 1 ? ('封禁 · ' + (u.ban_forever === 1 ? '永久' : '至 ' + t(u.ban_until)) + ' · ' + u.ban_reason) : (u.status === 2 ? '已删除' : '正常'));
  html += row('性别 / 地区', (u.gender === 1 ? '男' : (u.gender === 2 ? '女' : '未设置')) + (u.region ? ' · ' + u.region : ''));
  html += row('签名', u.bio);
  html += row('注册时间', t(u.created_at));
  html += row('最后活跃', t(u.last_active_at));
  html += row('设备标识', u.device_id);

  html += '<div style="margin-top:14px;font-size:12.5px;color:#374151;font-weight:600">设备记录（' + u.devices.length + '）</div>';
  if (!u.devices.length) {
    html += '<div class="adm-hint">暂无设备记录</div>';
  } else {
    u.devices.forEach(function (d) {
      html += '<div style="font-size:12px;color:#6B7280;padding:6px 0;border-bottom:1px solid #F2F4F8">' +
        esc(d.ip) + ' · ' + esc(d.ua) + '<div style="color:#9AA0AC">最后活跃 ' + t(d.last) + '</div></div>';
    });
  }

  html += '<div style="margin-top:14px;font-size:12.5px;color:#374151;font-weight:600">登录记录（最近 ' + u.logins.length + ' 条）</div>';
  if (!u.logins.length) {
    html += '<div class="adm-hint">暂无登录记录</div>';
  } else {
    u.logins.forEach(function (l) {
      html += '<div style="font-size:12px;color:#6B7280;padding:6px 0;border-bottom:1px solid #F2F4F8">' +
        esc(l.ip) + ' · ' + t(l.t) + '<div style="color:#9AA0AC">' + esc(l.ua) + '</div></div>';
    });
  }

  html += '<div style="margin-top:18px;padding-top:14px;border-top:1px dashed #F0D5D5">' +
    '<div style="font-size:12px;color:#9AA0AC;line-height:1.7;margin-bottom:10px">彻底删除会永久清除该用户的账号、会话、消息、好友、动态、钱包流水等全部数据，不可恢复。</div>' +
    '<button class="adm-btn danger" type="button" onclick="openPurge(' + u.id + ')" style="background:#7F1D1D">彻底删除该用户</button></div>';

  ADM.modal({ title: '用户详情 · ' + (u.nickname || u.account), html: html });
}

function openPurge(id) {
  var u = UDATA[id];
  if (!u) { ADM.toast('数据已过期，请刷新页面'); return; }
  var html = '<div style="background:#FEF2F2;border:1px solid #FBD5D5;border-radius:10px;padding:12px 14px;color:#B91C1C;font-size:12.5px;line-height:1.8">' +
    '<b>此操作不可恢复！</b><br>将永久删除 <b>' + ADM.esc(u.nickname || u.account) + '</b>（CC号 ' + ADM.esc(u.yx_id) + '）的账号、会话、消息、好友关系、朋友圈、钱包流水、提现/充值单、设备与登录记录等全部数据。' +
    '</div>' +
    '<form method="post" action="' + POST_URL + '" id="purgeForm" style="margin-top:14px">' +
    '<input type="hidden" name="act" value="hard_delete"><input type="hidden" name="uid" value="' + id + '">' +
    '<label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:#374151">' +
    '<input type="checkbox" name="dissolve_groups" value="1" checked> 同时删除该用户创建（作为群主）的群聊</label>' +
    '<div class="adm-hint">如果该用户是群主且不勾选此项，删除会失败并提示先转让群。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:18px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn danger" style="background:#7F1D1D">确认删除</button></div></form>';
  ADM.modal({ title: '彻底删除用户 · ' + (u.nickname || u.account), html: html, footer: false });
}

function openBan(id) {
  var u = UDATA[id];
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="ban"><input type="hidden" name="uid" value="' + id + '">' +
    '<div class="adm-field"><label>封禁理由</label><input class="adm-input" name="reason" placeholder="例如：发布违规内容" value="违反平台规定"></div>' +
    '<div class="adm-field" style="margin-top:12px"><label>封禁时长</label>' +
    '<select class="adm-select" name="days"><option value="1">1 天</option><option value="7">7 天</option><option value="30">30 天</option><option value="0">永久</option></select></div>' +
    '<div class="adm-hint">封禁后该用户所有设备会被强制下线。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn danger">确认封禁</button></div></form>';
  ADM.modal({ title: '封禁用户 · ' + (u ? (u.nickname || u.account) : id), html: html });
}

function openCoin(id) {
  var u = UDATA[id];
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="coin"><input type="hidden" name="uid" value="' + id + '">' +
    '<div class="adm-hint" style="margin-bottom:12px">当前余额：' + (u ? u.coin : '-') + ' CC币</div>' +
    '<div class="adm-field"><label>操作</label><select class="adm-select" name="dir"><option value="add">增加</option><option value="sub">扣除</option></select></div>' +
    '<div class="adm-field" style="margin-top:12px"><label>数量</label><input class="adm-input" name="amount" type="number" min="1" step="1" value="100"></div>' +
    '<div class="adm-field" style="margin-top:12px"><label>备注</label><input class="adm-input" name="remark" placeholder="后台调整" value="后台调整"></div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn">确认调整</button></div></form>';
  ADM.modal({ title: '调整 CC币 · ' + (u ? (u.nickname || u.account) : id), html: html });
}

function openVip(id) {
  var u = UDATA[id];
  var lv = '';
  for (var i = 1; i <= 9; i++) lv += '<option value="' + i + '"' + (u && u.vip_level === i ? ' selected' : '') + '>' + ADM.vipLabel(i) + '</option>';
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="vip"><input type="hidden" name="uid" value="' + id + '">' +
    '<div class="adm-hint" style="margin-bottom:12px">当前：' + (u && u.vip_level > 0 ? (ADM.vipLabel(u.vip_level) + ' · ' + ADM.fmt(u.vip_expire_at) + ' 到期') : '普通用户') + '</div>' +
    '<div class="adm-field"><label>会员等级</label><select class="adm-select" name="level">' + lv + '</select></div>' +
    '<div class="adm-field" style="margin-top:12px"><label>开通天数</label><input class="adm-input" name="days" type="number" min="1" max="3650" step="1" value="30"></div>' +
    '<div class="adm-hint">在原到期时间上顺延；已过期则从当前时间起算。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn">确认设置</button></div></form>';
  var f = ADM.modal({ title: '设置会员 · ' + (u ? (u.nickname || u.account) : id), html: html });
  if (u && u.vip_level > 0) {
    var foot = f.el.querySelector('.adm-modal-body');
    var btn = document.createElement('button');
    btn.className = 'adm-btn sm ghost';
    btn.style.marginTop = '8px';
    btn.textContent = '取消 VIP（清空等级与到期时间）';
    btn.onclick = function () {
      ADM.confirm({ title: '取消 VIP', text: '确认取消该用户 VIP？', danger: true }).then(function (v) {
        if (v) submitAct('vip_cancel', id, {});
      });
    };
    foot.appendChild(btn);
  }
}
</script>
<?php
admin_foot();
