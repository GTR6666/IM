<?php
/**
 * CC商聊 - 后台：运营配置
 * tab=gift 礼物 / tab=vip VIP 套餐 / tab=pretty 靓号 / tab=emoji 表情
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function prd_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'ops', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'products');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有运营配置权限。</div></div>';
    admin_foot();
    exit;
}

function prd_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'products.php'));
    exit;
}

function prd_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    prd_back();
}

function prd_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    prd_back();
}

function prd_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

$admin = prd_allow();

/* =========================================================
 * POST
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            /* ---------- 礼物 ---------- */
            case 'gift_save': {
                $id    = (int)($_POST['id'] ?? 0);
                $name  = trim((string)($_POST['name'] ?? ''));
                $icon  = trim((string)($_POST['icon'] ?? ''));
                $price = (int)($_POST['price'] ?? 0);
                $sort  = (int)($_POST['sort'] ?? 0);
                $st    = (int)($_POST['status'] ?? 1) === 1 ? 1 : 0;
                if ($name === '') prd_err('请填写礼物名称');
                if (mb_strlen($name) > 60) prd_err('礼物名称过长');
                if ($icon === '') prd_err('请填写图标（emoji）');
                if ($price <= 0) prd_err('价格必须大于 0');
                if ($id > 0) {
                    if (!one('SELECT id FROM gifts WHERE id=?', [$id])) prd_err('礼物不存在');
                    q('UPDATE gifts SET name=?, icon=?, price=?, status=?, sort=? WHERE id=?', [$name, $icon, $price, $st, $sort, $id]);
                    admin_log('礼物编辑', '#' . $id . ' ' . $name . ' / ' . $price . 'CC币');
                    prd_done('礼物已更新');
                } else {
                    q('INSERT INTO gifts (name,icon,price,status,sort) VALUES (?,?,?,?,?)', [$name, $icon, $price, $st, $sort]);
                    $nid = last_id();
                    admin_log('礼物新增', '#' . $nid . ' ' . $name . ' / ' . $price . 'CC币');
                    prd_done('礼物已新增');
                }
                break;
            }
            case 'gift_toggle': {
                $id = (int)($_POST['id'] ?? 0);
                $g = one('SELECT * FROM gifts WHERE id=?', [$id]);
                if (!$g) prd_err('礼物不存在');
                $v = (int)$g['status'] === 1 ? 0 : 1;
                q('UPDATE gifts SET status=? WHERE id=?', [$v, $id]);
                admin_log('礼物上下架', $g['name'] . ' → ' . ($v ? '上架' : '下架'));
                prd_done($v ? '已上架' : '已下架');
                break;
            }
            case 'gift_del': {
                $id = (int)($_POST['id'] ?? 0);
                $g = one('SELECT * FROM gifts WHERE id=?', [$id]);
                if (!$g) prd_err('礼物不存在');
                q('DELETE FROM gifts WHERE id=?', [$id]);
                admin_log('礼物删除', '#' . $id . ' ' . $g['name']);
                prd_done('礼物已删除');
                break;
            }

            /* ---------- VIP 套餐 ---------- */
            case 'vip_save': {
                $id    = (int)($_POST['id'] ?? 0);
                $name  = trim((string)($_POST['name'] ?? ''));
                $days  = (int)($_POST['days'] ?? 0);
                $price = (int)($_POST['price'] ?? 0);
                $level = (int)($_POST['level'] ?? 1);
                $sort  = (int)($_POST['sort'] ?? 0);
                $st    = (int)($_POST['status'] ?? 1) === 1 ? 1 : 0;
                if ($name === '') prd_err('请填写套餐名称');
                if ($days < 1 || $days > 3650) prd_err('天数需在 1 - 3650 之间');
                if ($price <= 0) prd_err('价格必须大于 0');
                if ($level < 1 || $level > 20) prd_err('等级需在 1 - 20 之间');
                if ($id > 0) {
                    if (!one('SELECT id FROM vip_plans WHERE id=?', [$id])) prd_err('套餐不存在');
                    q('UPDATE vip_plans SET name=?, days=?, price=?, level=?, status=?, sort=? WHERE id=?', [$name, $days, $price, $level, $st, $sort, $id]);
                    admin_log('VIP套餐编辑', '#' . $id . ' ' . $name);
                    prd_done('套餐已更新');
                } else {
                    q('INSERT INTO vip_plans (name,days,price,level,status,sort) VALUES (?,?,?,?,?,?)', [$name, $days, $price, $level, $st, $sort]);
                    $nid = last_id();
                    admin_log('VIP套餐新增', '#' . $nid . ' ' . $name);
                    prd_done('套餐已新增');
                }
                break;
            }
            case 'vip_toggle': {
                $id = (int)($_POST['id'] ?? 0);
                $v = one('SELECT * FROM vip_plans WHERE id=?', [$id]);
                if (!$v) prd_err('套餐不存在');
                $st = (int)$v['status'] === 1 ? 0 : 1;
                q('UPDATE vip_plans SET status=? WHERE id=?', [$st, $id]);
                admin_log('VIP套餐上下架', $v['name'] . ' → ' . ($st ? '上架' : '下架'));
                prd_done($st ? '已上架' : '已下架');
                break;
            }
            case 'vip_del': {
                $id = (int)($_POST['id'] ?? 0);
                $v = one('SELECT * FROM vip_plans WHERE id=?', [$id]);
                if (!$v) prd_err('套餐不存在');
                q('DELETE FROM vip_plans WHERE id=?', [$id]);
                admin_log('VIP套餐删除', '#' . $id . ' ' . $v['name']);
                prd_done('套餐已删除');
                break;
            }

            /* ---------- 靓号：批量添加 ---------- */
            case 'pretty_add': {
                $raw = trim((string)($_POST['batch'] ?? ''));
                $ptype = (string)($_POST['ptype'] ?? 'user') === 'group' ? 'group' : 'user';
                if ($raw === '') prd_err('请填写靓号，每行一个「号码 价格」');
                $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
                $added = 0;
                $skip = 0;
                $now = now();
                foreach ($lines as $line) {
                    $line = trim($line);
                    if ($line === '') continue;
                    $parts = preg_split('/[\s,，;；\t]+/u', $line) ?: [];
                    $no = trim((string)($parts[0] ?? ''));
                    $price = (int)($parts[1] ?? 0);
                    if ($no === '' || !preg_match('/^[0-9A-Za-z_]{3,20}$/', $no)) {
                        $skip++;
                        continue;
                    }
                    if ($price <= 0) $price = 100;
                    if (val('SELECT id FROM pretty_ids WHERE yx_id=?', [$no])) {
                        $skip++;
                        continue;
                    }
                    // 号码正在被某个用户 / 群使用（已售靓号被删除后仍在用），不允许重复上架
                    if (val('SELECT id FROM users WHERE pretty_yxid=?', [$no]) || val('SELECT gid FROM groups WHERE pretty_gid=?', [(int)$no])) {
                        $skip++;
                        continue;
                    }
                    q('INSERT INTO pretty_ids (yx_id,price,status,buyer_uid,created_at,sold_at,ptype) VALUES (?,?,0,0,?,0,?)', [$no, $price, $now, $ptype]);
                    $added++;
                }
                if ($added === 0) prd_err('没有新增靓号（' . $skip . ' 条已存在或格式有误）');
                admin_log('靓号批量添加', ($ptype === 'group' ? '群' : '个人') . '靓号 新增 ' . $added . ' 个，跳过 ' . $skip . ' 个');
                prd_done('已添加 ' . $added . ' 个' . ($ptype === 'group' ? '群' : '') . '靓号' . ($skip > 0 ? '，跳过 ' . $skip . ' 个' : ''));
                break;
            }
            case 'pretty_toggle': {
                $id = (int)($_POST['id'] ?? 0);
                $p = one('SELECT * FROM pretty_ids WHERE id=?', [$id]);
                if (!$p) prd_err('靓号不存在');
                if ((int)$p['status'] === 1) prd_err('已售出的靓号不能上下架');
                $v = (int)$p['status'] === 0 ? 2 : 0;
                q('UPDATE pretty_ids SET status=? WHERE id=?', [$v, $id]);
                admin_log('靓号上下架', $p['yx_id'] . ' → ' . ($v === 0 ? '上架' : '下架'));
                prd_done($v === 0 ? '已上架' : '已下架');
                break;
            }
            case 'pretty_del': {
                $id = (int)($_POST['id'] ?? 0);
                $p = one('SELECT * FROM pretty_ids WHERE id=?', [$id]);
                if (!$p) prd_err('靓号不存在');
                $sold = (int)$p['status'] === 1 || (int)$p['buyer_uid'] > 0;
                $revoke = (int)($_POST['revoke'] ?? 0) === 1;
                $no = (string)$p['yx_id'];
                $note = '';
                if ($sold && $revoke) {
                    // 收回：从买家账号 / 群聊上移除该靓号
                    if ((string)($p['ptype'] ?? 'user') === 'group') {
                        $gid = (int)($p['buyer_gid'] ?? 0);
                        if ($gid > 0) {
                            q('UPDATE groups SET pretty_gid=0 WHERE gid=? AND pretty_gid=?', [$gid, (int)$no]);
                            $note = '，已从群 ' . $gid . ' 收回';
                        }
                    } else {
                        $buyer = (int)($p['buyer_uid'] ?? 0);
                        if ($buyer > 0) {
                            q('UPDATE users SET pretty_yxid="" WHERE id=? AND pretty_yxid=?', [$buyer, $no]);
                            $note = '，已从用户 UID ' . $buyer . ' 收回';
                        }
                    }
                } elseif ($sold) {
                    $note = '（买家仍保留该靓号展示）';
                }
                q('DELETE FROM pretty_ids WHERE id=?', [$id]);
                admin_log('靓号删除', $no . ($sold ? ' 已售' : ' 未售') . ($revoke ? ' 收回靓号' : '') . $note);
                prd_done('靓号 ' . $no . ' 已删除' . $note);
                break;
            }

            /* ---------- 表情 ---------- */
            case 'emoji_add': {
                $ch = trim((string)($_POST['emoji'] ?? ''));
                $name = trim((string)($_POST['name'] ?? ''));
                if ($ch === '') prd_err('请填写表情符号');
                if (mb_strlen($ch) > 16) prd_err('表情符号过长');
                if ($name === '') $name = $ch;
                if (mb_strlen($name) > 60) $name = mb_substr($name, 0, 60);
                $url = 'emoji:' . $ch;
                if (val('SELECT id FROM emojis WHERE uid=0 AND url=?', [$url])) prd_err('该表情已存在');
                q('INSERT INTO emojis (uid,name,url,created_at) VALUES (0,?,?,?)', [$name, $url, now()]);
                $nid = last_id();
                admin_log('表情新增', $ch . ' ' . $name);
                prd_done('表情已添加');
                break;
            }
            case 'emoji_del': {
                $id = (int)($_POST['id'] ?? 0);
                $e2 = one('SELECT * FROM emojis WHERE id=? AND uid=0', [$id]);
                if (!$e2) prd_err('表情不存在');
                q('DELETE FROM emojis WHERE id=?', [$id]);
                admin_log('表情删除', (string)$e2['url']);
                prd_done('表情已删除');
                break;
            }

            default:
                prd_err('未知操作');
        }
    } catch (Throwable $e) {
        prd_err('操作失败：' . $e->getMessage());
    }
}

/* =========================================================
 * 数据
 * ========================================================= */
$tab = (string)($_GET['tab'] ?? 'gift');
if (!in_array($tab, ['gift', 'vip', 'pretty', 'emoji'], true)) $tab = 'gift';

$gifts = all('SELECT * FROM gifts ORDER BY sort ASC, id ASC');
$vips  = all('SELECT * FROM vip_plans ORDER BY sort ASC, id ASC');

$prettyKw = trim((string)($_GET['kw'] ?? ''));
$prettyType = (string)($_GET['ptyp'] ?? '');
if (!in_array($prettyType, ['user', 'group'], true)) $prettyType = '';
$prettySt = (string)($_GET['pst'] ?? '');
$pw = [];
$pp = [];
if ($prettyKw !== '') {
    $pw[] = '(p.yx_id LIKE ? OR u.account LIKE ? OR u.nickname LIKE ?)';
    $like = '%' . $prettyKw . '%';
    foreach ([1, 2, 3] as $_) $pp[] = $like;
}
if ($prettySt === '0' || $prettySt === '1' || $prettySt === '2') {
    $pw[] = 'p.status=?';
    $pp[] = (int)$prettySt;
}
if ($prettyType !== '') {
    $pw[] = 'p.ptype=?';
    $pp[] = $prettyType;
}
$pwhere = $pw ? (' WHERE ' . implode(' AND ', $pw)) : '';
$prettyTotal = (int)val('SELECT COUNT(*) FROM pretty_ids p LEFT JOIN users u ON u.id=p.buyer_uid' . $pwhere, $pp);
$ppage = max(1, (int)($_GET['page'] ?? 1));
$pper = 20;
$ppages = max(1, (int)ceil($prettyTotal / $pper));
if ($ppage > $ppages) $ppage = $ppages;
$pretties = all('SELECT p.*, u.account AS buyer_account, u.nickname AS buyer_nickname FROM pretty_ids p LEFT JOIN users u ON u.id=p.buyer_uid' . $pwhere . ' ORDER BY p.status ASC, p.id DESC LIMIT ' . $pper . ' OFFSET ' . (($ppage - 1) * $pper), $pp);

$fq = $_GET;
unset($fq['page']);
$qs = http_build_query($fq);
$pBaseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

$emojis = all('SELECT * FROM emojis WHERE uid=0 ORDER BY id ASC');

$statGift  = count($gifts);
$statVip   = count($vips);
$statPretty = (int)val('SELECT COUNT(*) FROM pretty_ids WHERE status=0');
$statSold  = (int)val('SELECT COUNT(*) FROM pretty_ids WHERE status=1');
$statEmoji = count($emojis);

$jsGift = [];
foreach ($gifts as $g) {
    $jsGift[(int)$g['id']] = ['name' => (string)$g['name'], 'icon' => (string)$g['icon'], 'price' => (int)$g['price'], 'status' => (int)$g['status'], 'sort' => (int)$g['sort']];
}
$jsVip = [];
foreach ($vips as $v) {
    $jsVip[(int)$v['id']] = ['name' => (string)$v['name'], 'days' => (int)$v['days'], 'price' => (int)$v['price'], 'level' => (int)$v['level'], 'status' => (int)$v['status'], 'sort' => (int)$v['sort']];
}

$flash = prd_flash();
$title = '运营配置';
admin_head($title, 'products');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat"><div class="st-ico">🎁</div><div class="st-label">礼物</div><div class="st-value"><?= number_format($statGift) ?></div><div class="st-sub">款</div></div>
  <div class="adm-stat purple"><div class="st-ico">👑</div><div class="st-label">VIP 套餐</div><div class="st-value"><?= number_format($statVip) ?></div><div class="st-sub">个</div></div>
  <div class="adm-stat blue"><div class="st-ico">🔢</div><div class="st-label">靓号在售</div><div class="st-value"><?= number_format($statPretty) ?></div><div class="st-sub"><?= $statSold > 0 ? '历史已售 ' . number_format($statSold) : '购买后自动下池' ?></div></div>
  <div class="adm-stat orange"><div class="st-ico">😀</div><div class="st-label">系统表情</div><div class="st-value"><?= number_format($statEmoji) ?></div><div class="st-sub">个</div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head" style="padding-bottom:14px">
    <div class="adm-toolbar" style="gap:4px">
      <a class="adm-btn <?= $tab === 'gift' ? '' : 'ghost' ?> sm" href="products.php?tab=gift">礼物</a>
      <a class="adm-btn <?= $tab === 'vip' ? '' : 'ghost' ?> sm" href="products.php?tab=vip">VIP 套餐</a>
      <a class="adm-btn <?= $tab === 'pretty' ? '' : 'ghost' ?> sm" href="products.php?tab=pretty">靓号</a>
      <a class="adm-btn <?= $tab === 'emoji' ? '' : 'ghost' ?> sm" href="products.php?tab=emoji">表情</a>
    </div>
    <div class="adm-toolbar">
      <?php if ($tab === 'gift'): ?>
        <button class="adm-btn sm" onclick="prdGift(0)">＋ 新增礼物</button>
      <?php elseif ($tab === 'vip'): ?>
        <button class="adm-btn sm" onclick="prdVip(0)">＋ 新增套餐</button>
      <?php elseif ($tab === 'pretty'): ?>
        <button class="adm-btn sm" onclick="prdPrettyAdd()">＋ 批量添加</button>
      <?php else: ?>
        <button class="adm-btn sm" onclick="prdEmoji()">＋ 添加表情</button>
      <?php endif; ?>
    </div>
  </div>

<?php if ($tab === 'gift'): ?>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>图标</th><th>名称</th><th>价格</th><th>状态</th><th>排序</th><th style="width:170px">操作</th></tr></thead>
      <tbody>
      <?php if (!$gifts): ?><tr><td colspan="7"><div class="adm-empty">还没有礼物</div></td></tr><?php endif; ?>
      <?php foreach ($gifts as $g): ?>
        <tr>
          <td class="sub">#<?= (int)$g['id'] ?></td>
          <td style="font-size:22px"><?= e((string)$g['icon']) ?></td>
          <td><span class="nm"><?= e((string)$g['name']) ?></span></td>
          <td class="num"><?= number_format((int)$g['price']) ?></td>
          <td><span class="tag <?= (int)$g['status'] === 1 ? 'green' : 'gray' ?>"><?= (int)$g['status'] === 1 ? '上架' : '下架' ?></span></td>
          <td class="sub"><?= (int)$g['sort'] ?></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" onclick="prdGift(<?= (int)$g['id'] ?>)">编辑</button>
              <button class="adm-btn sm <?= (int)$g['status'] === 1 ? 'orange' : '' ?>" onclick="prdAct('gift_toggle', <?= (int)$g['id'] ?>)"><?= (int)$g['status'] === 1 ? '下架' : '上架' ?></button>
              <button class="adm-btn sm danger" onclick="prdDel('gift_del', <?= (int)$g['id'] ?>, <?= json_encode((string)$g['name'], JSON_UNESCAPED_UNICODE) ?>)">删除</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

<?php elseif ($tab === 'vip'): ?>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>名称</th><th>天数</th><th>价格</th><th>等级</th><th>状态</th><th>排序</th><th style="width:170px">操作</th></tr></thead>
      <tbody>
      <?php if (!$vips): ?><tr><td colspan="8"><div class="adm-empty">还没有 VIP 套餐</div></td></tr><?php endif; ?>
      <?php foreach ($vips as $v): ?>
        <tr>
          <td class="sub">#<?= (int)$v['id'] ?></td>
          <td><span class="nm"><?= e((string)$v['name']) ?></span></td>
          <td class="num"><?= (int)$v['days'] ?> 天</td>
          <td class="num"><?= number_format((int)$v['price']) ?></td>
          <td><span class="tag <?= vip_tier((int)$v['level']) === 'SVIP' ? 'purple' : 'orange' ?>"><?= e(vip_label((int)$v['level'])) ?></span></td>
          <td><span class="tag <?= (int)$v['status'] === 1 ? 'green' : 'gray' ?>"><?= (int)$v['status'] === 1 ? '上架' : '下架' ?></span></td>
          <td class="sub"><?= (int)$v['sort'] ?></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" onclick="prdVip(<?= (int)$v['id'] ?>)">编辑</button>
              <button class="adm-btn sm <?= (int)$v['status'] === 1 ? 'orange' : '' ?>" onclick="prdAct('vip_toggle', <?= (int)$v['id'] ?>)"><?= (int)$v['status'] === 1 ? '下架' : '上架' ?></button>
              <button class="adm-btn sm danger" onclick="prdDel('vip_del', <?= (int)$v['id'] ?>, <?= json_encode((string)$v['name'], JSON_UNESCAPED_UNICODE) ?>)">删除</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

<?php elseif ($tab === 'pretty'): ?>
  <div class="adm-panel-body" style="padding-bottom:0">
    <div class="adm-hint" style="margin:-2px 0 12px">购买成功后号码会自动从号池移除，不再出现在商城与列表中，避免被二次购买；「已售」仅存在于旧数据，可直接删除。</div>
    <form method="get" class="adm-toolbar" style="margin-bottom:14px">
      <input type="hidden" name="tab" value="pretty">
      <select class="adm-select" name="ptyp" onchange="this.form.submit()">
        <option value="">全部类型</option>
        <option value="user" <?= $prettyType === 'user' ? 'selected' : '' ?>>个人靓号</option>
        <option value="group" <?= $prettyType === 'group' ? 'selected' : '' ?>>群靓号</option>
      </select>
      <select class="adm-select" name="pst" onchange="this.form.submit()">
        <option value="">全部状态</option>
        <option value="0" <?= $prettySt === '0' ? 'selected' : '' ?>>在售</option>
        <option value="1" <?= $prettySt === '1' ? 'selected' : '' ?>>已售</option>
        <option value="2" <?= $prettySt === '2' ? 'selected' : '' ?>>已下架</option>
      </select>
      <input class="adm-input" name="kw" value="<?= e($prettyKw) ?>" placeholder="靓号 / 买家 CC号 / 昵称" style="min-width:200px">
      <button class="adm-btn sm" type="submit">搜索</button>
      <a class="adm-btn ghost sm" href="products.php?tab=pretty">重置</a>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>靓号</th><th>类型</th><th>价格</th><th>状态</th><th>买家</th><th>售出时间</th><th style="width:220px">操作</th></tr></thead>
      <tbody>
      <?php if (!$pretties): ?><tr><td colspan="8"><div class="adm-empty">没有靓号，点右上角「批量添加」</div></td></tr><?php endif; ?>
      <?php foreach ($pretties as $p2): ?>
        <?php
        $ps = (int)$p2['status'];
        $psMap = [0 => ['在售', 'green'], 1 => ['已售', 'blue'], 2 => ['已下架', 'gray']];
        $psx = $psMap[$ps] ?? ['未知', 'gray'];
        ?>
        <tr>
          <td class="sub">#<?= (int)$p2['id'] ?></td>
          <td><span class="nm" style="font-family:ui-monospace,monospace;font-size:14px"><?= e((string)$p2['yx_id']) ?></span></td>
          <td><span class="tag <?= (string)($p2['ptype'] ?? 'user') === 'group' ? 'purple' : 'green' ?>"><?= (string)($p2['ptype'] ?? 'user') === 'group' ? '群靓号' : '个人' ?></span></td>
          <td class="num"><?= number_format((int)$p2['price']) ?></td>
          <td><span class="tag <?= $psx[1] ?>"><?= e($psx[0]) ?></span></td>
          <td>
            <?php if ((int)$p2['buyer_uid'] > 0): ?>
              <div class="nm" style="font-size:12.5px"><?= e((string)($p2['buyer_nickname'] ?: '-')) ?></div>
              <div class="sub">CC <?= e((string)($p2['buyer_account'] ?: '-')) ?></div>
            <?php else: ?>
              <span class="sub">-</span>
            <?php endif; ?>
          </td>
          <td><span class="sub"><?= (int)$p2['sold_at'] > 0 ? e(date('Y-m-d H:i', (int)$p2['sold_at'])) : '-' ?></span></td>
          <td>
            <div class="actions">
              <?php if ($ps !== 1): ?>
                <button class="adm-btn sm <?= $ps === 0 ? 'orange' : '' ?>" onclick="prdAct('pretty_toggle', <?= (int)$p2['id'] ?>)"><?= $ps === 0 ? '下架' : '上架' ?></button>
              <?php endif; ?>
              <button class="adm-btn sm danger" onclick='prdPrettyDel(<?= (int)$p2['id'] ?>, <?= json_encode((string)$p2['yx_id'], JSON_UNESCAPED_UNICODE) ?>, <?= $ps === 1 ? 1 : 0 ?>, <?= json_encode((string)($p2['buyer_nickname'] ?: ($p2['buyer_account'] ?: '')), JSON_UNESCAPED_UNICODE) ?>)'>删除</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($prettyTotal, $ppage, $pper, $pBaseUrl) ?>

<?php else: ?>
  <div class="adm-panel-body">
    <?php if (!$emojis): ?><div class="adm-empty">还没有系统表情</div><?php endif; ?>
    <div style="display:flex;flex-wrap:wrap;gap:10px">
      <?php foreach ($emojis as $em): ?>
        <?php $ch = (string)$em['url']; if (strpos($ch, 'emoji:') === 0) $ch = substr($ch, 6); ?>
        <div style="width:88px;border:1px solid #EBEEF4;border-radius:10px;padding:10px 6px;text-align:center;background:#FBFCFE">
          <div style="font-size:26px;line-height:1.2"><?= e($ch) ?></div>
          <div class="sub" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:4px 0 6px"><?= e((string)$em['name']) ?></div>
          <button class="adm-btn sm danger" style="height:24px;padding:0 8px;font-size:11px" onclick="prdDel('emoji_del', <?= (int)$em['id'] ?>, <?= json_encode($ch, JSON_UNESCAPED_UNICODE) ?>)">删除</button>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>
</div>

<script>
var PRD_GIFT = <?= json_encode($jsGift, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var PRD_VIP = <?= json_encode($jsVip, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
function prdAct(act, id) {
  var txt = act === 'pretty_toggle' ? '确认切换上架/下架状态？' : '确认执行该操作？';
  ADM.confirm({title:'操作确认', text:txt, ok:'确认'}).then(function (y) { if (y) ADM.postForm(act, {id:id}); });
}
function prdDel(act, id, name) {
  ADM.confirm({title:'删除确认', danger:true, ok:'删除', html:'<p style="margin:0;color:#6B7280">确认删除 <b style="color:#111827">' + ADM.esc(name) + '</b> ？该操作不可恢复。</p>'})
    .then(function (y) { if (y) ADM.postForm(act, {id:id}); });
}
function prdPrettyDel(id, num, sold, buyer) {
  if (!sold) {
    ADM.confirm({title:'删除靓号', danger:true, ok:'删除',
      html:'<p style="margin:0;color:#6B7280">确认删除靓号 <b style="color:#111827">' + ADM.esc(num) + '</b> ？该操作不可恢复。</p>'})
      .then(function (y) { if (y) ADM.postForm('pretty_del', {id:id}); });
    return;
  }
  var html = '<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:12px 14px;color:#92400E;font-size:12.5px;line-height:1.8">' +
    '靓号 <b>' + ADM.esc(num) + '</b> 已售出' + (buyer ? '（买家：' + ADM.esc(buyer) + '）' : '') + '，删除记录后买家仍会继续展示该号码。' +
    '</div>' +
    '<form method="post" action="' + location.pathname + location.search + '" id="pdForm" style="margin-top:14px">' +
    '<input type="hidden" name="act" value="pretty_del"><input type="hidden" name="id" value="' + id + '">' +
    '<label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:#374151">' +
    '<input type="checkbox" name="revoke" value="1"> 同时从买家账号 / 群聊中收回该靓号</label>' +
    '<div class="adm-hint">勾选后买家会恢复为原 CC号 / 群号，请谨慎操作。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:18px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn danger">确认删除</button></div></form>';
  ADM.modal({title:'删除已售靓号 · ' + num, html: html, footer:false});
}

function prdGift(id) {
  var g = id ? PRD_GIFT[id] : {name:'', icon:'', price:100, status:1, sort:0};
  if (!g) { ADM.toast('数据不存在'); return; }
  ADM.modal({title: id ? ('编辑礼物 #' + id) : '新增礼物', html:
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
      '<div class="adm-field"><label>名称</label><input class="adm-input" id="g-name" value="' + ADM.esc(g.name) + '" style="width:100%"></div>' +
      '<div class="adm-field"><label>图标（emoji）</label><input class="adm-input" id="g-icon" value="' + ADM.esc(g.icon) + '" placeholder="🌹" style="width:100%"></div>' +
      '<div class="adm-field"><label>价格（CC币）</label><input class="adm-input" type="number" min="1" id="g-price" value="' + parseInt(g.price, 10) + '" style="width:100%"></div>' +
      '<div class="adm-field"><label>排序（小的在前）</label><input class="adm-input" type="number" id="g-sort" value="' + parseInt(g.sort, 10) + '" style="width:100%"></div>' +
    '</div>' +
    '<label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-top:4px"><input type="checkbox" id="g-status" ' + (parseInt(g.status, 10) === 1 ? 'checked' : '') + '> 上架（前台可见）</label>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="g-ok">保存</button>',
    onOpen:function () {
      document.getElementById('g-ok').onclick = function () {
        var name = document.getElementById('g-name').value.trim();
        var icon = document.getElementById('g-icon').value.trim();
        var price = parseInt(document.getElementById('g-price').value, 10) || 0;
        if (!name) { ADM.toast('请填写名称'); return; }
        if (!icon) { ADM.toast('请填写图标'); return; }
        if (price <= 0) { ADM.toast('价格必须大于 0'); return; }
        ADM.postForm('gift_save', {id: id || 0, name: name, icon: icon, price: price,
          sort: parseInt(document.getElementById('g-sort').value, 10) || 0,
          status: document.getElementById('g-status').checked ? 1 : 0});
      };
    }});
}
function prdVip(id) {
  var v = id ? PRD_VIP[id] : {name:'', days:30, price:1980, level:1, status:1, sort:0};
  if (!v) { ADM.toast('数据不存在'); return; }
  ADM.modal({title: id ? ('编辑套餐 #' + id) : '新增套餐', html:
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
      '<div class="adm-field" style="grid-column:1/-1"><label>套餐名称</label><input class="adm-input" id="v-name" value="' + ADM.esc(v.name) + '" style="width:100%"></div>' +
      '<div class="adm-field"><label>天数</label><input class="adm-input" type="number" min="1" id="v-days" value="' + parseInt(v.days, 10) + '" style="width:100%"></div>' +
      '<div class="adm-field"><label>价格（CC币）</label><input class="adm-input" type="number" min="1" id="v-price" value="' + parseInt(v.price, 10) + '" style="width:100%"></div>' +
      '<div class="adm-field"><label>会员等级</label><input class="adm-input" type="number" min="1" max="20" id="v-level" value="' + parseInt(v.level, 10) + '" style="width:100%"><div class="adm-hint">≥ ' + ADM.svipMin() + ' 级显示为 SVIP，其余显示为 VIP（可在「系统设置」调整 SVIP 起始等级）</div></div>' +
      '<div class="adm-field"><label>排序</label><input class="adm-input" type="number" id="v-sort" value="' + parseInt(v.sort, 10) + '" style="width:100%"></div>' +
    '</div>' +
    '<label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-top:4px"><input type="checkbox" id="v-status" ' + (parseInt(v.status, 10) === 1 ? 'checked' : '') + '> 上架（前台可购买）</label>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="v-ok">保存</button>',
    onOpen:function () {
      document.getElementById('v-ok').onclick = function () {
        var name = document.getElementById('v-name').value.trim();
        if (!name) { ADM.toast('请填写名称'); return; }
        ADM.postForm('vip_save', {id: id || 0, name: name,
          days: parseInt(document.getElementById('v-days').value, 10) || 0,
          price: parseInt(document.getElementById('v-price').value, 10) || 0,
          level: parseInt(document.getElementById('v-level').value, 10) || 1,
          sort: parseInt(document.getElementById('v-sort').value, 10) || 0,
          status: document.getElementById('v-status').checked ? 1 : 0});
      };
    }});
}
function prdPrettyAdd() {
  ADM.modal({title:'批量添加靓号', html:
    '<div class="adm-field"><label>靓号类型</label><select class="adm-select" id="p-type">' +
      '<option value="user">个人靓号（CC号）</option><option value="group">群靓号（群号）</option></select>' +
      '<div class="adm-hint">个人靓号购买后替换用户展示 CC号；群靓号购买后应用到群主的群聊，群资料与会话列表显示「靓」标识。</div></div>' +
    '<div class="adm-field" style="margin-top:12px"><label>每行一个：号码 价格（空格或逗号分隔）</label>' +
    '<textarea class="adm-textarea" id="p-batch" style="min-height:170px" placeholder="888888 88888&#10;520520 5200&#10;1314520,13140"></textarea></div>' +
    '<div class="adm-hint">号码 3-20 位字母数字下划线；价格留空默认 100 CC币；已存在的号码会自动跳过。</div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="p-ok">批量添加</button>',
    onOpen:function () {
      document.getElementById('p-ok').onclick = function () {
        var v = document.getElementById('p-batch').value.trim();
        if (!v) { ADM.toast('请填写靓号'); return; }
        ADM.postForm('pretty_add', {batch: v, ptype: document.getElementById('p-type').value});
      };
    }});
}
function prdEmoji() {
  ADM.modal({title:'添加系统表情', html:
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">' +
      '<div class="adm-field"><label>表情符号</label><input class="adm-input" id="e-ch" placeholder="😀" style="width:100%"></div>' +
      '<div class="adm-field"><label>名称（可选）</label><input class="adm-input" id="e-name" placeholder="微笑" style="width:100%"></div>' +
    '</div><div class="adm-hint">保存为 emoji:😀 形式，全站用户可用。</div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="e-ok">添加</button>',
    onOpen:function () {
      document.getElementById('e-ok').onclick = function () {
        var ch = document.getElementById('e-ch').value.trim();
        if (!ch) { ADM.toast('请填写表情符号'); return; }
        ADM.postForm('emoji_add', {emoji: ch, name: document.getElementById('e-name').value.trim()});
      };
    }});
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
