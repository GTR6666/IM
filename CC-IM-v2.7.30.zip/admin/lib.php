<?php
/**
 * CC商聊 - 管理后台基础（鉴权 / 布局 / 日志）
 */
declare(strict_types=1);
require_once dirname(__DIR__) . '/lib/bootstrap.php';

function admin_session_start(): void
{
    cc_session_start();
}

function admin_current(): ?array
{
    admin_session_start();
    $id = (int)($_SESSION['admin_id'] ?? 0);
    if (!$id) return null;
    static $cache = null;
    if ($cache && (int)$cache['id'] === $id) return $cache;
    $a = one('SELECT * FROM admins WHERE id=?', [$id]);
    if (!$a || (int)$a['status'] !== 0) return null;
    $cache = $a;
    return $a;
}

function admin_login(string $username, string $password): array
{
    $a = one('SELECT * FROM admins WHERE username=?', [$username]);
    if (!$a || !password_verify($password, $a['password'])) {
        return [false, '账号或密码错误'];
    }
    if ((int)$a['status'] !== 0) return [false, '该管理员账号已被禁用'];
    admin_session_start();
    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int)$a['id'];
    q('UPDATE admins SET last_login_at=?, last_ip=? WHERE id=?', [now(), client_ip(), (int)$a['id']]);
    admin_log('login', '登录后台');
    return [true, 'ok'];
}

function admin_logout(): void
{
    admin_session_start();
    unset($_SESSION['admin_id']);
}

function admin_require(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    return $a;
}

function admin_can(string $role = 'ops'): bool
{
    $a = admin_current();
    if (!$a) return false;
    if ($a['role'] === 'super') return true;
    return $a['role'] === $role;
}

function admin_log(string $action, string $detail = ''): void
{
    $a = admin_current();
    try {
        q('INSERT INTO admin_logs (admin_id,action,detail,ip,created_at) VALUES (?,?,?,?,?)', [
            $a ? (int)$a['id'] : 0, mb_substr($action, 0, 64), mb_substr($detail, 0, 500), client_ip(), now(),
        ]);
    } catch (Throwable $e) {
    }
}

function admin_head(string $title, string $active = ''): void
{
    $site = setting('site_name', 'CC商聊');
    $a = admin_current();
    // 分组导航：g => 分组名，item => [文件, 名称, key, 允许角色]
    $nav = [
        ['g' => '概览'],
        ['item' => ['index.php', '数据总览', 'dashboard', 'super,ops,finance']],
        ['g' => '用户与内容'],
        ['item' => ['users.php', '用户管理', 'users', 'super,ops']],
        ['item' => ['groups.php', '群组管理', 'groups', 'super,ops']],
        ['item' => ['messages.php', '消息审计', 'messages', 'super,ops']],
        ['item' => ['moments.php', '动态管理', 'moments', 'super,ops']],
        ['item' => ['live.php', '直播 / 通话', 'live', 'super,ops']],
        ['g' => '资金'],
        ['item' => ['recharge.php', '充值 / USDT', 'recharge', 'super,finance']],
        ['item' => ['withdraw.php', '提现审核', 'withdraw', 'super,finance']],
        ['item' => ['wallet_logs.php', '资金流水', 'wallet', 'super,finance']],
        ['item' => ['products.php', '商品与套餐', 'products', 'super,ops']],
        ['g' => '运营'],
        ['item' => ['invite.php', '邀请奖励', 'invite', 'super,ops']],
        ['item' => ['landing.php', '落地页', 'landing', 'super,ops']],
        ['item' => ['notices.php', '公告管理', 'notices', 'super,ops']],
        ['item' => ['appeals.php', '申诉 / 举报', 'appeals', 'super,ops']],
        ['g' => '系统'],
        ['item' => ['settings.php', '系统设置', 'settings', 'super']],
        ['item' => ['admins.php', '管理员', 'admins', 'super']],
        ['item' => ['logs.php', '操作日志', 'logs', 'super']],
        ['item' => ['maintenance.php', '数据维护', 'maintenance', 'super']],
    ];
    $role = $a ? $a['role'] : '';
    ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> · <?= e($site) ?> 管理后台</title>
<link rel="icon" href="../icons/icon-192.png">
<link rel="stylesheet" href="assets/admin.css?v=<?= CC_VERSION ?>">
</head>
<body class="admin-body">
<div class="adm-shell">
  <aside class="adm-side" id="admSide" aria-label="后台导航">
    <div class="adm-brand">
      <div class="adm-logo">CC</div>
      <div class="adm-brand-txt">
        <div class="adm-brand-name"><?= e($site) ?></div>
        <div class="adm-brand-sub">管理后台 v<?= CC_VERSION ?></div>
      </div>
      <button class="adm-side-close" id="admSideClose" aria-label="关闭菜单">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>
    <nav class="adm-nav">
      <?php foreach ($nav as $n): ?>
        <?php if (isset($n['g'])): ?>
          <div class="adm-nav-group"><?= e($n['g']) ?></div>
        <?php continue; endif; ?>
        <?php $it = $n['item']; if (!in_array($role, explode(',', $it[3]), true)) continue; ?>
        <a class="adm-nav-item <?= $active === $it[2] ? 'active' : '' ?>" href="<?= $it[0] ?>">
          <?= admin_icon($it[2]) ?><span><?= $it[1] ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="adm-side-foot">
      <a href="../index.php" target="_blank" rel="noopener">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M14 4h6v6M20 4l-8.5 8.5"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>
        打开前台
      </a>
      <a href="logout.php">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M15 17l5-5-5-5"/><path d="M20 12H9"/><path d="M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6"/></svg>
        退出登录
      </a>
    </div>
  </aside>
  <div class="adm-side-mask" id="admSideMask"></div>
  <main class="adm-main">
    <header class="adm-top">
      <button class="adm-menu-btn" id="admMenuBtn" aria-label="打开菜单">
        <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
      <h1><?= e($title) ?></h1>
      <div class="adm-top-right">
        <span class="adm-role"><b><?= e($a ? $a['username'] : '') ?></b> · <?= e($a ? $a['role'] : '') ?></span>
      </div>
    </header>
    <div class="adm-content">
<?php
}

function admin_foot(): void
{
    ?>
    </div>
  </main>
</div>
<script>window.ADM_SVIP_MIN=<?= (int)svip_min_level() ?>;
window.TERMS=<?= json_encode([
  'brand'  => term_brand(),
  'id'     => term_id(),
  'coin'   => term_coin(),
  'pretty' => term_pretty(),
  'member' => term_member(),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="assets/admin.js?v=<?= CC_VERSION ?>"></script>
</body>
</html>
<?php
}

function admin_icon(string $k): string
{
    $p = [
        'dashboard' => '<rect x="3" y="3" width="7" height="8" rx="1.6"/><rect x="14" y="3" width="7" height="5" rx="1.6"/><rect x="14" y="11" width="7" height="10" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/>',
        'users'     => '<circle cx="9" cy="8" r="3.4"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0"/><path d="M16 5.5a3 3 0 0 1 0 5.6"/><path d="M17.5 14.4A5.4 5.4 0 0 1 21 20"/>',
        'groups'    => '<circle cx="8" cy="8" r="3"/><circle cx="16.5" cy="7" r="2.4"/><path d="M2.5 19.5a5.5 5.5 0 0 1 11 0"/><path d="M14.5 14.6a4.6 4.6 0 0 1 6.5 4.2"/>',
        'messages'  => '<path d="M20 12.5a7.5 7.5 0 0 1-11 6.7L4 20.5l1.3-4.2A7.5 7.5 0 1 1 20 12.5z"/>',
        'moments'   => '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><circle cx="9" cy="9" r="1.6"/><path d="M4.5 17l4.6-4.3 3.2 2.9 3-2.6 4.2 3.7"/>',
        'live'      => '<circle cx="12" cy="12" r="2.6"/><path d="M7.4 7.4a6.5 6.5 0 0 0 0 9.2M16.6 16.6a6.5 6.5 0 0 0 0-9.2"/><path d="M4.6 4.6a10.5 10.5 0 0 0 0 14.8M19.4 19.4a10.5 10.5 0 0 0 0-14.8"/>',
        'recharge'  => '<rect x="2.5" y="6" width="19" height="12.5" rx="3"/><path d="M2.5 10h19"/><path d="M6.5 14.5h4"/>',
        'withdraw'  => '<path d="M12 3.5v11"/><path d="M8 10.5l4 4 4-4"/><path d="M4 17.5h16"/>',
        'wallet'    => '<path d="M3.5 7.5a2.5 2.5 0 0 1 2.5-2.5h10.5A2.5 2.5 0 0 1 19 7.5"/><rect x="3.5" y="7.5" width="17" height="12" rx="2.6"/><circle cx="16.5" cy="13.5" r="1.3"/>',
        'products'  => '<path d="M4 9.5h16l-1.3 9.2a1.6 1.6 0 0 1-1.6 1.3H6.9a1.6 1.6 0 0 1-1.6-1.3z"/><path d="M8.4 9.5a3.6 3.6 0 0 1 7.2 0"/><path d="M4 9.5h16"/>',
        'invite'    => '<circle cx="9" cy="8.5" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M18.5 6.5v6M15.5 9.5h6"/>',
        'notices'   => '<path d="M4.5 10v4l9 4.5V5.5z"/><path d="M18 9.2a4 4 0 0 1 0 5.6"/><path d="M6.5 14.2V19a1.4 1.4 0 0 0 2.8 0v-3.4"/>',
        'appeals'   => '<path d="M12 3.2l7 2.8v6c0 4.2-2.9 7.3-7 8.8-4.1-1.5-7-4.6-7-8.8v-6z"/><path d="M9.2 12.2l2 2 3.6-3.8"/>',
        'settings'  => '<circle cx="12" cy="12" r="3"/><path d="M19.4 14a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2v.2a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-2.9-1.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 14a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.2-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 3.1V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 10h.2a2 2 0 1 1 0 4z"/>',
        'admins'    => '<circle cx="8.5" cy="14" r="3.2"/><path d="M11 11.4l8-8"/><path d="M16.4 2.6l2.4 2.4"/><path d="M14.8 4.2l2.4 2.4"/>',
        'logs'      => '<rect x="4" y="3" width="16" height="18" rx="2.4"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'maintenance' => '<path d="M4 7h16M4 12h16M4 17h10"/><path d="M17.5 15.5l2 2-4 4-2-2z"/>',
        'landing'   => '<rect x="3" y="4.5" width="18" height="15" rx="2.2"/><path d="M3 9h18M8 13.5h8M8 16.5h5"/>',
    ];
    $d = $p[$k] ?? '<circle cx="12" cy="12" r="8"/>';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . $d . '</svg>';
}

function admin_money(int $n): string
{
    return number_format($n);
}

/* =========================================================
 * 硬删除（不可恢复）：用户 / 群组
 * ========================================================= */

/** 删除本地上传文件（仅限 uploads/ 下的相对路径，防止误删） */
function admin_unlink_upload(string $path): void
{
    $path = trim($path);
    if ($path === '') return;
    if (preg_match('#^https?://#i', $path)) return;
    $path = ltrim($path, '/');
    if (strpos($path, 'uploads/') !== 0) return;
    $full = CC_ROOT . '/' . $path;
    if (is_file($full)) @unlink($full);
}

/**
 * 硬删除群组：群消息、会话、成员、公告、入群申请、直播、举报等全部清除
 * @return array 各表删除条数
 */
function admin_purge_group(int $gid, bool $ownTransaction = true): array
{
    $g = one('SELECT * FROM groups WHERE gid=?', [$gid]);
    if (!$g) throw new RuntimeException('群不存在');
    $stat = [];
    $pdo = db();
    if ($ownTransaction) $pdo->beginTransaction();
    try {
        $stat['messages']    = q('DELETE FROM messages WHERE gid=?', [$gid])->rowCount();
        $stat['conversations'] = q('DELETE FROM conversations WHERE ctype=2 AND peer_id=?', [$gid])->rowCount();
        $stat['members']     = q('DELETE FROM group_members WHERE gid=?', [$gid])->rowCount();
        $stat['join_reqs']   = q('DELETE FROM group_join_requests WHERE gid=?', [$gid])->rowCount();
        $stat['notices']     = q('DELETE FROM group_notices WHERE gid=?', [$gid])->rowCount();
        $stat['calls']       = q('DELETE FROM calls WHERE gid=?', [$gid])->rowCount();
        $stat['gifts']       = q('DELETE FROM gift_records WHERE gid=?', [$gid])->rowCount();
        $stat['red_packets'] = q('DELETE FROM red_packets WHERE gid=?', [$gid])->rowCount();
        $stat['live']        = q('DELETE FROM live_rooms WHERE gid=?', [$gid])->rowCount();
        $stat['reports']     = q('DELETE FROM reports WHERE target_type=? AND target_id=?', ['group', $gid])->rowCount();
        admin_unlink_upload((string)$g['avatar']);
        q('DELETE FROM groups WHERE gid=?', [$gid]);
        $stat['groups'] = 1;
        if ($ownTransaction) $pdo->commit();
    } catch (Throwable $e) {
        if ($ownTransaction) $pdo->rollBack();
        throw $e;
    }
    return $stat;
}

/**
 * 硬删除用户：所有关联数据清除（不可恢复）
 * @param bool $dissolveGroups 该用户作为群主的群是否一并删除
 * @return array 各表删除条数
 */
function admin_purge_user(int $uid, bool $dissolveGroups = true): array
{
    $u = one('SELECT * FROM users WHERE id=?', [$uid]);
    if (!$u) throw new RuntimeException('用户不存在');

    // 官方账号保护
    $svcAcc = (string)setting('service_uid', '10086');
    if (in_array((string)$u['account'], array_filter([$svcAcc, '990375']), true)) {
        throw new RuntimeException('官方客服 / 机器人账号不允许删除，请先更换客服账号');
    }

    $ownedGroups = all('SELECT gid,name FROM groups WHERE owner_uid=?', [$uid]);
    if ($ownedGroups && !$dissolveGroups) {
        $names = implode('、', array_map(static function ($g) { return '「' . $g['name'] . '」'; }, $ownedGroups));
        throw new RuntimeException('该用户是 ' . count($ownedGroups) . ' 个群的群主（' . $names . '），请先转让或解散，或勾选「同时删除其创建的群」');
    }

    $stat = ['owned_groups' => 0];
    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($ownedGroups as $g) {
            admin_purge_group((int)$g['gid'], false); // 复用外层事务
            $stat['owned_groups']++;
        }

        $stat['devices']      = q('DELETE FROM devices WHERE uid=?', [$uid])->rowCount();
        $stat['login_logs']   = q('DELETE FROM login_logs WHERE uid=?', [$uid])->rowCount();
        $stat['friends']      = q('DELETE FROM friends WHERE uid=? OR fid=?', [$uid, $uid])->rowCount();
        $stat['friend_reqs']  = q('DELETE FROM friend_requests WHERE to_uid=? OR from_uid=?', [$uid, $uid])->rowCount();
        $stat['group_members']= q('DELETE FROM group_members WHERE uid=?', [$uid])->rowCount();
        $stat['group_reqs']   = q('DELETE FROM group_join_requests WHERE uid=?', [$uid])->rowCount();
        $stat['group_notices']= q('DELETE FROM group_notices WHERE uid=?', [$uid])->rowCount();
        $stat['conversations']= q('DELETE FROM conversations WHERE uid=?', [$uid])->rowCount();
        $stat['messages']     = q('DELETE FROM messages WHERE from_uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['moments']      = q('DELETE FROM moment WHERE uid=?', [$uid])->rowCount();
        $stat['moment_likes'] = q('DELETE FROM moment_likes WHERE uid=?', [$uid])->rowCount();
        $stat['moment_comments'] = q('DELETE FROM moment_comments WHERE uid=? OR reply_uid=?', [$uid, $uid])->rowCount();
        $stat['moment_reads'] = q('DELETE FROM moment_reads WHERE uid=?', [$uid])->rowCount();
        $stat['notice_reads'] = q('DELETE FROM notice_reads WHERE uid=?', [$uid])->rowCount();
        $stat['wallet_logs']  = q('DELETE FROM wallet_logs WHERE uid=?', [$uid])->rowCount();
        $stat['recharge']     = q('DELETE FROM recharge_orders WHERE uid=?', [$uid])->rowCount();
        $stat['withdraw']     = q('DELETE FROM withdraw_orders WHERE uid=?', [$uid])->rowCount();
        $stat['red_packets']  = q('DELETE FROM red_packets WHERE uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['rp_records']   = q('DELETE FROM red_packet_records WHERE uid=?', [$uid])->rowCount();
        $stat['transfers']    = q('DELETE FROM transfers WHERE from_uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['gifts']        = q('DELETE FROM gift_records WHERE from_uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['calls']        = q('DELETE FROM calls WHERE from_uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['call_signals'] = q('DELETE FROM call_signals WHERE from_uid=? OR to_uid=?', [$uid, $uid])->rowCount();
        $stat['favorites']    = q('DELETE FROM favorites WHERE uid=?', [$uid])->rowCount();
        $stat['emojis']       = q('DELETE FROM emojis WHERE uid=?', [$uid])->rowCount();
        $stat['live_rooms']   = q('DELETE FROM live_rooms WHERE uid=?', [$uid])->rowCount();
        $stat['live_msgs']    = q('DELETE FROM live_messages WHERE uid=?', [$uid])->rowCount();
        $stat['reports']      = q('DELETE FROM reports WHERE from_uid=?', [$uid])->rowCount();
        $stat['appeals']      = q('DELETE FROM appeals WHERE uid=?', [$uid])->rowCount();
        $stat['invites']      = q('DELETE FROM invites WHERE uid=? OR invitee_uid=?', [$uid, $uid])->rowCount();
        $stat['invite_claims']= q('DELETE FROM invite_claims WHERE uid=?', [$uid])->rowCount();
        if ((string)$u['email'] !== '') {
            $stat['verify_codes'] = q('DELETE FROM verify_codes WHERE target=?', [(string)$u['email']])->rowCount();
        }
        // 已购靓号释放回号池
        $stat['pretty_release'] = q('UPDATE pretty_ids SET status=0, buyer_uid=0, sold_at=0 WHERE buyer_uid=? AND ptype=?', [$uid, 'user'])->rowCount();
        admin_unlink_upload((string)$u['avatar']);
        q('DELETE FROM users WHERE id=?', [$uid]);
        $stat['users'] = 1;
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return $stat;
}

function admin_pager(int $total, int $page, int $per, string $baseUrl): string
{
    $pages = max(1, (int)ceil($total / $per));
    if ($pages <= 1) return '';
    $out = '<div class="adm-pager">';
    $start = max(1, $page - 3);
    $end = min($pages, $page + 3);
    if ($page > 1) $out .= '<a href="' . e($baseUrl . 'page=' . ($page - 1)) . '">上一页</a>';
    for ($i = $start; $i <= $end; $i++) {
        $out .= '<a class="' . ($i === $page ? 'on' : '') . '" href="' . e($baseUrl . 'page=' . $i) . '">' . $i . '</a>';
    }
    if ($page < $pages) $out .= '<a href="' . e($baseUrl . 'page=' . ($page + 1)) . '">下一页</a>';
    $out .= '<span class="pinfo">共 ' . $total . ' 条 / ' . $pages . ' 页</span></div>';
    return $out;
}

function admin_qs(array $extra = []): string
{
    $q = array_merge($_GET, $extra);
    unset($q['page']);
    return http_build_query($q) . '&';
}

/** CSV 公式注入防护：以 = + - @ 开头的单元格前置单引号 */
function csv_safe(string $v): string
{
    if ($v !== '' && in_array($v[0], ['=', '+', '-', '@', "\t", "\r"], true)) return "'" . $v;
    return $v;
}
