<?php
/**
 * CC商聊 - 后台：公告管理
 * 列表 / 新增 / 编辑 / 置顶 / 发布下线 / 删除
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function ntc_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'ops', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'notices');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有公告管理权限。</div></div>';
    admin_foot();
    exit;
}

function ntc_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'notices.php'));
    exit;
}

function ntc_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    ntc_back();
}

function ntc_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    ntc_back();
}

function ntc_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

$admin = ntc_allow();

/* =========================================================
 * POST
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            case 'save': {
                $id      = (int)($_POST['id'] ?? 0);
                $title   = trim((string)($_POST['title'] ?? ''));
                $content = trim((string)($_POST['content'] ?? ''));
                $isTop   = (int)($_POST['is_top'] ?? 0) === 1 ? 1 : 0;
                $status  = (int)($_POST['status'] ?? 1) === 1 ? 1 : 0;
                if ($title === '') ntc_err('请填写公告标题');
                if (mb_strlen($title) > 120) ntc_err('标题不能超过 120 字');
                if ($content === '') ntc_err('请填写公告内容');
                $t = now();
                if ($id > 0) {
                    $old = one('SELECT * FROM notices WHERE id=?', [$id]);
                    if (!$old) ntc_err('公告不存在');
                    q('UPDATE notices SET title=?, content=?, is_top=?, status=?, updated_at=? WHERE id=?', [
                        $title, $content, $isTop, $status, $t, $id,
                    ]);
                    admin_log('公告编辑', '#' . $id . ' ' . $title);
                    ntc_done('公告已更新');
                } else {
                    q('INSERT INTO notices (title,content,is_top,status,created_at,updated_at) VALUES (?,?,?,?,?,?)', [
                        $title, $content, $isTop, $status, $t, $t,
                    ]);
                    $nid = last_id();
                    admin_log('公告新增', '#' . $nid . ' ' . $title);
                    ntc_done('公告已新增');
                }
                break;
            }
            case 'top': {
                $id = (int)($_POST['id'] ?? 0);
                $n = one('SELECT * FROM notices WHERE id=?', [$id]);
                if (!$n) ntc_err('公告不存在');
                $v = (int)$n['is_top'] === 1 ? 0 : 1;
                q('UPDATE notices SET is_top=?, updated_at=? WHERE id=?', [$v, now(), $id]);
                admin_log('公告置顶', '#' . $id . ' ' . ($v ? '置顶' : '取消置顶'));
                ntc_done($v ? '已置顶' : '已取消置顶');
                break;
            }
            case 'status': {
                $id = (int)($_POST['id'] ?? 0);
                $n = one('SELECT * FROM notices WHERE id=?', [$id]);
                if (!$n) ntc_err('公告不存在');
                $v = (int)$n['status'] === 1 ? 0 : 1;
                q('UPDATE notices SET status=?, updated_at=? WHERE id=?', [$v, now(), $id]);
                admin_log('公告状态', '#' . $id . ' ' . ($v ? '发布' : '下线'));
                ntc_done($v ? '公告已发布，前台可见' : '公告已下线');
                break;
            }
            case 'del': {
                $id = (int)($_POST['id'] ?? 0);
                $n = one('SELECT * FROM notices WHERE id=?', [$id]);
                if (!$n) ntc_err('公告不存在');
                q('UPDATE notices SET status=0, updated_at=? WHERE id=?', [now(), $id]);
                admin_log('公告删除', '#' . $id . ' ' . $n['title']);
                ntc_done('公告已删除（已下线）');
                break;
            }
            case 'purge': {
                $id = (int)($_POST['id'] ?? 0);
                $n = one('SELECT * FROM notices WHERE id=?', [$id]);
                if (!$n) ntc_err('公告不存在');
                q('DELETE FROM notice_reads WHERE nid=?', [$id]);
                q('DELETE FROM notices WHERE id=?', [$id]);
                admin_log('公告彻底删除', '#' . $id . ' ' . $n['title']);
                ntc_done('公告已彻底删除');
                break;
            }
            default:
                ntc_err('未知操作');
        }
    } catch (Throwable $e) {
        ntc_err('操作失败：' . $e->getMessage());
    }
}

/* =========================================================
 * 列表
 * ========================================================= */
$fStatus = (string)($_GET['status'] ?? '');
$w = [];
$p = [];
if ($fStatus === '0' || $fStatus === '1') {
    $w[] = 'status=?';
    $p[] = (int)$fStatus;
}
$where = $w ? (' WHERE ' . implode(' AND ', $w)) : '';
$total = (int)val('SELECT COUNT(*) FROM notices' . $where, $p);
$page  = max(1, (int)($_GET['page'] ?? 1));
$per   = 20;
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per;
$rows = all('SELECT * FROM notices' . $where . ' ORDER BY is_top DESC, id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);

$fq = $_GET;
unset($fq['page']);
$qs = http_build_query($fq);
$baseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

$jsRows = [];
foreach ($rows as $r) {
    $jsRows[(int)$r['id']] = [
        'title'   => (string)$r['title'],
        'content' => (string)$r['content'],
        'is_top'  => (int)$r['is_top'],
        'status'  => (int)$r['status'],
    ];
}

$statOn  = (int)val('SELECT COUNT(*) FROM notices WHERE status=1');
$statOff = (int)val('SELECT COUNT(*) FROM notices WHERE status=0');
$statTop = (int)val('SELECT COUNT(*) FROM notices WHERE status=1 AND is_top=1');

$flash = ntc_flash();
$title = '公告管理';
admin_head($title, 'notices');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat"><div class="st-ico">✅</div><div class="st-label">已发布</div><div class="st-value"><?= number_format($statOn) ?></div><div class="st-sub">前台可见</div></div>
  <div class="adm-stat gray" style="background:#fff"><div class="st-ico">💤</div><div class="st-label">已下线</div><div class="st-value"><?= number_format($statOff) ?></div><div class="st-sub">前台不可见</div></div>
  <div class="adm-stat orange"><div class="st-ico">📌</div><div class="st-label">置顶中</div><div class="st-value"><?= number_format($statTop) ?></div><div class="st-sub">排在最前</div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>公告列表<span class="sub">共 <?= number_format($total) ?> 条</span></h2>
    <div class="adm-toolbar">
      <form method="get" class="adm-toolbar">
        <select class="adm-select" name="status" onchange="this.form.submit()">
          <option value="">全部</option>
          <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>已发布</option>
          <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>已下线</option>
        </select>
      </form>
      <button class="adm-btn" onclick="ntcEdit(0)">＋ 新增公告</button>
    </div>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th style="width:56px">ID</th><th>标题 / 内容</th><th>置顶</th><th>状态</th><th>更新时间</th><th style="width:250px">操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="6"><div class="adm-empty">还没有公告，点右上角「新增公告」</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td style="max-width:420px">
            <div class="nm"><?php if ((int)$r['is_top'] === 1): ?><span class="tag red" style="margin-right:6px">置顶</span><?php endif; ?><?= e((string)$r['title']) ?></div>
            <div class="sub" style="white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.5"><?= e(mb_substr(str_replace(["\r\n", "\n"], ' ', (string)$r['content']), 0, 90)) ?></div>
          </td>
          <td><span class="tag <?= (int)$r['is_top'] === 1 ? 'orange' : 'gray' ?>"><?= (int)$r['is_top'] === 1 ? '置顶' : '普通' ?></span></td>
          <td><span class="tag <?= (int)$r['status'] === 1 ? 'green' : 'gray' ?>"><?= (int)$r['status'] === 1 ? '已发布' : '已下线' ?></span></td>
          <td><span class="sub"><?= e(date('Y-m-d H:i', (int)$r['updated_at'] ?: (int)$r['created_at'])) ?></span></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" onclick="ntcEdit(<?= (int)$r['id'] ?>)">编辑</button>
              <button class="adm-btn sm ghost" onclick="ntcAct('top', <?= (int)$r['id'] ?>)"><?= (int)$r['is_top'] === 1 ? '取消置顶' : '置顶' ?></button>
              <button class="adm-btn sm <?= (int)$r['status'] === 1 ? 'orange' : '' ?>" onclick="ntcAct('status', <?= (int)$r['id'] ?>)"><?= (int)$r['status'] === 1 ? '下线' : '发布' ?></button>
              <button class="adm-btn sm danger" onclick="ntcDel(<?= (int)$r['id'] ?>)">删除</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>

<script>
var NTC_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
function ntcAct(act, id) {
  var txt = act === 'top' ? '确认切换置顶状态？' : '确认切换发布状态？';
  ADM.confirm({title:'操作确认', text:txt, ok:'确认'}).then(function (yes) { if (yes) ADM.postForm(act, {id:id}); });
}
function ntcDel(id) {
  ADM.confirm({title:'删除公告', danger:true, ok:'删除',
    html:'<p style="margin:0 0 10px;color:#6B7280">删除后公告立即下线，前台不再可见。</p>' +
         '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#374151"><input type="checkbox" id="ntc-purge"> 同时从数据库彻底删除</label>'
  }).then(function (yes) {
    if (!yes) return;
    var purge = document.getElementById('ntc-purge');
    ADM.postForm(purge && purge.checked ? 'purge' : 'del', {id:id});
  });
}
function ntcEdit(id) {
  var r = id ? NTC_ROWS[id] : {title:'', content:'', is_top:0, status:1};
  if (!r) { ADM.toast('数据不存在'); return; }
  ADM.modal({title: id ? ('编辑公告 #' + id) : '新增公告', html:
    '<div class="adm-field" style="margin-bottom:12px"><label>标题</label><input class="adm-input" id="nt-title" maxlength="120" value="' + ADM.esc(r.title) + '" style="width:100%"></div>' +
    '<div class="adm-field" style="margin-bottom:12px"><label>内容</label><textarea class="adm-textarea" id="nt-content" style="min-height:180px">' + ADM.esc(r.content) + '</textarea></div>' +
    '<div style="display:flex;gap:20px;align-items:center;font-size:13px">' +
      '<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="nt-top" ' + (parseInt(r.is_top,10) === 1 ? 'checked' : '') + '> 置顶</label>' +
      '<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="nt-status" ' + (parseInt(r.status,10) === 1 ? 'checked' : '') + '> 立即发布</label>' +
    '</div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="nt-ok">保存</button>',
    onOpen:function () {
      document.getElementById('nt-ok').onclick = function () {
        var title = document.getElementById('nt-title').value.trim();
        var content = document.getElementById('nt-content').value;
        if (!title) { ADM.toast('请填写标题'); return; }
        if (!content.trim()) { ADM.toast('请填写内容'); return; }
        ADM.postForm('save', {
          id: id || 0, title: title, content: content,
          is_top: document.getElementById('nt-top').checked ? 1 : 0,
          status: document.getElementById('nt-status').checked ? 1 : 0
        });
      };
    }});
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
