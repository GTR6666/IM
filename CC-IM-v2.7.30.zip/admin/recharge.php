<?php
/**
 * CC商聊 - 后台：充值 / USDT 管理
 * 设置项、订单列表、手动通过、拒绝、补单、详情、筛选、CSV 导出
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

/* =========================================================
 * 权限与小工具
 * ========================================================= */
function rch_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'recharge');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有充值管理权限，请使用财务或超级管理员账号。</div></div>';
    admin_foot();
    exit;
}

function rch_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'recharge.php'));
    exit;
}

function rch_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    rch_back();
}

function rch_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    rch_back();
}

function rch_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

function rch_status(int $s): array
{
    $map = [
        0 => ['待支付', 'gray'],
        1 => ['待审核', 'orange'],
        2 => ['已到账', 'green'],
        3 => ['已拒绝', 'red'],
        4 => ['已过期', 'gray'],
    ];
    return $map[$s] ?? ['未知', 'gray'];
}

function rch_day0(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 00:00:00');
    return $t ?: 0;
}

function rch_day1(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 23:59:59');
    return $t ?: 0;
}

$admin = rch_allow();

/* =========================================================
 * 超时订单置为已过期（客服单不参与）
 * ========================================================= */
$expireSec = (int)setting('usdt_expire', '1800');
if ($expireSec > 0) {
    try {
        ex('UPDATE recharge_orders SET status=4, remark=? WHERE status=0 AND network NOT IN (?,?) AND created_at>0 AND created_at<?', [
            '订单超时未支付', '客服', '补单', now() - $expireSec,
        ]);
    } catch (Throwable $e) {
    }
}

/* =========================================================
 * POST 写操作
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            /* ---------- USDT 设置 ---------- */
            case 'settings': {
                $address = trim((string)($_POST['usdt_address'] ?? ''));
                $network = trim((string)($_POST['usdt_network'] ?? 'TRC20'));
                if (!in_array($network, ['TRC20', 'ERC20'], true)) $network = 'TRC20';
                $rate    = (int)($_POST['usdt_rate'] ?? 0);
                $minCoin = (int)($_POST['usdt_min_coin'] ?? 0);
                $auto    = (int)($_POST['usdt_auto_check'] ?? 0) === 1 ? '1' : '0';
                $key     = mb_substr(trim((string)($_POST['usdt_trongrid_key'] ?? '')), 0, 128);
                $expire  = (int)($_POST['usdt_expire'] ?? 0);
                $window  = (int)($_POST['usdt_match_window'] ?? 0);

                if ($address !== '') {
                    if ($network === 'TRC20' && !preg_match('/^T[1-9A-HJ-NP-Za-km-z]{33}$/', $address)) {
                        rch_err('TRC20 收款地址格式不正确（T 开头，34 位）');
                    }
                    if ($network === 'ERC20' && !preg_match('/^0x[0-9a-fA-F]{40}$/', $address)) {
                        rch_err('ERC20 收款地址格式不正确（0x 开头，40 位十六进制）');
                    }
                }
                if ($rate < 1 || $rate > 100000) rch_err('汇率需在 1 - 100000 之间');
                if ($minCoin < 1) rch_err('最低充值 CC币数需大于 0');
                if ($expire < 60) rch_err('订单过期秒数不能小于 60');
                if ($window < 60) rch_err('匹配时间窗不能小于 60 秒');

                set_setting('usdt_address', $address);
                set_setting('usdt_network', $network);
                set_setting('usdt_rate', (string)$rate);
                set_setting('usdt_min_coin', (string)$minCoin);
                set_setting('usdt_auto_check', $auto);
                set_setting('usdt_trongrid_key', $key);
                set_setting('usdt_expire', (string)$expire);
                set_setting('usdt_match_window', (string)$window);
                admin_log('充值设置', 'USDT 设置更新：' . $network . ' / 汇率 ' . $rate . ' / 最低 ' . $minCoin . ' / 自动核对 ' . $auto);
                rch_done('USDT 设置已保存');
                break;
            }

            /* ---------- 手动通过（加币） ---------- */
            case 'pass': {
                $id = (int)($_POST['id'] ?? 0);
                $o = one('SELECT * FROM recharge_orders WHERE id=?', [$id]);
                if (!$o) rch_err('订单不存在');
                if ((int)$o['status'] === 2) rch_err('该订单已到账，不能重复加币');
                if ((int)$o['coin'] <= 0) rch_err('订单 CC币数额异常');
                $biz = in_array((string)$o['network'], ['客服', '补单'], true) ? 'manual_recharge' : 'usdt_recharge';
                $aff = q('UPDATE recharge_orders SET status=2, paid_at=?, admin_id=?, remark=? WHERE id=? AND status<>2', [
                    now(), (int)$admin['id'], '管理员手动通过', $id,
                ])->rowCount();
                if (!$aff) rch_err('该订单已被处理');
                try {
                    add_coin((int)$o['uid'], (int)$o['coin'], $biz, $id, '充值到账 ' . $o['coin'] . ' CC币（' . $o['order_no'] . '）');
                } catch (Throwable $e) {
                    q('UPDATE recharge_orders SET status=?, paid_at=?, remark=? WHERE id=?', [
                        (int)$o['status'], (int)$o['paid_at'], (string)$o['remark'], $id,
                    ]);
                    rch_err('加币失败：' . $e->getMessage());
                }
                admin_log('充值通过', '订单 ' . $o['order_no'] . ' 用户#' . $o['uid'] . ' +' . $o['coin'] . ' CC币');
                rch_done('已通过并入账 ' . number_format((int)$o['coin']) . ' CC币', ['id' => $id]);
                break;
            }

            /* ---------- 拒绝 ---------- */
            case 'reject': {
                $id = (int)($_POST['id'] ?? 0);
                $remark = mb_substr(trim((string)($_POST['remark'] ?? '')), 0, 200);
                if ($remark === '') $remark = '管理员拒绝';
                $o = one('SELECT * FROM recharge_orders WHERE id=?', [$id]);
                if (!$o) rch_err('订单不存在');
                if ((int)$o['status'] === 2) rch_err('已到账订单不能拒绝');
                $aff = q('UPDATE recharge_orders SET status=3, admin_id=?, remark=? WHERE id=? AND status<>2', [
                    (int)$admin['id'], $remark, $id,
                ])->rowCount();
                if (!$aff) rch_err('该订单已被处理');
                admin_log('充值拒绝', '订单 ' . $o['order_no'] . '：' . $remark);
                rch_done('订单已拒绝');
                break;
            }

            /* ---------- 补单（直接加币 + 生成已到账订单） ---------- */
            case 'makeup': {
                $acc = trim((string)($_POST['account'] ?? ''));
                $coin = (int)($_POST['coin'] ?? 0);
                $remark = mb_substr(trim((string)($_POST['remark'] ?? '')), 0, 200);
                if ($acc === '') rch_err('请输入用户 CC号 / 账号');
                if ($coin <= 0) rch_err('CC币数量必须大于 0');
                if ($coin > 100000000) rch_err('单笔补单上限 1 亿 CC币');
                $u = one('SELECT * FROM users WHERE account=? OR yx_id=? OR pretty_yxid=?', [$acc, $acc, $acc]);
                if (!$u) rch_err('用户不存在：' . $acc);
                $orderNo = order_no('M');
                $t = now();
                q('INSERT INTO recharge_orders (order_no,uid,coin,rate,amount_usdt,address,network,status,txid,pay_tx,remark,created_at,paid_at,admin_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
                    $orderNo, (int)$u['id'], $coin, 0, '0', '', '补单', 2, '', '', ($remark !== '' ? $remark : '管理员补单'), $t, $t, (int)$admin['id'],
                ]);
                $oid = last_id();
                try {
                    add_coin((int)$u['id'], $coin, 'manual_recharge', $oid, '补单加币 ' . $coin . ' CC币（' . $orderNo . '）');
                } catch (Throwable $e) {
                    q('DELETE FROM recharge_orders WHERE id=?', [$oid]);
                    rch_err('补单失败：' . $e->getMessage());
                }
                admin_log('充值补单', '用户 ' . $u['account'] . '(#' . $u['id'] . ') +' . $coin . ' CC币，订单 ' . $orderNo . '，备注：' . $remark);
                rch_done('补单成功，已为 ' . $u['account'] . ' 增加 ' . number_format($coin) . ' CC币', ['order_no' => $orderNo, 'id' => $oid]);
                break;
            }

            default:
                rch_err('未知操作');
        }
    } catch (Throwable $e) {
        rch_err('操作失败：' . $e->getMessage());
    }
}

/* =========================================================
 * 筛选 / 分页 / 导出
 * ========================================================= */
$fStatus = (string)($_GET['status'] ?? '');
$fNet    = trim((string)($_GET['network'] ?? ''));
$kw      = trim((string)($_GET['kw'] ?? ''));
$d1      = trim((string)($_GET['d1'] ?? ''));
$d2      = trim((string)($_GET['d2'] ?? ''));
$t1      = rch_day0($d1);
$t2      = rch_day1($d2);

$w = [];
$p = [];
if ($fStatus !== '' && $fStatus !== 'all') {
    $w[] = 'o.status=?';
    $p[] = (int)$fStatus;
}
if ($fNet !== '') {
    $w[] = 'o.network=?';
    $p[] = $fNet;
}
if ($kw !== '') {
    $w[] = '(o.order_no LIKE ? OR o.txid LIKE ? OR o.pay_tx LIKE ? OR u.account LIKE ? OR u.nickname LIKE ? OR u.yx_id LIKE ?)';
    $like = '%' . $kw . '%';
    foreach ([1, 2, 3, 4, 5, 6] as $_) $p[] = $like;
}
if ($t1 > 0) {
    $w[] = 'o.created_at>=?';
    $p[] = $t1;
}
if ($t2 > 0) {
    $w[] = 'o.created_at<=?';
    $p[] = $t2;
}
$where = $w ? (' WHERE ' . implode(' AND ', $w)) : '';
$sqlFrom = ' FROM recharge_orders o LEFT JOIN users u ON u.id=o.uid' . $where;

/* 网络下拉 */
$netList = [];
try {
    foreach (all('SELECT network, COUNT(*) AS n FROM recharge_orders GROUP BY network ORDER BY n DESC') as $r) {
        if ((string)$r['network'] !== '') $netList[] = (string)$r['network'];
    }
} catch (Throwable $e) {
}

/* ---------- CSV 导出 ---------- */
if (isset($_GET['export']) && (string)$_GET['export'] === '1') {
    $rows = all('SELECT o.*, u.account, u.nickname' . $sqlFrom . ' ORDER BY o.id DESC LIMIT 20000', $p);
    $fname = 'recharge_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $fname . '"');
    header('Cache-Control: no-store');
    echo "\xEF\xBB\xBF";
    $fp = fopen('php://output', 'w');
    if ($fp) {
        fputcsv($fp, ['订单号', '用户CC号', '昵称', 'CC币', 'USDT金额', '网络', '状态', 'TXID', '备注', '创建时间', '到账时间'], ',', '"', '\\');
        foreach ($rows as $r) {
            $st = rch_status((int)$r['status']);
            if ((string)$r['network'] === '客服' && (int)$r['status'] === 0) $st = ['待确认', 'orange'];
            fputcsv($fp, [
                csv_safe((string)$r['order_no']),
                csv_safe((string)($r['account'] ?? '')),
                csv_safe((string)($r['nickname'] ?? '')),
                (int)$r['coin'],
                csv_safe((string)$r['amount_usdt']),
                csv_safe((string)$r['network']),
                $st[0],
                csv_safe((string)($r['pay_tx'] !== '' ? $r['pay_tx'] : $r['txid'])),
                csv_safe((string)$r['remark']),
                $r['created_at'] ? date('Y-m-d H:i:s', (int)$r['created_at']) : '',
                $r['paid_at'] ? date('Y-m-d H:i:s', (int)$r['paid_at']) : '',
            ], ',', '"', '\\');
        }
        fclose($fp);
    }
    admin_log('充值导出', '导出 ' . count($rows) . ' 条充值订单');
    exit;
}

$total = (int)val('SELECT COUNT(*)' . $sqlFrom, $p);
$page  = max(1, (int)($_GET['page'] ?? 1));
$per   = 20;
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per;
$rows = all('SELECT o.*, u.account, u.nickname, u.yx_id, u.avatar' . $sqlFrom . ' ORDER BY o.id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);

$fq = $_GET;
unset($fq['page'], $fq['export']);
$qs = http_build_query($fq);
$baseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

/* ---------- 汇总 ---------- */
$today0 = strtotime('today');
$sumStat = [
    'wait'  => (int)val('SELECT COUNT(*) FROM recharge_orders WHERE status=1'),
    'unpay' => (int)val('SELECT COUNT(*) FROM recharge_orders WHERE status=0'),
    'today' => (int)val('SELECT COALESCE(SUM(coin),0) FROM recharge_orders WHERE status=2 AND paid_at>=?', [$today0]),
    'all'   => (int)val('SELECT COALESCE(SUM(coin),0) FROM recharge_orders WHERE status=2'),
];

/* ---------- 设置当前值 ---------- */
$cfg = [
    'address' => (string)setting('usdt_address', ''),
    'network' => (string)setting('usdt_network', 'TRC20'),
    'rate'    => (int)setting('usdt_rate', '7'),
    'min'     => (int)setting('usdt_min_coin', '10'),
    'auto'    => (string)setting('usdt_auto_check', '1') === '1',
    'key'     => (string)setting('usdt_trongrid_key', ''),
    'expire'  => (int)setting('usdt_expire', '1800'),
    'window'  => (int)setting('usdt_match_window', '86400'),
];

/* ---------- 详情数据 ---------- */
$jsRows = [];
foreach ($rows as $r) {
    $jsRows[(int)$r['id']] = [
        'order_no' => (string)$r['order_no'],
        'account'  => (string)($r['account'] ?? ''),
        'nickname' => (string)($r['nickname'] ?? ''),
        'coin'     => (int)$r['coin'],
        'rate'     => (int)$r['rate'],
        'usdt'     => (string)$r['amount_usdt'],
        'network'  => (string)$r['network'],
        'address'  => (string)$r['address'],
        'status'   => (int)$r['status'],
        'txid'     => (string)($r['pay_tx'] !== '' ? $r['pay_tx'] : $r['txid']),
        'txid_own' => (string)$r['txid'],
        'remark'   => (string)$r['remark'],
        'created'  => (int)$r['created_at'],
        'paid'     => (int)$r['paid_at'],
        'admin_id' => (int)$r['admin_id'],
    ];
}

$flash = rch_flash();
$title = '充值 / USDT';
admin_head($title, 'recharge');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat"><div class="st-ico">⏳</div><div class="st-label">待审核</div><div class="st-value"><?= number_format($sumStat['wait']) ?></div><div class="st-sub">用户已提交，等待核对</div></div>
  <div class="adm-stat orange"><div class="st-ico">💤</div><div class="st-label">待支付</div><div class="st-value"><?= number_format($sumStat['unpay']) ?></div><div class="st-sub">下单未转账</div></div>
  <div class="adm-stat blue"><div class="st-ico">📈</div><div class="st-label">今日到账</div><div class="st-value"><?= number_format($sumStat['today']) ?></div><div class="st-sub">CC币</div></div>
  <div class="adm-stat"><div class="st-ico">💰</div><div class="st-label">累计到账</div><div class="st-value"><?= number_format($sumStat['all']) ?></div><div class="st-sub">CC币</div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>USDT 收款设置<span class="sub">前台充值页即时生效</span></h2>
    <span class="tag <?= $cfg['auto'] ? 'green' : 'gray' ?>">自动核对 <?= $cfg['auto'] ? '已开启' : '已关闭' ?></span>
  </div>
  <div class="adm-panel-body">
    <form method="post" class="adm-form" autocomplete="off">
      <input type="hidden" name="act" value="settings">
      <div class="adm-field full">
        <label>收款地址</label>
        <input class="adm-input" name="usdt_address" value="<?= e($cfg['address']) ?>" placeholder="<?= $cfg['network'] === 'ERC20' ? '0x...' : 'T...' ?>">
        <div class="adm-hint">TRC20 为 T 开头 34 位；ERC20 为 0x 开头 42 位。前台下单时取该地址。</div>
      </div>
      <div class="adm-field">
        <label>网络</label>
        <select class="adm-select" name="usdt_network">
          <option value="TRC20" <?= $cfg['network'] === 'TRC20' ? 'selected' : '' ?>>TRC20（波场）</option>
          <option value="ERC20" <?= $cfg['network'] === 'ERC20' ? 'selected' : '' ?>>ERC20（以太坊）</option>
        </select>
      </div>
      <div class="adm-field">
        <label>汇率（1 USDT = N CC币）</label>
        <input class="adm-input" type="number" min="1" max="100000" name="usdt_rate" value="<?= (int)$cfg['rate'] ?>">
      </div>
      <div class="adm-field">
        <label>最低充值（CC币）</label>
        <input class="adm-input" type="number" min="1" name="usdt_min_coin" value="<?= (int)$cfg['min'] ?>">
      </div>
      <div class="adm-field">
        <label>订单过期（秒）</label>
        <input class="adm-input" type="number" min="60" max="604800" name="usdt_expire" value="<?= (int)$cfg['expire'] ?>">
        <div class="adm-hint">超时未支付的 USDT 订单自动标记为已过期（客服单除外）。</div>
      </div>
      <div class="adm-field">
        <label>链上匹配时间窗（秒）</label>
        <input class="adm-input" type="number" min="60" max="604800" name="usdt_match_window" value="<?= (int)$cfg['window'] ?>">
        <div class="adm-hint">自动核对时向前追溯的区块时间范围，默认 86400。</div>
      </div>
      <div class="adm-field">
        <label>TronGrid API Key</label>
        <input class="adm-input" name="usdt_trongrid_key" value="<?= e($cfg['key']) ?>" placeholder="可留空，留空则用公共节点">
      </div>
      <div class="adm-field">
        <label>自动链上核对</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="usdt_auto_check" value="1" <?= $cfg['auto'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">关闭后全部转人工审核</span>
        </div>
      </div>
      <div class="adm-field full" style="display:flex;gap:10px;align-items:center">
        <button class="adm-btn" type="submit">保存设置</button>
        <span class="adm-hint" style="margin:0">保存后写入 admin_logs</span>
      </div>
    </form>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>充值订单<span class="sub">共 <?= number_format($total) ?> 条</span></h2>
    <div class="adm-toolbar">
      <button class="adm-btn ghost sm" onclick="rchMakeup()">＋ 补单</button>
      <a class="adm-btn ghost sm" href="<?= e($baseUrl) ?>export=1">导出 CSV</a>
    </div>
  </div>
  <div class="adm-panel-body" style="padding-bottom:0">
    <form method="get" class="adm-toolbar" style="margin-bottom:14px">
      <select class="adm-select" name="status">
        <option value="">全部状态</option>
        <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>待支付</option>
        <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>待审核</option>
        <option value="2" <?= $fStatus === '2' ? 'selected' : '' ?>>已到账</option>
        <option value="3" <?= $fStatus === '3' ? 'selected' : '' ?>>已拒绝</option>
        <option value="4" <?= $fStatus === '4' ? 'selected' : '' ?>>已过期</option>
      </select>
      <select class="adm-select" name="network">
        <option value="">全部网络</option>
        <?php foreach ($netList as $n): ?>
          <option value="<?= e($n) ?>" <?= $fNet === $n ? 'selected' : '' ?>><?= e($n) ?></option>
        <?php endforeach; ?>
      </select>
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="订单号 / CC号 / 昵称 / TXID" style="min-width:200px">
      <input class="adm-input" type="date" name="d1" value="<?= e($d1) ?>">
      <input class="adm-input" type="date" name="d2" value="<?= e($d2) ?>">
      <button class="adm-btn" type="submit">筛选</button>
      <a class="adm-btn ghost" href="recharge.php">重置</a>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr>
          <th>订单号</th><th>用户</th><th>CC币</th><th>USDT</th><th>网络</th><th>状态</th><th>TXID</th><th>创建时间</th><th style="width:210px">操作</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="9"><div class="adm-empty">没有符合条件的充值订单</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <?php
        $st = rch_status((int)$r['status']);
        if ((string)$r['network'] === '客服' && (int)$r['status'] === 0) $st = ['待确认', 'orange'];
        $txid = (string)($r['pay_tx'] !== '' ? $r['pay_tx'] : $r['txid']);
        ?>
        <tr>
          <td><span class="nm"><?= e((string)$r['order_no']) ?></span><div class="sub">#<?= (int)$r['id'] ?></div></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if (!empty($r['avatar'])): ?><img src="../<?= e(ltrim((string)$r['avatar'], '/')) ?>" alt=""><?php else: ?><?= e(mb_substr((string)($r['nickname'] ?: $r['account'] ?? '?'), 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e((string)($r['nickname'] ?? '未知用户')) ?></div>
                <div class="sub">CC <?= e((string)($r['account'] ?? '-')) ?></div>
              </div>
            </div>
          </td>
          <td class="num"><?= number_format((int)$r['coin']) ?></td>
          <td class="num"><?= $r['network'] === '客服' || $r['network'] === '补单' ? '-' : e(number_format((float)$r['amount_usdt'], 2, '.', '')) ?></td>
          <td><span class="tag <?= $r['network'] === 'TRC20' ? 'blue' : ($r['network'] === 'ERC20' ? 'purple' : 'gray') ?>"><?= e((string)$r['network']) ?></span></td>
          <td><span class="tag <?= $st[1] ?>"><?= e($st[0]) ?></span></td>
          <td>
            <?php if ($txid !== ''): ?>
              <div style="display:flex;align-items:center;gap:6px">
                <span title="<?= e($txid) ?>" style="font-family:ui-monospace,monospace;font-size:11px"><?= e(mb_substr($txid, 0, 10)) ?>…</span>
                <button class="adm-btn sm ghost" data-copy="<?= e($txid) ?>" style="height:22px;padding:0 7px;font-size:11px">复制</button>
              </div>
            <?php else: ?>
              <span class="sub">-</span>
            <?php endif; ?>
          </td>
          <td><span class="sub"><?= e(date('m-d H:i', (int)$r['created_at'])) ?></span></td>
          <td>
            <div class="actions">
              <?php if ((int)$r['status'] !== 2): ?>
                <button class="adm-btn sm" onclick="rchPass(<?= (int)$r['id'] ?>, <?= (int)$r['coin'] ?>, <?= json_encode((string)$r['order_no'], JSON_UNESCAPED_UNICODE) ?>)">通过</button>
                <button class="adm-btn sm danger" onclick="rchReject(<?= (int)$r['id'] ?>)">拒绝</button>
              <?php endif; ?>
              <button class="adm-btn sm ghost" onclick="rchDetail(<?= (int)$r['id'] ?>)">详情</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>

<script>
var RCH_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var RCH_ST = {0:['待支付','gray'],1:['待审核','orange'],2:['已到账','green'],3:['已拒绝','red'],4:['已过期','gray']};
document.addEventListener('click', function (ev) {
  var b = ev.target.closest ? ev.target.closest('[data-copy]') : null;
  if (b) { ADM.copy(b.getAttribute('data-copy')); }
});
function rchPass(id, coin, no) {
  ADM.confirm({title:'手动通过订单', ok:'确认入账', html:'<p style="margin:0 0 8px;color:#6B7280">订单 <b>' + ADM.esc(no) + '</b></p><p style="margin:0;color:#111827">将为该用户增加 <b style="color:#07C160">' + ADM.money(coin) + '</b> CC币，且不可撤销。</p>'})
    .then(function (yes) { if (yes) ADM.postForm('pass', {id: id}); });
}
function rchReject(id) {
  ADM.modal({title:'拒绝订单 #' + id, html:'<div class="adm-field"><label>拒绝原因（会展示给用户）</label><input class="adm-input" id="rj-remark" value="未查询到对应转账" style="width:100%"></div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn danger" id="rj-ok">确认拒绝</button>',
    onOpen:function () {
      document.getElementById('rj-ok').onclick = function () {
        ADM.postForm('reject', {id: id, remark: document.getElementById('rj-remark').value});
      };
    }});
}
function rchMakeup() {
  ADM.modal({title:'补单 / 手动加币', html:
    '<div class="adm-field" style="margin-bottom:12px"><label>用户 CC号 / 账号 / 靓号</label><input class="adm-input" id="mk-acc" placeholder="例如 740999800" style="width:100%"></div>' +
    '<div class="adm-field" style="margin-bottom:12px"><label>CC币数量</label><input class="adm-input" type="number" min="1" id="mk-coin" value="100" style="width:100%"></div>' +
    '<div class="adm-field"><label>备注</label><input class="adm-input" id="mk-remark" placeholder="补单原因 / 客服单号" style="width:100%"></div>' +
    '<div class="adm-hint">会生成一条「已到账」订单便于对账，资金流水记为 manual_recharge。</div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="mk-ok">确认加币</button>',
    onOpen:function () {
      document.getElementById('mk-ok').onclick = function () {
        var acc = document.getElementById('mk-acc').value.trim();
        var coin = parseInt(document.getElementById('mk-coin').value, 10) || 0;
        if (!acc) { ADM.toast('请输入用户 CC号'); return; }
        if (coin <= 0) { ADM.toast('CC币数量有误'); return; }
        ADM.postForm('makeup', {account: acc, coin: coin, remark: document.getElementById('mk-remark').value});
      };
    }});
}
function rchDetail(id) {
  var r = RCH_ROWS[id];
  if (!r) return;
  var st = RCH_ST[r.status] || ['未知', 'gray'];
  var kv = [
    ['订单号', r.order_no], ['用户', r.account + ' / ' + (r.nickname || '-')],
    ['CC币', ADM.money(r.coin)], ['USDT 金额', r.usdt], ['汇率', r.rate ? ('1 USDT = ' + r.rate + ' CC币') : '-'],
    ['网络', r.network], ['收款地址', r.address || '-'],
    ['状态', '<span class="tag ' + st[1] + '">' + st[0] + '</span>'],
    ['TXID', r.txid || '-'], ['备注', r.remark || '-'],
    ['创建时间', r.created ? ADM.fmt(r.created) : '-'], ['到账时间', r.paid ? ADM.fmt(r.paid) : '-'],
    ['处理管理员', r.admin_id ? ('#' + r.admin_id) : '-']
  ];
  var html = '<table style="width:100%;font-size:13px;border-collapse:collapse">';
  kv.forEach(function (x) {
    html += '<tr><td style="color:#6B7280;padding:6px 0;width:96px;vertical-align:top">' + ADM.esc(x[0]) + '</td><td style="padding:6px 0;word-break:break-all">' + (x[0] === '状态' ? x[1] : ADM.esc(x[1])) + '</td></tr>';
  });
  html += '</table>';
  ADM.modal({title:'订单详情', html:html});
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
