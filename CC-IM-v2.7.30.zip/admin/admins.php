<?php
/**
 * CC商聊 - 后台：管理员管理（仅 super）
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function adm_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if ($a['role'] === 'super') return $a;
    http_response_code(403);
    admin_head('无权限', 'admins');
    echo '<div class="adm-panel"><div class="adm-empty">管理员管理仅超级管理员（super）可访问。</div></div>';
    admin_foot();
    exit;
}

function adm_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'admins.php'));
    exit;
}

function adm_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    adm_back();
}

function adm_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    adm_back();
}

function adm_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

function adm_role_name(string $r): string
{
    $map = ['super' => '超级管理员', 'ops' => '运营', 'finance' => '财务'];
    return $map[$r] ?? $r;
}

$admin = adm_allow();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            /* ---------- 新增管理员 ---------- */
            case 'add': {
                $username = trim((string)($_POST['username'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                $role = trim((string)($_POST['role'] ?? 'ops'));
                if (!preg_match('/^[0-9A-Za-z_]{3,32}$/', $username)) adm_err('用户名需为 3-32 位字母、数字或下划线');
                if (mb_strlen($password) < 6) adm_err('密码至少 6 位');
                if (!in_array($role, ['super', 'ops', 'finance'], true)) adm_err('角色不合法');
                if (val('SELECT id FROM admins WHERE username=?', [$username])) adm_err('该用户名已存在');
                q('INSERT INTO admins (username,password,role,status,last_login_at,last_ip,created_at) VALUES (?,?,?,0,0,?,?)', [
                    $username, password_hash($password, PASSWORD_DEFAULT), $role, '', now(),
                ]);
                $nid = last_id();
                admin_log('新增管理员', '#' . $nid . ' ' . $username . ' / ' . $role);
                adm_done('管理员 ' . $username . ' 已创建');
                break;
            }

            /* ---------- 修改密码 ---------- */
            case 'passwd': {
                $id = (int)($_POST['id'] ?? 0);
                $password = (string)($_POST['password'] ?? '');
                $t = one('SELECT * FROM admins WHERE id=?', [$id]);
                if (!$t) adm_err('管理员不存在');
                if (mb_strlen($password) < 6) adm_err('密码至少 6 位');
                if (mb_strlen($password) > 72) adm_err('密码不能超过 72 位');
                q('UPDATE admins SET password=? WHERE id=?', [password_hash($password, PASSWORD_DEFAULT), $id]);
                admin_log('修改管理员密码', '#' . $id . ' ' . $t['username']);
                adm_done('已重置 ' . $t['username'] . ' 的密码');
                break;
            }

            /* ---------- 启用 / 禁用 ---------- */
            case 'toggle': {
                $id = (int)($_POST['id'] ?? 0);
                $t = one('SELECT * FROM admins WHERE id=?', [$id]);
                if (!$t) adm_err('管理员不存在');
                if ($id === (int)$admin['id']) adm_err('不能禁用当前登录的账号');
                $v = (int)$t['status'] === 0 ? 1 : 0;
                if ($v === 1 && $t['role'] === 'super') {
                    $supers = (int)val('SELECT COUNT(*) FROM admins WHERE role=? AND status=0 AND id<>?', ['super', $id]);
                    if ($supers < 1) adm_err('至少需要保留一个可用的超级管理员');
                }
                q('UPDATE admins SET status=? WHERE id=?', [$v, $id]);
                admin_log('管理员状态', '#' . $id . ' ' . $t['username'] . ' → ' . ($v === 0 ? '启用' : '禁用'));
                adm_done($v === 0 ? '已启用' : '已禁用');
                break;
            }

            /* ---------- 删除 ---------- */
            case 'del': {
                $id = (int)($_POST['id'] ?? 0);
                $t = one('SELECT * FROM admins WHERE id=?', [$id]);
                if (!$t) adm_err('管理员不存在');
                if ($id === (int)$admin['id']) adm_err('不能删除当前登录的账号');
                if ($t['role'] === 'super') {
                    $supers = (int)val('SELECT COUNT(*) FROM admins WHERE role=? AND id<>?', ['super', $id]);
                    if ($supers < 1) adm_err('至少需要保留一个超级管理员');
                }
                q('DELETE FROM admins WHERE id=?', [$id]);
                admin_log('删除管理员', '#' . $id . ' ' . $t['username']);
                adm_done('管理员 ' . $t['username'] . ' 已删除');
                break;
            }

            default:
                adm_err('未知操作');
        }
    } catch (Throwable $e) {
        adm_err('操作失败：' . $e->getMessage());
    }
}

$rows = all('SELECT * FROM admins ORDER BY id ASC');
$jsRows = [];
foreach ($rows as $r) {
    $jsRows[(int)$r['id']] = [
        'username' => (string)$r['username'],
        'role'     => (string)$r['role'],
        'status'   => (int)$r['status'],
        'self'     => (int)$r['id'] === (int)$admin['id'] ? 1 : 0,
    ];
}

$flash = adm_flash();
$title = '管理员';
admin_head($title, 'admins');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat"><div class="st-ico">🔑</div><div class="st-label">管理员总数</div><div class="st-value"><?= number_format(count($rows)) ?></div><div class="st-sub">含超级管理员</div></div>
  <div class="adm-stat blue"><div class="st-ico">✅</div><div class="st-label">启用中</div><div class="st-value"><?= number_format((int)val('SELECT COUNT(*) FROM admins WHERE status=0')) ?></div><div class="st-sub">可正常登录</div></div>
  <div class="adm-stat gray" style="background:#fff"><div class="st-ico">🚫</div><div class="st-label">已禁用</div><div class="st-value"><?= number_format((int)val('SELECT COUNT(*) FROM admins WHERE status=1')) ?></div><div class="st-sub">无法登录</div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>管理员列表</h2>
    <button class="adm-btn sm" onclick="admAdd()">＋ 新增管理员</button>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead><tr><th style="width:52px">ID</th><th>用户名</th><th>角色</th><th>状态</th><th>最后登录</th><th>登录 IP</th><th style="width:250px">操作</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <?php $isSelf = (int)$r['id'] === (int)$admin['id']; ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td>
            <div class="nm"><?= e((string)$r['username']) ?><?= $isSelf ? ' <span class="tag blue" style="margin-left:6px">当前账号</span>' : '' ?></div>
          </td>
          <td><span class="tag <?= $r['role'] === 'super' ? 'purple' : ($r['role'] === 'finance' ? 'green' : 'blue') ?>"><?= e(adm_role_name((string)$r['role'])) ?></span></td>
          <td><span class="tag <?= (int)$r['status'] === 0 ? 'green' : 'red' ?>"><?= (int)$r['status'] === 0 ? '启用' : '已禁用' ?></span></td>
          <td><span class="sub"><?= (int)$r['last_login_at'] > 0 ? e(date('Y-m-d H:i', (int)$r['last_login_at'])) : '从未登录' ?></span></td>
          <td><span class="sub" style="font-family:ui-monospace,monospace"><?= e((string)$r['last_ip']) ?: '-' ?></span></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" onclick="admPwd(<?= (int)$r['id'] ?>)">改密码</button>
              <?php if (!$isSelf): ?>
                <button class="adm-btn sm <?= (int)$r['status'] === 0 ? 'orange' : '' ?>" onclick="admAct('toggle', <?= (int)$r['id'] ?>)"><?= (int)$r['status'] === 0 ? '禁用' : '启用' ?></button>
                <button class="adm-btn sm danger" onclick="admDel(<?= (int)$r['id'] ?>)">删除</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-body">
    <div class="adm-hint" style="margin:0;line-height:1.9">
      角色权限：<b>super</b> 全部功能（含系统设置、管理员管理）；<b>ops</b> 用户 / 群组 / 内容 / 公告 / 申诉；<b>finance</b> 充值 / 提现 / 资金流水。<br>
      所有写操作均记录到 admin_logs，密码不会写入日志。
    </div>
  </div>
</div>

<script>
var ADM_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
function admAct(act, id) {
  var r = ADM_ROWS[id] || {};
  var label = r.status === 0 ? '禁用' : '启用';
  ADM.confirm({title: label + '管理员', text: '确认' + label + '账号「' + (r.username || '') + '」？', ok: '确认', danger: r.status === 0})
    .then(function (y) { if (y) ADM.postForm(act, {id:id}); });
}
function admDel(id) {
  var r = ADM_ROWS[id] || {};
  ADM.confirm({title:'删除管理员', danger:true, ok:'删除', html:'<p style="margin:0;color:#6B7280">确认删除 <b style="color:#111827">' + ADM.esc(r.username || '') + '</b> ？该账号将立即失去后台访问权限。</p>'})
    .then(function (y) { if (y) ADM.postForm('del', {id:id}); });
}
function admPwd(id) {
  var r = ADM_ROWS[id] || {};
  ADM.modal({title:'修改密码 · ' + (r.username || ''), html:
    '<div class="adm-field" style="margin-bottom:12px"><label>新密码（至少 6 位）</label><input class="adm-input" type="password" id="ap-pwd" style="width:100%" autocomplete="new-password"></div>' +
    '<div class="adm-field"><label>确认新密码</label><input class="adm-input" type="password" id="ap-pwd2" style="width:100%" autocomplete="new-password"></div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="ap-ok">确认修改</button>',
    onOpen:function () {
      document.getElementById('ap-ok').onclick = function () {
        var p1 = document.getElementById('ap-pwd').value;
        var p2 = document.getElementById('ap-pwd2').value;
        if (p1.length < 6) { ADM.toast('密码至少 6 位'); return; }
        if (p1 !== p2) { ADM.toast('两次密码不一致'); return; }
        ADM.postForm('passwd', {id:id, password:p1});
      };
    }});
}
function admAdd() {
  ADM.modal({title:'新增管理员', html:
    '<div class="adm-field" style="margin-bottom:12px"><label>用户名</label><input class="adm-input" id="aa-user" style="width:100%" autocomplete="off" placeholder="3-32 位字母、数字或下划线"></div>' +
    '<div class="adm-field" style="margin-bottom:12px"><label>密码</label><input class="adm-input" type="password" id="aa-pwd" style="width:100%" autocomplete="new-password" placeholder="至少 6 位"></div>' +
    '<div class="adm-field"><label>角色</label><select class="adm-select" id="aa-role" style="width:100%">' +
      '<option value="ops">运营（用户 / 群组 / 内容）</option>' +
      '<option value="finance">财务（充值 / 提现 / 流水）</option>' +
      '<option value="super">超级管理员（全部权限）</option>' +
    '</select></div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn" id="aa-ok">创建</button>',
    onOpen:function () {
      document.getElementById('aa-ok').onclick = function () {
        var u = document.getElementById('aa-user').value.trim();
        var p = document.getElementById('aa-pwd').value;
        if (!/^[0-9A-Za-z_]{3,32}$/.test(u)) { ADM.toast('用户名格式不正确'); return; }
        if (p.length < 6) { ADM.toast('密码至少 6 位'); return; }
        ADM.postForm('add', {username:u, password:p, role:document.getElementById('aa-role').value});
      };
    }});
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
