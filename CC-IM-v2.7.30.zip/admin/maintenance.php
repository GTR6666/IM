<?php
/**
 * CC商聊 - 数据维护（清理工具）
 * 仅超级管理员可用。所有操作不可恢复。
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (($admin['role'] ?? '') !== 'super') {
    admin_head('数据维护', 'maintenance');
    echo '<div class="adm-empty">仅超级管理员（super）可访问。</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;

/** 统计各表行数（不存在则 0） */
function mt_count(string $table): int
{
    try { return (int)val('SELECT COUNT(*) FROM ' . $table); } catch (Throwable $e) { return 0; }
}

/** 清空指定表，返回删除行数 */
function mt_clear(array $tables, array &$detail): int
{
    $total = 0;
    $pdo = db();
    foreach ($tables as $t) {
        try {
            $n = (int)val('SELECT COUNT(*) FROM ' . $t);
            if ($n <= 0) { $detail[$t] = 0; continue; }
            $pdo->exec('DELETE FROM ' . $t);
            $detail[$t] = $n;
            $total += $n;
        } catch (Throwable $e) {
            $detail[$t] = 0;
        }
    }
    return $total;
}

/** 清理上传文件（保留目录结构），返回删除数量 */
function mt_clear_uploads(): int
{
    $root = CC_ROOT . '/uploads';
    if (!is_dir($root)) return 0;
    $n = 0;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) {
        if ($f->isFile()) {
            $name = $f->getFilename();
            if ($name === '.htaccess' || $name === '.gitkeep') continue;
            if (@unlink($f->getPathname())) $n++;
        }
    }
    return $n;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    $detail = [];
    try {
        switch ($act) {
            /* ---------- 1. 清理聊天内容 ---------- */
            case 'purge_chat': {
                $total = mt_clear(['messages', 'conversations', 'call_signals', 'live_messages',
                                   'favorites', 'red_packet_records'], $detail);
                $files = mt_clear_uploads();
                admin_log('purge_chat', '清理聊天内容 ' . $total . ' 条，文件 ' . $files . ' 个');
                $msg = '已清理聊天内容：' . $total . ' 条记录，' . $files . ' 个上传文件';
                break;
            }
            /* ---------- 2. 清理日志 ---------- */
            case 'purge_logs': {
                $total = mt_clear(['admin_logs', 'login_logs', 'call_signals', 'verify_codes'], $detail);
                // 清空日志后再记一条，便于追溯
                admin_log('purge_logs', '清理系统日志 ' . $total . ' 条');
                $msg = '已清理系统日志：' . $total . ' 条';
                break;
            }
            /* ---------- 3. 清理动态（朋友圈） ---------- */
            case 'purge_moments': {
                $total = mt_clear(['moment_comments', 'moment_likes', 'moment_reads', 'moment'], $detail);
                admin_log('purge_moments', '清理动态 ' . $total . ' 条');
                $msg = '已清理朋友圈数据：' . $total . ' 条';
                break;
            }
            /* ---------- 4. 清理资金流水（保留账户余额） ---------- */
            case 'purge_wallet': {
                $total = mt_clear(['wallet_logs', 'recharge_orders', 'withdraw_orders', 'transfers',
                                   'red_packets', 'gift_records'], $detail);
                admin_log('purge_wallet', '清理资金流水 ' . $total . ' 条');
                $msg = '已清理资金流水：' . $total . ' 条（用户余额不变）';
                break;
            }
            /* ---------- 5. 一键清空全部数据（危险） ---------- */
            case 'purge_all': {
                $confirm = trim((string)($_POST['confirm_text'] ?? ''));
                if ($confirm !== '确认清空') throw new RuntimeException('请输入「确认清空」四个字以确认操作');
                $keepOfficial = (int)($_POST['keep_official'] ?? 0) === 1;
                $pdo = db();
                $pdo->beginTransaction();
                try {
                    $svcUid = (int)val("SELECT v FROM settings WHERE k='service_uid'");
                    $keepUids = [];
                    if ($keepOfficial) {
                        foreach (all("SELECT id FROM users WHERE account IN (?, ?)", [
                            (string)setting('service_uid', '10086'), '990375'
                        ]) as $r) { $keepUids[] = (int)$r['id']; }
                    }
                    // 群相关
                    $total = mt_clear(['group_pins', 'group_bans', 'group_notices', 'group_join_requests',
                                       'group_members', 'groups'], $detail);
                    // 聊天相关
                    $total += mt_clear(['messages', 'conversations', 'call_signals', 'live_messages',
                                        'live_rooms', 'favorites', 'red_packet_records', 'red_packets',
                                        'transfers', 'gift_records', 'calls'], $detail);
                    // 社交关系
                    $total += mt_clear(['friends', 'friend_requests', 'blocks', 'invites', 'invite_claims'], $detail);
                    // 内容
                    $total += mt_clear(['moment_comments', 'moment_likes', 'moment_reads', 'moment',
                                        'reports', 'appeals', 'notice_reads'], $detail);
                    // 资金
                    $total += mt_clear(['wallet_logs', 'recharge_orders', 'withdraw_orders', 'devices', 'login_logs'], $detail);
                    // 用户（可保留官方账号）
                    $users = all('SELECT id FROM users');
                    $delUsers = 0;
                    foreach ($users as $u) {
                        $id = (int)$u['id'];
                        if ($keepUids && in_array($id, $keepUids, true)) continue;
                        q('DELETE FROM users WHERE id=?', [$id]);
                        $delUsers++;
                    }
                    $detail['users'] = $delUsers;
                    $total += $delUsers;
                    // 客服账号若已被删，清空设置避免指向不存在的用户
                    if (in_array($svcUid, $keepUids, true) === false && !one('SELECT id FROM users WHERE id=?', [$svcUid])) {
                        q("UPDATE settings SET v='' WHERE k='service_uid'");
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    $pdo->rollBack();
                    throw $e;
                }
                $files = mt_clear_uploads();
                admin_log('purge_all', '一键清空全部数据 ' . $total . ' 条，文件 ' . $files . ' 个');
                $msg = '已清空全部数据：删除 ' . $total . ' 条记录（含 ' . (int)($detail['users'] ?? 0) . ' 个用户），'
                     . $files . ' 个上传文件。管理员账号与系统设置保留。';
                break;
            }
            default:
                $msg = '未知操作';
                $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 当前数据量 ---------- */
$stat = [
    '用户'       => mt_count('users'),
    '群聊'       => mt_count('groups'),
    '群成员'     => mt_count('group_members'),
    '消息'       => mt_count('messages'),
    '会话'       => mt_count('conversations'),
    '朋友圈'     => mt_count('moment'),
    '评论/赞'    => mt_count('moment_comments') + mt_count('moment_likes'),
    '好友关系'   => mt_count('friends'),
    '资金流水'   => mt_count('wallet_logs'),
    '充值单'     => mt_count('recharge_orders'),
    '提现单'     => mt_count('withdraw_orders'),
    '操作日志'   => mt_count('admin_logs'),
    '登录日志'   => mt_count('login_logs'),
];
$uploads = 0;
$bytes = 0;
$upRoot = CC_ROOT . '/uploads';
if (is_dir($upRoot)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($upRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if ($f->isFile() && $f->getFilename() !== '.htaccess' && $f->getFilename() !== '.gitkeep') {
            $uploads++;
            $bytes += (int)$f->getSize();
        }
    }
}

$title = '数据维护';
admin_head($title, 'maintenance');
?>
<?php if ($msg !== ''): ?>
<script>window.__admFlash = <?= json_encode($msg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <?php foreach ($stat as $k => $v): ?>
  <div class="adm-stat"><div class="st-label"><?= e($k) ?></div><div class="st-value"><?= number_format($v) ?></div></div>
  <?php endforeach; ?>
  <div class="adm-stat"><div class="st-label">上传文件</div><div class="st-value"><?= number_format($uploads) ?></div>
    <div class="st-sub"><?= $bytes > 1048576 ? round($bytes / 1048576, 1) . ' MB' : round($bytes / 1024) . ' KB' ?></div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head"><h2>清理工具</h2><span class="sub">释放空间、解决数据过多导致的卡顿</span></div>
  <div class="adm-panel-body">
    <div class="mnt-grid">
      <div class="mnt-card">
        <div class="mnt-t">清理聊天内容</div>
        <div class="mnt-d">删除全部会话、消息、通话信令、收藏、红包领取记录，以及 uploads 下的图片/语音/文件。用户与群聊保留。</div>
        <button class="adm-btn danger" onclick="mtRun('purge_chat','清理聊天内容','将删除所有会话与消息（用户、群聊保留），不可恢复。')">立即清理</button>
      </div>
      <div class="mnt-card">
        <div class="mnt-t">清理系统日志</div>
        <div class="mnt-d">删除操作日志、登录日志、验证码记录、通话信令。</div>
        <button class="adm-btn danger" onclick="mtRun('purge_logs','清理系统日志','将删除所有操作日志与登录日志，不可恢复。')">立即清理</button>
      </div>
      <div class="mnt-card">
        <div class="mnt-t">清理朋友圈</div>
        <div class="mnt-d">删除全部动态、点赞、评论与已读记录。</div>
        <button class="adm-btn danger" onclick="mtRun('purge_moments','清理朋友圈','将删除所有动态、点赞与评论，不可恢复。')">立即清理</button>
      </div>
      <div class="mnt-card">
        <div class="mnt-t">清理资金流水</div>
        <div class="mnt-d">删除流水、充值单、提现单、转账、红包、礼物记录。<b>用户余额不变。</b></div>
        <button class="adm-btn danger" onclick="mtRun('purge_wallet','清理资金流水','将删除所有资金流水与订单（余额不变），不可恢复。')">立即清理</button>
      </div>
    </div>
  </div>
</div>

<div class="adm-panel" style="border:1.5px solid #FBD5D5">
  <div class="adm-panel-head"><h2 style="color:#B91C1C">一键清空全部数据</h2><span class="sub">危险操作 · 不可恢复</span></div>
  <div class="adm-panel-body">
    <div style="background:#FEF2F2;border:1px solid #FBD5D5;border-radius:10px;padding:14px 16px;color:#B91C1C;font-size:13px;line-height:1.9">
      <b>将永久删除：</b>所有用户、所有群聊及其成员/公告/封禁/置顶、全部消息与会话、朋友圈、好友关系、黑名单、邀请记录、资金流水与订单、设备与登录记录、以及 uploads 下的所有上传文件。<br>
      <b>将保留：</b>管理员账号（admins 表）、系统设置、会员套餐/礼物/靓号/表情等商品配置。
    </div>
    <div class="adm-field" style="margin-top:14px">
      <label>请输入「确认清空」四个字以启用按钮</label>
      <input class="adm-input" id="mtConfirm" placeholder="确认清空" autocomplete="off" oninput="mtCheck()">
    </div>
    <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#374151;margin-top:12px">
      <input type="checkbox" id="mtKeepOfficial" checked> 保留官方客服与机器人账号
    </label>
    <div style="margin-top:16px">
      <button class="adm-btn danger" id="mtAllBtn" disabled style="background:#7F1D1D" onclick="mtPurgeAll()">一键清空全部数据</button>
    </div>
  </div>
</div>

<style>
.mnt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.mnt-card{border:1px solid var(--line);border-radius:12px;padding:14px 16px;display:flex;flex-direction:column;gap:8px}
.mnt-t{font-size:14.5px;font-weight:600}
.mnt-d{font-size:12px;color:#6B7280;line-height:1.7;flex:1}
.mnt-card .adm-btn{align-self:flex-start}
</style>

<script>
function mtCheck(){
  var v = (document.getElementById('mtConfirm').value || '').trim();
  document.getElementById('mtAllBtn').disabled = v !== '确认清空';
}
function mtRun(act, title, text){
  ADM.confirm({title:title, text:text, danger:true, ok:'确认清理'}).then(function(y){
    if (!y) return;
    ADM.postForm(act, {});
  });
}
function mtPurgeAll(){
  var keep = document.getElementById('mtKeepOfficial').checked ? 1 : 0;
  ADM.confirm({
    title:'一键清空全部数据',
    html:'<div style="background:#FEF2F2;border:1px solid #FBD5D5;border-radius:10px;padding:12px 14px;color:#B91C1C;font-size:12.5px;line-height:1.8">'
       + '<b>最后确认：</b>所有用户、群聊、消息、动态、资金流水与上传文件都会被永久删除，无法恢复。</div>',
    danger:true, ok:'彻底清空'
  }).then(function(y){
    if (!y) return;
    ADM.postForm('purge_all', { confirm_text:'确认清空', keep_official: keep });
  });
}
</script>
<?php admin_foot(); ?>
