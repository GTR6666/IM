/* CC商聊 - 管理后台脚本 */
(function (w, d) {
  var A = w.ADM = w.ADM || {};
  A.toast = function (msg, ms) {
    var el = d.querySelector('.adm-toast');
    if (!el) { el = d.createElement('div'); el.className = 'adm-toast'; d.body.appendChild(el); }
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.classList.remove('show'); }, ms || 2200);
  };
  A.post = function (url, data) {
    var fd = new FormData();
    Object.keys(data || {}).forEach(function (k) {
      var v = data[k];
      if (v === undefined || v === null) return;
      fd.append(k, typeof v === 'object' ? JSON.stringify(v) : v);
    });
    return fetch(url, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); });
  };
  A.get = function (url) {
    return fetch(url, { credentials: 'same-origin', cache: 'no-store' }).then(function (r) { return r.json(); });
  };
  A.esc = function (s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };
  A.fmt = function (t) {
    t = parseInt(t, 10) || 0;
    if (!t) return '-';
    var x = new Date(t * 1000);
    function p(n) { return n < 10 ? '0' + n : n; }
    return x.getFullYear() + '-' + p(x.getMonth() + 1) + '-' + p(x.getDate()) + ' ' + p(x.getHours()) + ':' + p(x.getMinutes());
  };
  A.money = function (n) { return (parseInt(n, 10) || 0).toLocaleString('zh-CN'); };
  /* ---------- 会员标识（VIP / SVIP，与前台一致） ---------- */
  A.svipMin = function () {
    var v = parseInt(w.ADM_SVIP_MIN || 4, 10);
    return (v >= 2 && v <= 20) ? v : 4;
  };
  A.vipTier = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    return level >= A.svipMin() ? 'SVIP' : 'VIP';
  };
  A.vipLabel = function (level) {
    level = parseInt(level, 10) || 0;
    if (level <= 0) return '';
    var min = A.svipMin();
    if (level < min) return 'VIP' + level;
    var step = level - min + 1;
    return step <= 1 ? 'SVIP' : 'SVIP' + step;
  };
  A.confirm = function (opts) {
    return new Promise(function (res) {
      var mask = d.querySelector('.adm-mask');
      var modal = d.querySelector('.adm-modal');
      if (!mask) { mask = d.createElement('div'); mask.className = 'adm-mask'; d.body.appendChild(mask); }
      if (!modal) { modal = d.createElement('div'); modal.className = 'adm-modal'; d.body.appendChild(modal); }
      modal.innerHTML = '<div class="adm-modal-hd"><h3>' + A.esc(opts.title || '确认') + '</h3><button class="x" data-c="0">✕</button></div>' +
        '<div class="adm-modal-body">' + (opts.html || ('<p style="margin:0;color:#6B7280">' + A.esc(opts.text || '') + '</p>')) + '</div>' +
        '<div class="adm-modal-foot"><button class="adm-btn ghost" data-c="0">取消</button>' +
        '<button class="adm-btn ' + (opts.danger ? 'danger' : '') + '" data-c="1">' + A.esc(opts.ok || '确定') + '</button></div>';
      mask.classList.add('show'); modal.classList.add('show');
      function close(v) { mask.classList.remove('show'); modal.classList.remove('show'); res(v); }
      mask.onclick = function () { close(false); };
      modal.querySelectorAll('[data-c]').forEach(function (b) {
        b.onclick = function () { close(b.getAttribute('data-c') === '1'); };
      });
    });
  };
  A.modal = function (opts) {
    var mask = d.querySelector('.adm-mask');
    var modal = d.querySelector('.adm-modal');
    if (!mask) { mask = d.createElement('div'); mask.className = 'adm-mask'; d.body.appendChild(mask); }
    if (!modal) { modal = d.createElement('div'); modal.className = 'adm-modal'; d.body.appendChild(modal); }
    modal.innerHTML = '<div class="adm-modal-hd"><h3>' + A.esc(opts.title || '') + '</h3><button class="x">✕</button></div>' +
      '<div class="adm-modal-body">' + (opts.html || '') + '</div>' +
      (opts.footer === false ? '' : '<div class="adm-modal-foot">' + (opts.footer || '<button class="adm-btn ghost" data-close="1">关闭</button>') + '</div>');
    mask.classList.add('show'); modal.classList.add('show');
    function close() { mask.classList.remove('show'); modal.classList.remove('show'); if (opts.onClose) opts.onClose(); }
    modal.querySelector('.x').onclick = close;
    mask.onclick = close;
    modal.querySelectorAll('[data-close]').forEach(function (b) { b.onclick = close; });
    if (opts.onOpen) opts.onOpen(modal);
    return { el: modal, close: close };
  };
  A.copy = function (t) {
    if (navigator.clipboard) navigator.clipboard.writeText(t).then(function () { A.toast('已复制'); });
    else {
      var ta = d.createElement('textarea'); ta.value = t; d.body.appendChild(ta); ta.select();
      d.execCommand('copy'); ta.remove(); A.toast('已复制');
    }
  };
  /* ---------- 响应式侧边栏（移动端抽屉） ---------- */
  A.sidebar = (function () {
    var side = null, mask = null, timer = null;
    function el() { side = d.getElementById('admSide'); mask = d.getElementById('admSideMask'); }
    function open() {
      if (!side) el();
      if (!side) return;
      side.classList.add('open');
      if (mask) mask.classList.add('show');
      d.documentElement.style.overflow = 'hidden';
      d.body.style.overflow = 'hidden';
    }
    function close() {
      if (!side) el();
      if (!side) return;
      side.classList.remove('open');
      if (mask) mask.classList.remove('show');
      d.documentElement.style.overflow = '';
      d.body.style.overflow = '';
    }
    function toggle() { side && side.classList.contains('open') ? close() : open(); }
    function bind() {
      el();
      var btn = d.getElementById('admMenuBtn');
      var x = d.getElementById('admSideClose');
      if (btn) btn.onclick = toggle;
      if (x) x.onclick = close;
      if (mask) mask.onclick = close;
      // 点击导航项后自动收起
      if (side) side.querySelectorAll('.adm-nav-item').forEach(function (a) {
        a.addEventListener('click', function () { if (w.innerWidth <= 900) close(); });
      });
      // 窗口放大到桌面尺寸时复位
      w.addEventListener('resize', function () {
        clearTimeout(timer);
        timer = setTimeout(function () { if (w.innerWidth > 900) close(); }, 120);
      });
    }
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', bind);
    else bind();
    return { open: open, close: close, toggle: toggle };
  })();

  /* ---------- 小屏表格转卡片：自动补齐 data-label ---------- */
  (function () {
    function prepare() {
      d.querySelectorAll('table.adm-table').forEach(function (table) {
        var heads = [].map.call(table.querySelectorAll('thead th'), function (th) {
          return (th.textContent || '').trim();
        });
        if (!heads.length) return;
        // 标记可隐藏的次要列（ID / #），手机端不占位置
        var hideIdx = heads.map(function (h, i) { return (h === 'ID' || h === '#') ? i : -1; }).filter(function (i) { return i >= 0; });
        if (hideIdx.length) {
          [].forEach.call(table.querySelectorAll('thead th'), function (th, i) {
            if (hideIdx.indexOf(i) >= 0) th.classList.add('hide-sm');
          });
        }
        table.querySelectorAll('tbody tr').forEach(function (tr) {
          [].forEach.call(tr.children, function (td, i) {
            if (!td.hasAttribute('data-label')) {
              var label = heads[i] || '';
              if (label) td.setAttribute('data-label', label);
            }
            if (td.querySelector('.cell-user')) td.classList.add('cell-flex');
            if (hideIdx.indexOf(i) >= 0) td.classList.add('hide-sm');
          });
        });
      });
    }
    function run() {
      prepare();
      // 动态渲染（AJAX 刷新）后重新补齐
      var mo = new MutationObserver(function () {
        clearTimeout(run._t);
        run._t = setTimeout(prepare, 120);
      });
      d.querySelectorAll('table.adm-table').forEach(function (t) {
        mo.observe(t, { childList: true, subtree: true });
      });
    }
    if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', run);
    else run();
  })();

  A.postForm = function (action, data, reload) {
    return A.post(location.pathname, Object.assign({ ajax: 1, act: action }, data)).then(function (res) {
      if (res.code !== 0) { A.toast(res.msg || '操作失败'); throw new Error(res.msg); }
      A.toast(res.msg || '操作成功');
      if (reload !== false) setTimeout(function () { location.reload(); }, 450);
      return res.data;
    });
  };
})(window, document);
