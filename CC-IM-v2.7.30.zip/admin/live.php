<?php
/**
 * CC商聊 - 直播 / 通话记录
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'live');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;

/* ---------- 写操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'end_live') {
            $id = (int)($_POST['id'] ?? 0);
            $room = $id > 0 ? one('SELECT * FROM live_rooms WHERE id=?', [$id]) : null;
            if (!$room) throw new RuntimeException('直播间不存在');
            if ((int)$room['status'] === 1) throw new RuntimeException('该直播已结束');
            q('UPDATE live_rooms SET status=1, ended_at=? WHERE id=?', [now(), $id]);
            admin_log('end_live', 'room_id=' . $id . ' room_no=' . $room['room_no'] . ' uid=' . $room['uid'] . ' title=' . $room['title']);
            $msg = '已结束直播「' . $room['title'] . '」（房间 ' . $room['room_no'] . '）';
        } else {
            $msg = '未知操作';
            $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 统计 ---------- */
$todayStart = strtotime(date('Y-m-d'));
$todayEnd = $todayStart + 86400;
$liveNow = (int)val('SELECT COUNT(*) FROM live_rooms WHERE status=0');
$liveToday = (int)val('SELECT COUNT(*) FROM live_rooms WHERE created_at>=? AND created_at<?', [$todayStart, $todayEnd]);
$callToday = (int)val('SELECT COUNT(*) FROM calls WHERE created_at>=? AND created_at<?', [$todayStart, $todayEnd]);
$callDuration = (int)val('SELECT COALESCE(SUM(duration),0) FROM calls WHERE created_at>=? AND created_at<?', [$todayStart, $todayEnd]);

/* ---------- 直播列表 ---------- */
$lStatus = (string)($_GET['lstatus'] ?? '');
$lw = [];
$lp = [];
if ($lStatus === '0' || $lStatus === '1') {
    $lw[] = 'r.status=?';
    $lp[] = (int)$lStatus;
}
$lwhere = $lw ? ' WHERE ' . implode(' AND ', $lw) : '';
$liveRows = all('SELECT r.*, u.nickname, u.account, g.name AS group_name,
        (SELECT COUNT(*) FROM live_messages lm WHERE lm.room_id=r.id) AS msg_count
    FROM live_rooms r LEFT JOIN users u ON u.id=r.uid LEFT JOIN groups g ON g.gid=r.gid'
    . $lwhere . ' ORDER BY r.id DESC LIMIT 100', $lp);

/* ---------- 通话列表 ---------- */
$cMedia = (string)($_GET['cmedia'] ?? '');
$cStatus = (string)($_GET['cstatus'] ?? '');
$cw = [];
$cp = [];
if ($cMedia === '1' || $cMedia === '2') {
    $cw[] = 'c.media=?';
    $cp[] = (int)$cMedia;
}
if (in_array($cStatus, ['0', '1', '2', '3'], true)) {
    $cw[] = 'c.status=?';
    $cp[] = (int)$cStatus;
}
$cwhere = $cw ? ' WHERE ' . implode(' AND ', $cw) : '';
$callRows = all('SELECT c.*, f.nickname AS from_name, f.account AS from_account,
        t.nickname AS to_name, t.account AS to_account, g.name AS group_name
    FROM calls c LEFT JOIN users f ON f.id=c.from_uid LEFT JOIN users t ON t.id=c.to_uid
    LEFT JOIN groups g ON g.gid=c.gid' . $cwhere . ' ORDER BY c.id DESC LIMIT 100', $cp);

$postUrl = 'live.php?' . admin_qs();

function call_duration(int $sec): string
{
    if ($sec <= 0) return '-';
    $m = intdiv($sec, 60);
    $s = $sec % 60;
    if ($m >= 60) return intdiv($m, 60) . '时' . ($m % 60) . '分';
    return $m . '分' . $s . '秒';
}

admin_head('直播 / 通话', 'live');
?>
<?php if ($msg !== ''): ?>
<div class="adm-panel" style="border-left:4px solid <?= $msgOk ? '#07C160' : '#EF4444' ?>">
  <div class="adm-panel-body" style="padding:12px 18px;color:<?= $msgOk ? '#059669' : '#DC2626' ?>;font-size:13px"><?= e($msg) ?></div>
</div>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat red">
    <div class="st-label">正在直播</div>
    <div class="st-value"><?= admin_money($liveNow) ?></div>
    <div class="st-sub">status=0 的房间</div>
    <div class="st-ico">📡</div>
  </div>
  <div class="adm-stat">
    <div class="st-label">今日开播</div>
    <div class="st-value"><?= admin_money($liveToday) ?></div>
    <div class="st-sub">场次</div>
    <div class="st-ico">🎬</div>
  </div>
  <div class="adm-stat blue">
    <div class="st-label">今日通话</div>
    <div class="st-value"><?= admin_money($callToday) ?></div>
    <div class="st-sub">总时长 <?= e(call_duration($callDuration)) ?></div>
    <div class="st-ico">📞</div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>直播列表 <span class="sub">最近 100 场</span></h2>
    <form class="adm-toolbar" method="get" action="live.php">
      <select class="adm-select" name="lstatus">
        <option value="">全部状态</option>
        <option value="0" <?= $lStatus === '0' ? 'selected' : '' ?>>直播中</option>
        <option value="1" <?= $lStatus === '1' ? 'selected' : '' ?>>已结束</option>
      </select>
      <button class="adm-btn" type="submit">筛选</button>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>房间号</th><th>主播</th><th>标题</th><th>观看数</th><th>消息数</th><th>状态</th><th>开播时间</th><th>结束时间</th><th>操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$liveRows): ?>
        <tr><td colspan="9"><div class="adm-empty">暂无直播记录</div></td></tr>
      <?php endif; ?>
      <?php foreach ($liveRows as $r): ?>
        <?php $live = (int)$r['status'] === 0; ?>
        <tr>
          <td style="font-variant-numeric:tabular-nums;font-weight:600"><?= e($r['room_no']) ?></td>
          <td>
            <div class="nm"><?= e($r['nickname'] ?: ('UID ' . (int)$r['uid'])) ?></div>
            <div class="sub"><?= e((string)$r['account']) ?></div>
          </td>
          <td style="max-width:240px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($r['title'] ?: '（无标题）') ?></div>
            <?php if ((int)$r['gid'] > 0): ?><div class="sub">群 <?= e($r['group_name'] ?: (string)$r['gid']) ?></div><?php endif; ?>
          </td>
          <td class="num"><?= admin_money((int)$r['viewers']) ?></td>
          <td class="num"><?= admin_money((int)$r['msg_count']) ?></td>
          <td><span class="tag <?= $live ? 'red' : 'gray' ?>"><?= $live ? '直播中' : '已结束' ?></span></td>
          <td><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></td>
          <td><?= (int)$r['ended_at'] ? e(date('Y-m-d H:i', (int)$r['ended_at'])) : '-' ?></td>
          <td>
            <div class="actions">
              <?php if ($live): ?>
                <button class="adm-btn sm danger" type="button" onclick="endLive(<?= (int)$r['id'] ?>)">结束直播</button>
              <?php else: ?>
                <span class="adm-hint">已结束</span>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>通话记录 <span class="sub">最近 100 条</span></h2>
    <form class="adm-toolbar" method="get" action="live.php">
      <?php if ($lStatus !== ''): ?><input type="hidden" name="lstatus" value="<?= e($lStatus) ?>"><?php endif; ?>
      <select class="adm-select" name="cmedia">
        <option value="">全部类型</option>
        <option value="1" <?= $cMedia === '1' ? 'selected' : '' ?>>语音</option>
        <option value="2" <?= $cMedia === '2' ? 'selected' : '' ?>>视频</option>
      </select>
      <select class="adm-select" name="cstatus">
        <option value="">全部状态</option>
        <option value="0" <?= $cStatus === '0' ? 'selected' : '' ?>>呼叫中</option>
        <option value="1" <?= $cStatus === '1' ? 'selected' : '' ?>>已接通</option>
        <option value="2" <?= $cStatus === '2' ? 'selected' : '' ?>>已结束</option>
        <option value="3" <?= $cStatus === '3' ? 'selected' : '' ?>>已拒绝</option>
      </select>
      <button class="adm-btn" type="submit">筛选</button>
      <?php if ($cMedia !== '' || $cStatus !== '' || $lStatus !== ''): ?><a class="adm-btn ghost" href="live.php">重置</a><?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>call_id</th><th>主叫</th><th>被叫 / 群</th><th>类型</th><th>状态</th><th>时长</th><th>发起时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$callRows): ?>
        <tr><td colspan="7"><div class="adm-empty">暂无通话记录</div></td></tr>
      <?php endif; ?>
      <?php
      $callStatus = [0 => ['呼叫中', 'orange'], 1 => ['已接通', 'blue'], 2 => ['已结束', 'green'], 3 => ['已拒绝', 'red']];
      foreach ($callRows as $c):
          $cs = $callStatus[(int)$c['status']] ?? ['未知', 'gray'];
      ?>
        <tr>
          <td style="font-family:ui-monospace,Consolas,monospace;font-size:11.5px"><?= e($c['call_id']) ?></td>
          <td>
            <div class="nm"><?= e($c['from_name'] ?: ('UID ' . (int)$c['from_uid'])) ?></div>
            <div class="sub"><?= e((string)$c['from_account']) ?></div>
          </td>
          <td>
            <?php if ((int)$c['ctype'] === 2): ?>
              <div class="nm"><?= e($c['group_name'] ?: ('群 ' . (int)$c['gid'])) ?></div>
              <div class="sub">群通话 · <?= (int)$c['gid'] ?></div>
            <?php else: ?>
              <div class="nm"><?= e($c['to_name'] ?: ('UID ' . (int)$c['to_uid'])) ?></div>
              <div class="sub"><?= e((string)$c['to_account']) ?></div>
            <?php endif; ?>
          </td>
          <td><span class="tag <?= (int)$c['media'] === 2 ? 'purple' : 'blue' ?>"><?= (int)$c['media'] === 2 ? '视频' : '语音' ?></span></td>
          <td><span class="tag <?= $cs[1] ?>"><?= $cs[0] ?></span></td>
          <td><?= e(call_duration((int)$c['duration'])) ?></td>
          <td><?= e(date('Y-m-d H:i', (int)$c['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<form id="actForm" method="post" action="<?= e($postUrl) ?>" style="display:none">
  <input type="hidden" name="act" value="end_live">
  <input type="hidden" name="id" value="0">
</form>
<script>
function endLive(id) {
  ADM.confirm({ title: '结束直播', text: '结束后主播端将立即下播，确认结束该直播？', danger: true, ok: '结束直播' }).then(function (v) {
    if (!v) return;
    var f = document.getElementById('actForm');
    f.querySelector('input[name="id"]').value = id;
    f.submit();
  });
}
</script>
<?php
admin_foot();
