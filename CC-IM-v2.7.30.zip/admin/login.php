<?php
/**
 * CC商聊 - 后台登录
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

if (admin_current()) {
    header('Location: index.php');
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!rate_limit('adm_login:' . client_ip(), 10, 300)) {
        $err = '尝试过于频繁，请 5 分钟后再试';
    } else {
        $u = trim((string)($_POST['username'] ?? ''));
        $p = (string)($_POST['password'] ?? '');
        if ($u === '' || $p === '') {
            $err = '请输入账号和密码';
        } else {
            list($okv, $msg) = admin_login($u, $p);
            if ($okv) {
                header('Location: index.php');
                exit;
            }
            $err = $msg;
        }
    }
}
$site = setting('site_name', 'CC商聊');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>管理后台 · <?= e($site) ?></title>
<link rel="icon" href="../icons/icon-192.png">
<link rel="stylesheet" href="assets/admin.css?v=<?= CC_VERSION ?>">
</head>
<body class="adm-login-body">
<div class="adm-login-card">
  <div class="adm-login-logo">CC</div>
  <h1><?= e($site) ?> · 管理后台</h1>
  <p>请使用管理员账号登录</p>
  <div class="adm-login-err <?= $err ? 'show' : '' ?>" id="err"><?= e($err) ?></div>
  <form method="post" id="f">
    <div class="adm-login-field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#6B7590" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/></svg>
      <input name="username" id="username" type="text" placeholder="管理员账号" autocomplete="username" autofocus>
    </div>
    <div class="adm-login-field">
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#6B7590" stroke-width="1.9" stroke-linecap="round"><rect x="4" y="10.5" width="16" height="10" rx="2.4"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg>
      <input name="password" id="password" type="password" placeholder="登录密码" autocomplete="current-password">
    </div>
    <button class="adm-login-btn" id="btn" type="submit">登 录</button>
  </form>
  <div class="adm-login-foot">
    <span><span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#22C55E;margin-right:6px;vertical-align:1px"></span>系统运行正常</span>
    <a href="../index.php">返回前台</a>
  </div>
</div>
<script>
document.getElementById('f').addEventListener('submit', function(e){
  var u = document.getElementById('username').value.trim();
  var p = document.getElementById('password').value;
  if (!u || !p){ e.preventDefault(); var err = document.getElementById('err'); err.textContent = '请输入账号和密码'; err.classList.add('show'); return; }
  var b = document.getElementById('btn'); b.disabled = true; b.textContent = '登录中…';
});
</script>
</body>
</html>
