<?php
/**
 * CC商聊 - 后台：提现审核
 * 列表 / 通过 / 拒绝退回 / 已打款 / 收款码大图 / 筛选 / CSV
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

/* =========================================================
 * 权限与小工具
 * ========================================================= */
function wd_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'withdraw');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有提现审核权限。</div></div>';
    admin_foot();
    exit;
}

function wd_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'withdraw.php'));
    exit;
}

function wd_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    wd_back();
}

function wd_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    wd_back();
}

function wd_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

function wd_status(int $s): array
{
    $map = [
        0 => ['待审核', 'orange'],
        1 => ['已通过', 'blue'],
        2 => ['已拒绝', 'red'],
        3 => ['已打款', 'green'],
    ];
    return $map[$s] ?? ['未知', 'gray'];
}

function wd_day0(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 00:00:00');
    return $t ?: 0;
}

function wd_day1(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 23:59:59');
    return $t ?: 0;
}

function wd_img(string $u): string
{
    $u = trim($u);
    if ($u === '') return '';
    if (preg_match('#^https?://#i', $u)) return $u;
    return '../' . ltrim($u, '/');
}

$admin = wd_allow();

/* =========================================================
 * POST 写操作
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        switch ($act) {
            /* ---------- 通过：仅标记，不打款不扣币 ---------- */
            case 'pass': {
                $id = (int)($_POST['id'] ?? 0);
                $o = one('SELECT * FROM withdraw_orders WHERE id=?', [$id]);
                if (!$o) wd_err('订单不存在');
                if ((int)$o['status'] !== 0) wd_err('仅待审核订单可以标记通过');
                $aff = q('UPDATE withdraw_orders SET status=1, admin_id=?, handled_at=? WHERE id=? AND status=0', [
                    (int)$admin['id'], now(), $id,
                ])->rowCount();
                if (!$aff) wd_err('该订单已被处理');
                admin_log('提现通过', '订单 ' . $o['order_no'] . ' 用户#' . $o['uid'] . ' ' . $o['amount'] . ' CC币');
                wd_done('已标记通过（请线下打款）');
                break;
            }

            /* ---------- 拒绝：退回 CC币 ---------- */
            case 'reject': {
                $id = (int)($_POST['id'] ?? 0);
                $remark = mb_substr(trim((string)($_POST['remark'] ?? '')), 0, 200);
                if ($remark === '') $remark = '管理员拒绝';
                $o = one('SELECT * FROM withdraw_orders WHERE id=?', [$id]);
                if (!$o) wd_err('订单不存在');
                if ((int)$o['status'] === 2) wd_err('该订单已拒绝');
                if ((int)$o['status'] === 3) wd_err('已打款订单不能拒绝');
                $aff = q('UPDATE withdraw_orders SET status=2, admin_id=?, handled_at=?, remark=? WHERE id=? AND status IN (0,1)', [
                    (int)$admin['id'], now(), $remark, $id,
                ])->rowCount();
                if (!$aff) wd_err('该订单已被处理');
                try {
                    add_coin((int)$o['uid'], (int)$o['amount'], 'withdraw_refund', $id, '提现被拒绝，退回 ' . $o['amount'] . ' CC币（' . $o['order_no'] . '）');
                } catch (Throwable $e) {
                    q('UPDATE withdraw_orders SET status=?, admin_id=?, handled_at=?, remark=? WHERE id=?', [
                        (int)$o['status'], (int)$o['admin_id'], (int)$o['handled_at'], (string)$o['remark'], $id,
                    ]);
                    wd_err('退回失败：' . $e->getMessage());
                }
                admin_log('提现拒绝', '订单 ' . $o['order_no'] . ' 退回 ' . $o['amount'] . ' CC币：' . $remark);
                wd_done('已拒绝并退回 ' . number_format((int)$o['amount']) . ' CC币');
                break;
            }

            /* ---------- 已打款 ---------- */
            case 'paid': {
                $id = (int)($_POST['id'] ?? 0);
                $o = one('SELECT * FROM withdraw_orders WHERE id=?', [$id]);
                if (!$o) wd_err('订单不存在');
                if ((int)$o['status'] === 3) wd_err('该订单已标记打款');
                if ((int)$o['status'] === 2) wd_err('已拒绝订单不能标记打款');
                $aff = q('UPDATE withdraw_orders SET status=3, admin_id=?, handled_at=? WHERE id=? AND status IN (0,1)', [
                    (int)$admin['id'], now(), $id,
                ])->rowCount();
                if (!$aff) wd_err('该订单已被处理');
                admin_log('提现已打款', '订单 ' . $o['order_no'] . ' 用户#' . $o['uid'] . ' ' . $o['amount'] . ' CC币');
                wd_done('已标记为已打款');
                break;
            }

            default:
                wd_err('未知操作');
        }
    } catch (Throwable $e) {
        wd_err('操作失败：' . $e->getMessage());
    }
}

/* =========================================================
 * 筛选 / 导出 / 分页
 * ========================================================= */
$fStatus = (string)($_GET['status'] ?? '');
$kw      = trim((string)($_GET['kw'] ?? ''));
$d1      = trim((string)($_GET['d1'] ?? ''));
$d2      = trim((string)($_GET['d2'] ?? ''));
$t1      = wd_day0($d1);
$t2      = wd_day1($d2);

$w = [];
$p = [];
if ($fStatus !== '' && $fStatus !== 'all') {
    $w[] = 'o.status=?';
    $p[] = (int)$fStatus;
}
if ($kw !== '') {
    $w[] = '(o.order_no LIKE ? OR o.account LIKE ? OR u.account LIKE ? OR u.nickname LIKE ? OR u.yx_id LIKE ?)';
    $like = '%' . $kw . '%';
    foreach ([1, 2, 3, 4, 5] as $_) $p[] = $like;
}
if ($t1 > 0) {
    $w[] = 'o.created_at>=?';
    $p[] = $t1;
}
if ($t2 > 0) {
    $w[] = 'o.created_at<=?';
    $p[] = $t2;
}
$where = $w ? (' WHERE ' . implode(' AND ', $w)) : '';
$sqlFrom = ' FROM withdraw_orders o LEFT JOIN users u ON u.id=o.uid' . $where;

/* ---------- CSV ---------- */
if (isset($_GET['export']) && (string)$_GET['export'] === '1') {
    $rows = all('SELECT o.*, u.account AS u_account, u.nickname' . $sqlFrom . ' ORDER BY o.id DESC LIMIT 20000', $p);
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="withdraw_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');
    echo "\xEF\xBB\xBF";
    $fp = fopen('php://output', 'w');
    if ($fp) {
        fputcsv($fp, ['订单号', '用户CC号', '昵称', 'CC币', '收款账号', '收款码', '状态', '备注', '申请时间', '处理时间'], ',', '"', '\\');
        foreach ($rows as $r) {
            $st = wd_status((int)$r['status']);
            fputcsv($fp, [
                csv_safe((string)$r['order_no']),
                csv_safe((string)($r['u_account'] ?? '')),
                csv_safe((string)($r['nickname'] ?? '')),
                (int)$r['amount'],
                csv_safe((string)$r['account']),
                csv_safe((string)$r['qr']),
                $st[0],
                csv_safe((string)$r['remark']),
                $r['created_at'] ? date('Y-m-d H:i:s', (int)$r['created_at']) : '',
                $r['handled_at'] ? date('Y-m-d H:i:s', (int)$r['handled_at']) : '',
            ], ',', '"', '\\');
        }
        fclose($fp);
    }
    admin_log('提现导出', '导出 ' . count($rows) . ' 条提现订单');
    exit;
}

$total = (int)val('SELECT COUNT(*)' . $sqlFrom, $p);
$page  = max(1, (int)($_GET['page'] ?? 1));
$per   = 20;
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per;
$rows = all('SELECT o.*, u.account AS u_account, u.nickname, u.yx_id, u.avatar' . $sqlFrom . ' ORDER BY o.id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);

$fq = $_GET;
unset($fq['page'], $fq['export']);
$qs = http_build_query($fq);
$baseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

/* ---------- 汇总 ---------- */
$sumStat = [
    'wait_n'  => (int)val('SELECT COUNT(*) FROM withdraw_orders WHERE status=0'),
    'wait_c'  => (int)val('SELECT COALESCE(SUM(amount),0) FROM withdraw_orders WHERE status=0'),
    'paid'    => (int)val('SELECT COALESCE(SUM(amount),0) FROM withdraw_orders WHERE status=3'),
    'refund'  => (int)val('SELECT COALESCE(SUM(amount),0) FROM withdraw_orders WHERE status=2'),
];

$jsRows = [];
foreach ($rows as $r) {
    $jsRows[(int)$r['id']] = [
        'order_no' => (string)$r['order_no'],
        'account'  => (string)($r['u_account'] ?? ''),
        'nickname' => (string)($r['nickname'] ?? ''),
        'amount'   => (int)$r['amount'],
        'pay_acc'  => (string)$r['account'],
        'qr'       => (string)$r['qr'],
        'qr_url'   => wd_img((string)$r['qr']),
        'status'   => (int)$r['status'],
        'remark'   => (string)$r['remark'],
        'created'  => (int)$r['created_at'],
        'handled'  => (int)$r['handled_at'],
        'admin_id' => (int)$r['admin_id'],
    ];
}

$flash = wd_flash();
$title = '提现审核';
admin_head($title, 'withdraw');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<div class="adm-cards">
  <div class="adm-stat orange"><div class="st-ico">⏳</div><div class="st-label">待审核</div><div class="st-value"><?= number_format($sumStat['wait_n']) ?></div><div class="st-sub">笔</div></div>
  <div class="adm-stat orange"><div class="st-ico">💸</div><div class="st-label">待审核金额</div><div class="st-value"><?= number_format($sumStat['wait_c']) ?></div><div class="st-sub">CC币</div></div>
  <div class="adm-stat"><div class="st-ico">🏦</div><div class="st-label">已打款</div><div class="st-value"><?= number_format($sumStat['paid']) ?></div><div class="st-sub">CC币</div></div>
  <div class="adm-stat red"><div class="st-ico">↩️</div><div class="st-label">已退回</div><div class="st-value"><?= number_format($sumStat['refund']) ?></div><div class="st-sub">CC币</div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>提现订单<span class="sub">共 <?= number_format($total) ?> 条</span></h2>
    <a class="adm-btn ghost sm" href="<?= e($baseUrl) ?>export=1">导出 CSV</a>
  </div>
  <div class="adm-panel-body" style="padding-bottom:0">
    <form method="get" class="adm-toolbar" style="margin-bottom:14px">
      <select class="adm-select" name="status">
        <option value="">全部状态</option>
        <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>待审核</option>
        <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>已通过</option>
        <option value="2" <?= $fStatus === '2' ? 'selected' : '' ?>>已拒绝</option>
        <option value="3" <?= $fStatus === '3' ? 'selected' : '' ?>>已打款</option>
      </select>
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="订单号 / CC号 / 昵称 / 收款账号" style="min-width:220px">
      <input class="adm-input" type="date" name="d1" value="<?= e($d1) ?>">
      <input class="adm-input" type="date" name="d2" value="<?= e($d2) ?>">
      <button class="adm-btn" type="submit">筛选</button>
      <a class="adm-btn ghost" href="withdraw.php">重置</a>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr>
          <th>订单号</th><th>用户</th><th>金额</th><th>收款账号</th><th>收款码</th><th>状态</th><th>申请时间</th><th style="width:230px">操作</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8"><div class="adm-empty">没有符合条件的提现订单</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <?php $st = wd_status((int)$r['status']); $qrUrl = wd_img((string)$r['qr']); ?>
        <tr>
          <td><span class="nm"><?= e((string)$r['order_no']) ?></span><div class="sub">#<?= (int)$r['id'] ?></div></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if (!empty($r['avatar'])): ?><img src="../<?= e(ltrim((string)$r['avatar'], '/')) ?>" alt=""><?php else: ?><?= e(mb_substr((string)($r['nickname'] ?: ($r['u_account'] ?? '?')), 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e((string)($r['nickname'] ?? '未知用户')) ?></div>
                <div class="sub">CC <?= e((string)($r['u_account'] ?? '-')) ?></div>
              </div>
            </div>
          </td>
          <td class="num"><?= number_format((int)$r['amount']) ?></td>
          <td><span style="font-family:ui-monospace,monospace;font-size:12px;word-break:break-all"><?= e((string)$r['account']) ?></span></td>
          <td>
            <?php if ($qrUrl !== ''): ?>
              <img src="<?= e($qrUrl) ?>" alt="收款码" style="width:40px;height:40px;object-fit:cover;border-radius:7px;cursor:zoom-in;border:1px solid #EBEEF4" onclick="wdQr(<?= (int)$r['id'] ?>)">
            <?php else: ?>
              <span class="sub">无</span>
            <?php endif; ?>
          </td>
          <td><span class="tag <?= $st[1] ?>"><?= e($st[0]) ?></span></td>
          <td><span class="sub"><?= e(date('m-d H:i', (int)$r['created_at'])) ?></span></td>
          <td>
            <div class="actions">
              <?php if ((int)$r['status'] === 0): ?>
                <button class="adm-btn sm blue" onclick="wdAct('pass', <?= (int)$r['id'] ?>)">通过</button>
                <button class="adm-btn sm" onclick="wdAct('paid', <?= (int)$r['id'] ?>)">已打款</button>
                <button class="adm-btn sm danger" onclick="wdReject(<?= (int)$r['id'] ?>, <?= (int)$r['amount'] ?>)">拒绝</button>
              <?php elseif ((int)$r['status'] === 1): ?>
                <button class="adm-btn sm" onclick="wdAct('paid', <?= (int)$r['id'] ?>)">已打款</button>
                <button class="adm-btn sm danger" onclick="wdReject(<?= (int)$r['id'] ?>, <?= (int)$r['amount'] ?>)">拒绝</button>
              <?php endif; ?>
              <button class="adm-btn sm ghost" onclick="wdDetail(<?= (int)$r['id'] ?>)">详情</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>

<script>
var WD_ROWS = <?= json_encode($jsRows, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var WD_ST = {0:['待审核','orange'],1:['已通过','blue'],2:['已拒绝','red'],3:['已打款','green']};
function wdAct(act, id) {
  var label = act === 'pass' ? '标记通过' : '标记已打款';
  var tip = act === 'pass' ? '仅标记为已通过，不扣币也不打款，需线下转账。' : '确认已向该用户线下打款？标记后不可再拒绝。';
  ADM.confirm({title: label, text: tip, ok: '确认'}).then(function (yes) {
    if (yes) ADM.postForm(act, {id: id});
  });
}
function wdReject(id, amount) {
  ADM.modal({title:'拒绝提现 #' + id, html:
    '<p style="margin:0 0 10px;color:#6B7280">拒绝后将自动退回 <b style="color:#07C160">' + ADM.money(amount) + '</b> CC币给用户。</p>' +
    '<div class="adm-field"><label>拒绝原因</label><input class="adm-input" id="wd-remark" value="收款信息有误" style="width:100%"></div>',
    footer:'<button class="adm-btn ghost" data-close="1">取消</button><button class="adm-btn danger" id="wd-ok">确认拒绝并退回</button>',
    onOpen:function () {
      document.getElementById('wd-ok').onclick = function () {
        ADM.postForm('reject', {id: id, remark: document.getElementById('wd-remark').value});
      };
    }});
}
function wdQr(id) {
  var r = WD_ROWS[id];
  if (!r) return;
  if (!r.qr_url) { ADM.toast('该订单未上传收款码'); return; }
  ADM.modal({title:'收款码 · ' + r.order_no, html:'<div style="text-align:center"><img src="' + ADM.esc(r.qr_url) + '" alt="收款码" style="max-width:100%;border-radius:10px"></div>'});
}
function wdDetail(id) {
  var r = WD_ROWS[id];
  if (!r) return;
  var st = WD_ST[r.status] || ['未知', 'gray'];
  var kv = [
    ['订单号', r.order_no], ['用户', r.account + ' / ' + (r.nickname || '-')],
    ['金额', ADM.money(r.amount) + ' CC币'], ['收款账号', r.pay_acc || '-'],
    ['状态', '<span class="tag ' + st[1] + '">' + st[0] + '</span>'],
    ['备注', r.remark || '-'], ['申请时间', r.created ? ADM.fmt(r.created) : '-'],
    ['处理时间', r.handled ? ADM.fmt(r.handled) : '-'], ['处理管理员', r.admin_id ? ('#' + r.admin_id) : '-']
  ];
  var html = '<table style="width:100%;font-size:13px;border-collapse:collapse">';
  kv.forEach(function (x) {
    html += '<tr><td style="color:#6B7280;padding:6px 0;width:96px;vertical-align:top">' + ADM.esc(x[0]) + '</td><td style="padding:6px 0;word-break:break-all">' + (x[0] === '状态' ? x[1] : ADM.esc(x[1])) + '</td></tr>';
  });
  html += '</table>';
  if (r.qr_url) html += '<div style="margin-top:12px;text-align:center"><img src="' + ADM.esc(r.qr_url) + '" style="max-width:240px;border-radius:10px"></div>';
  ADM.modal({title:'提现详情', html:html});
}
if (window.__admFlash) { ADM.toast(window.__admFlash); }
</script>
<?php admin_foot(); ?>
