<?php
/**
 * CC商聊 - 操作日志 / 登录日志
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'logs');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

/* ---------- 操作日志筛选 ---------- */
$aid = (string)($_GET['aid'] ?? '');
$action = trim((string)($_GET['action'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 30;

$where = [];
$par = [];
if ($aid !== '' && (int)$aid > 0) {
    $where[] = 'l.admin_id=?';
    $par[] = (int)$aid;
}
if ($action !== '') {
    $where[] = '(l.action LIKE ? OR l.detail LIKE ?)';
    $par[] = '%' . $action . '%';
    $par[] = '%' . $action . '%';
}
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$total = (int)val('SELECT COUNT(*) FROM admin_logs l' . $w, $par);
$rows = all('SELECT l.*, a.username, a.role FROM admin_logs l LEFT JOIN admins a ON a.id=l.admin_id'
    . $w . ' ORDER BY l.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);

$admins = all('SELECT id, username, role FROM admins ORDER BY id ASC');

/* ---------- 登录日志 ---------- */
$lpage = max(1, (int)($_GET['lpage'] ?? 1));
$lper = 30;
$lkw = trim((string)($_GET['lkw'] ?? ''));
$lwhere = [];
$lpar = [];
if ($lkw !== '') {
    $lwhere[] = '(u.nickname LIKE ? OR u.account LIKE ? OR lo.ip LIKE ?)';
    $like = '%' . $lkw . '%';
    array_push($lpar, $like, $like, $like);
}
$lw = $lwhere ? ' WHERE ' . implode(' AND ', $lwhere) : '';
$ltotal = (int)val('SELECT COUNT(*) FROM login_logs lo LEFT JOIN users u ON u.id=lo.uid' . $lw, $lpar);
$loginRows = all('SELECT lo.id, lo.uid, lo.ip, lo.ua, lo.created_at, u.nickname, u.account
    FROM login_logs lo LEFT JOIN users u ON u.id=lo.uid' . $lw . '
    ORDER BY lo.id DESC LIMIT ' . $lper . ' OFFSET ' . (($lpage - 1) * $lper), $lpar);

$aPager = 'logs.php?' . admin_qs();
$lPager = 'logs.php?' . admin_qs(['page' => 1]);

admin_head('操作日志', 'logs');
?>
<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>管理员操作日志 <span class="sub">共 <?= admin_money($total) ?> 条</span></h2>
    <form class="adm-toolbar" method="get" action="logs.php">
      <?php if ($lkw !== ''): ?><input type="hidden" name="lkw" value="<?= e($lkw) ?>"><?php endif; ?>
      <select class="adm-select" name="aid">
        <option value="">全部管理员</option>
        <?php foreach ($admins as $a): ?>
          <option value="<?= (int)$a['id'] ?>" <?= $aid === (string)(int)$a['id'] ? 'selected' : '' ?>>
            <?= e($a['username']) ?>（<?= e($a['role']) ?>）
          </option>
        <?php endforeach; ?>
      </select>
      <input class="adm-input" name="action" value="<?= e($action) ?>" placeholder="动作 / 详情关键词" style="width:200px">
      <button class="adm-btn" type="submit">筛选</button>
      <?php if ($aid !== '' || $action !== ''): ?><a class="adm-btn ghost" href="logs.php">重置</a><?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>管理员</th><th>动作</th><th>详情</th><th>IP</th><th>时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="6"><div class="adm-empty">暂无操作日志</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td>
            <div class="nm"><?= e($r['username'] ?: ('Admin #' . (int)$r['admin_id'])) ?></div>
            <div class="sub"><?= e((string)$r['role']) ?></div>
          </td>
          <td><span class="tag blue"><?= e($r['action']) ?></span></td>
          <td style="max-width:420px;word-break:break-all;font-size:12.5px;color:#6B7280"><?= e($r['detail']) ?></td>
          <td style="font-family:ui-monospace,Consolas,monospace;font-size:12px"><?= e($r['ip']) ?></td>
          <td><?= e(date('Y-m-d H:i:s', (int)$r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $aPager) ?>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>用户登录日志 <span class="sub">共 <?= admin_money($ltotal) ?> 条</span></h2>
    <form class="adm-toolbar" method="get" action="logs.php">
      <?php if ($aid !== ''): ?><input type="hidden" name="aid" value="<?= e($aid) ?>"><?php endif; ?>
      <?php if ($action !== ''): ?><input type="hidden" name="action" value="<?= e($action) ?>"><?php endif; ?>
      <input class="adm-input" name="lkw" value="<?= e($lkw) ?>" placeholder="用户昵称 / CC号 / IP" style="width:220px">
      <button class="adm-btn" type="submit">筛选</button>
      <?php if ($lkw !== ''): ?><a class="adm-btn ghost" href="logs.php">重置</a><?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>用户</th><th>IP</th><th>设备 UA</th><th>登录时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$loginRows): ?>
        <tr><td colspan="5"><div class="adm-empty">暂无登录日志</div></td></tr>
      <?php endif; ?>
      <?php foreach ($loginRows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td>
            <div class="nm"><?= e($r['nickname'] ?: ('UID ' . (int)$r['uid'])) ?></div>
            <div class="sub"><?= e((string)$r['account']) ?></div>
          </td>
          <td style="font-family:ui-monospace,Consolas,monospace;font-size:12px"><?= e($r['ip']) ?></td>
          <td style="max-width:360px;font-size:12px;color:#6B7280;word-break:break-all"><?= e($r['ua']) ?></td>
          <td><?= e(date('Y-m-d H:i:s', (int)$r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($ltotal, $lpage, $lper, $lPager) ?>
</div>
<?php
admin_foot();
