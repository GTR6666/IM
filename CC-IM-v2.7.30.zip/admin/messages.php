<?php
/**
 * CC商聊 - 消息审计
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'messages');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

function msg_type_name(int $type): string
{
    $map = [
        1 => '文本', 5 => '图片', 6 => '语音', 7 => '红包', 8 => '转账', 9 => '礼物',
        11 => '系统', 12 => '名片', 13 => '群名片', 14 => '通话', 15 => '视频', 16 => '动态',
        17 => '聊天记录', 18 => '文件', 19 => '直播', 20 => '撤回', 21 => '红包', 22 => '转账', 23 => '礼物',
    ];
    return $map[$type] ?? ('类型' . $type);
}

function msg_type_tag(int $type): string
{
    if (in_array($type, [5, 15, 6, 18], true)) return 'blue';
    if (in_array($type, [7, 8, 9, 21, 22, 23], true)) return 'orange';
    if ($type === 11) return 'gray';
    if ($type === 20) return 'red';
    return 'green';
}

$msg = '';
$msgOk = true;

/* ---------- 写操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    $m = $id > 0 ? one('SELECT * FROM messages WHERE id=?', [$id]) : null;
    try {
        if (!$m) throw new RuntimeException('消息不存在');
        switch ($act) {
            case 'recall':
                if ((int)$m['recalled'] === 1) throw new RuntimeException('该消息已撤回');
                q('UPDATE messages SET recalled=1, type=20 WHERE id=?', [$id]);
                admin_log('recall_message', 'mid=' . $id . ' from=' . $m['from_uid'] . ' gid=' . $m['gid'] . ' to=' . $m['to_uid']);
                $msg = '已撤回消息 #' . $id;
                break;
            case 'delete':
                q('UPDATE messages SET deleted=1 WHERE id=?', [$id]);
                admin_log('delete_message', 'mid=' . $id . ' from=' . $m['from_uid'] . ' gid=' . $m['gid'] . ' to=' . $m['to_uid']);
                $msg = '已删除消息 #' . $id;
                break;
            default:
                $msg = '未知操作';
                $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 筛选 ---------- */
$kw = trim((string)($_GET['kw'] ?? ''));
$fromUid = trim((string)($_GET['from_uid'] ?? ''));
$gid = trim((string)($_GET['gid'] ?? ''));
$type = (string)($_GET['type'] ?? '');
$df = trim((string)($_GET['df'] ?? ''));
$dt = trim((string)($_GET['dt'] ?? ''));
$fState = (string)($_GET['state'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 20;

$where = [];
$par = [];
if ($kw !== '') {
    $where[] = 'm.content LIKE ?';
    $par[] = '%' . $kw . '%';
}
if ($fromUid !== '' && (int)$fromUid > 0) {
    $where[] = 'm.from_uid=?';
    $par[] = (int)$fromUid;
}
if ($gid !== '' && (int)$gid > 0) {
    $where[] = 'm.gid=?';
    $par[] = (int)$gid;
}
if ($type !== '' && (int)$type > 0) {
    $where[] = 'm.type=?';
    $par[] = (int)$type;
}
if ($df !== '') {
    $ts = strtotime($df . ' 00:00:00');
    if ($ts) {
        $where[] = 'm.created_at>=?';
        $par[] = $ts;
    }
}
if ($dt !== '') {
    $ts = strtotime($dt . ' 23:59:59');
    if ($ts) {
        $where[] = 'm.created_at<=?';
        $par[] = $ts;
    }
}
if ($fState === 'normal') $where[] = 'm.recalled=0 AND m.deleted=0';
elseif ($fState === 'recalled') $where[] = 'm.recalled=1';
elseif ($fState === 'deleted') $where[] = 'm.deleted=1';

$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$total = (int)val('SELECT COUNT(*) FROM messages m' . $w, $par);

$rows = all('SELECT m.*, f.nickname AS from_name, f.account AS from_account,
        t.nickname AS to_name, t.account AS to_account, g.name AS group_name
    FROM messages m
    LEFT JOIN users f ON f.id=m.from_uid
    LEFT JOIN users t ON t.id=m.to_uid
    LEFT JOIN groups g ON g.gid=m.gid' . $w . '
    ORDER BY m.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);

/* 类型统计：使用除类型外的筛选条件 */
$typeWhere = [];
$typePar = [];
if ($kw !== '') {
    $typeWhere[] = 'm.content LIKE ?';
    $typePar[] = '%' . $kw . '%';
}
if ($fromUid !== '' && (int)$fromUid > 0) {
    $typeWhere[] = 'm.from_uid=?';
    $typePar[] = (int)$fromUid;
}
if ($gid !== '' && (int)$gid > 0) {
    $typeWhere[] = 'm.gid=?';
    $typePar[] = (int)$gid;
}
if ($df !== '') {
    $ts = strtotime($df . ' 00:00:00');
    if ($ts) {
        $typeWhere[] = 'm.created_at>=?';
        $typePar[] = $ts;
    }
}
if ($dt !== '') {
    $ts = strtotime($dt . ' 23:59:59');
    if ($ts) {
        $typeWhere[] = 'm.created_at<=?';
        $typePar[] = $ts;
    }
}
if ($fState === 'normal') $typeWhere[] = 'm.recalled=0 AND m.deleted=0';
elseif ($fState === 'recalled') $typeWhere[] = 'm.recalled=1';
elseif ($fState === 'deleted') $typeWhere[] = 'm.deleted=1';
$tw = $typeWhere ? ' WHERE ' . implode(' AND ', $typeWhere) : '';
$typeCounts = all('SELECT m.type, COUNT(*) AS c FROM messages m' . $tw . ' GROUP BY m.type ORDER BY c DESC', $typePar);

$postUrl = 'messages.php?' . admin_qs();
$pagerUrl = 'messages.php?' . admin_qs();

admin_head('消息审计', 'messages');
?>
<?php if ($msg !== ''): ?>
<div class="adm-panel" style="border-left:4px solid <?= $msgOk ? '#07C160' : '#EF4444' ?>">
  <div class="adm-panel-body" style="padding:12px 18px;color:<?= $msgOk ? '#059669' : '#DC2626' ?>;font-size:13px"><?= e($msg) ?></div>
</div>
<?php endif; ?>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>类型统计</h2>
    <span class="sub">当前筛选下各类型消息量</span>
  </div>
  <div class="adm-panel-body">
    <div class="adm-toolbar">
      <?php if (!$typeCounts): ?>
        <span class="adm-hint">暂无消息</span>
      <?php endif; ?>
      <?php foreach ($typeCounts as $tc): ?>
        <?php $tt = (int)$tc['type']; ?>
        <a class="tag <?= msg_type_tag($tt) ?>" style="padding:6px 10px;font-size:12px;text-decoration:none" href="messages.php?<?= e(admin_qs(['type' => $tt, 'page' => 1])) ?>">
          <?= e(msg_type_name($tt)) ?> · <?= (int)$tc['c'] ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>消息列表 <span class="sub">共 <?= admin_money($total) ?> 条</span></h2>
  </div>
  <div class="adm-panel-body" style="padding-bottom:6px">
    <form class="adm-toolbar" method="get" action="messages.php">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="内容关键词" style="width:180px">
      <input class="adm-input" name="from_uid" value="<?= e($fromUid) ?>" placeholder="发送者 UID" style="width:120px">
      <input class="adm-input" name="gid" value="<?= e($gid) ?>" placeholder="群号" style="width:110px">
      <select class="adm-select" name="type">
        <option value="">全部类型</option>
        <?php foreach ([1, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20] as $t): ?>
          <option value="<?= $t ?>" <?= $type === (string)$t ? 'selected' : '' ?>><?= e(msg_type_name($t)) ?></option>
        <?php endforeach; ?>
      </select>
      <select class="adm-select" name="state">
        <option value="">全部状态</option>
        <option value="normal" <?= $fState === 'normal' ? 'selected' : '' ?>>正常</option>
        <option value="recalled" <?= $fState === 'recalled' ? 'selected' : '' ?>>已撤回</option>
        <option value="deleted" <?= $fState === 'deleted' ? 'selected' : '' ?>>已删除</option>
      </select>
      <input class="adm-input" name="df" value="<?= e($df) ?>" type="date" title="开始日期">
      <input class="adm-input" name="dt" value="<?= e($dt) ?>" type="date" title="结束日期">
      <button class="adm-btn" type="submit">筛选</button>
      <a class="adm-btn ghost" href="messages.php">重置</a>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>类型</th><th>发送者</th><th>接收方</th><th>内容摘要</th><th>时间</th><th>操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7"><div class="adm-empty">没有匹配的消息</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $m): ?>
        <?php
          $id = (int)$m['id'];
          $mt = (int)$m['type'];
          $ctype = (int)$m['ctype'];
          $digest = msg_digest($mt, (string)$m['content']);
          if ($digest === '') $digest = '（空）';
          $statTag = (int)$m['deleted'] === 1 ? '<span class="tag red">已删除</span>' : ((int)$m['recalled'] === 1 ? '<span class="tag orange">已撤回</span>' : '');
        ?>
        <tr>
          <td><?= $id ?></td>
          <td><span class="tag <?= msg_type_tag($mt) ?>"><?= e(msg_type_name($mt)) ?></span><?= $statTag ? '<div style="margin-top:4px">' . $statTag . '</div>' : '' ?></td>
          <td>
            <div class="nm"><?= e($m['from_name'] ?: ('UID ' . (int)$m['from_uid'])) ?></div>
            <div class="sub">UID <?= (int)$m['from_uid'] ?></div>
          </td>
          <td>
            <?php if ($ctype === 2): ?>
              <div class="nm"><?= e($m['group_name'] ?: ('群 ' . (int)$m['gid'])) ?></div>
              <div class="sub">群聊 · 群号 <?= (int)$m['gid'] ?></div>
            <?php else: ?>
              <div class="nm"><?= e($m['to_name'] ?: ('UID ' . (int)$m['to_uid'])) ?></div>
              <div class="sub">私聊 · UID <?= (int)$m['to_uid'] ?></div>
            <?php endif; ?>
          </td>
          <td style="max-width:280px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($digest) ?></div></td>
          <td><?= e(date('Y-m-d H:i:s', (int)$m['created_at'])) ?></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" type="button" onclick="openMsg(<?= $id ?>)" data-mid="<?= $id ?>">原文</button>
              <?php if ((int)$m['recalled'] === 0 && (int)$m['deleted'] === 0): ?>
                <button class="adm-btn sm orange" type="button" onclick="doAct('recall',<?= $id ?>,'撤回后该消息显示为撤回提示，确认撤回？')">撤回</button>
              <?php endif; ?>
              <?php if ((int)$m['deleted'] === 0): ?>
                <button class="adm-btn sm danger" type="button" onclick="doAct('delete',<?= $id ?>,'删除后该消息在后台标记为已删除，确认删除？')">删除</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $pagerUrl) ?>
</div>

<form id="actForm" method="post" action="<?= e($postUrl) ?>" style="display:none"></form>

<script>
var MSGS = <?= json_encode(array_map(static function ($m) {
    return [
        'id' => (int)$m['id'],
        'ctype' => (int)$m['ctype'],
        'from_uid' => (int)$m['from_uid'],
        'from_name' => (string)($m['from_name'] ?: ''),
        'to_uid' => (int)$m['to_uid'],
        'to_name' => (string)($m['to_name'] ?: ''),
        'gid' => (int)$m['gid'],
        'group_name' => (string)($m['group_name'] ?: ''),
        'type' => (int)$m['type'],
        'type_name' => msg_type_name((int)$m['type']),
        'content' => (string)$m['content'],
        'extra' => (string)$m['extra'],
        'created_at' => (int)$m['created_at'],
        'recalled' => (int)$m['recalled'],
        'deleted' => (int)$m['deleted'],
    ];
}, $rows), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var POST_URL = <?= json_encode($postUrl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

function submitAct(act, id, extra) {
  var h = '<input type="hidden" name="act" value="' + ADM.esc(act) + '">' +
          '<input type="hidden" name="id" value="' + ADM.esc(id) + '">';
  Object.keys(extra || {}).forEach(function (k) {
    h += '<input type="hidden" name="' + ADM.esc(k) + '" value="' + ADM.esc(extra[k]) + '">';
  });
  var f = document.getElementById('actForm');
  f.innerHTML = h;
  f.submit();
}

function doAct(act, id, text) {
  ADM.confirm({ title: '确认操作', text: text, danger: act === 'delete' }).then(function (v) {
    if (v) submitAct(act, id, {});
  });
}

function openMsg(id) {
  var m = null;
  for (var i = 0; i < MSGS.length; i++) if (MSGS[i].id === id) { m = MSGS[i]; break; }
  if (!m) { ADM.toast('数据已过期，请刷新页面'); return; }
  var html = '<div style="font-size:12.5px;color:#6B7280;display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;margin-bottom:12px">' +
    '<div>消息 ID：' + m.id + '</div>' +
    '<div>类型：' + ADM.esc(m.type_name) + '（' + m.type + '）</div>' +
    '<div>发送者：' + ADM.esc(m.from_name || ('UID ' + m.from_uid)) + '（UID ' + m.from_uid + '）</div>' +
    '<div>' + (m.ctype === 2 ? '群聊：' + ADM.esc(m.group_name || ('群 ' + m.gid)) + '（' + m.gid + '）' : '接收者：' + ADM.esc(m.to_name || ('UID ' + m.to_uid)) + '（UID ' + m.to_uid + '）') + '</div>' +
    '<div>会话类型：' + (m.ctype === 2 ? '群聊' : '私聊') + '</div>' +
    '<div>时间：' + ADM.fmt(m.created_at) + '</div>' +
    '<div>状态：' + (m.deleted === 1 ? '已删除' : (m.recalled === 1 ? '已撤回' : '正常')) + '</div>' +
    '<div>撤回标记：' + m.recalled + '</div></div>';
  html += '<div style="font-size:12.5px;color:#374151;font-weight:600;margin-bottom:6px">原文</div>';
  html += '<div style="background:#F8FAFD;border:1px solid #EBEEF4;border-radius:9px;padding:10px 12px;font-size:13px;white-space:pre-wrap;word-break:break-all;max-height:240px;overflow:auto">' + ADM.esc(m.content) + '</div>';
  if (m.extra) {
    html += '<div style="font-size:12.5px;color:#374151;font-weight:600;margin:12px 0 6px">附加数据 extra</div>' +
      '<div style="background:#0F1420;color:#C9D3E6;border-radius:9px;padding:10px 12px;font-size:12px;white-space:pre-wrap;word-break:break-all;max-height:200px;overflow:auto">' + ADM.esc(m.extra) + '</div>';
  }
  ADM.modal({ title: '消息原文 #' + m.id, html: html });
}
</script>
<?php
admin_foot();
