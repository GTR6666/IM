<?php
/**
 * CC商聊 - 后台：宣传落地页配置
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!in_array(($admin['role'] ?? ''), ['super', 'ops'], true)) {
    admin_head('落地页', 'landing');
    echo '<div class="adm-empty">当前账号没有落地页配置权限。</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;

/* ---------- 保存 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $cfg = landing_config();
        $cfg['enabled'] = (int)($_POST['enabled'] ?? 0) === 1 ? 1 : 0;

        // 单行字段
        $map = [
            'hero' => ['badge', 'title', 'subtitle', 'btn1', 'btn1_url', 'btn2', 'btn2_url'],
            'stats' => [],
            'features' => ['title', 'subtitle'],
            'shots' => ['title', 'subtitle'],
            'download' => ['title', 'subtitle', 'android', 'ios', 'tip'],
            'faq' => ['title', 'subtitle'],
            'cta' => ['title', 'desc', 'btn', 'btn_url'],
            'footer' => ['text', 'icp', 'contact'],
        ];
        foreach ($map as $group => $fields) {
            $cfg[$group]['show'] = (int)($_POST['show_' . $group] ?? 0) === 1 ? 1 : 0;
            foreach ($fields as $f) {
                $v = trim((string)($_POST[$group . '_' . $f] ?? ''));
                $cfg[$group][$f] = mb_substr($v, 0, $f === 'subtitle' || $f === 'desc' ? 300 : 120);
            }
        }

        // 列表字段：每行 "字段1|字段2"（| 或 ｜ 均可）
        $parse = static function (string $raw, array $keys): array {
            $out = [];
            foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
                $line = trim($line);
                if ($line === '') continue;
                $parts = array_map('trim', preg_split('/[|｜]/u', $line));
                $row = [];
                foreach ($keys as $i => $k) $row[$k] = mb_substr((string)($parts[$i] ?? ''), 0, 300);
                if (implode('', $row) === '') continue;
                $out[] = $row;
                if (count($out) >= 12) break;
            }
            return $out;
        };
        // 只有表单真的提交了该字段才覆盖（避免部分提交把列表清空）
        if (array_key_exists('features_items', $_POST)) {
            $cfg['features']['items'] = $parse((string)$_POST['features_items'], ['icon', 'title', 'desc']);
        }
        if (array_key_exists('stats_items', $_POST)) {
            $cfg['stats']['items'] = $parse((string)$_POST['stats_items'], ['num', 'label']);
        }
        if (array_key_exists('faq_items', $_POST)) {
            $cfg['faq']['items'] = $parse((string)$_POST['faq_items'], ['q', 'a']);
        }
        if (array_key_exists('shots_items', $_POST)) {
            $cfg['shots']['items'] = $parse((string)$_POST['shots_items'], ['img', 'alt']);
        }

        set_setting('landing_config', json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        admin_log('landing_save', '落地页配置已保存（' . ($cfg['enabled'] ? '已开放' : '未开放') . '）');
        $msg = '落地页配置已保存' . ($cfg['enabled'] ? '，当前状态：已开放' : '，当前状态：未开放');
    } catch (Throwable $e) {
        $msg = '保存失败：' . $e->getMessage();
        $msgOk = false;
    }
}

$C = landing_config();

/** 把列表转成可编辑文本 */
function ld_dump(array $items, array $keys, string $sep = ' | '): string
{
    $lines = [];
    foreach ($items as $it) {
        $row = [];
        foreach ($keys as $k) $row[] = (string)($it[$k] ?? '');
        $lines[] = implode($sep, $row);
    }
    return implode("\n", $lines);
}

$title = '落地页';
admin_head($title, 'landing');
?>
<?php if ($msg !== ''): ?>
<script>window.__admFlash = <?= json_encode($msg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<form method="post" class="ld-form">
<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>总开关</h2>
    <span class="sub">关闭后访问 /landing.php 会自动跳转到登录页</span>
  </div>
  <div class="adm-panel-body">
    <label class="ld-switch">
      <input type="checkbox" name="enabled" value="1" <?= $C['enabled'] ? 'checked' : '' ?>>
      <span class="ld-switch-txt">开放落地页（推荐开启，便于百度 / 必应 / 谷歌收录）</span>
    </label>
    <div class="adm-hint" style="margin-top:10px">
      访问地址：<a href="landing.php" target="_blank" style="color:#07C160">/landing.php</a>
      　已加入 sitemap 与 robots 白名单。
    </div>
  </div>
</div>

<?php
$blocks = [
    'hero' => ['首屏 Hero', [
        'badge' => '顶部小标签', 'title' => '主标题（H1）', 'subtitle' => '副标题 / 描述',
        'btn1' => '按钮1 文字', 'btn1_url' => '按钮1 链接', 'btn2' => '按钮2 文字（留空隐藏）', 'btn2_url' => '按钮2 链接',
    ]],
    'stats' => ['数据展示带', []],
    'features' => ['功能特色', ['title' => '区块标题（H2）', 'subtitle' => '区块副标题']],
    'shots' => ['截图展示', ['title' => '区块标题（H2）', 'subtitle' => '区块副标题']],
    'download' => ['下载区块', ['title' => '区块标题（H2）', 'subtitle' => '副标题', 'android' => 'Android 下载链接', 'ios' => 'iOS 下载链接', 'tip' => '底部提示文字']],
    'faq' => ['常见问题', ['title' => '区块标题（H2）', 'subtitle' => '副标题']],
    'cta' => ['底部行动区', ['title' => '标题（H2）', 'desc' => '描述', 'btn' => '按钮文字', 'btn_url' => '按钮链接']],
    'footer' => ['页脚', ['text' => '站点描述', 'icp' => '备案号（可留空）', 'contact' => '联系我们链接（可留空）']],
];
foreach ($blocks as $key => $def):
    [$label, $fields] = $def;
?>
<div class="adm-panel">
  <div class="adm-panel-head">
    <h2><?= e($label) ?></h2>
    <label class="ld-show">
      <input type="checkbox" name="show_<?= $key ?>" value="1" <?= !empty($C[$key]['show']) ? 'checked' : '' ?>>
      显示此区块
    </label>
  </div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <?php foreach ($fields as $f => $fLabel): ?>
      <div class="adm-field">
        <label><?= e($fLabel) ?></label>
        <input class="adm-input" name="<?= $key ?>_<?= $f ?>" value="<?= e((string)($C[$key][$f] ?? '')) ?>" maxlength="300">
      </div>
      <?php endforeach; ?>

      <?php if ($key === 'stats'): ?>
      <div class="adm-field ld-full">
        <label>数据条目（每行一条：数字 | 说明）</label>
        <textarea class="adm-textarea" name="stats_items" rows="5"><?= e(ld_dump($C['stats']['items'], ['num', 'label'])) ?></textarea>
      </div>
      <?php elseif ($key === 'features'): ?>
      <div class="adm-field ld-full">
        <label>功能条目（每行一条：图标 | 标题 | 描述）</label>
        <textarea class="adm-textarea" name="features_items" rows="8"><?= e(ld_dump($C['features']['items'], ['icon', 'title', 'desc'])) ?></textarea>
        <div class="adm-hint">图标可填 emoji，例如 💬 🎥 🌈；最多 12 条。</div>
      </div>
      <?php elseif ($key === 'faq'): ?>
      <div class="adm-field ld-full">
        <label>问答条目（每行一条：问题 | 答案）</label>
        <textarea class="adm-textarea" name="faq_items" rows="8"><?= e(ld_dump($C['faq']['items'], ['q', 'a'])) ?></textarea>
        <div class="adm-hint">FAQ 会自动输出 schema.org FAQPage 结构化数据，利于搜索引擎展示问答。</div>
      </div>
      <?php elseif ($key === 'shots'): ?>
      <div class="adm-field ld-full">
        <label>截图条目（每行一条：图片地址 | 替代文字 alt）</label>
        <textarea class="adm-textarea" name="shots_items" rows="5"><?= e(ld_dump($C['shots']['items'], ['img', 'alt'])) ?></textarea>
        <div class="adm-hint">图片地址如 <code>uploads/landing/shot1.png</code>；alt 对 SEO 重要，建议填写。</div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>

<div class="adm-panel">
  <div class="adm-panel-body">
    <button class="adm-btn" type="submit" style="width:100%;height:46px;font-size:15px">保存落地页配置</button>
  </div>
</div>
</form>

<style>
.ld-form .adm-panel{margin-bottom:16px}
.ld-switch{display:flex;align-items:center;gap:10px;font-size:14px;cursor:pointer}
.ld-switch input{width:20px;height:20px;accent-color:#07C160}
.ld-switch-txt{font-weight:600}
.ld-show{display:flex;align-items:center;gap:8px;font-size:13px;color:#374151;cursor:pointer}
.ld-show input{width:18px;height:18px;accent-color:#07C160}
.ld-form .adm-form{grid-template-columns:1fr 1fr}
.ld-form .ld-full{grid-column:1/-1}
@media (max-width:640px){.ld-form .adm-form{grid-template-columns:1fr}}
</style>

<script>
// 区块显示开关：未勾选时该区块表单淡化，便于识别
document.querySelectorAll('.ld-show input').forEach(function(cb){
  var panel = cb.closest('.adm-panel');
  function paint(){ panel.style.opacity = cb.checked ? '1' : '.55'; }
  cb.addEventListener('change', paint); paint();
});
</script>
<?php admin_foot(); ?>
