<?php
/**
 * CC商聊 - 后台：系统设置（仅 super）
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function stg_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if ($a['role'] === 'super') return $a;
    http_response_code(403);
    admin_head('无权限', 'settings');
    echo '<div class="adm-panel"><div class="adm-empty">系统设置仅超级管理员（super）可访问。</div></div>';
    admin_foot();
    exit;
}

function stg_back(): void
{
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? 'settings.php'));
    exit;
}

function stg_done(string $msg, array $data = []): void
{
    if (isset($_POST['ajax'])) ok($data, $msg);
    $_SESSION['adm_flash'] = $msg;
    stg_back();
}

function stg_err(string $msg): void
{
    if (isset($_POST['ajax'])) fail($msg);
    $_SESSION['adm_flash'] = $msg;
    stg_back();
}

function stg_flash(): string
{
    $m = (string)($_SESSION['adm_flash'] ?? '');
    unset($_SESSION['adm_flash']);
    return $m;
}

$admin = stg_allow();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'smtp_test') {
        // 使用当前表单值发一封测试邮件（未保存也可测）
        $to = trim((string)($_POST['test_to'] ?? ''));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) stg_err('请填写正确的收件邮箱');
        $conf = [
            'enabled' => true,
            'host'    => trim((string)($_POST['smtp_host'] ?? '')),
            'port'    => (int)($_POST['smtp_port'] ?? 465),
            'secure'  => (string)($_POST['smtp_secure'] ?? 'ssl'),
            'user'    => (string)($_POST['smtp_user'] ?? ''),
            'pass'    => (string)($_POST['smtp_pass'] ?? ''),
            'from'    => trim((string)($_POST['smtp_from'] ?? '')),
            'name'    => trim((string)($_POST['smtp_name'] ?? '')),
            'timeout' => 15,
        ];
        try {
            smtp_send($to, '【' . setting('site_name', 'CC商聊') . '】SMTP 测试邮件',
                '<p style="font-family:sans-serif">这是一封来自 CC商聊 后台的测试邮件，收到即表示 SMTP 配置可用。</p>',
                '这是一封来自 CC商聊 后台的测试邮件，收到即表示 SMTP 配置可用。', $conf);
            stg_done('测试邮件已发送，请查收');
        } catch (Throwable $e) {
            stg_err('发送失败：' . $e->getMessage());
        }
    }
    if ($act !== 'save') stg_err('未知操作');
    try {
        $siteName  = trim((string)($_POST['site_name'] ?? ''));
        $slogan    = trim((string)($_POST['site_slogan'] ?? ''));
        $logo      = trim((string)($_POST['site_logo'] ?? ''));
        $download  = trim((string)($_POST['app_download_url'] ?? ''));
        $serviceUid = trim((string)($_POST['service_uid'] ?? ''));
        $serviceContact = trim((string)($_POST['service_contact'] ?? ''));
        $officialGid = trim((string)($_POST['official_gid'] ?? ''));
        $inviteReward = (int)($_POST['invite_reward'] ?? 0);
        $withdrawMin  = (int)($_POST['withdraw_min'] ?? 0);
        $groupMax     = (int)($_POST['group_max_limit'] ?? 0);
        $registerOpen = (int)($_POST['register_open'] ?? 0) === 1 ? '1' : '0';
        $regIdLen     = (int)($_POST['reg_id_len'] ?? 8);
        $gidLen       = (int)($_POST['gid_len'] ?? 8);
        if ($regIdLen < 6) $regIdLen = 6;
        if ($regIdLen > 9) $regIdLen = 9;
        if ($gidLen < 6) $gidLen = 6;
        if ($gidLen > 9) $gidLen = 9;
        $svipMin      = (int)($_POST['svip_min_level'] ?? 4);
        if ($svipMin < 2) $svipMin = 2;
        if ($svipMin > 20) $svipMin = 20;
        $callEnabled  = (int)($_POST['call_enabled'] ?? 0) === 1 ? '1' : '0';
        $liveEnabled  = (int)($_POST['live_enabled'] ?? 0) === 1 ? '1' : '0';
        $noticeTitle  = trim((string)($_POST['notice_title'] ?? ''));
        $noticeContent = trim((string)($_POST['notice_content'] ?? ''));
        $termId       = mb_substr(trim((string)($_POST['term_id'] ?? '')), 0, 12);
        $termCoin     = mb_substr(trim((string)($_POST['term_coin'] ?? '')), 0, 12);
        $termPretty   = mb_substr(trim((string)($_POST['term_pretty'] ?? '')), 0, 12);
        $termMember   = mb_substr(trim((string)($_POST['term_member'] ?? '')), 0, 12);
        $smtpEnabled  = (int)($_POST['smtp_enabled'] ?? 0) === 1 ? '1' : '0';
        $smtpHost     = trim((string)($_POST['smtp_host'] ?? ''));
        $smtpPort     = (int)($_POST['smtp_port'] ?? 465);
        $smtpSecure   = in_array((string)($_POST['smtp_secure'] ?? 'ssl'), ['ssl', 'tls', 'none'], true) ? (string)$_POST['smtp_secure'] : 'ssl';
        $smtpUser     = trim((string)($_POST['smtp_user'] ?? ''));
        $smtpPass     = (string)($_POST['smtp_pass'] ?? '');
        $smtpFrom     = trim((string)($_POST['smtp_from'] ?? ''));
        $smtpName     = trim((string)($_POST['smtp_name'] ?? ''));
        $emailVerify  = (int)($_POST['email_verify'] ?? 0) === 1 ? '1' : '0';

        if ($siteName === '') stg_err('站点名称不能为空');
        if (mb_strlen($siteName) > 60) stg_err('站点名称过长');
        if ($slogan !== '' && mb_strlen($slogan) > 120) stg_err('标语过长');
        if ($download !== '' && !preg_match('#^(https?://|/)#i', $download)) stg_err('下载地址需以 http(s):// 或 / 开头');
        if ($serviceUid !== '' && !preg_match('/^[0-9A-Za-z_]{3,32}$/', $serviceUid)) stg_err('客服 CC号格式不正确');
        if ($officialGid !== '' && !preg_match('/^[0-9]{4,12}$/', $officialGid)) stg_err('官方群号应为 4-12 位数字');
        if ($inviteReward < 0 || $inviteReward > 100000) stg_err('邀请奖励需在 0 - 100000 之间');
        if ($withdrawMin < 1) stg_err('最低提现需大于 0');
        if ($groupMax < 1 || $groupMax > 100000) stg_err('群人数上限需在 1 - 100000 之间');
        if ($smtpEnabled === '1') {
            if ($smtpHost === '') stg_err('请填写 SMTP 服务器地址');
            if ($smtpPort < 1 || $smtpPort > 65535) stg_err('SMTP 端口不正确');
            if ($smtpFrom !== '' && !filter_var($smtpFrom, FILTER_VALIDATE_EMAIL)) stg_err('发件邮箱格式不正确');
            if ($smtpFrom === '' && !filter_var($smtpUser, FILTER_VALIDATE_EMAIL)) stg_err('请填写发件邮箱（smtp_from）');
        }
        if ($emailVerify === '1' && $smtpEnabled !== '1') stg_err('开启「注册邮箱验证」前请先启用并保存 SMTP');

        set_setting('site_name', $siteName);
        set_setting('site_slogan', $slogan);
        set_setting('site_logo', $logo);
        set_setting('app_download_url', $download);
        set_setting('service_uid', $serviceUid);
        set_setting('service_contact', $serviceContact);
        set_setting('official_gid', $officialGid);
        set_setting('invite_reward', (string)$inviteReward);
        set_setting('withdraw_min', (string)$withdrawMin);
        set_setting('group_max_limit', (string)$groupMax);
        set_setting('register_open', $registerOpen);
        set_setting('reg_id_len', (string)$regIdLen);
        set_setting('gid_len', (string)$gidLen);
        set_setting('svip_min_level', (string)$svipMin);
        set_setting('call_enabled', $callEnabled);
        set_setting('live_enabled', $liveEnabled);
        set_setting('notice_title', $noticeTitle);
        set_setting('notice_content', $noticeContent);
        set_setting('term_brand', $siteName);
        set_setting('term_id', $termId !== '' ? $termId : 'CC号');
        set_setting('term_coin', $termCoin !== '' ? $termCoin : 'CC币');
        set_setting('term_pretty', $termPretty !== '' ? $termPretty : '靓号');
        set_setting('term_member', $termMember !== '' ? $termMember : '会员');
        set_setting('smtp_enabled', $smtpEnabled);
        set_setting('smtp_host', $smtpHost);
        set_setting('smtp_port', (string)$smtpPort);
        set_setting('smtp_secure', $smtpSecure);
        set_setting('smtp_user', $smtpUser);
        if ($smtpPass !== '') set_setting('smtp_pass', $smtpPass);
        set_setting('smtp_from', $smtpFrom);
        set_setting('smtp_name', $smtpName);
        set_setting('email_verify', $emailVerify);
        admin_log('系统设置', '站点 ' . $siteName . ' / 客服 ' . $serviceUid . ' / 注册 ' . $registerOpen . ' / 通话 ' . $callEnabled . ' / 直播 ' . $liveEnabled);
        stg_done('系统设置已保存');
    } catch (Throwable $e) {
        stg_err('保存失败：' . $e->getMessage());
    }
}

$v = static function (string $k, string $d = ''): string {
    return (string)setting($k, $d);
};
$cfg = [
    'site_name'        => $v('site_name', 'CC商聊'),
    'site_slogan'      => $v('site_slogan', '连接每一次商机'),
    'site_logo'        => $v('site_logo', 'icons/icon-192.png'),
    'app_download_url' => $v('app_download_url', ''),
    'service_uid'      => $v('service_uid', '10086'),
    'service_contact'  => $v('service_contact', ''),
    'official_gid'     => $v('official_gid', '666666'),
    'invite_reward'    => (int)$v('invite_reward', '0'),
    'withdraw_min'     => (int)$v('withdraw_min', '100'),
    'group_max_limit'  => (int)$v('group_max_limit', '2000'),
    'register_open'    => $v('register_open', '1') === '1',
    'reg_id_len'       => (int)$v('reg_id_len', '8'),
    'gid_len'          => (int)$v('gid_len', '8'),
    'svip_min_level'   => (int)$v('svip_min_level', '4'),
    'term_id'          => $v('term_id', 'CC号'),
    'term_coin'        => $v('term_coin', 'CC币'),
    'term_pretty'      => $v('term_pretty', '靓号'),
    'term_member'      => $v('term_member', '会员'),
    'smtp_enabled'     => $v('smtp_enabled', '0') === '1',
    'smtp_host'        => $v('smtp_host', ''),
    'smtp_port'        => (int)$v('smtp_port', '465'),
    'smtp_secure'      => $v('smtp_secure', 'ssl'),
    'smtp_user'        => $v('smtp_user', ''),
    'smtp_from'        => $v('smtp_from', ''),
    'smtp_name'        => $v('smtp_name', ''),
    'smtp_has_pass'    => ((string)setting('smtp_pass', '')) !== '',
    'email_verify'     => $v('email_verify', '0') === '1',
    'call_enabled'     => $v('call_enabled', '1') === '1',
    'live_enabled'     => $v('live_enabled', '1') === '1',
    'notice_title'     => $v('notice_title', ''),
    'notice_content'   => $v('notice_content', ''),
];

$logoUrl = $cfg['site_logo'];
if ($logoUrl !== '' && !preg_match('#^https?://#i', $logoUrl)) $logoUrl = '../' . ltrim($logoUrl, '/');

$flash = stg_flash();
$title = '系统设置';
admin_head($title, 'settings');
?>
<?php if ($flash !== ''): ?>
<script>window.__admFlash = <?= json_encode($flash, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<?php endif; ?>

<form method="post" autocomplete="off">
<input type="hidden" name="act" value="save">

<div class="adm-panel">
  <div class="adm-panel-head"><h2>站点信息</h2><span class="sub">前台标题、Logo 与下载入口</span></div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>站点名称</label>
        <input class="adm-input" name="site_name" value="<?= e($cfg['site_name']) ?>" maxlength="60">
      </div>
      <div class="adm-field">
        <label>站点标语</label>
        <input class="adm-input" name="site_slogan" value="<?= e($cfg['site_slogan']) ?>" maxlength="120">
      </div>
      <div class="adm-field full">
        <label>Logo 地址</label>
        <input class="adm-input" name="site_logo" value="<?= e($cfg['site_logo']) ?>" placeholder="icons/icon-192.png 或 https://...">
        <div class="adm-hint">相对路径基于项目根目录；也可填完整 URL。</div>
      </div>
      <div class="adm-field full">
        <label>App 下载地址</label>
        <input class="adm-input" name="app_download_url" value="<?= e($cfg['app_download_url']) ?>" placeholder="https://example.com/app.apk">
      </div>
      <?php if ($logoUrl !== ''): ?>
        <div class="adm-field full">
          <label>Logo 预览</label>
          <img src="<?= e($logoUrl) ?>" alt="logo" style="width:64px;height:64px;object-fit:cover;border-radius:14px;border:1px solid #EBEEF4" onerror="this.style.display='none'">
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head"><h2>客服与官方群</h2></div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>客服 CC号</label>
        <input class="adm-input" name="service_uid" value="<?= e($cfg['service_uid']) ?>" placeholder="10086">
        <div class="adm-hint">前台「联系客服」「充值申请」会发消息给该账号。</div>
      </div>
      <div class="adm-field">
        <label>官方群号</label>
        <input class="adm-input" name="official_gid" value="<?= e($cfg['official_gid']) ?>" placeholder="666666">
      </div>
      <div class="adm-field full">
        <label>客服联系方式</label>
        <textarea class="adm-textarea" name="service_contact" style="min-height:80px"><?= e($cfg['service_contact']) ?></textarea>
        <div class="adm-hint">支持多行，前台按行展示。</div>
      </div>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head"><h2>奖励与限制</h2></div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>每人注册立得（CC币）</label>
        <input class="adm-input" type="number" min="0" max="100000" name="invite_reward" value="<?= (int)$cfg['invite_reward'] ?>">
        <div class="adm-hint">0 = 关闭（推荐）。阶梯奖励请到「邀请奖励」配置；此项为旧的「每邀请一人即得 CC币」模式，仅在被邀请人注册时立即发放给双方。</div>
      </div>
      <div class="adm-field">
        <label>最低提现（CC币）</label>
        <input class="adm-input" type="number" min="1" name="withdraw_min" value="<?= (int)$cfg['withdraw_min'] ?>">
      </div>
      <div class="adm-field">
        <label>群人数上限</label>
        <input class="adm-input" type="number" min="1" max="100000" name="group_max_limit" value="<?= (int)$cfg['group_max_limit'] ?>">
        <div class="adm-hint">新建群的默认上限，也用于升级上限的封顶。</div>
      </div>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head"><h2>功能开关</h2></div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>注册开关</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="register_open" value="1" <?= $cfg['register_open'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">关闭后前台无法注册</span>
        </div>
      </div>
      <div class="adm-field">
        <label>SVIP 起始等级</label>
        <input class="adm-input" type="number" min="2" max="20" step="1" name="svip_min_level" value="<?= (int)$cfg['svip_min_level'] ?>">
        <div class="adm-hint">会员等级 ≥ 该值即显示 SVIP 标识（默认 4，即 1-3 级为 VIP，4 级及以上为 SVIP）。套餐等级在「运营 → VIP 套餐」中设置。</div>
      </div>
      <div class="adm-field">
        <label>注册随机 CC号位数</label>
        <input class="adm-input" type="number" min="6" max="9" step="1" name="reg_id_len" value="<?= (int)$cfg['reg_id_len'] ?>">
        <div class="adm-hint">用户注册时系统随机分配的 CC号位数，范围 6 - 9 位（默认 8 位）。号码由系统生成，用户不可自定义。</div>
      </div>
      <div class="adm-field">
        <label>创建群聊随机群号位数</label>
        <input class="adm-input" type="number" min="6" max="9" step="1" name="gid_len" value="<?= (int)$cfg['gid_len'] ?>">
        <div class="adm-hint">新建群聊时系统随机生成的群号位数，范围 6 - 9 位（默认 8 位）。修改后仅对之后创建的群生效。</div>
      </div>
      <div class="adm-field">
        <label>通话开关</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="call_enabled" value="1" <?= $cfg['call_enabled'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">语音 / 视频通话</span>
        </div>
      </div>
      <div class="adm-field">
        <label>直播开关</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="live_enabled" value="1" <?= $cfg['live_enabled'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">直播创建与观看</span>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>名称与称号</h2>
    <span class="sub">改一处，全站生效（页面标题、按钮、提示、脚本文案、公告文字）</span>
  </div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>品牌 / 站点名称</label>
        <div class="adm-input" style="display:flex;align-items:center;background:#F4F6FA;color:#6B7280"><?= e($cfg['site_name']) ?></div>
        <div class="adm-hint">在上方「站点信息 → 站点名称」修改；凡页面出现「CC商聊」的地方都会替换成该名称（标题、PWA 名称、页面文案）。</div>
      </div>
      <div class="adm-field">
        <label>ID 称号</label>
        <input class="adm-input" name="term_id" value="<?= e($cfg['term_id']) ?>" maxlength="12" placeholder="CC号">
        <div class="adm-hint">如改成「JB号」，全站「CC号」自动变成「JB号」（含注册提示、搜索框、接口提示）。</div>
      </div>
      <div class="adm-field">
        <label>货币称号</label>
        <input class="adm-input" name="term_coin" value="<?= e($cfg['term_coin']) ?>" maxlength="12" placeholder="CC币">
      </div>
      <div class="adm-field">
        <label>靓号称号</label>
        <input class="adm-input" name="term_pretty" value="<?= e($cfg['term_pretty']) ?>" maxlength="12" placeholder="靓号">
      </div>
      <div class="adm-field">
        <label>会员称号</label>
        <input class="adm-input" name="term_member" value="<?= e($cfg['term_member']) ?>" maxlength="12" placeholder="会员">
        <div class="adm-hint">「会员」为通用词，替换范围包含「会员中心」「会员等级」等词组，建议保持默认或使用等长词。</div>
      </div>
    </div>
    <div class="adm-hint" style="margin-top:12px;padding:10px 12px;background:#F8FAFD;border-radius:10px;line-height:1.8">
      替换规则：<b>CC商聊 → <?= e($cfg['site_name']) ?></b> ·
      <b>CC号 → <?= e($cfg['term_id']) ?></b> ·
      <b>CC币 → <?= e($cfg['term_coin']) ?></b> ·
      <b>靓号 → <?= e($cfg['term_pretty']) ?></b> ·
      <b>会员 → <?= e($cfg['term_member']) ?></b><br>
      说明：替换发生在页面输出时，因此数据库里已有的公告、消息文字也会跟着显示为新称号，无需改数据。
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>邮件服务（SMTP）</h2>
    <span class="sub">用于注册邮箱验证与自助找回密码</span>
  </div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field">
        <label>启用 SMTP</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="smtp_enabled" value="1" <?= $cfg['smtp_enabled'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">关闭后无法发信，注册/找回密码也不会要求邮箱验证</span>
        </div>
      </div>
      <div class="adm-field">
        <label>注册邮箱验证</label>
        <div style="display:flex;align-items:center;gap:10px;height:40px">
          <label class="adm-switch"><input type="checkbox" name="email_verify" value="1" <?= $cfg['email_verify'] ? 'checked' : '' ?>><span></span></label>
          <span class="adm-hint" style="margin:0">开启：注册需填邮箱验证码、找回密码走邮箱；关闭：注册免验证、找回密码提示联系客服</span>
        </div>
      </div>
      <div class="adm-field">
        <label>SMTP 服务器</label>
        <input class="adm-input" name="smtp_host" value="<?= e($cfg['smtp_host']) ?>" placeholder="smtp.qq.com / smtp.exmail.qq.com">
      </div>
      <div class="adm-field">
        <label>端口</label>
        <input class="adm-input" type="number" name="smtp_port" value="<?= (int)$cfg['smtp_port'] ?>" placeholder="465">
      </div>
      <div class="adm-field">
        <label>加密方式</label>
        <select class="adm-select" name="smtp_secure">
          <option value="ssl" <?= $cfg['smtp_secure'] === 'ssl' ? 'selected' : '' ?>>SSL（465）</option>
          <option value="tls" <?= $cfg['smtp_secure'] === 'tls' ? 'selected' : '' ?>>STARTTLS（587）</option>
          <option value="none" <?= $cfg['smtp_secure'] === 'none' ? 'selected' : '' ?>>不加密（25）</option>
        </select>
      </div>
      <div class="adm-field">
        <label>SMTP 账号</label>
        <input class="adm-input" name="smtp_user" value="<?= e($cfg['smtp_user']) ?>" placeholder="通常与发件邮箱一致" autocomplete="off">
      </div>
      <div class="adm-field">
        <label>SMTP 密码 / 授权码</label>
        <input class="adm-input" type="password" name="smtp_pass" value="" placeholder="<?= $cfg['smtp_has_pass'] ? '已保存，留空表示不修改' : '企业邮箱授权码' ?>" autocomplete="new-password">
        <div class="adm-hint">QQ/163 邮箱请使用「授权码」，不是登录密码。</div>
      </div>
      <div class="adm-field">
        <label>发件邮箱</label>
        <input class="adm-input" name="smtp_from" value="<?= e($cfg['smtp_from']) ?>" placeholder="noreply@yourdomain.com">
      </div>
      <div class="adm-field">
        <label>发件人名称</label>
        <input class="adm-input" name="smtp_name" value="<?= e($cfg['smtp_name']) ?>" placeholder="<?= e($cfg['site_name']) ?>">
      </div>
    </div>
    <div class="adm-mail-test">
      <div class="mt-l">
        <b>发送测试邮件</b>
        <span>填写收件邮箱后点击测试（使用上方未保存的配置立即发送）</span>
      </div>
      <div class="mt-r">
        <input class="adm-input" id="smtpTestTo" placeholder="接收测试的邮箱">
        <button type="button" class="adm-btn ghost" id="btnSmtpTest">发送测试</button>
      </div>
    </div>
    <div class="adm-hint" style="margin-top:10px">常见配置：QQ 邮箱 smtp.qq.com:465(SSL)；163 邮箱 smtp.163.com:465(SSL)；Gmail smtp.gmail.com:465(SSL)。若服务器屏蔽 465，可改用 587 + STARTTLS。</div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head"><h2>公告默认内容</h2><span class="sub">仅作为新建公告的模板，不直接改前台公告</span></div>
  <div class="adm-panel-body">
    <div class="adm-form">
      <div class="adm-field full">
        <label>默认标题</label>
        <input class="adm-input" name="notice_title" value="<?= e($cfg['notice_title']) ?>" maxlength="120">
      </div>
      <div class="adm-field full">
        <label>默认内容</label>
        <textarea class="adm-textarea" name="notice_content" style="min-height:160px"><?= e($cfg['notice_content']) ?></textarea>
        <div class="adm-hint">需要真正发布公告，请到「公告管理」新增。</div>
      </div>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-body" style="display:flex;gap:12px;align-items:center">
    <button class="adm-btn" type="submit">保存全部设置</button>
    <span class="adm-hint" style="margin:0">保存后写入 admin_logs，前台即时生效</span>
  </div>
</div>
</form>

<script>
if (window.__admFlash) { ADM.toast(window.__admFlash); }

// SMTP 测试发信
(function(){
  var btn = document.getElementById('btnSmtpTest');
  if (!btn) return;
  btn.onclick = function(){
    var to = (document.getElementById('smtpTestTo').value || '').trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) { ADM.toast('请填写正确的收件邮箱'); return; }
    var form = document.querySelector('form[method=post]');
    var fd = new FormData(form);
    fd.set('act', 'smtp_test');
    fd.set('test_to', to);
    fd.set('ajax', '1');
    btn.disabled = true; btn.textContent = '发送中…';
    fetch(location.pathname, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(res){
        btn.disabled = false; btn.textContent = '发送测试';
        ADM.toast(res.msg || (res.code === 0 ? '已发送' : '发送失败'));
      })
      .catch(function(){ btn.disabled = false; btn.textContent = '发送测试'; ADM.toast('网络异常'); });
  };
})();
</script>
<?php admin_foot(); ?>
