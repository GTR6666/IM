<?php
/**
 * CC商聊 - 后台数据总览
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();

$todayStart = strtotime(date('Y-m-d'));
$todayEnd   = $todayStart + 86400;

$stat = [
    'user_today'      => (int)val('SELECT COUNT(*) FROM users WHERE created_at>=? AND created_at<?', [$todayStart, $todayEnd]),
    'user_total'      => (int)val('SELECT COUNT(*) FROM users'),
    'user_ban'        => (int)val('SELECT COUNT(*) FROM users WHERE status=1'),
    'msg_today'       => (int)val('SELECT COUNT(*) FROM messages WHERE created_at>=? AND created_at<? AND deleted=0', [$todayStart, $todayEnd]),
    'msg_total'       => (int)val('SELECT COUNT(*) FROM messages WHERE deleted=0'),
    'group_total'     => (int)val('SELECT COUNT(*) FROM groups WHERE status=1'),
    'moment_total'    => (int)val('SELECT COUNT(*) FROM moment WHERE deleted=0'),
    'recharge_today'  => (int)val('SELECT COALESCE(SUM(coin),0) FROM recharge_orders WHERE status=2 AND (paid_at>=? OR (paid_at=0 AND created_at>=?))', [$todayStart, $todayStart]),
    'recharge_pending'=> (int)val('SELECT COUNT(*) FROM recharge_orders WHERE status=1'),
    'withdraw_pending'=> (int)val('SELECT COUNT(*) FROM withdraw_orders WHERE status=0'),
    'report_pending'  => (int)val('SELECT COUNT(*) FROM reports WHERE status=0'),
    'appeal_pending'  => (int)val('SELECT COUNT(*) FROM appeals WHERE status=0'),
    'online'          => (int)val('SELECT COUNT(*) FROM users WHERE online=1'),
];

/* 7 日趋势：PHP 逐日聚合，避免方言差异 */
$userTrend = [];
$msgTrend  = [];
for ($i = 6; $i >= 0; $i--) {
    $s = $todayStart - $i * 86400;
    $t = $s + 86400;
    $label = date('m-d', $s);
    $userTrend[] = ['label' => $label, 'v' => (int)val('SELECT COUNT(*) FROM users WHERE created_at>=? AND created_at<?', [$s, $t])];
    $msgTrend[]  = ['label' => $label, 'v' => (int)val('SELECT COUNT(*) FROM messages WHERE created_at>=? AND created_at<? AND deleted=0', [$s, $t])];
}

function dash_bars(array $rows, string $color): string
{
    $max = 1;
    foreach ($rows as $r) $max = max($max, (int)$r['v']);
    $out = '<div style="display:flex;align-items:flex-end;gap:10px;height:176px;padding-top:6px">';
    foreach ($rows as $r) {
        $h = (int)round((int)$r['v'] / $max * 118);
        $h = max(3, $h);
        $out .= '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:6px">'
            . '<div style="font-size:11px;color:#6B7280;font-variant-numeric:tabular-nums">' . (int)$r['v'] . '</div>'
            . '<div style="width:100%;max-width:36px;height:' . $h . 'px;background:' . $color . ';border-radius:6px 6px 0 0"></div>'
            . '<div style="font-size:11px;color:#9AA0AC">' . e($r['label']) . '</div>'
            . '</div>';
    }
    return $out . '</div>';
}

$recentUsers = all('SELECT id,account,yx_id,pretty_yxid,nickname,avatar,coin,status,created_at,online FROM users ORDER BY id DESC LIMIT 10');
$recentRecharge = all('SELECT r.*, u.nickname, u.account FROM recharge_orders r LEFT JOIN users u ON u.id=r.uid ORDER BY r.id DESC LIMIT 10');
$isSuper = $admin['role'] === 'super';

admin_head('数据总览', 'dashboard');
?>
<div class="adm-cards">
  <div class="adm-stat">
    <div class="st-label">今日新增用户</div>
    <div class="st-value"><?= admin_money($stat['user_today']) ?></div>
    <div class="st-sub">总用户 <?= admin_money($stat['user_total']) ?> · 封禁 <?= admin_money($stat['user_ban']) ?></div>
    <div class="st-ico">👤</div>
  </div>
  <div class="adm-stat blue">
    <div class="st-label">今日消息</div>
    <div class="st-value"><?= admin_money($stat['msg_today']) ?></div>
    <div class="st-sub">总消息 <?= admin_money($stat['msg_total']) ?></div>
    <div class="st-ico">💬</div>
  </div>
  <div class="adm-stat purple">
    <div class="st-label">群组数</div>
    <div class="st-value"><?= admin_money($stat['group_total']) ?></div>
    <div class="st-sub">正常状态群</div>
    <div class="st-ico">👥</div>
  </div>
  <div class="adm-stat">
    <div class="st-label">动态数</div>
    <div class="st-value"><?= admin_money($stat['moment_total']) ?></div>
    <div class="st-sub">未删除动态</div>
    <div class="st-ico">🖼️</div>
  </div>
  <div class="adm-stat orange">
    <div class="st-label">今日充值 CC币</div>
    <div class="st-value"><?= admin_money($stat['recharge_today']) ?></div>
    <div class="st-sub">待审核充值单 <?= admin_money($stat['recharge_pending']) ?></div>
    <div class="st-ico">💰</div>
  </div>
  <div class="adm-stat red">
    <div class="st-label">待处理举报 / 申诉</div>
    <div class="st-value"><?= admin_money($stat['report_pending'] + $stat['appeal_pending']) ?></div>
    <div class="st-sub">举报 <?= admin_money($stat['report_pending']) ?> · 申诉 <?= admin_money($stat['appeal_pending']) ?></div>
    <div class="st-ico">🛡️</div>
  </div>
  <div class="adm-stat blue">
    <div class="st-label">待审核提现单</div>
    <div class="st-value"><?= admin_money($stat['withdraw_pending']) ?></div>
    <div class="st-sub">提现队列</div>
    <div class="st-ico">🏦</div>
  </div>
  <div class="adm-stat">
    <div class="st-label">在线用户</div>
    <div class="st-value"><?= admin_money($stat['online']) ?></div>
    <div class="st-sub">online=1</div>
    <div class="st-ico">🟢</div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>快捷入口</h2>
  </div>
  <div class="adm-panel-body">
    <div class="adm-toolbar">
      <?php if (admin_can('ops')): ?>
        <a class="adm-btn ghost" href="users.php">用户管理</a>
        <a class="adm-btn ghost" href="groups.php">群组管理</a>
        <a class="adm-btn ghost" href="messages.php">消息审计</a>
        <a class="adm-btn ghost" href="moments.php">动态管理</a>
        <a class="adm-btn ghost" href="live.php">直播 / 通话</a>
        <a class="adm-btn ghost" href="appeals.php">申诉 / 举报</a>
      <?php endif; ?>
      <?php if ($isSuper || $admin['role'] === 'finance'): ?>
        <a class="adm-btn ghost" href="recharge.php">充值 / USDT</a>
        <a class="adm-btn ghost" href="withdraw.php">提现审核</a>
        <a class="adm-btn ghost" href="wallet_logs.php">资金流水</a>
      <?php endif; ?>
      <?php if ($isSuper): ?>
        <a class="adm-btn ghost" href="logs.php">操作日志</a>
        <a class="adm-btn ghost" href="settings.php">系统设置</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>近 7 日趋势</h2>
    <span class="sub"><?= e(date('Y-m-d', $todayStart - 6 * 86400)) ?> 至 <?= e(date('Y-m-d', $todayStart)) ?></span>
  </div>
  <div class="adm-panel-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:22px">
    <div>
      <div style="font-size:12.5px;color:#6B7280;margin-bottom:6px">注册用户 / 日</div>
      <?= dash_bars($userTrend, 'linear-gradient(180deg,#07C160,#4ADE80)') ?>
    </div>
    <div>
      <div style="font-size:12.5px;color:#6B7280;margin-bottom:6px">消息量 / 日</div>
      <?= dash_bars($msgTrend, 'linear-gradient(180deg,#3B82F6,#93C5FD)') ?>
    </div>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>最近注册用户</h2>
    <a class="adm-btn sm ghost" href="users.php">查看全部</a>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>用户</th><th>CC号</th><th>CC币</th><th>状态</th><th>注册时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$recentUsers): ?>
        <tr><td colspan="6"><div class="adm-empty">暂无用户</div></td></tr>
      <?php endif; ?>
      <?php foreach ($recentUsers as $u): ?>
        <?php
          $yxid = $u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account']);
          $st = (int)$u['status'];
          $stText = $st === 1 ? '封禁' : ($st === 2 ? '已删除' : '正常');
          $stTag = $st === 1 ? 'red' : ($st === 2 ? 'gray' : 'green');
        ?>
        <tr>
          <td><?= (int)$u['id'] ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if ($u['avatar']): ?><img src="<?= e('../' . $u['avatar']) ?>" alt=""><?php else: ?><?= e(mb_substr($u['nickname'] ?: 'U', 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e($u['nickname'] ?: '未设置昵称') ?></div>
                <div class="sub"><?= (int)$u['online'] === 1 ? '<span style="color:#059669">在线</span>' : '离线' ?></div>
              </div>
            </div>
          </td>
          <td><?= e($yxid) ?></td>
          <td class="num"><?= admin_money((int)$u['coin']) ?></td>
          <td><span class="tag <?= $stTag ?>"><?= $stText ?></span></td>
          <td><?= e(date('Y-m-d H:i', (int)$u['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>最近充值订单</h2>
    <?php if ($isSuper || $admin['role'] === 'finance'): ?><a class="adm-btn sm ghost" href="recharge.php">充值审核</a><?php endif; ?>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>订单号</th><th>用户</th><th>CC币</th><th>USDT</th><th>状态</th><th>创建时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$recentRecharge): ?>
        <tr><td colspan="6"><div class="adm-empty">暂无充值订单</div></td></tr>
      <?php endif; ?>
      <?php
      $orderTags = [0 => ['待支付', 'gray'], 1 => ['待审核', 'orange'], 2 => ['已到账', 'green'], 3 => ['已拒绝', 'red']];
      foreach ($recentRecharge as $r):
          $t = $orderTags[(int)$r['status']] ?? ['未知', 'gray'];
      ?>
        <tr>
          <td style="font-family:ui-monospace,Consolas,monospace;font-size:12px"><?= e($r['order_no']) ?></td>
          <td>
            <div class="nm"><?= e($r['nickname'] ?: ('UID ' . (int)$r['uid'])) ?></div>
            <div class="sub"><?= e($r['account']) ?></div>
          </td>
          <td class="num"><?= admin_money((int)$r['coin']) ?></td>
          <td class="num"><?= e($r['amount_usdt']) ?></td>
          <td><span class="tag <?= $t[1] ?>"><?= $t[0] ?></span></td>
          <td><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php
admin_foot();
