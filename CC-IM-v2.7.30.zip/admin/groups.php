<?php
/**
 * CC商聊 - 群组管理
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'groups');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;

/* ---------- 写操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    $gid = (int)($_POST['gid'] ?? 0);
    $g = $gid > 0 ? group_by_gid($gid) : null;
    try {
        if (!$g) throw new RuntimeException('群不存在');
        switch ($act) {
            case 'dissolve':
                if ((int)$g['status'] !== 1) throw new RuntimeException('该群已解散');
                push_message(['ctype' => 2, 'from_uid' => 0, 'gid' => $gid, 'type' => 11, 'content' => '该群已被管理员解散']);
                q('UPDATE groups SET status=0 WHERE gid=?', [$gid]);
                q('UPDATE conversations SET visible=0 WHERE ctype=2 AND peer_id=?', [$gid]);
                admin_log('dissolve_group', 'gid=' . $gid . ' name=' . $g['name']);
                $msg = '已解散群「' . $g['name'] . '」';
                break;
            case 'purge':
                if (($admin['role'] ?? '') !== 'super') throw new RuntimeException('仅超级管理员可彻底删除群组');
                $st = admin_purge_group($gid);
                $total = 0;
                foreach ($st as $k => $v) { if (is_int($v)) $total += $v; }
                admin_log('purge_group', 'gid=' . $gid . ' name=' . $g['name'] . ' rows=' . $total);
                $msg = '已彻底删除群「' . $g['name'] . '」（共清理 ' . $total . ' 条数据）';
                break;
            case 'transfer':
                $to = (int)($_POST['to_uid'] ?? 0);
                if ($to <= 0) throw new RuntimeException('请输入新群主 UID');
                $m = group_member($gid, $to);
                if (!$m) throw new RuntimeException('该用户不在群内');
                $old = (int)$g['owner_uid'];
                q('UPDATE groups SET owner_uid=? WHERE gid=?', [$to, $gid]);
                q('UPDATE group_members SET role=2 WHERE gid=? AND uid=?', [$gid, $to]);
                q('UPDATE group_members SET role=0 WHERE gid=? AND uid=?', [$gid, $old]);
                push_message(['ctype' => 2, 'from_uid' => 0, 'gid' => $gid, 'type' => 11, 'content' => '群主已变更为 UID ' . $to]);
                admin_log('transfer_group', 'gid=' . $gid . ' name=' . $g['name'] . ' old=' . $old . ' new=' . $to);
                $msg = '已将群主转让给 UID ' . $to;
                break;
            case 'limit':
                $limit = (int)($_POST['limit'] ?? 100);
                if (!in_array($limit, [100, 500, 2000], true)) throw new RuntimeException('上限只能是 100 / 500 / 2000');
                q('UPDATE groups SET member_limit=? WHERE gid=?', [$limit, $gid]);
                admin_log('group_member_limit', 'gid=' . $gid . ' name=' . $g['name'] . ' limit=' . $limit);
                $msg = '群成员上限已改为 ' . $limit;
                break;
            case 'notice':
                $content = trim((string)($_POST['content'] ?? ''));
                if ($content === '') throw new RuntimeException('公告内容不能为空');
                $content = mb_substr($content, 0, 500);
                q('INSERT INTO group_notices (gid,uid,content,created_at) VALUES (?,?,?,?)', [$gid, (int)$admin['id'], $content, now()]);
                push_message(['ctype' => 2, 'from_uid' => 0, 'gid' => $gid, 'type' => 11, 'content' => '【群公告】' . $content]);
                admin_log('group_notice', 'gid=' . $gid . ' name=' . $g['name'] . ' content=' . $content);
                $msg = '群公告已发布并推送系统消息';
                break;
            default:
                $msg = '未知操作';
                $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 列表 ---------- */
$kw = trim((string)($_GET['kw'] ?? ''));
$fStatus = (string)($_GET['status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 20;

$where = [];
$par = [];
if ($kw !== '') {
    $where[] = '(g.name LIKE ? OR g.gid LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($par, $like, $like);
}
if (in_array($fStatus, ['0', '1'], true)) {
    $where[] = 'g.status=?';
    $par[] = (int)$fStatus;
}
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$total = (int)val('SELECT COUNT(*) FROM groups g' . $w, $par);
$rows = all('SELECT g.*, u.nickname AS owner_name, u.account AS owner_account,
        (SELECT COUNT(*) FROM group_members gm WHERE gm.gid=g.gid) AS member_count
    FROM groups g LEFT JOIN users u ON u.id=g.owner_uid' . $w . '
    ORDER BY g.gid DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);

/* ---------- 成员数据 ---------- */
$members = [];
if ($rows) {
    $gids = array_map(static fn($r) => (int)$r['gid'], $rows);
    $in = implode(',', array_fill(0, count($gids), '?'));
    $list = all('SELECT gm.gid, gm.uid, gm.role, gm.joined_at, gm.mute_until, u.nickname, u.account, u.avatar
        FROM group_members gm LEFT JOIN users u ON u.id=gm.uid
        WHERE gm.gid IN (' . $in . ') ORDER BY gm.role DESC, gm.id ASC', $gids);
    foreach ($list as $m) {
        $g = (int)$m['gid'];
        if (count($members[$g] ?? []) >= 200) continue;
        $members[$g][] = [
            'uid' => (int)$m['uid'],
            'nickname' => (string)($m['nickname'] ?: ('用户' . $m['uid'])),
            'account' => (string)$m['account'],
            'role' => (int)$m['role'],
            'joined_at' => (int)$m['joined_at'],
            'avatar' => (string)($m['avatar'] ?: ''),
        ];
    }
}

$postUrl = 'groups.php?' . admin_qs();
$pagerUrl = 'groups.php?' . admin_qs();

admin_head('群组管理', 'groups');
?>
<?php if ($msg !== ''): ?>
<div class="adm-panel" style="border-left:4px solid <?= $msgOk ? '#07C160' : '#EF4444' ?>">
  <div class="adm-panel-body" style="padding:12px 18px;color:<?= $msgOk ? '#059669' : '#DC2626' ?>;font-size:13px"><?= e($msg) ?></div>
</div>
<?php endif; ?>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>群列表 <span class="sub">共 <?= admin_money($total) ?> 个</span></h2>
    <form class="adm-toolbar" method="get" action="groups.php">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="群号 / 群名称" style="width:200px">
      <select class="adm-select" name="status">
        <option value="">全部状态</option>
        <option value="1" <?= $fStatus === '1' ? 'selected' : '' ?>>正常</option>
        <option value="0" <?= $fStatus === '0' ? 'selected' : '' ?>>已解散</option>
      </select>
      <button class="adm-btn" type="submit">搜索</button>
      <?php if ($kw !== '' || $fStatus !== ''): ?><a class="adm-btn ghost" href="groups.php">重置</a><?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>群号</th><th>群名称</th><th>群主</th><th>成员 / 上限</th><th>状态</th><th>创建时间</th><th>操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7"><div class="adm-empty">没有匹配的群</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $g): ?>
        <?php
          $gid = (int)$g['gid'];
          $st = (int)$g['status'];
          $cnt = (int)$g['member_count'];
          $limit = (int)$g['member_limit'];
        ?>
        <tr>
          <td style="font-variant-numeric:tabular-nums;font-weight:600"><?= $gid ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if ($g['avatar']): ?><img src="<?= e('../' . $g['avatar']) ?>" alt=""><?php else: ?>👥<?php endif; ?></div>
              <div>
                <div class="nm"><?= e($g['name']) ?></div>
                <div class="sub"><?= e(mb_substr((string)$g['intro'], 0, 40)) ?></div>
              </div>
            </div>
          </td>
          <td>
            <div class="nm"><?= e($g['owner_name'] ?: '未知') ?></div>
            <div class="sub">UID <?= (int)$g['owner_uid'] ?></div>
          </td>
          <td class="num"><?= $cnt ?> / <?= $limit ?>
            <div style="margin-top:4px;width:72px;height:5px;background:#EEF1F6;border-radius:3px;overflow:hidden">
              <div style="height:100%;width:<?= min(100, $limit > 0 ? (int)round($cnt / $limit * 100) : 0) ?>%;background:<?= $cnt >= $limit ? '#EF4444' : '#07C160' ?>"></div>
            </div>
          </td>
          <td><span class="tag <?= $st === 1 ? 'green' : 'gray' ?>"><?= $st === 1 ? '正常' : '已解散' ?></span></td>
          <td><?= e(date('Y-m-d H:i', (int)$g['created_at'])) ?></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" type="button" onclick="openMembers(<?= $gid ?>)">成员</button>
              <?php if ($st === 1): ?>
                <button class="adm-btn sm ghost" type="button" onclick="openTransfer(<?= $gid ?>)">转让群主</button>
                <button class="adm-btn sm ghost" type="button" onclick="openLimit(<?= $gid ?>,<?= $limit ?>)">改上限</button>
                <button class="adm-btn sm ghost" type="button" onclick="openNotice(<?= $gid ?>)">发公告</button>
                <button class="adm-btn sm danger" type="button" onclick="doAct('dissolve',<?= $gid ?>,'解散后该群将不可再用，确认解散？')">解散</button>
                <?php if (($admin['role'] ?? '') === 'super'): ?>
                <button class="adm-btn sm danger" type="button" onclick="openPurgeGroup(<?= (int)$gid ?>)" style="background:#7F1D1D">彻底删除</button>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $pagerUrl) ?>
</div>

<form id="actForm" method="post" action="<?= e($postUrl) ?>" style="display:none"></form>

<script>
var GMEMBERS = <?= json_encode($members, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var GNAMES = <?= json_encode(array_map(static fn($r) => (string)$r['name'], array_column($rows, null, 'gid')), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var POST_URL = <?= json_encode($postUrl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var NOW = <?= now() ?>;

function submitAct(act, gid, extra) {
  var h = '<input type="hidden" name="act" value="' + ADM.esc(act) + '">' +
          '<input type="hidden" name="gid" value="' + ADM.esc(gid) + '">';
  Object.keys(extra || {}).forEach(function (k) {
    h += '<input type="hidden" name="' + ADM.esc(k) + '" value="' + ADM.esc(extra[k]) + '">';
  });
  var f = document.getElementById('actForm');
  f.innerHTML = h;
  f.submit();
}

function openPurgeGroup(gid) {
  var html = '<div style="background:#FEF2F2;border:1px solid #FBD5D5;border-radius:10px;padding:12px 14px;color:#B91C1C;font-size:12.5px;line-height:1.8">' +
    '<b>此操作不可恢复！</b><br>将永久删除群号 <b>' + gid + '</b> 的全部数据：群资料、成员关系、群消息、会话、群公告、入群申请、群直播与礼物记录。' +
    '</div>' +
    '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="purge"><input type="hidden" name="gid" value="' + gid + '">' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:18px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn danger" style="background:#7F1D1D">确认删除</button></div></form>';
  ADM.modal({ title: '彻底删除群组 · ' + gid, html: html, footer: false });
}

function doAct(act, gid, text) {
  ADM.confirm({ title: '确认操作', text: text, danger: act === 'dissolve' }).then(function (v) {
    if (v) submitAct(act, gid, {});
  });
}

function openMembers(gid) {
  var list = GMEMBERS[gid] || [];
  var name = GNAMES[gid] || ('群 ' + gid);
  var html = '<div class="adm-hint" style="margin-bottom:10px">共 ' + list.length + ' 位成员（最多显示 200 位）</div>';
  if (!list.length) {
    html += '<div class="adm-empty">暂无成员</div>';
  } else {
    html += '<div style="max-height:420px;overflow:auto">';
    list.forEach(function (m) {
      var role = m.role === 2 ? '<span class="tag orange">群主</span>' : (m.role === 1 ? '<span class="tag blue">管理员</span>' : '<span class="tag gray">成员</span>');
      html += '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #F2F4F8">' +
        '<div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:500">' + ADM.esc(m.nickname) +
        ' <span style="color:#9AA0AC;font-weight:400">UID ' + m.uid + '</span></div>' +
        '<div style="font-size:11.5px;color:#9AA0AC">CC号 ' + ADM.esc(m.account) + ' · 加入 ' + ADM.fmt(m.joined_at) + '</div></div>' +
        role + '</div>';
    });
    html += '</div>';
  }
  ADM.modal({ title: '群成员 · ' + name, html: html });
}

function openTransfer(gid) {
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="transfer"><input type="hidden" name="gid" value="' + gid + '">' +
    '<div class="adm-field"><label>新群主 UID</label><input class="adm-input" name="to_uid" type="number" min="1" placeholder="必须是群成员" required></div>' +
    '<div class="adm-hint">转让后原群主降为普通成员。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn">确认转让</button></div></form>';
  ADM.modal({ title: '转让群主', html: html });
}

function openLimit(gid, cur) {
  var opts = [100, 500, 2000].map(function (n) {
    return '<option value="' + n + '"' + (n === cur ? ' selected' : '') + '>' + n + ' 人</option>';
  }).join('');
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="limit"><input type="hidden" name="gid" value="' + gid + '">' +
    '<div class="adm-field"><label>成员上限</label><select class="adm-select" name="limit">' + opts + '</select></div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn">保存</button></div></form>';
  ADM.modal({ title: '修改群成员上限', html: html });
}

function openNotice(gid) {
  var html = '<form method="post" action="' + POST_URL + '">' +
    '<input type="hidden" name="act" value="notice"><input type="hidden" name="gid" value="' + gid + '">' +
    '<div class="adm-field full"><label>群公告内容</label><textarea class="adm-textarea" name="content" maxlength="500" placeholder="例如：本群禁止发布广告，违者移出"></textarea></div>' +
    '<div class="adm-hint">发布后写入群公告并在群内推送一条系统消息。</div>' +
    '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
    '<button type="button" class="adm-btn ghost" data-close="1">取消</button>' +
    '<button type="submit" class="adm-btn">发布公告</button></div></form>';
  ADM.modal({ title: '发布群公告', html: html });
}
</script>
<?php
admin_foot();
