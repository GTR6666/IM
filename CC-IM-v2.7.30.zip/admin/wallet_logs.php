<?php
/**
 * CC商聊 - 后台：资金流水
 * wallet_logs 分页 / 用户 / 方向 / 业务类型 / 日期筛选 / 汇总 / CSV
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';

function wl_allow(): array
{
    $a = admin_current();
    if (!$a) {
        header('Location: login.php');
        exit;
    }
    if (in_array($a['role'], ['super', 'finance'], true)) return $a;
    http_response_code(403);
    admin_head('无权限', 'wallet');
    echo '<div class="adm-panel"><div class="adm-empty">当前账号（' . e((string)$a['role']) . '）没有资金流水权限。</div></div>';
    admin_foot();
    exit;
}

function wl_day0(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 00:00:00');
    return $t ?: 0;
}

function wl_day1(string $s): int
{
    $s = trim($s);
    if ($s === '') return 0;
    $t = strtotime($s . ' 23:59:59');
    return $t ?: 0;
}

/** 业务类型中文名 */
function wl_biz_name(string $b): string
{
    $map = [
        'usdt_recharge'   => 'USDT 充值',
        'manual_recharge' => '人工充值',
        'recharge'        => '充值',
        'withdraw'        => '提现',
        'withdraw_refund' => '提现退回',
        'transfer'        => '转账',
        'redpacket'       => '红包',
        'gift'            => '礼物',
        'vip'             => '会员',
        'pretty'          => '靓号',
        'invite'          => '邀请奖励',
        'system'          => '系统调整',
        'admin'           => '后台调整',
    ];
    return $map[$b] ?? ($b !== '' ? $b : '其他');
}

$admin = wl_allow();

/* =========================================================
 * 筛选
 * ========================================================= */
$kw    = trim((string)($_GET['kw'] ?? ''));
$fDir  = (string)($_GET['direction'] ?? '');
$fBiz  = trim((string)($_GET['biz'] ?? ''));
$d1    = trim((string)($_GET['d1'] ?? ''));
$d2    = trim((string)($_GET['d2'] ?? ''));
$t1    = wl_day0($d1);
$t2    = wl_day1($d2);

$w = [];
$p = [];
if ($kw !== '') {
    $w[] = '(l.uid=? OR u.account LIKE ? OR u.nickname LIKE ? OR u.yx_id LIKE ? OR l.remark LIKE ?)';
    $p[] = is_numeric($kw) ? (int)$kw : -1;
    $like = '%' . $kw . '%';
    foreach ([1, 2, 3, 4] as $_) $p[] = $like;
}
if ($fDir === '1' || $fDir === '2') {
    $w[] = 'l.direction=?';
    $p[] = (int)$fDir;
}
if ($fBiz !== '') {
    $w[] = 'l.biz=?';
    $p[] = $fBiz;
}
if ($t1 > 0) {
    $w[] = 'l.created_at>=?';
    $p[] = $t1;
}
if ($t2 > 0) {
    $w[] = 'l.created_at<=?';
    $p[] = $t2;
}
$where = $w ? (' WHERE ' . implode(' AND ', $w)) : '';
$sqlFrom = ' FROM wallet_logs l LEFT JOIN users u ON u.id=l.uid' . $where;

/* 业务类型下拉 */
$bizList = [];
try {
    $bizList = all('SELECT biz, COUNT(*) AS n FROM wallet_logs GROUP BY biz ORDER BY n DESC LIMIT 60');
} catch (Throwable $e) {
}

/* ---------- CSV ---------- */
if (isset($_GET['export']) && (string)$_GET['export'] === '1') {
    $rows = all('SELECT l.*, u.account, u.nickname' . $sqlFrom . ' ORDER BY l.id DESC LIMIT 50000', $p);
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="wallet_logs_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');
    echo "\xEF\xBB\xBF";
    $fp = fopen('php://output', 'w');
    if ($fp) {
        fputcsv($fp, ['ID', '用户CC号', '昵称', '方向', '金额', '余额', '业务', '业务ID', '备注', '时间'], ',', '"', '\\');
        foreach ($rows as $r) {
            fputcsv($fp, [
                (int)$r['id'],
                csv_safe((string)($r['account'] ?? '')),
                csv_safe((string)($r['nickname'] ?? '')),
                (int)$r['direction'] === 1 ? '收入' : '支出',
                (int)$r['amount'],
                (int)$r['balance_after'],
                csv_safe(wl_biz_name((string)$r['biz'])),
                (int)$r['biz_id'],
                csv_safe((string)$r['remark']),
                $r['created_at'] ? date('Y-m-d H:i:s', (int)$r['created_at']) : '',
            ], ',', '"', '\\');
        }
        fclose($fp);
    }
    admin_log('流水导出', '导出 ' . count($rows) . ' 条资金流水');
    exit;
}

/* ---------- 汇总（按当前筛选） ---------- */
$sum = one('SELECT COALESCE(SUM(CASE WHEN l.direction=1 THEN l.amount ELSE 0 END),0) AS inc,
                   COALESCE(SUM(CASE WHEN l.direction=2 THEN l.amount ELSE 0 END),0) AS exp,
                   COUNT(*) AS n' . $sqlFrom, $p) ?: ['inc' => 0, 'exp' => 0, 'n' => 0];
$sumInc = (int)$sum['inc'];
$sumExp = (int)$sum['exp'];

/* ---------- 分页 ---------- */
$total = (int)val('SELECT COUNT(*)' . $sqlFrom, $p);
$page  = max(1, (int)($_GET['page'] ?? 1));
$per   = 20;
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per;
$rows = all('SELECT l.*, u.account, u.nickname, u.yx_id, u.avatar' . $sqlFrom . ' ORDER BY l.id DESC LIMIT ' . $per . ' OFFSET ' . $offset, $p);

$fq = $_GET;
unset($fq['page'], $fq['export']);
$qs = http_build_query($fq);
$baseUrl = '?' . ($qs !== '' ? $qs . '&' : '');

/* 全站汇总（不受筛选影响） */
$allSum = one('SELECT COALESCE(SUM(CASE WHEN direction=1 THEN amount ELSE 0 END),0) AS inc,
                      COALESCE(SUM(CASE WHEN direction=2 THEN amount ELSE 0 END),0) AS exp FROM wallet_logs')
    ?: ['inc' => 0, 'exp' => 0];

$title = '资金流水';
admin_head($title, 'wallet');
?>

<div class="adm-cards">
  <div class="adm-stat"><div class="st-ico">⬆️</div><div class="st-label">筛选范围 · 总收入</div><div class="st-value" style="color:#07C160"><?= number_format($sumInc) ?></div><div class="st-sub">CC币 · <?= number_format((int)$sum['n']) ?> 条流水</div></div>
  <div class="adm-stat red"><div class="st-ico">⬇️</div><div class="st-label">筛选范围 · 总支出</div><div class="st-value" style="color:#EF4444"><?= number_format($sumExp) ?></div><div class="st-sub">CC币</div></div>
  <div class="adm-stat blue"><div class="st-ico">📊</div><div class="st-label">筛选范围 · 净额</div><div class="st-value"><?= ($sumInc - $sumExp >= 0 ? '+' : '') . number_format($sumInc - $sumExp) ?></div><div class="st-sub">CC币</div></div>
  <div class="adm-stat purple"><div class="st-ico">🌐</div><div class="st-label">全站净额</div><div class="st-value"><?= number_format((int)$allSum['inc'] - (int)$allSum['exp']) ?></div><div class="st-sub">收入 <?= number_format((int)$allSum['inc']) ?> / 支出 <?= number_format((int)$allSum['exp']) ?></div></div>
</div>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>资金流水<span class="sub">共 <?= number_format($total) ?> 条</span></h2>
    <a class="adm-btn ghost sm" href="<?= e($baseUrl) ?>export=1">导出 CSV</a>
  </div>
  <div class="adm-panel-body" style="padding-bottom:0">
    <form method="get" class="adm-toolbar" style="margin-bottom:14px">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="用户 ID / CC号 / 昵称 / 备注" style="min-width:200px">
      <select class="adm-select" name="direction">
        <option value="">全部方向</option>
        <option value="1" <?= $fDir === '1' ? 'selected' : '' ?>>收入</option>
        <option value="2" <?= $fDir === '2' ? 'selected' : '' ?>>支出</option>
      </select>
      <select class="adm-select" name="biz">
        <option value="">全部业务</option>
        <?php foreach ($bizList as $b): ?>
          <option value="<?= e((string)$b['biz']) ?>" <?= $fBiz === (string)$b['biz'] ? 'selected' : '' ?>>
            <?= e(wl_biz_name((string)$b['biz'])) ?>（<?= (int)$b['n'] ?>）
          </option>
        <?php endforeach; ?>
      </select>
      <input class="adm-input" type="date" name="d1" value="<?= e($d1) ?>">
      <input class="adm-input" type="date" name="d2" value="<?= e($d2) ?>">
      <button class="adm-btn" type="submit">筛选</button>
      <a class="adm-btn ghost" href="wallet_logs.php">重置</a>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>用户</th><th>方向</th><th>金额</th><th>余额</th><th>业务</th><th>备注</th><th>时间</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="8"><div class="adm-empty">没有符合条件的资金流水</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <?php $in = (int)$r['direction'] === 1; ?>
        <tr>
          <td class="sub">#<?= (int)$r['id'] ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if (!empty($r['avatar'])): ?><img src="../<?= e(ltrim((string)$r['avatar'], '/')) ?>" alt=""><?php else: ?><?= e(mb_substr((string)($r['nickname'] ?: ($r['account'] ?? '?')), 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e((string)($r['nickname'] ?? '已注销用户')) ?></div>
                <div class="sub">CC <?= e((string)($r['account'] ?? '-')) ?> · UID <?= (int)$r['uid'] ?></div>
              </div>
            </div>
          </td>
          <td><span class="tag <?= $in ? 'green' : 'red' ?>"><?= $in ? '收入' : '支出' ?></span></td>
          <td class="num" style="color:<?= $in ? '#059669' : '#DC2626' ?>"><?= ($in ? '+' : '-') . number_format((int)$r['amount']) ?></td>
          <td class="num"><?= number_format((int)$r['balance_after']) ?></td>
          <td><span class="tag gray"><?= e(wl_biz_name((string)$r['biz'])) ?></span><?php if ((int)$r['biz_id'] > 0): ?><div class="sub">#<?= (int)$r['biz_id'] ?></div><?php endif; ?></td>
          <td><span class="sub" style="font-size:12px;color:#4B5563"><?= e((string)$r['remark']) ?></span></td>
          <td><span class="sub"><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $baseUrl) ?>
</div>
<?php admin_foot(); ?>
