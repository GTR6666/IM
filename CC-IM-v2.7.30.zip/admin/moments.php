<?php
/**
 * CC商聊 - 动态管理
 */
declare(strict_types=1);
require __DIR__ . '/lib.php';
$admin = admin_require();
if (!admin_can('ops')) {
    admin_head('无权限', 'moments');
    echo '<div class="adm-empty">无权限</div>';
    admin_foot();
    exit;
}

$msg = '';
$msgOk = true;

/* ---------- 写操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $m = $id > 0 ? one('SELECT * FROM moment WHERE id=?', [$id]) : null;
            if (!$m) throw new RuntimeException('动态不存在');
            q('UPDATE moment SET deleted=1 WHERE id=?', [$id]);
            admin_log('delete_moment', 'mid=' . $id . ' uid=' . $m['uid'] . ' content=' . mb_substr((string)$m['content'], 0, 80));
            $msg = '已删除动态 #' . $id;
        } elseif ($act === 'del_comment') {
            $cid = (int)($_POST['cid'] ?? 0);
            $c = $cid > 0 ? one('SELECT * FROM moment_comments WHERE id=?', [$cid]) : null;
            if (!$c) throw new RuntimeException('评论不存在');
            q('UPDATE moment_comments SET deleted=1 WHERE id=?', [$cid]);
            admin_log('delete_moment_comment', 'cid=' . $cid . ' mid=' . $c['mid'] . ' uid=' . $c['uid'] . ' content=' . mb_substr((string)$c['content'], 0, 80));
            $msg = '已删除评论 #' . $cid;
        } else {
            $msg = '未知操作';
            $msgOk = false;
        }
    } catch (Throwable $e) {
        $msg = '操作失败：' . $e->getMessage();
        $msgOk = false;
    }
}

/* ---------- 列表 ---------- */
$kw = trim((string)($_GET['kw'] ?? ''));
$fStatus = (string)($_GET['state'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 20;

$where = [];
$par = [];
if ($kw !== '') {
    $where[] = '(m.content LIKE ? OR u.nickname LIKE ? OR u.account LIKE ?)';
    $like = '%' . $kw . '%';
    array_push($par, $like, $like, $like);
}
if ($fStatus === 'normal') $where[] = 'm.deleted=0';
elseif ($fStatus === 'deleted') $where[] = 'm.deleted=1';
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$total = (int)val('SELECT COUNT(*) FROM moment m LEFT JOIN users u ON u.id=m.uid' . $w, $par);
$rows = all('SELECT m.*, u.nickname, u.account, u.avatar,
        (SELECT COUNT(*) FROM moment_likes l WHERE l.mid=m.id) AS likes,
        (SELECT COUNT(*) FROM moment_comments c WHERE c.mid=m.id AND c.deleted=0) AS comments
    FROM moment m LEFT JOIN users u ON u.id=m.uid' . $w . '
    ORDER BY m.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);

/* ---------- 动态明细（图片 / 评论） ---------- */
$mids = array_map(static fn($r) => (int)$r['id'], $rows);
$comments = [];
$imgs = [];
if ($mids) {
    $in = implode(',', array_fill(0, count($mids), '?'));
    $cs = all('SELECT c.id, c.mid, c.uid, c.reply_uid, c.content, c.created_at, u.nickname, u.account
        FROM moment_comments c LEFT JOIN users u ON u.id=c.uid
        WHERE c.mid IN (' . $in . ') AND c.deleted=0 ORDER BY c.id DESC', $mids);
    foreach ($cs as $c) {
        $mid = (int)$c['mid'];
        if (count($comments[$mid] ?? []) >= 100) continue;
        $comments[$mid][] = [
            'id' => (int)$c['id'],
            'uid' => (int)$c['uid'],
            'nickname' => (string)($c['nickname'] ?: ('UID ' . $c['uid'])),
            'content' => (string)$c['content'],
            'created_at' => (int)$c['created_at'],
        ];
    }
    foreach ($rows as $r) {
        $arr = json_decode_arr($r['images'] ?? '');
        $imgs[(int)$r['id']] = array_values(array_filter(array_map(static fn($x) => is_string($x) ? $x : (string)($x['url'] ?? ''), $arr)));
    }
}

$detail = [];
foreach ($rows as $r) {
    $id = (int)$r['id'];
    $detail[$id] = [
        'id' => $id,
        'uid' => (int)$r['uid'],
        'nickname' => (string)$r['nickname'],
        'account' => (string)$r['account'],
        'content' => (string)$r['content'],
        'video' => (string)$r['video'],
        'images' => $imgs[$id] ?? [],
        'likes' => (int)$r['likes'],
        'comments' => $comments[$id] ?? [],
        'created_at' => (int)$r['created_at'],
        'visibility' => (int)$r['visibility'],
        'deleted' => (int)$r['deleted'],
    ];
}

$postUrl = 'moments.php?' . admin_qs();
$pagerUrl = 'moments.php?' . admin_qs();

admin_head('动态管理', 'moments');
?>
<?php if ($msg !== ''): ?>
<div class="adm-panel" style="border-left:4px solid <?= $msgOk ? '#07C160' : '#EF4444' ?>">
  <div class="adm-panel-body" style="padding:12px 18px;color:<?= $msgOk ? '#059669' : '#DC2626' ?>;font-size:13px"><?= e($msg) ?></div>
</div>
<?php endif; ?>

<div class="adm-panel">
  <div class="adm-panel-head">
    <h2>动态列表 <span class="sub">共 <?= admin_money($total) ?> 条</span></h2>
    <form class="adm-toolbar" method="get" action="moments.php">
      <input class="adm-input" name="kw" value="<?= e($kw) ?>" placeholder="内容 / 作者昵称 / CC号" style="width:220px">
      <select class="adm-select" name="state">
        <option value="">全部状态</option>
        <option value="normal" <?= $fStatus === 'normal' ? 'selected' : '' ?>>正常</option>
        <option value="deleted" <?= $fStatus === 'deleted' ? 'selected' : '' ?>>已删除</option>
      </select>
      <button class="adm-btn" type="submit">搜索</button>
      <?php if ($kw !== '' || $fStatus !== ''): ?><a class="adm-btn ghost" href="moments.php">重置</a><?php endif; ?>
    </form>
  </div>
  <div class="adm-table-wrap">
    <table class="adm-table">
      <thead>
        <tr><th>ID</th><th>作者</th><th>内容</th><th>图片</th><th>点赞</th><th>评论</th><th>时间</th><th>状态</th><th>操作</th></tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="9"><div class="adm-empty">没有匹配的动态</div></td></tr>
      <?php endif; ?>
      <?php foreach ($rows as $m): ?>
        <?php
          $id = (int)$m['id'];
          $del = (int)$m['deleted'] === 1;
          $imgCount = count($imgs[$id] ?? []);
          $text = trim((string)$m['content']);
          if ($text === '') $text = $m['video'] ? '[视频]' : ($imgCount ? '[图片动态]' : '（空）');
        ?>
        <tr>
          <td><?= $id ?></td>
          <td>
            <div class="cell-user">
              <div class="mini-avatar"><?php if ($m['avatar']): ?><img src="<?= e('../' . $m['avatar']) ?>" alt=""><?php else: ?><?= e(mb_substr($m['nickname'] ?: 'U', 0, 1)) ?><?php endif; ?></div>
              <div>
                <div class="nm"><?= e($m['nickname'] ?: ('UID ' . (int)$m['uid'])) ?></div>
                <div class="sub"><?= e((string)$m['account']) ?></div>
              </div>
            </div>
          </td>
          <td style="max-width:300px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e(mb_substr($text, 0, 60)) ?></div></td>
          <td class="num"><?= $imgCount ?></td>
          <td class="num"><?= (int)$m['likes'] ?></td>
          <td class="num"><?= (int)$m['comments'] ?></td>
          <td><?= e(date('Y-m-d H:i', (int)$m['created_at'])) ?></td>
          <td><span class="tag <?= $del ? 'gray' : 'green' ?>"><?= $del ? '已删除' : '正常' ?></span></td>
          <td>
            <div class="actions">
              <button class="adm-btn sm ghost" type="button" onclick="openMoment(<?= $id ?>)">查看</button>
              <?php if (!$del): ?>
                <button class="adm-btn sm danger" type="button" onclick="doAct('delete',<?= $id ?>,'删除后该动态在客户端不再可见，确认删除？')">删除</button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= admin_pager($total, $page, $per, $pagerUrl) ?>
</div>

<form id="actForm" method="post" action="<?= e($postUrl) ?>" style="display:none"></form>

<script>
var MDATA = <?= json_encode($detail, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
var POST_URL = <?= json_encode($postUrl, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

function submitAct(act, extra) {
  var h = '<input type="hidden" name="act" value="' + ADM.esc(act) + '">';
  Object.keys(extra || {}).forEach(function (k) {
    h += '<input type="hidden" name="' + ADM.esc(k) + '" value="' + ADM.esc(extra[k]) + '">';
  });
  var f = document.getElementById('actForm');
  f.innerHTML = h;
  f.submit();
}

function doAct(act, id, text) {
  ADM.confirm({ title: '确认操作', text: text, danger: true }).then(function (v) {
    if (v) submitAct(act, { id: id });
  });
}

function delComment(cid) {
  ADM.confirm({ title: '删除评论', text: '确认删除这条评论？', danger: true }).then(function (v) {
    if (v) submitAct('del_comment', { cid: cid });
  });
}

function openMoment(id) {
  var m = MDATA[id];
  if (!m) { ADM.toast('数据已过期，请刷新页面'); return; }
  var html = '<div style="font-size:12.5px;color:#6B7280;margin-bottom:10px">' +
    ADM.esc(m.nickname || ('UID ' + m.uid)) + ' · ' + ADM.esc(m.account) + ' · ' + ADM.fmt(m.created_at) +
    ' · 可见性 ' + (m.visibility === 1 ? '公开' : '仅好友') + '</div>';
  html += '<div style="background:#F8FAFD;border:1px solid #EBEEF4;border-radius:9px;padding:12px;font-size:13.5px;white-space:pre-wrap;word-break:break-word;max-height:240px;overflow:auto">' + ADM.esc(m.content || '（无文字内容）') + '</div>';

  if (m.images && m.images.length) {
    html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px">';
    m.images.forEach(function (src) {
      html += '<a href="../' + ADM.esc(src) + '" target="_blank" rel="noopener"><img src="../' + ADM.esc(src) + '" alt="" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;background:#EEF1F6" onerror="this.style.opacity=.35"></a>';
    });
    html += '</div>';
  }
  if (m.video) {
    html += '<div style="margin-top:12px;font-size:12.5px;color:#374151">视频：<a href="../' + ADM.esc(m.video) + '" target="_blank" rel="noopener" style="color:#2563EB">打开视频</a></div>';
  }

  html += '<div style="margin-top:14px;font-size:12.5px;color:#374151;font-weight:600">互动：点赞 ' + m.likes + ' · 评论 ' + m.comments.length + '</div>';
  if (!m.comments.length) {
    html += '<div class="adm-hint">暂无评论</div>';
  } else {
    html += '<div style="max-height:260px;overflow:auto;margin-top:6px">';
    m.comments.forEach(function (c) {
      html += '<div style="display:flex;gap:10px;align-items:flex-start;padding:7px 0;border-bottom:1px solid #F2F4F8">' +
        '<div style="flex:1;min-width:0"><div style="font-size:12.5px;color:#374151"><b>' + ADM.esc(c.nickname) + '</b>' +
        '<span style="color:#9AA0AC"> · ' + ADM.fmt(c.created_at) + '</span></div>' +
        '<div style="font-size:12.5px;color:#6B7280;word-break:break-word">' + ADM.esc(c.content) + '</div></div>' +
        '<button class="adm-btn sm danger" type="button" onclick="delComment(' + c.id + ')">删除</button></div>';
    });
    html += '</div>';
  }
  if (m.deleted === 1) {
    html += '<div class="adm-hint" style="margin-top:10px;color:#DC2626">该动态已被删除</div>';
  }
  ADM.modal({ title: '动态详情 #' + m.id, html: html });
}
</script>
<?php
admin_foot();
