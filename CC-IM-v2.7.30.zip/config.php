<?php
/**
 * CC商聊 - 全局配置
 * 修改本文件即可切换数据库 / 站点参数。安装向导 install.php 也会写回部分配置到 settings 表。
 */
return [
    // ---------- 数据库 ----------
    // driver: sqlite（默认，零配置，开箱即用）或 mysql
    'db' => [
        'driver'      => 'sqlite',
        // 放在站点根目录之外，避免数据库被直接下载（生产建议改用 MySQL）
        'sqlite_path' => dirname(__DIR__) . '/akchat-data/akchat.db',
        'host'        => '127.0.0.1',
        'port'        => 3306,
        'name'        => 'akchat',
        'user'        => 'root',
        'pass'        => '',
        'charset'     => 'utf8mb4',
    ],

    // ---------- 站点 ----------
    'app' => [
        'name'        => 'CC商聊',
        'brand'       => 'CC',
        'url'         => '',                 // 留空自动识别
        'debug'       => false,
        'upload_dir'  => __DIR__ . '/uploads',
        'max_upload'  => 60 * 1024 * 1024,   // 单文件上限 60MB
        'session_days'=> 30,
        'timezone'    => 'Asia/Shanghai',
    ],

    // ---------- 通话 / 直播（WebRTC） ----------
    'webrtc' => [
        'ice' => [
            ['urls' => 'stun:stun.l.google.com:19302'],
            ['urls' => 'stun:stun.qq.com:3478'],
        ],
    ],

    // ---------- USDT 链上收款（可在后台覆盖） ----------
    'usdt' => [
        'network'       => 'TRC20',
        'address'       => 'TTeoJPafaxcJ2Z4UrcpDT8tjaJGKotT9aB',
        'rate'          => 7,               // 1 USDT = N CC币
        'min_coin'      => 10,
        'auto_check'    => 1,               // 1=开启链上自动匹配
        'trongrid_key'  => '',              // TronGrid API Key（可选，提升额度）
        'trongrid_url'  => 'https://api.trongrid.io',
        'match_window'  => 86400,           // 只匹配 24h 内的转账
        'amount_floor'  => 0.000001,
    ],
];
