<?php
/**
 * CC商聊 - PWA manifest（站点名称、主题色跟随后台设置）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';

$brand = term_brand();
$logo = (string)setting('site_logo', 'icons/icon-192.png');
if ($logo !== '' && preg_match('#^https?://#i', $logo)) {
    $icon = $logo;
} else {
    // manifest 位于站点根目录，图标统一用站点图标
    $icon = 'icons/icon-192.png';
}

header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: no-cache');

echo json_encode([
    'name'             => $brand,
    'short_name'       => mb_substr($brand, 0, 12),
    'description'      => (string)setting('site_slogan', '连接每一次商机'),
    'start_url'        => 'index.php',
    'scope'            => './',
    'display'          => 'standalone',
    'background_color' => '#F6F7F9',
    'theme_color'      => '#07C160',
    'icons'            => [
        ['src' => $icon, 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'],
        ['src' => $icon, 'sizes' => '512x512', 'type' => 'image/png'],
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
