#!/bin/sh
# CC商聊 - 本地测试服务（带看门狗：PHP 退出后自动重启）
# 用法： sh serve.sh start | stop | restart | status
# 访问： http://127.0.0.1:8102/

PORT=${PORT:-8102}
ROOT=/var/minis/workspace/im
LOG=/tmp/cc-im-server.log
PIDF=/tmp/cc-im-watchdog.pid
PHP=php82

start() {
  if [ -f "$PIDF" ] && kill -0 "$(cat "$PIDF")" 2>/dev/null; then
    echo "看门狗已在运行（pid $(cat "$PIDF")）"
    return 0
  fi
  # 只清理残留的 PHP 实例（看门狗命令行不含该模式，不会被误杀）
  pkill -f "$PHP -S 0.0.0.0:$PORT" 2>/dev/null
  sleep 0.3
  cd "$ROOT" || exit 1
  PORT="$PORT" LOG="$LOG" nohup sh "$ROOT/watchdog.sh" > /dev/null 2>&1 &
  echo $! > "$PIDF"
  sleep 1.2
  if curl -s -m 3 -o /dev/null "http://127.0.0.1:$PORT/login.php"; then
    echo "已启动（看门狗模式）: http://127.0.0.1:$PORT/"
    LAN=$(ip -4 addr show 2>/dev/null | awk '/^[0-9]+: en/ {iface=$2} /inet /{ip=$2; sub(/\/.*/,"",ip); if (iface ~ /^en/ && ip !~ /^127\./) print ip}' | head -1)
    [ -z "$LAN" ] && LAN=$(ip -4 addr show 2>/dev/null | sed -n 's/.*inet \([0-9.]*\)\/.*/\1/p' | grep -v '^127\.' | head -1)
    [ -n "$LAN" ] && echo "局域网:  http://$LAN:$PORT/"
    echo "日志: $LOG"
  else
    echo "启动失败，请查看日志: $LOG"
    tail -10 "$LOG"
  fi
}

stop() {
  if [ -f "$PIDF" ]; then
    kill "$(cat "$PIDF")" 2>/dev/null
    rm -f "$PIDF"
  fi
  pkill -f "$ROOT/watchdog.sh" 2>/dev/null
  pkill -f "$PHP -S 0.0.0.0:$PORT" 2>/dev/null
  sleep 0.5
  echo "已停止"
}

status() {
  code=$(curl -s -m 3 -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/login.php")
  if [ "$code" = "200" ]; then echo "运行中: http://127.0.0.1:$PORT/"; else echo "未运行（端口 $PORT 无响应）"; fi
  [ -f "$PIDF" ] && echo "看门狗 pid: $(cat "$PIDF")"
}

case "$1" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  status) status ;;
  *) echo "用法: sh $0 start|stop|restart|status" ;;
esac
