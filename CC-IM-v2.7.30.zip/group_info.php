<?php
/**
 * CC商聊 - 群资料与成员管理
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myUid = (int)$me['id'];

function p_av(string $avatar, string $name, string $cls = ''): string
{
    if ($avatar !== '') return '<span class="avatar ' . $cls . '"><img src="' . e($avatar) . '" alt=""></span>';
    return '<span class="avatar ' . $cls . '" style="background:var(--brand)">' . e(mb_substr($name !== '' ? $name : '?', 0, 1)) . '</span>';
}

$gid = (int)($_GET['gid'] ?? 0);
$g = $gid > 0 ? group_by_gid($gid) : null;
$alive = $g && (int)$g['status'] === 1;
$role = $alive ? group_role($gid, $myUid) : -1;

if (!$alive) {
    cc_head('群资料');
    ?>
    <div class="app"><div class="page">
      <?php cc_topbar('群资料', 'group_list.php'); ?>
      <div class="page-body no-tab">
        <div class="empty">
          <div class="ico">👥</div>
          <div>群聊不存在或已解散</div>
          <div style="margin-top:14px"><a class="btn" href="group_list.php" style="max-width:200px;margin:0 auto">返回我的群组</a></div>
        </div>
      </div>
    </div></div>
    <?php
    cc_foot();
    exit;
}
if ($role < 0) {
    header('Location: group_card.php?gid=' . $gid);
    exit;
}

$members = all('SELECT gm.uid, gm.role, gm.nickname AS gnick, gm.mute_until, gm.joined_at,
        u.nickname, u.avatar, u.yx_id, u.online, u.is_developer, u.pretty_yxid, u.vip_level, u.vip_expire_at
    FROM group_members gm JOIN users u ON u.id=gm.uid
    WHERE gm.gid=? ORDER BY gm.role DESC, gm.id ASC', [$gid]);
$total = count($members);
$owner = one('SELECT id,nickname,avatar,yx_id FROM users WHERE id=?', [(int)$g['owner_uid']]);
$notice = one('SELECT n.*, u.nickname FROM group_notices n LEFT JOIN users u ON u.id=n.uid WHERE n.gid=? ORDER BY n.id DESC LIMIT 1', [$gid]);
$myGm = group_member($gid, $myUid);
$myNick = $myGm ? (string)$myGm['nickname'] : '';
$byRole = [2 => [], 1 => [], 0 => []];
foreach ($members as $m) {
    $r = (int)$m['role'];
    if (!isset($byRole[$r])) $r = 0;
    $byRole[$r][] = $m;
}
$joinModes = [0 => '自由加入', 1 => '需审核', 2 => '不允许加入'];
$joinMode = (int)$g['join_mode'];

cc_head('群资料');
?>
<style>
.mem-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px 6px;padding:14px 12px;background:var(--card);}
.mem-item{display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;min-width:0;}
.mem-item .avatar{width:46px;height:46px;border-radius:10px;font-size:16px;}
.mem-item .nm{font-size:11px;color:var(--t2);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.mem-item .mute-tag{font-size:9px;color:var(--red);line-height:1;}
.mem-pretty{position:absolute;right:-4px;bottom:-3px;font-size:8.5px;font-weight:700;color:#FFF4D6;background:linear-gradient(135deg,#8B5A18,#C08A34);
  border:1px solid rgba(255,214,140,.6);border-radius:4px;padding:0 2.5px;line-height:1.5;}
</style>
<div class="app">
  <div class="page">
    <?php cc_topbar('群资料', 'index.php', '<a class="tb-btn" href="index.php?gid=' . $gid . '" aria-label="进入群聊" style="color:var(--brand)"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5h16a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H9l-5 3.5v-3.5H4A1.5 1.5 0 0 1 2.5 16V7A1.5 1.5 0 0 1 4 5.5z"/></svg></a>'); ?>
    <div class="page-body no-tab" style="padding-bottom:calc(92px + var(--safe-b))">

      <div class="card" style="text-align:center;padding:24px 16px 18px">
        <button id="avatarBtn" style="display:inline-block;position:relative" <?= $role >= 1 ? '' : 'disabled' ?>>
          <?= p_av((string)$g['avatar'], (string)$g['name'], 'xl') ?>
          <?php if ($role >= 1): ?>
          <span style="position:absolute;right:-4px;bottom:-4px;width:26px;height:26px;border-radius:50%;background:var(--brand);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;border:2px solid var(--card)">📷</span>
          <?php endif; ?>
        </button>
        <input type="file" id="avatarFile" accept="image/*" class="hidden">
        <?php $prettyGid = (int)($g['pretty_gid'] ?? 0); ?>
        <div style="font-size:19px;font-weight:600;margin-top:12px;display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap">
          <?= e($g['name']) ?>
          <?php if ($prettyGid > 0): ?><span class="tag-pretty">靓 <?= $prettyGid ?></span><?php endif; ?>
        </div>
        <div class="t3 small" style="margin-top:4px">群号 <?= $gid ?></div>
        <div style="display:flex;justify-content:center;gap:8px;margin-top:12px;flex-wrap:wrap">
          <span class="pill"><?= $total ?>/<?= (int)$g['member_limit'] ?> 人</span>
          <span class="pill"><?= e($joinModes[$joinMode] ?? '自由加入') ?></span>
          <?php if ((int)$g['mute_all'] === 1): ?><span class="pill" style="color:var(--red)">全员禁言</span><?php endif; ?>
          <?php if ($role === 2): ?><span class="badge gold">群主</span>
          <?php elseif ($role === 1): ?><span class="badge purple">管理员</span><?php endif; ?>
        </div>
      </div>

      <?php if ($notice): ?>
      <div class="card">
        <div class="row-between">
          <span style="font-weight:600">群公告</span>
          <?php if ($role >= 1): ?><button class="green-text small" data-act="notice">发布</button><?php endif; ?>
        </div>
        <div style="margin-top:8px;font-size:13.5px;line-height:1.75;white-space:pre-wrap;word-break:break-word"><?= e($notice['content']) ?></div>
        <div class="t3 small" style="margin-top:8px"><?= e($notice['nickname'] !== null ? $notice['nickname'] : '系统') ?> · <?= fmt_time((int)$notice['created_at']) ?></div>
      </div>
      <?php elseif ($role >= 1): ?>
      <div class="card row-between" data-act="notice" style="cursor:pointer">
        <span class="t2">还没有群公告</span>
        <span class="green-text small">发布 ›</span>
      </div>
      <?php endif; ?>

      <div class="cell-group">
        <div class="cell" data-act="name">
          <div class="c-title">群名称</div>
          <div class="c-value nowrap" style="max-width:200px"><?= e($g['name']) ?></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-act="copygid">
          <div class="c-title">群号</div>
          <div class="c-value"><?= $prettyGid > 0 ? $prettyGid : $gid ?><?php if ($prettyGid > 0): ?> <span class="tag-pretty">靓号</span><?php endif; ?> <span class="badge">复制</span></div>
        </div>
        <div class="cell" data-act="intro">
          <div class="c-title">群简介</div>
          <div class="c-value nowrap" style="max-width:180px"><?= trim((string)$g['intro']) !== '' ? e($g['intro']) : '未填写' ?></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-act="nick">
          <div class="c-title">我在本群的昵称</div>
          <div class="c-value nowrap" style="max-width:160px"><?= $myNick !== '' ? e($myNick) : '未设置' ?></div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-act="joinmode">
          <div class="c-title">加入方式</div>
          <div class="c-value"><?= e($joinModes[$joinMode] ?? '自由加入') ?></div>
          <span class="arrow">›</span>
        </div>
      </div>

      <div class="cell-group">
        <div class="cell" data-act="invite">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
          </div>
          <div class="c-title">邀请好友</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-act="gidcard">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14h1M14 20h1M18 20h3v1"/></svg>
          </div>
          <div class="c-title">群号卡片</div>
          <div class="c-value">二维码替代</div>
          <span class="arrow">›</span>
        </div>
        <?php if ($role >= 1): ?>
        <div class="cell" data-act="muteall">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M9 6l6 6-6 6"/><path d="M4 12h8"/></svg>
          </div>
          <div class="c-title">全员禁言</div>
          <div class="c-value">
            <span class="badge <?= (int)$g['mute_all'] === 1 ? 'red' : 'gray' ?>"><?= (int)$g['mute_all'] === 1 ? '已开启' : '已关闭' ?></span>
          </div>
        </div>
        <div class="cell" data-act="privacy">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>
          </div>
          <div class="c-title">成员信息可查看</div>
          <div class="c-value">
            <span class="badge <?= (int)($g['hide_member_info'] ?? 0) === 1 ? 'gray' : '' ?>" id="privacyBadge"><?= (int)($g['hide_member_info'] ?? 0) === 1 ? '已关闭' : '已开启' ?></span>
          </div>
        </div>
        <div class="cell" data-act="bans">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></svg>
          </div>
          <div class="c-title">封禁列表</div>
          <span class="arrow">›</span>
        </div>
        <?php endif; ?>
        <?php if ($role === 2): ?>
        <div class="cell" data-act="upgrade">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M12 19V5M6 11l6-6 6 6"/></svg>
          </div>
          <div class="c-title">升级群人数</div>
          <div class="c-value"><?= (int)$g['member_limit'] ?> 人</div>
          <span class="arrow">›</span>
        </div>
        <div class="cell" data-act="transfer">
          <div class="c-icon">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 8h13l-3-3M20 16H7l3 3"/></svg>
          </div>
          <div class="c-title">转让群主</div>
          <span class="arrow">›</span>
        </div>
        <?php endif; ?>
        <?php if ($role !== 2): ?>
        <div class="cell danger" data-act="exit"><div class="c-title">退出群聊</div></div>
        <?php else: ?>
        <div class="cell danger" data-act="dissolve"><div class="c-title">解散群聊</div></div>
        <?php endif; ?>
      </div>

      <div class="row-between" style="padding:18px 16px 6px">
        <span style="font-size:13px;color:var(--t3)">群成员（<?= $total ?>）</span>
        <button class="green-text small" data-act="invite">邀请</button>
      </div>

      <?php
      $sections = [
          2 => ['群主', $byRole[2]],
          1 => ['群管理员', $byRole[1]],
          0 => ['群成员', $byRole[0]],
      ];
      foreach ($sections as $rk => $sec):
          [$label, $arr] = $sec;
          if (!$arr) continue;
      ?>
      <div class="group-title" style="padding:10px 18px 6px"><?= e($label) ?>（<?= count($arr) ?>）</div>
      <div class="mem-grid">
        <?php foreach ($arr as $m):
            $dn = $m['gnick'] !== '' ? (string)$m['gnick'] : (string)$m['nickname'];
            $muted = (int)$m['mute_until'] > now();
        ?>
        <div class="mem-item" data-uid="<?= (int)$m['uid'] ?>" data-role="<?= (int)$m['role'] ?>"
             data-mute="<?= (int)$m['mute_until'] ?>" data-name="<?= e($dn) ?>">
          <span style="position:relative;display:block">
            <?= p_av((string)$m['avatar'], $dn) ?>
            <?php if (!empty($m['pretty_yxid'])): ?><span class="mem-pretty" title="靓号 <?= e((string)$m['pretty_yxid']) ?>">靓</span><?php endif; ?>
          </span>
          <span class="nm"><?= e($dn) ?></span>
          <?php if ($muted): ?><span class="mute-tag">禁言中</span><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>

    </div>

    <div style="position:absolute;left:0;right:0;bottom:0;z-index:25;padding:10px 16px calc(10px + var(--safe-b));background:var(--card);border-top:1px solid var(--line)">
      <a class="btn" href="index.php?gid=<?= $gid ?>">进入群聊</a>
    </div>
  </div>
</div>
<script>
window.ME = <?= cc_me_json($me) ?>;
window.GROUP = {
  gid: <?= $gid ?>,
  role: <?= $role ?>,
  myUid: <?= $myUid ?>,
  muteAll: <?= (int)$g['mute_all'] ?>,
  joinMode: <?= $joinMode ?>,
  name: <?= json_encode((string)$g['name'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  intro: <?= json_encode((string)$g['intro'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  myNick: <?= json_encode($myNick, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
  hideMemberInfo: <?= (int)($g['hide_member_info'] ?? 0) ?>
};
document.addEventListener('DOMContentLoaded', function () {
  var G = window.GROUP;

  function copyText(t) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      CC.toast(ok ? '已复制' : '复制失败，请长按群号复制');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () { CC.toast('已复制'); }, fallback);
    } else {
      fallback();
    }
  }

  function call(action, data, msg) {
    return CC.api(action, data).then(function (d) {
      if (msg) CC.toast(msg);
      setTimeout(function () { location.reload(); }, 550);
      return d;
    }).catch(function (e) {
      CC.toast(e.message || '操作失败');
      return null;
    });
  }

  function pickFriends(title, onDone) {
    CC.api('share_targets').then(function (d) {
      var friends = d.friends || [];
      if (!friends.length) { CC.toast('还没有好友，先去通讯录添加吧'); return; }
      var html = '<div class="picker-list">' + friends.map(function (f) {
        return '<div class="picker-item" data-uid="' + f.id + '">' +
          '<span class="check">✓</span>' + CC.avatarHtml({ avatar: f.avatar, nickname: f.name }, 'sm') +
          '<div class="flex1 nowrap">' + CC.esc(f.name) + '</div></div>';
      }).join('') + '</div><div style="padding:12px 0 4px"><button class="btn" id="pickOk">确定邀请</button></div>';
      var s = CC.sheet(title, html);
      s.el.querySelectorAll('.picker-item').forEach(function (el) {
        el.onclick = function () { el.classList.toggle('selected'); };
      });
      s.el.querySelector('#pickOk').onclick = function () {
        var ids = [];
        s.el.querySelectorAll('.picker-item.selected').forEach(function (el) {
          ids.push(parseInt(el.getAttribute('data-uid'), 10));
        });
        if (!ids.length) { CC.toast('请选择好友'); return; }
        s.close();
        onDone(ids);
      };
    }).catch(function (e) { CC.toast(e.message || '加载好友失败'); });
  }

  function inviteTo(ids) {
    var i = 0, okCount = 0;
    CC.toast('正在发送群名片…');
    (function next() {
      if (i >= ids.length) { CC.toast('已邀请 ' + okCount + ' 位好友'); return; }
      CC.api('group_share_card', { gid: G.gid, to: ids[i++] }).then(function () {
        okCount++;
        next();
      }).catch(function () { next(); });
    })();
  }

  function openMember(uid, mrole, mute, name) {
    var nowSec = Math.floor(Date.now() / 1000);
    var muted = mute > nowSec;
    var canAdmin = G.role === 2 && mrole < 2;
    var canMod = G.role >= 1 && mrole < G.role;
    // 群主关闭「成员信息可查看」后：普通成员之间看不到资料，但群主/管理员仍可查看
    var hideInfo = parseInt(G.hideMemberInfo || 0, 10) === 1;
    var targetIsManager = mrole >= 1;
    var iAmManager = G.role >= 1;
    var canProfile = !hideInfo || targetIsManager || iAmManager;

    var html = '<div class="sheet-item" data-a="profile"' + (canProfile ? '' : ' data-blocked="1"') + '>查看资料</div>';
    if (canAdmin) html += '<div class="sheet-item" data-a="admin">' + (mrole === 1 ? '取消管理员' : '设为管理员') + '</div>';
    if (canMod) html += '<div class="sheet-item" data-a="mute">' + (muted ? '解除禁言' : '禁言') + '</div>';
    if (canMod) html += '<div class="sheet-item danger" data-a="kick">移出群聊</div>';
    if (canMod) html += '<div class="sheet-item danger" data-a="ban">封禁（禁止再次加入）</div>';
    if (G.role === 2 && mrole < 2) html += '<div class="sheet-item danger" data-a="transfer">转让群主</div>';
    var s = CC.sheet(name || '成员操作', html);
    s.el.querySelectorAll('[data-a]').forEach(function (it) {
      it.onclick = function () {
        var a = it.getAttribute('data-a');
        s.close();
        if (a === 'profile') {
          if (!canProfile) { CC.toast('群主已关闭成员信息查看'); return; }
          location.href = 'user.php?uid=' + uid + '&gid=' + G.gid;
          return;
        }
        if (a === 'ban') {
          CC.confirm({
            title: '封禁成员',
            html: '<p style="margin:0 0 10px;color:#6B7280">封禁后该成员将被移出群聊，且无法再次加入。</p>'
              + '<div class="field" style="margin:0"><input id="banReason" type="text" maxlength="100" placeholder="封禁原因（选填）"></div>',
            danger: true, ok: '确认封禁'
          }).then(function (yes) {
            if (!yes) return;
            var r = (document.getElementById('banReason') || {}).value || '';
            call('group_ban', { gid: G.gid, uid: uid, reason: r }, '已封禁');
          });
          return;
        }
        if (a === 'admin') {
          call('group_set_admin', { gid: G.gid, uid: uid, set: mrole === 1 ? 0 : 1 }, '已更新');
          return;
        }
        if (a === 'mute') { openMute(uid, muted); return; }
        if (a === 'kick') {
          CC.confirm({ title: '移出群聊', text: '确定把该成员移出群聊？', danger: true, ok: '移出' }).then(function (yes) {
            if (yes) call('group_kick', { gid: G.gid, uid: uid }, '已移出群聊');
          });
          return;
        }
        if (a === 'transfer') {
          CC.confirm({ title: '转让群主', text: '转让后你将成为管理员，确定继续？', danger: true, ok: '确定转让' }).then(function (yes) {
            if (yes) call('group_transfer', { gid: G.gid, uid: uid }, '群主已转让');
          });
        }
      };
    });
  }

  function openMute(uid, muted) {
    var html = '';
    if (muted) html += '<div class="sheet-item" data-m="0">解除禁言</div>';
    html += '<div class="sheet-item" data-m="10">禁言 10 分钟</div>' +
      '<div class="sheet-item" data-m="60">禁言 1 小时</div>' +
      '<div class="sheet-item" data-m="1440">禁言 1 天</div>' +
      '<div class="sheet-item danger" data-m="5256000">永久禁言</div>';
    var s = CC.sheet('禁言设置', html);
    s.el.querySelectorAll('[data-m]').forEach(function (it) {
      it.onclick = function () {
        var mi = parseInt(it.getAttribute('data-m'), 10);
        s.close();
        call('group_mute_member', { gid: G.gid, uid: uid, minutes: mi }, mi > 0 ? '已禁言' : '已解除禁言');
      };
    });
  }

  document.querySelectorAll('.mem-item').forEach(function (el) {
    el.onclick = function () {
      openMember(parseInt(el.getAttribute('data-uid'), 10),
        parseInt(el.getAttribute('data-role'), 10),
        parseInt(el.getAttribute('data-mute'), 10),
        el.getAttribute('data-name') || '');
    };
  });

  var avatarFile = document.getElementById('avatarFile');
  var avatarBtn = document.getElementById('avatarBtn');
  if (avatarBtn && !avatarBtn.disabled) {
    avatarBtn.onclick = function () { avatarFile.click(); };
    avatarFile.onchange = function () {
      var f = avatarFile.files && avatarFile.files[0];
      if (!f) return;
      CC.toast('上传中…');
      CC.upload('group_upload_avatar', f, { gid: G.gid }).then(function () {
        CC.toast('群头像已更新');
        setTimeout(function () { location.reload(); }, 500);
      }).catch(function (e) { CC.toast(e.message || '上传失败'); });
    };
  }

  var acts = {
    copygid: function () { copyText(String(G.gid)); },
    name: function () {
      if (G.role < 1) { CC.toast('仅群主/管理员可修改'); return; }
      CC.prompt({ title: '修改群名称', value: G.name, max: 20, placeholder: '群名称' }).then(function (v) {
        if (v === null || v === G.name) return;
        if (!v) { CC.toast('群名称不能为空'); return; }
        call('group_update', { gid: G.gid, name: v }, '已保存');
      });
    },
    intro: function () {
      if (G.role < 1) { CC.toast('仅群主/管理员可修改'); return; }
      CC.prompt({ title: '修改群简介', value: G.intro, max: 200, multiline: true, placeholder: '群简介' }).then(function (v) {
        if (v === null) return;
        call('group_update', { gid: G.gid, intro: v }, '已保存');
      });
    },
    nick: function () {
      CC.prompt({ title: '我在本群的昵称', value: G.myNick, max: 20, placeholder: '留空则显示我的昵称' }).then(function (v) {
        if (v === null) return;
        call('group_set_nickname', { gid: G.gid, nickname: v }, '已保存');
      });
    },
    joinmode: function () {
      if (G.role !== 2) { CC.toast('仅群主可修改'); return; }
      var html = '<div class="sheet-item" data-m="0">自由加入</div>' +
        '<div class="sheet-item" data-m="1">需审核</div>' +
        '<div class="sheet-item" data-m="2">不允许加入</div>';
      var s = CC.sheet('加入方式', html);
      s.el.querySelectorAll('[data-m]').forEach(function (it) {
        it.onclick = function () {
          var v = parseInt(it.getAttribute('data-m'), 10);
          s.close();
          call('group_update', { gid: G.gid, join_mode: v }, '已更新');
        };
      });
    },
    notice: function () {
      if (G.role < 1) { CC.toast('仅群主/管理员可发布'); return; }
      CC.prompt({ title: '发布群公告', max: 500, multiline: true, placeholder: '输入公告内容' }).then(function (v) {
        if (!v) return;
        call('group_notice_set', { gid: G.gid, content: v }, '公告已发布');
      });
    },
    invite: function () {
      pickFriends('邀请好友加入', function (ids) { inviteTo(ids); });
    },
    gidcard: function () {
      var html = '<div style="text-align:center;padding:8px 0 14px">' +
        '<div style="border:1px dashed var(--line);border-radius:14px;padding:22px 12px;background:var(--bg)">' +
        '<div class="t3 small">群号</div>' +
        '<div style="font-size:30px;font-weight:700;letter-spacing:3px;margin:4px 0">' + G.gid + '</div>' +
        '<div class="t3 small">' + CC.esc(G.name) + '</div></div></div>' +
        '<button class="btn" id="cardCopy">复制群号</button>';
      var s = CC.sheet('群号卡片', html);
      s.el.querySelector('#cardCopy').onclick = function () { copyText(String(G.gid)); };
    },
    muteall: function () {
      call('group_mute_all', { gid: G.gid, mute_all: G.muteAll ? 0 : 1 }, G.muteAll ? '已关闭全员禁言' : '已开启全员禁言');
    },
    privacy: function () {
      var hide = parseInt(G.hideMemberInfo || 0, 10) === 1 ? 0 : 1;
      CC.confirm({
        title: hide ? '关闭成员信息查看' : '开启成员信息查看',
        text: hide
          ? '关闭后，普通成员之间点击头像将提示「群主已关闭成员信息查看」；群主与管理员的信息仍可查看。'
          : '开启后，群成员可以互相查看资料。',
        ok: hide ? '关闭' : '开启'
      }).then(function (yes) {
        if (!yes) return;
        call('group_set_privacy', { gid: G.gid, hide_member_info: hide }, hide ? '已关闭成员信息查看' : '已开启成员信息查看');
      });
    },
    bans: function () {
      var s = CC.sheet('封禁列表', '<div id="banBox"><div class="loading"><span class="spin"></span> 加载中…</div></div>');
      var box = s.el.querySelector('#banBox');
      function load(){
        CC.ajax('group_bans', { gid: G.gid }).then(function (res) {
          if (res.code !== 0) { box.innerHTML = '<div class="empty" style="padding:28px">' + (res.msg || '加载失败') + '</div>'; return; }
          var list = (res.data && res.data.list) || [];
          if (!list.length) {
            box.innerHTML = '<div class="empty" style="padding:32px 16px"><div class="ico">🛡️</div><div>暂无封禁成员</div>'
              + '<div style="font-size:12px;margin-top:6px;color:var(--t3)">在成员菜单里可以封禁该成员</div></div>';
            return;
          }
          box.innerHTML = list.map(function (u) {
            return '<div class="row-between" style="padding:12px 2px;border-bottom:1px solid var(--line);gap:10px">'
              + CC.avatarHtml({ nickname: u.name, avatar: u.avatar }, 'sm')
              + '<div style="flex:1;min-width:0"><div class="nowrap">' + CC.esc(u.name) + '</div>'
              + '<div class="t3 small">' + CC.T('id', 'CC号') + ' ' + CC.esc(u.account)
              + (u.reason ? ' · ' + CC.esc(u.reason) : '') + '</div></div>'
              + '<button class="btn small ghost" data-unban="' + u.uid + '">解除</button></div>';
          }).join('');
          box.querySelectorAll('[data-unban]').forEach(function (b) {
            b.onclick = function () {
              b.disabled = true;
              CC.api('group_unban', { gid: G.gid, uid: b.getAttribute('data-unban') }).then(function () {
                CC.toast('已解除封禁'); load();
              }).catch(function (e) { b.disabled = false; CC.toast(e.message); });
            };
          });
        }).catch(function () { box.innerHTML = '<div class="empty" style="padding:28px">加载失败</div>'; });
      }
      load();
    },
    upgrade: function () {
      CC.confirm({ title: '升级群人数', text: '当前上限 ' + <?= (int)$g['member_limit'] ?> + ' 人，升级需要 VIP。确定升级？', ok: '升级' }).then(function (yes) {
        if (yes) call('group_upgrade_limit', { gid: G.gid }, '人数上限已升级');
      });
    },
    transfer: function () {
      var items = document.querySelectorAll('.mem-item');
      var html = '';
      items.forEach(function (el) {
        if (parseInt(el.getAttribute('data-role'), 10) >= 2) return;
        html += '<div class="picker-item" data-uid="' + el.getAttribute('data-uid') + '">' +
          el.querySelector('.avatar').outerHTML +
          '<div class="flex1 nowrap">' + CC.esc(el.getAttribute('data-name') || '') + '</div></div>';
      });
      if (!html) { CC.toast('没有可转让的成员'); return; }
      var s = CC.sheet('选择新群主', '<div class="picker-list">' + html + '</div>');
      s.el.querySelectorAll('[data-uid]').forEach(function (it) {
        it.onclick = function () {
          var uid = parseInt(it.getAttribute('data-uid'), 10);
          s.close();
          CC.confirm({ title: '转让群主', text: '确定把群主转让给该成员？', danger: true, ok: '确定转让' }).then(function (yes) {
            if (yes) call('group_transfer', { gid: G.gid, uid: uid }, '群主已转让');
          });
        };
      });
    },
    exit: function () {
      CC.confirm({ title: '退出群聊', text: '退出后将不再接收该群消息，确定退出？', danger: true, ok: '退出' }).then(function (yes) {
        if (!yes) return;
        CC.api('group_exit', { gid: G.gid }).then(function () {
          CC.toast('已退出群聊');
          setTimeout(function () { location.href = 'group_list.php'; }, 500);
        }).catch(function (e) { CC.toast(e.message || '操作失败'); });
      });
    },
    dissolve: function () {
      CC.confirm({ title: '解散群聊', text: '解散后所有成员将被移出，且无法恢复。确定解散？', danger: true, ok: '解散' }).then(function (yes) {
        if (!yes) return;
        CC.api('group_dissolve', { gid: G.gid }).then(function () {
          CC.toast('群聊已解散');
          setTimeout(function () { location.href = 'group_list.php'; }, 500);
        }).catch(function (e) { CC.toast(e.message || '操作失败'); });
      });
    }
  };

  document.querySelectorAll('[data-act]').forEach(function (el) {
    var a = el.getAttribute('data-act');
    if (acts[a]) el.onclick = acts[a];
  });
});
</script>
<?php cc_foot(); ?>
