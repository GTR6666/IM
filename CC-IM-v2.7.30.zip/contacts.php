<?php
/**
 * CC商聊 - 通讯录
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$myYxid = $me['pretty_yxid'] ?: ($me['yx_id'] ?: $me['account']);
cc_head('通讯录', ['body_class' => 'app-body', 'css' => '
.ct-tabs{display:flex;gap:6px;background:var(--card);margin:10px 12px 0;padding:6px;border-radius:14px;position:sticky;top:0;z-index:12;box-shadow:0 3px 12px rgba(26,32,60,.04)}
.ct-tab{flex:1;height:38px;border-radius:10px;font-size:14px;color:var(--t2);font-weight:500;display:flex;align-items:center;justify-content:center;gap:6px;position:relative;transition:.18s}
.ct-tab .ct-num{font-size:11px;color:var(--t3);background:var(--bg);border-radius:8px;padding:1px 6px;font-weight:600}
.ct-tab.on{background:var(--brand);color:#fff;font-weight:600;box-shadow:0 6px 16px rgba(7,193,96,.22)}
.ct-tab.on .ct-num{background:rgba(255,255,255,.22);color:#fff}
#paneGroup .cell .c-title{min-width:0}
']); ?>
<div class="app" id="app">
  <div class="page">
    <?php cc_topbar('通讯录', '', '<button class="tb-btn" id="btnAdd" aria-label="添加朋友">'
      . '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>'
      . '</button>'); ?>

    <div class="page-body" id="pb">
      <div class="cell-group" style="margin-top:2px">
        <div class="cell" id="cellNewFriend">
          <div class="c-icon" style="background:rgba(245,166,35,.14);color:var(--gold)">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="9.5" cy="8" r="3.4"/><path d="M3.5 19.5a6 6 0 0 1 12 0"/><path d="M18 8v6M15 11h6"/></svg>
          </div>
          <div class="c-title">新的朋友</div>
          <div class="c-value"><span class="conv-badge hidden" id="bFriend">0</span><span class="arrow">›</span></div>
        </div>
        <div class="cell" id="cellGroupReq">
          <div class="c-icon" style="background:rgba(108,92,240,.14);color:var(--purple)">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><path d="M16.5 7.5a2.6 2.6 0 0 1 0 5"/><path d="M17.5 19a4.5 4.5 0 0 0-2-3.7"/></svg>
          </div>
          <div class="c-title">群通知</div>
          <div class="c-value"><span class="conv-badge hidden" id="bGroup">0</span><span class="arrow">›</span></div>
        </div>
        <div class="cell" id="cellNotice">
          <div class="c-icon" style="background:rgba(59,130,246,.14);color:#3B82F6">
            <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9.5v5a1 1 0 0 0 1 1h3l5 3.5v-14L8 8.5H5a1 1 0 0 0-1 1z"/><path d="M17 9a4.5 4.5 0 0 1 0 6"/></svg>
          </div>
          <div class="c-title">系统公告</div>
          <div class="c-value"><span class="conv-badge hidden" id="bNotice">0</span><span class="arrow">›</span></div>
        </div>
      </div>

      <div class="ct-tabs" id="ctTabs">
        <button class="ct-tab on" data-tab="friend">好友<span class="ct-num" id="cntFriend">0</span></button>
        <button class="ct-tab" data-tab="group">群聊<span class="ct-num" id="cntGroup">0</span></button>
      </div>

      <!-- 好友列表 -->
      <div id="paneFriend">
        <div id="friendBox">
          <div class="cell-group"><div class="loading"><span class="spin"></span> 加载中…</div></div>
        </div>
      </div>

      <!-- 群聊列表 -->
      <div id="paneGroup" style="display:none">
        <div class="cell-group" id="groupBox"><div class="loading"><span class="spin"></span> 加载中…</div></div>
      </div>

      <div class="empty" id="emptyAll" style="display:none">
        <div class="ico">👥</div>
        <div>通讯录还是空的</div>
        <div style="font-size:12px;margin-top:4px">点头像加入口，搜索 CC号 添加好友</div>
      </div>
      <div style="height:26px"></div>
    </div>

    <div id="azBar" style="display:none;position:absolute;right:2px;top:50%;transform:translateY(-50%);z-index:15;padding:4px 3px;border-radius:12px;color:var(--t3);font-size:10px;line-height:1.28;text-align:center;user-select:none"></div>
    <?php cc_tabbar('contacts'); ?>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var FRIENDS = [], GROUPS = [], LETTERS = [];

  function letterOf(name){
    var c = String(name || '').trim().charAt(0);
    if (!c) return '#';
    return /^[A-Za-z]$/.test(c) ? c.toUpperCase() : '#';
  }
  function badge(el, n){
    if (!el) return;
    n = parseInt(n, 10) || 0;
    if (n > 0){ el.textContent = n > 99 ? '99+' : n; el.classList.remove('hidden'); }
    else el.classList.add('hidden');
  }
  function cellAvatar(name, avatar){
    return CC.avatarHtml({ nickname: name, avatar: avatar }, 'sm');
  }

  /* ---------- 好友 ---------- */
  function renderFriends(){
    var box = document.getElementById('friendBox');
    if (!FRIENDS.length){
      box.innerHTML = '<div class="empty" style="padding:34px 16px;font-size:12.5px"><div class="ico">👤</div><div>还没有好友</div>'
        + '<div style="margin-top:10px"><a href="add.php" class="btn small ghost" style="display:inline-flex">去添加好友</a></div></div>';
      LETTERS = [];
      renderAz();
      return;
    }
    var map = {};
    FRIENDS.forEach(function(f){
      var L = letterOf(f.nickname);
      (map[L] = map[L] || []).push(f);
    });
    var keys = Object.keys(map).sort(function(a, b){
      if (a === '#') return 1;
      if (b === '#') return -1;
      return a < b ? -1 : 1;
    });
    LETTERS = keys;
    var html = '';
    keys.forEach(function(L){
      html += '<div class="group-title" id="sec-' + L + '" style="scroll-margin-top:8px">' + L + '</div>';
      html += '<div class="cell-group">';
      map[L].forEach(function(f){
        html += '<div class="cell" data-uid="' + f.id + '">'
          + cellAvatar(f.nickname, f.avatar)
          + '<div class="c-title" style="min-width:0"><div class="name-row"><span class="name-txt">' + CC.esc(f.nickname)
          + '</span><span class="name-tags">' + CC.prettyBadge(f.pretty) + CC.vipTag(f.vip_level) + '</span></div>'
          + (f.remark ? '<div class="c-desc">昵称 ' + CC.esc(f.raw_nickname || '') + '</div>' : '')
          + '</div>'
          + (parseInt(f.online, 10) ? '<span class="tag-online" title="在线"></span>' : '')
          + '<span class="arrow">›</span></div>';
      });
      html += '</div>';
    });
    box.innerHTML = html;
    box.querySelectorAll('.cell[data-uid]').forEach(function(el){
      el.onclick = function(){ location.href = 'index.php?to=' + el.getAttribute('data-uid'); };
    });
    renderAz();
  }

  function renderAz(){
    var bar = document.getElementById('azBar');
    if (!LETTERS.length){ bar.style.display = 'none'; return; }
    bar.style.display = 'block';
    var all = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ#'.split('');
    bar.innerHTML = all.map(function(L){
      var on = LETTERS.indexOf(L) >= 0;
      return '<div data-l="' + L + '" style="padding:1px 4px;color:' + (on ? 'var(--t3)' : 'var(--line)') + ';font-weight:' + (on ? '600' : '400') + '">' + L + '</div>';
    }).join('');
    bar.onclick = function(e){
      var el = e.target.closest ? e.target.closest('[data-l]') : null;
      if (!el) return;
      var L = el.getAttribute('data-l');
      var sec = document.getElementById('sec-' + L);
      if (!sec){ CC.toast(L + ' 组暂无好友'); return; }
      sec.scrollIntoView({ block: 'start', behavior: 'smooth' });
      el.style.color = 'var(--brand)';
      setTimeout(function(){ el.style.color = 'var(--t3)'; }, 260);
    };
  }

  /* ---------- 群聊 ---------- */
  function renderGroups(list){
    var box = document.getElementById('groupBox');
    if (!list.length){
      box.innerHTML = '<div class="empty" style="padding:34px 16px;font-size:12.5px"><div class="ico">👥</div><div>还没有加入任何群聊</div>'
        + '<div style="margin-top:10px"><a href="group_join.php" class="btn small ghost" style="display:inline-flex">去加入群聊</a></div></div>';
      return;
    }
    box.innerHTML = list.map(function(g){
      return '<div class="cell" data-gid="' + g.gid + '">'
        + CC.avatarHtml({ nickname: g.name, avatar: g.avatar }, 'sm')
        + '<div class="c-title nowrap">' + CC.esc(g.name) + '</div>'
        + '<div class="c-value small">' + (g.members || 0) + '人</div>'
        + '<span class="arrow">›</span></div>';
    }).join('');
    box.querySelectorAll('[data-gid]').forEach(function(el){
      el.onclick = function(){ location.href = 'group_info.php?gid=' + el.getAttribute('data-gid'); };
    });
  }

  /* ---------- 群通知（入群申请） ---------- */
  function openGroupReq(){
    CC.ajax('group_join_requests', {}).then(function(res){
      if (res.code !== 0){ CC.toast(res.msg || '加载失败'); return; }
      var list = (res.data && res.data.list) || [];
      var s = CC.sheet('群通知', '<div id="grBox"></div>');
      var box = s.el.querySelector('#grBox');
      function paint(){
        if (!list.length){
          box.innerHTML = '<div class="empty" style="padding:34px 10px"><div class="ico">📭</div><div>暂无新的群通知</div></div>';
          return;
        }
        box.innerHTML = list.map(function(r){
          return '<div class="row-between" style="padding:11px 2px;border-bottom:1px solid var(--line);gap:10px">'
            + '<div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1">'
            + CC.avatarHtml({ nickname: r.nickname, avatar: r.avatar }, 'sm')
            + '<div style="min-width:0"><div class="nowrap" style="font-size:14px">' + CC.esc(r.nickname) + '</div>'
            + '<div class="t3 small nowrap">申请加入 ' + CC.esc(r.gname || '') + '</div></div></div>'
            + '<div class="gap8"><button class="btn small ghost" data-act="reject" data-id="' + r.id + '">拒绝</button>'
            + '<button class="btn small" data-act="accept" data-id="' + r.id + '">同意</button></div></div>';
        }).join('');
        box.querySelectorAll('[data-act]').forEach(function(b){
          b.onclick = function(){
            var act = b.getAttribute('data-act');
            b.disabled = true;
            CC.api('group_handle_join', { id: b.getAttribute('data-id'), act: act }).then(function(){
              CC.toast(act === 'accept' ? '已同意' : '已拒绝');
              list = list.filter(function(x){ return String(x.id) !== String(b.getAttribute('data-id')); });
              paint(); loadUnread();
            }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
          };
        });
      }
      paint();
    });
  }

  /* ---------- 未读 ---------- */
  function loadUnread(){
    CC.ajax('contacts_unread', {}).then(function(res){
      if (res.code !== 0) return;
      var d = res.data || {};
      badge(document.getElementById('bFriend'), d.friend_req);
      badge(document.getElementById('bGroup'), d.group_req);
      badge(document.getElementById('bNotice'), d.notice);
    });
  }

  /* ---------- 好友 / 群聊 标签 ---------- */
  var TAB_KEY = 'contacts_tab';
  function setTab(name, remember){
    if (name !== 'group') name = 'friend';
    document.querySelectorAll('#ctTabs .ct-tab').forEach(function(b){
      b.classList.toggle('on', b.getAttribute('data-tab') === name);
    });
    document.getElementById('paneFriend').style.display = name === 'friend' ? '' : 'none';
    document.getElementById('paneGroup').style.display = name === 'group' ? '' : 'none';
    // 字母索引导航只在好友页显示
    var bar = document.getElementById('azBar');
    if (bar && name !== 'friend') bar.style.display = 'none';
    if (name === 'friend') renderAz();
    if (remember) { try { localStorage.setItem(TAB_KEY, name); } catch (e) {} }
  }
  function setCounts(){
    var f = document.getElementById('cntFriend'), g = document.getElementById('cntGroup');
    if (f) f.textContent = FRIENDS.length;
    if (g) g.textContent = GROUPS.length;
  }
  document.querySelectorAll('#ctTabs .ct-tab').forEach(function(b){
    b.onclick = function(){
      setTab(b.getAttribute('data-tab'), true);
      var pb = document.getElementById('pb'); if (pb) pb.scrollTop = 0;
    };
  });

  /* ---------- 初始化 ---------- */
  document.getElementById('btnAdd').onclick = function(){ location.href = 'add.php'; };
  document.getElementById('cellNewFriend').onclick = function(){ location.href = 'add.php'; };
  document.getElementById('cellGroupReq').onclick = openGroupReq;
  document.getElementById('cellNotice').onclick = function(){ location.href = 'notice.php'; };

  Promise.all([
    CC.ajax('friend_list', {}).then(function(r){ return (r.code === 0 && r.data && r.data.list) || []; }).catch(function(){ return []; }),
    CC.ajax('group_list', {}).then(function(r){ return (r.code === 0 && r.data && r.data.joined) || []; }).catch(function(){ return []; })
  ]).then(function(arr){
    FRIENDS = arr[0] || [];
    GROUPS = arr[1] || [];
    renderFriends();
    renderGroups(GROUPS);
    setCounts();
    var remember = 'friend';
    try { remember = localStorage.getItem(TAB_KEY) || 'friend'; } catch (e) {}
    // 没有好友但有群时默认展示群聊
    if (remember === 'friend' && !FRIENDS.length && GROUPS.length) remember = 'group';
    setTab(remember, false);
    if (!FRIENDS.length && !GROUPS.length) document.getElementById('emptyAll').style.display = 'block';
    else document.getElementById('emptyAll').style.display = 'none';
  });

  loadUnread();
  CC.startBadgePoll(20000);
})();
</script>
<?php cc_foot(); ?>
