<?php
/**
 * CC商聊 - 忘记密码 / 封禁申诉
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$tab = (string)($_GET['appeal'] ?? '') === '1' ? 'appeal' : 'reset';
$account = (string)($_GET['account'] ?? '');
$site = setting('site_name', 'CC商聊');
$emailVerify = email_verify_register();
$serviceContact = trim((string)setting('service_contact', ''));
cc_head($tab === 'appeal' ? '账号申诉' : '找回密码', ['index' => true, 'desc' => setting('site_name', 'CC商聊') . ' 账号找回与申诉入口，可通过邮箱验证码重置密码或提交账号申诉。', 'body_class' => 'login-body', 'css' => '
html{background:#F5F6F8;min-height:100%;}
body{background:#F5F6F8;min-height:100vh;min-height:100dvh;}
.wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px 20px;}
.card{width:100%;max-width:430px;background:#fff;border-radius:20px;padding:26px 22px;box-shadow:0 20px 50px rgba(26,32,60,.08)}
h1{font-size:20px;text-align:center;margin:0 0 6px}
.sub{text-align:center;color:#9AA0AC;font-size:12.5px;margin:0 0 22px;line-height:1.6}
.field{height:50px;border-radius:12px;background:#F5F6F8;margin-bottom:11px}
.field input{font-size:14.5px}
.code-row{display:flex;gap:8px}
.code-row .field{flex:1;margin-bottom:11px}
.code-btn{height:50px;padding:0 14px;border-radius:12px;background:#F0FBF5;color:#07C160;font-size:13px;font-weight:600;margin-bottom:11px}
textarea{width:100%;min-height:110px;background:#F5F6F8;border-radius:12px;padding:12px;font-size:14px;margin-bottom:11px;border:0;outline:0;resize:vertical;color:inherit}
.tabs{display:flex;gap:8px;margin-bottom:18px}
.tabs a{flex:1;text-align:center;padding:9px;border-radius:10px;background:#F5F6F8;color:#6B7280;font-size:13px}
.tabs a.on{background:#07C160;color:#fff;font-weight:600}
.tip-box{background:#F6FBF8;border:1px solid #DFF3E8;border-radius:14px;padding:16px 15px;margin-bottom:16px}
.tip-t{font-size:14px;font-weight:600;color:#07A15A;margin-bottom:6px}
.tip-b{font-size:12.5px;color:#6B7280;line-height:1.8}
.tip-btn{display:block;margin-top:12px;height:42px;line-height:42px;text-align:center;border-radius:11px;background:#07C160;color:#fff;font-size:14px;font-weight:600}
.back{text-align:center;margin-top:18px;font-size:13px;color:#9AA0AC}
.back a{color:#07C160;font-weight:600}
']); ?>

<div class="wrap">
  <div class="card">
    <h1><?= $tab === 'appeal' ? '账号申诉' : '找回密码' ?></h1>
    <p class="sub"><?= $tab === 'appeal' ? '提交后由管理员核实处理，请填写有效联系方式' : '通过绑定邮箱验证身份后重置登录密码' ?></p>

    <div class="tabs">
      <a class="<?= $tab === 'reset' ? 'on' : '' ?>" href="forget.php">找回密码</a>
      <a class="<?= $tab === 'appeal' ? 'on' : '' ?>" href="forget.php?appeal=1">账号申诉</a>
    </div>

    <?php if ($tab === 'reset'): ?>
    <?php if (!$emailVerify): ?>
    <div class="tip-box">
      <div class="tip-t">当前未开启邮箱验证</div>
      <div class="tip-b">如需重置密码，请联系官方客服协助处理<?= $serviceContact !== '' ? '：<br>' . nl2br(e($serviceContact)) : '' ?></div>
      <a class="tip-btn" href="service.php">联系客服</a>
    </div>
    <?php else: ?>
    <div class="field"><input id="kw" type="text" placeholder="CC号 / 邮箱" value="<?= e($account) ?>"></div>
    <div class="code-row">
      <div class="field"><input id="code" type="text" maxlength="6" placeholder="邮箱验证码"></div>
      <button class="code-btn" id="btnCode">获取验证码</button>
    </div>
    <div class="field"><input id="pwd" type="password" maxlength="32" placeholder="新密码（至少 6 位）"></div>
    <button class="btn" id="btnReset">重 置 密 码</button>
    <?php endif; ?>
    <?php else: ?>
    <div class="field"><input id="apAccount" type="text" placeholder="被封禁的账号 / CC号" value="<?= e($account) ?>"></div>
    <textarea id="apReason" maxlength="500" placeholder="请填写申诉理由，例如：账号被盗、误封、已整改等"></textarea>
    <div class="field"><input id="apContact" type="text" maxlength="100" placeholder="联系方式（QQ / TG / 邮箱）"></div>
    <button class="btn" id="btnAppeal">提 交 申 诉</button>
    <?php endif; ?>

    <div class="back"><a href="login.php">返回登录</a></div>
  </div>
</div>

<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var tab = '<?= $tab ?>';
  if (tab === 'reset'){
    var btnCode = document.getElementById('btnCode');
    var btnReset = document.getElementById('btnReset');
    if (btnCode) btnCode.onclick = function(){
      var kw = document.getElementById('kw').value.trim();
      if (!kw) { CC.toast('请先填写账号或邮箱'); return; }
      btnCode.disabled = true;
      CC.ajax('send_code', {target: kw, purpose: 'reset'}).then(function(res){
        btnCode.disabled = false;
        CC.toast(res.msg || (res.data && res.data.debug) || '已发送');
        if (res.data && res.data.debug) console.log(res.data.debug);
        var n = 60;
        btnCode.disabled = true;
        var t = setInterval(function(){
          btnCode.textContent = n + 's';
          if (--n <= 0){ clearInterval(t); btnCode.disabled = false; btnCode.textContent = '获取验证码'; }
        }, 1000);
      }).catch(function(){ btnCode.disabled = false; });
    };
    if (btnReset) btnReset.onclick = function(){
      var kw = document.getElementById('kw').value.trim();
      var code = document.getElementById('code').value.trim();
      var pwd = document.getElementById('pwd').value;
      if (!kw || !code) { CC.toast('请填写完整'); return; }
      if (pwd.length < 6) { CC.toast('新密码至少 6 位'); return; }
      var btn = this; btn.disabled = true; btn.innerHTML = '<span class="spin"></span> 提交中…';
      CC.ajax('reset_password', {keyword: kw, code: code, password: pwd}).then(function(res){
        btn.disabled = false; btn.textContent = '重 置 密 码';
        CC.toast(res.msg || '已提交');
        if (res.code === 0) setTimeout(function(){ location.href = 'login.php'; }, 800);
      });
    };
  } else {
    document.getElementById('btnAppeal').onclick = function(){
      var account = document.getElementById('apAccount').value.trim();
      var reason = document.getElementById('apReason').value.trim();
      var contact = document.getElementById('apContact').value.trim();
      if (!account) { CC.toast('请填写账号'); return; }
      if (reason.length < 5) { CC.toast('请填写申诉理由'); return; }
      var btn = this; btn.disabled = true; btn.innerHTML = '<span class="spin"></span> 提交中…';
      CC.ajax('appeal_submit', {account: account, reason: reason, contact: contact}).then(function(res){
        btn.disabled = false; btn.textContent = '提 交 申 诉';
        CC.toast(res.msg || '已提交');
        if (res.code === 0) setTimeout(function(){ location.href = 'login.php'; }, 1200);
      });
    };
  }
})();
</script>
</body>
</html>
