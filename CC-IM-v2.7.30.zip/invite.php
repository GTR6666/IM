<?php
/**
 * CC商聊 - 邀请有礼（阶梯奖励）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$site = setting('site_name', 'CC商聊');
$uid = (int)$me['id'];

$code = my_invite_code($me);
$count = (int)val('SELECT COUNT(*) FROM invites WHERE uid=?', [$uid]);
$rewards = invite_reward_list($uid, $count);
$nextNeed = 0;
foreach ($rewards as $r) if (!$r['claimed'] && $r['need'] > $count) { $nextNeed = $r['need']; break; }
$lowest = 0;
foreach ($rewards as $r) { if ($lowest === 0 || $r['need'] < $lowest) $lowest = $r['need']; }
$target = $nextNeed > 0 ? $nextNeed : ($lowest > 0 ? $lowest : 0);
$progress = $target > 0 ? min(100, (int)round($count / $target * 100)) : 100;

cc_head('邀请有礼', ['body_class' => 'app-body', 'css' => '
.inv-wrap{padding:12px 12px 96px}
.inv-hero{position:relative;border-radius:20px;padding:22px 18px 20px;color:#fff;text-align:center;overflow:hidden;
  background:linear-gradient(135deg,#07C160 0%,#06AD56 55%,#059669 100%);box-shadow:0 16px 34px rgba(7,193,96,.28)}
.inv-hero::after{content:"";position:absolute;width:190px;height:190px;border-radius:50%;right:-70px;top:-90px;background:rgba(255,255,255,.12)}
.inv-hero .ih-t{font-size:12.5px;opacity:.92;letter-spacing:.4px}
.inv-hero .ih-code{font-size:34px;font-weight:800;letter-spacing:3px;margin:8px 0 14px;font-variant-numeric:tabular-nums}
.inv-copy{display:inline-flex;align-items:center;gap:7px;height:38px;padding:0 18px;border-radius:20px;background:#fff;color:#07A15A;font-size:13.5px;font-weight:600}
.inv-stat{margin-top:12px;background:var(--card);border-radius:16px;padding:16px 16px 14px}
.inv-stat .is-top{display:flex;align-items:baseline;justify-content:space-between;gap:10px;font-size:13px;color:var(--t2)}
.inv-stat .is-top b{font-size:22px;color:var(--brand);font-weight:800;margin:0 3px}
.inv-stat .is-top .is-r{font-size:11.5px;color:var(--t3)}
.is-bar{height:8px;border-radius:5px;background:var(--line);margin-top:11px;overflow:hidden}
.is-bar i{display:block;height:100%;border-radius:5px;background:linear-gradient(90deg,#07C160,#4ED69A);transition:width .5s}
.inv-link{margin-top:12px;background:var(--card);border-radius:16px;padding:16px}
.inv-link .il-t{font-size:11.5px;color:var(--t3)}
.inv-link .il-u{font-size:12.5px;color:var(--brand);word-break:break-all;line-height:1.7;margin-top:7px;font-weight:500}
.inv-link .il-h{font-size:11px;color:var(--t3);line-height:1.65;margin-top:8px}
.il-row{display:flex;align-items:flex-start;gap:10px}
.il-row .il-c{flex:0 0 auto;width:34px;height:34px;border-radius:10px;background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center}
.inv-qr{margin-top:12px;background:var(--card);border-radius:16px;padding:16px;text-align:center}
.qr-head{display:flex;align-items:center;justify-content:space-between;font-size:11.5px;color:var(--t3);margin-bottom:12px}
.qr-save{font-size:11.5px;color:var(--brand);font-weight:600}
.qr-body{display:flex;flex-direction:column;align-items:center;gap:10px}
.qr-body img{width:180px;height:180px;border-radius:12px;background:#fff;padding:6px;box-shadow:0 6px 20px rgba(26,32,60,.08)}
.qr-tip{font-size:12px;color:var(--t3);line-height:1.7}
.qr-share{margin-top:14px;width:100%;height:42px;border-radius:12px;background:var(--brand-soft);color:var(--brand);
  font-size:14px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px}
.sec-t{display:flex;align-items:center;gap:7px;font-size:15px;font-weight:600;padding:20px 4px 10px}
.sec-t::before{content:"";width:3px;height:14px;border-radius:2px;background:var(--brand)}
.rw{display:flex;align-items:center;gap:12px;background:var(--card);border-radius:14px;padding:14px;margin-bottom:10px}
.rw .rw-ico{width:46px;height:46px;border-radius:13px;background:#F4F6FC;display:flex;align-items:center;justify-content:center;font-size:24px;flex:0 0 auto}
.rw .rw-main{flex:1;min-width:0}
.rw .rw-n{font-size:14.5px;font-weight:600}
.rw .rw-s{font-size:11.5px;color:var(--t3);margin-top:4px}
.rw .rw-s b{color:var(--gold);font-weight:700}
.rw .rw-btn{flex:0 0 auto;height:32px;padding:0 14px;border-radius:16px;font-size:12.5px;font-weight:600;background:var(--brand);color:#fff}
.rw .rw-btn.dis{background:var(--line);color:var(--t3);font-weight:500}
.rw .rw-btn.done{background:rgba(7,193,96,.1);color:var(--brand);font-weight:600}
.rw.done .rw-ico{opacity:.55}
.inv-empty{background:var(--card);border-radius:14px;padding:26px 16px;text-align:center;color:var(--t3);font-size:12.5px;line-height:1.8}
.inv-row{display:flex;align-items:center;gap:10px;background:var(--card);border-radius:14px;padding:12px 14px;margin-bottom:8px}
.inv-row .ir-t{flex:1;min-width:0;font-size:13.5px}
.inv-row .ir-s{font-size:11px;color:var(--t3);margin-top:2px}
.inv-bar{position:fixed;left:0;right:0;bottom:0;z-index:30;display:flex;gap:10px;padding:10px 14px calc(10px + var(--safe-b));
  background:rgba(255,255,255,.94);backdrop-filter:blur(14px);border-top:1px solid var(--line);max-width:var(--app-w);margin:0 auto}
.inv-bar button{flex:1;height:46px;border-radius:13px;font-size:14.5px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:7px}
.inv-bar .b-ghost{background:var(--bg);color:var(--text)}
.inv-bar .b-main{background:var(--brand);color:#fff;box-shadow:0 8px 20px rgba(7,193,96,.28)}
']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('邀请好友', 'me.php'); ?>

    <div class="page-body no-tab">
      <div class="inv-wrap">
        <div class="inv-hero">
          <div class="ih-t">我的专属邀请码</div>
          <div class="ih-code" id="invCode"><?= e($code) ?></div>
          <button class="inv-copy" id="btnCopyCode">
            <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/></svg>
            复制邀请码
          </button>
        </div>

        <div class="inv-stat">
          <div class="is-top">
            <div>已成功邀请 <b id="invCount"><?= $count ?></b> 人</div>
            <div class="is-r" id="invTip">
              <?php if ($target > 0 && $count < $target): ?>还差 <span style="color:var(--gold);font-weight:700"><?= $target - $count ?></span> 人可领奖励
              <?php elseif ($target > 0): ?>已达成最低奖励门槛
              <?php else: ?>暂未配置奖励<?php endif; ?>
            </div>
          </div>
          <div class="is-bar"><i id="invBar" style="width:<?= $progress ?>%"></i></div>
        </div>

        <div class="inv-link">
          <div class="il-row">
            <div style="flex:1;min-width:0">
              <div class="il-t">我的专属邀请链接</div>
              <div class="il-u" id="invUrl"><?= e(site_url('register.php?invite=' . $code)) ?></div>
              <div class="il-h">好友打开链接注册会自动绑定你的邀请码，注册成功后计入邀请人数</div>
            </div>
            <button class="il-c" id="btnCopyUrl" aria-label="复制链接">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/></svg>
            </button>
          </div>
        </div>

        <div class="inv-qr">
          <div class="qr-head">
            <span>我的二维码名片</span>
            <button class="qr-save" id="btnQrSave">保存到相册</button>
          </div>
          <div class="qr-body">
            <img id="qrImg" src="qr.php?f=png&s=300&d=<?= urlencode(site_url('register.php?invite=' . $code)) ?>" alt="邀请二维码" width="180" height="180">
            <div class="qr-tip">扫码即可注册<br>自动绑定你的邀请码</div>
          </div>
          <button class="qr-share" id="btnQrShare">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="18" cy="5.5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="18.5" r="2.6"/><path d="M8.3 10.7l7.4-3.9M8.3 13.3l7.4 3.9"/></svg>
            分享二维码名片
          </button>
        </div>

        <div class="sec-t">邀请奖励</div>
        <div id="rewardList">
          <?php if (!$rewards): ?>
          <div class="inv-empty">暂未配置邀请奖励<br>请稍后再来看看</div>
          <?php endif; ?>
          <?php foreach ($rewards as $r): ?>
          <div class="rw <?= $r['claimed'] ? 'done' : '' ?>">
            <div class="rw-ico"><?= e($r['icon']) ?></div>
            <div class="rw-main">
              <div class="rw-n"><?= e($r['name']) ?></div>
              <div class="rw-s">需邀请 <b><?= (int)$r['need'] ?></b> 人<?= $r['claimed'] ? ' · 已领取' : '' ?></div>
            </div>
            <?php if ($r['claimed']): ?>
            <div class="rw-btn dis">已领取</div>
            <?php elseif ($r['claimable']): ?>
            <button class="rw-btn" data-claim="<?= (int)$r['id'] ?>">立即领取</button>
            <?php else: ?>
            <div class="rw-btn dis">未达成</div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="sec-t">我邀请了谁</div>
        <div id="invitedList">
          <div class="inv-empty" id="invitedEmpty">还没有邀请记录<br>快去复制专属链接分享给好友吧</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="inv-bar">
  <button class="b-ghost" id="btnShare">
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="18" cy="5.5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="18.5" r="2.6"/><path d="M8.3 10.7l7.4-3.9M8.3 13.3l7.4 3.9"/></svg>
    分享链接
  </button>
  <button class="b-main" id="btnPoster">
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M12 3.5v11"/><path d="M8 10.5l4 4 4-4"/><path d="M4 17.5h16"/></svg>
    保存海报
  </button>
</div>

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var SITE = <?= json_encode($site, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var DATA = { code: <?= json_encode($code) ?>, url: <?= json_encode(site_url('register.php?invite=' . $code)) ?>, count: <?= $count ?> };

  function copyText(text){
    if (!text) return;
    if (navigator.clipboard && window.isSecureContext){
      navigator.clipboard.writeText(text).then(function(){ CC.toast('已复制'); }, function(){ fb(); });
    } else fb();
    function fb(){
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); CC.toast('已复制'); } catch (e) { CC.toast('复制失败，请长按选择'); }
      ta.remove();
    }
  }

  document.getElementById('btnCopyCode').onclick = function(){ copyText(DATA.code); };
  document.getElementById('btnCopyUrl').onclick = function(){ copyText(DATA.url); };

  function share(){
    var text = '我在 ' + SITE + ' 等你，注册填邀请码 ' + DATA.code + '，一起领会员和靓号奖励';
    if (navigator.share){
      navigator.share({ title: '邀请你加入 ' + SITE, text: text, url: DATA.url }).catch(function(){ copyText(text + ' ' + DATA.url); });
    } else {
      copyText(text + ' ' + DATA.url);
    }
  }
  document.getElementById('btnShare').onclick = share;

  /* ---------- 领取奖励 ---------- */
  document.querySelectorAll('[data-claim]').forEach(function(b){
    b.onclick = function(){
      var id = b.getAttribute('data-claim');
      b.disabled = true; var raw = b.textContent; b.textContent = '领取中…';
      CC.ajax('invite_claim', { reward_id: id }).then(function(res){
        if (res.code === 0){
          CC.toast(res.msg || '领取成功');
          setTimeout(function(){ location.reload(); }, 900);
        } else {
          b.disabled = false; b.textContent = raw;
          CC.toast(res.msg || '领取失败');
        }
      }).catch(function(){ b.disabled = false; b.textContent = raw; CC.toast('网络异常'); });
    };
  });

  /* ---------- 邀请记录 ---------- */
  CC.ajax('invite_info', {}).then(function(res){
    if (res.code !== 0) return;
    var d = res.data || {};
    if (Array.isArray(d.invited) && d.invited.length){
      var box = document.getElementById('invitedList');
      box.innerHTML = d.invited.map(function(u){
        return '<div class="inv-row">' + CC.avatarHtml(u, 'sm') +
          '<div class="ir-t"><div class="nowrap">' + CC.esc(u.nickname || '用户') + '</div>' +
          '<div class="ir-s">CC号 ' + CC.esc(u.yx_id || '') + '</div></div>' +
          '<div class="ir-s">' + CC.fmtTime(u.created_at) + '</div></div>';
      }).join('');
      var emp = document.getElementById('invitedEmpty');
      if (emp) emp.style.display = 'none';
    }
  }).catch(function(){});

  /* ---------- 二维码名片 ---------- */
  var qrUrl = <?= json_encode(site_url('register.php?invite=' . $code)) ?>;

  document.getElementById('btnQrShare').onclick = function(){
    var text = '我在 ' + SITE + ' 等你，扫码或点链接注册：' + qrUrl;
    if (navigator.share){
      navigator.share({ title: '邀请你加入 ' + SITE, text: text, url: qrUrl }).catch(function(){ copyText(qrUrl); });
    } else { copyText(qrUrl); }
  };

  document.getElementById('btnQrSave').onclick = function(){
    var img = document.getElementById('qrImg');
    var a = document.createElement('a');
    a.href = img.src;
    a.download = 'invite-qr-' + DATA.code + '.png';
    document.body.appendChild(a); a.click(); a.remove();
    CC.toast('二维码已保存');
  };

  /* ---------- 保存海报 ---------- */
  document.getElementById('btnPoster').onclick = function(){
    var W = 750, H = 1050;
    var c = document.createElement('canvas');
    c.width = W; c.height = H;
    var g = c.getContext('2d');
    // 背景
    var bg = g.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#07C160'); bg.addColorStop(.55, '#06AD56'); bg.addColorStop(1, '#059669');
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    // 卡片
    g.fillStyle = '#FFFFFF';
    var r = 36;
    var x = 50, y = 150, w = W - 100, h = H - 300;
    g.beginPath();
    g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r);
    g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r);
    g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y);
    g.closePath(); g.fill();
    // 文案
    g.textAlign = 'center';
    g.fillStyle = 'rgba(255,255,255,.92)';
    g.font = '600 30px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText(SITE, W / 2, 95);
    g.fillStyle = '#1A2030';
    g.font = '700 40px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText('邀请你加入' + SITE, W / 2, y + 90);
    g.fillStyle = '#9AA0AC';
    g.font = '26px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText('注册请填写我的邀请码', W / 2, y + 150);
    g.fillStyle = '#07C160';
    g.font = '800 76px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText(DATA.code, W / 2, y + 250);
    g.fillStyle = '#6B7280';
    g.font = '24px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText('邀请好友注册可得 VIP / SVIP / 靓号奖励', W / 2, y + 320);
    // 链接二维码区域占位
    g.fillStyle = '#F4F6FA';
    var qy = y + 370, qs = 220;
    g.beginPath();
    g.moveTo((W - qs) / 2 + 20, qy); g.arcTo(W / 2 + qs / 2, qy, W / 2 + qs / 2, qy + qs, 22);
    g.arcTo(W / 2 + qs / 2, qy + qs, (W - qs) / 2, qy + qs, 22);
    g.arcTo((W - qs) / 2, qy + qs, (W - qs) / 2, qy, 22);
    g.arcTo((W - qs) / 2, qy, W / 2 + qs / 2, qy, 22);
    g.closePath(); g.fill();
    g.fillStyle = '#9AA0AC';
    g.font = '22px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText('扫码或打开链接注册', W / 2, qy + qs / 2 + 8);
    g.fillStyle = '#07C160';
    g.font = '20px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif';
    g.fillText(DATA.url.replace(/^https?:\/\//, ''), W / 2, y + h - 40);

    try {
      var url = c.toDataURL('image/png');
      var a = document.createElement('a');
      a.href = url; a.download = 'invite-' + DATA.code + '.png';
      document.body.appendChild(a); a.click(); a.remove();
      CC.toast('海报已生成，请到相册/下载中查看');
    } catch (e) {
      CC.toast('海报生成失败');
    }
  };
})();
</script>
<?php cc_foot(); ?>
