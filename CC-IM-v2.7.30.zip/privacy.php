<?php
/**
 * CC商聊 - 隐私设置
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$S = json_decode_arr($me['settings'] ?? '');
$val = static function (string $k, string $d = '1') use ($S): string {
    return (string)($S[$k] ?? $d);
};
cc_head('隐私设置', ['body_class' => 'app-body', 'css' => '
.pv-sec{font-size:12.5px;color:var(--t3);padding:18px 18px 8px;font-weight:600;display:flex;align-items:center;gap:7px}
.pv-sec::before{content:"";width:3px;height:12px;border-radius:2px;background:var(--brand)}
.pv-item{display:flex;align-items:flex-start;gap:12px;padding:15px 16px;background:var(--card);cursor:pointer}
.pv-item+.pv-item{border-top:1px solid var(--line)}
.pv-main{flex:1;min-width:0}
.pv-t{font-size:15px;font-weight:500}
.pv-s{font-size:11.5px;color:var(--t3);line-height:1.65;margin-top:4px}
.pv-item.danger .pv-t{color:var(--red)}
.sw{position:relative;width:48px;height:28px;flex:0 0 auto;border-radius:16px;background:#D5DBE6;transition:.2s;margin-top:2px}
.sw::after{content:"";position:absolute;width:24px;height:24px;border-radius:50%;background:#fff;left:2px;top:2px;transition:.2s;box-shadow:0 1px 4px rgba(0,0,0,.18)}
.sw.on{background:var(--brand)}
.sw.on::after{transform:translateX(20px)}
']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('隐私设置', 'me.php'); ?>
    <div class="page-body no-tab">

      <div class="pv-sec">好友隐私</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" data-k="allow_add" data-v="<?= e($val('allow_add')) ?>">
          <div class="pv-main">
            <div class="pv-t">允许任何人添加我为好友</div>
            <div class="pv-s">关闭后，别人无法向你发送好友申请</div>
          </div>
          <span class="sw <?= $val('allow_add') === '1' ? 'on' : '' ?>"></span>
        </div>
        <div class="pv-item" data-k="friend_no_verify" data-v="<?= e($val('friend_no_verify', '0')) ?>">
          <div class="pv-main">
            <div class="pv-t">添加好友无需验证</div>
            <div class="pv-s">开启后，别人添加你会直接成为好友，不再发送好友申请</div>
          </div>
          <span class="sw <?= $val('friend_no_verify', '0') === '1' ? 'on' : '' ?>"></span>
        </div>
      </div>

      <div class="pv-sec">隐私</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" id="cellBlock">
          <div class="pv-main">
            <div class="pv-t">黑名单管理</div>
            <div class="pv-s">被拉黑的人无法给你发消息、看你的动态，也无法加你为好友</div>
          </div>
          <span class="arrow">›</span>
        </div>
        <div class="pv-item" data-k="read_receipt" data-v="<?= e($val('read_receipt')) ?>">
          <div class="pv-main">
            <div class="pv-t">已读回执</div>
            <div class="pv-s">关闭后双方都看不到消息的已读状态</div>
          </div>
          <span class="sw <?= $val('read_receipt') === '1' ? 'on' : '' ?>"></span>
        </div>
      </div>

      <div class="pv-sec">群聊隐私</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" data-k="allow_group_invite" data-v="<?= e($val('allow_group_invite')) ?>">
          <div class="pv-main">
            <div class="pv-t">允许任何人邀请我加入群聊</div>
            <div class="pv-s">关闭后，别人邀请你需要你同意才能进群</div>
          </div>
          <span class="sw <?= $val('allow_group_invite') === '1' ? 'on' : '' ?>"></span>
        </div>
      </div>

      <div class="pv-sec">危险操作</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item danger" id="cellDelete">
          <div class="pv-main">
            <div class="pv-t">注销账号</div>
            <div class="pv-s">永久删除账号及全部数据，靓号将回收</div>
          </div>
          <span class="arrow">›</span>
        </div>
      </div>

      <div style="height:30px"></div>
    </div>
  </div>
</div>

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  /* ---------- 开关 ---------- */
  document.querySelectorAll('.pv-item[data-k]').forEach(function(row){
    row.onclick = function(){
      var k = row.getAttribute('data-k');
      var cur = row.getAttribute('data-v') === '1' ? '1' : '0';
      var next = cur === '1' ? '0' : '1';
      var sw = row.querySelector('.sw');
      row.setAttribute('data-v', next);
      sw.classList.toggle('on', next === '1');
      var payload = {}; payload[k] = next;
      CC.api('update_settings', payload).then(function(){
        CC.toast(next === '1' ? '已开启' : '已关闭');
      }).catch(function(e){
        row.setAttribute('data-v', cur);
        sw.classList.toggle('on', cur === '1');
        CC.toast(e.message);
      });
    };
  });

  /* ---------- 黑名单 ---------- */
  document.getElementById('cellBlock').onclick = function(){
    var s = CC.sheet('黑名单管理', '<div id="blBox"><div class="loading"><span class="spin"></span> 加载中…</div></div>');
    var box = s.el.querySelector('#blBox');
    function load(){
      CC.ajax('block_list', {}).then(function(res){
        if (res.code !== 0){ box.innerHTML = '<div class="empty" style="padding:30px">加载失败</div>'; return; }
        var list = (res.data && res.data.list) || [];
        if (!list.length){
          box.innerHTML = '<div class="empty" style="padding:34px 16px"><div class="ico">🛡️</div><div>黑名单为空</div>'
            + '<div style="font-size:12px;margin-top:6px;color:var(--t3)">在聊天或资料页可以拉黑对方</div></div>';
          return;
        }
        box.innerHTML = list.map(function(u){
          return '<div class="row-between" style="padding:12px 2px;border-bottom:1px solid var(--line);gap:10px">'
            + CC.avatarHtml({ nickname: u.name, avatar: u.avatar }, 'sm')
            + '<div style="flex:1;min-width:0"><div class="nowrap">' + CC.esc(u.name) + '</div>'
            + '<div class="t3 small">' + CC.T('id','CC号') + ' ' + CC.esc(u.account) + '</div></div>'
            + '<button class="btn small ghost" data-unblock="' + u.uid + '">移出</button></div>';
        }).join('');
        box.querySelectorAll('[data-unblock]').forEach(function(b){
          b.onclick = function(){
            b.disabled = true;
            CC.api('block_del', { uid: b.getAttribute('data-unblock') }).then(function(){
              CC.toast('已移出黑名单'); load();
            }).catch(function(e){ b.disabled = false; CC.toast(e.message); });
          };
        });
      }).catch(function(){ box.innerHTML = '<div class="empty" style="padding:30px">加载失败</div>'; });
    }
    load();
  };

  /* ---------- 注销账号 ---------- */
  document.getElementById('cellDelete').onclick = function(){
    CC.confirm({
      title: '注销账号',
      html: '<div style="background:#FEF2F2;border:1px solid #FBD5D5;border-radius:10px;padding:12px 14px;color:#B91C1C;font-size:12.5px;line-height:1.8">'
        + '<b>此操作不可恢复！</b><br>账号资料将被清除、无法登录；已购靓号会被回收放回商城；聊天记录仍会保留在对方设备与数据库中。</div>'
        + '<div class="field" style="margin-top:12px"><input id="delPwd" type="password" placeholder="请输入登录密码确认" autocomplete="current-password"></div>',
      ok: '确认注销',
      danger: true
    }).then(function(yes){
      if (!yes) return;
      var pwd = (document.getElementById('delPwd') || {}).value || '';
      if (!pwd){ CC.toast('请输入密码'); return; }
      CC.api('account_delete', { password: pwd }).then(function(){
        CC.toast('账号已注销');
        setTimeout(function(){ location.replace('login.php'); }, 900);
      }).catch(function(e){ CC.toast(e.message); });
    });
  };
})();
</script>
<?php cc_foot(); ?>
