<?php
/**
 * CC商聊 - 官方公告
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$rows = all('SELECT * FROM notices WHERE status=1 ORDER BY is_top DESC, id DESC LIMIT 50');
$readMap = [];
foreach (all('SELECT nid FROM notice_reads WHERE uid=?', [(int)$me['id']]) as $r) $readMap[(int)$r['nid']] = 1;
$unread = 0;
foreach ($rows as $r) if (!isset($readMap[(int)$r['id']])) $unread++;

cc_head('官方公告', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('官方公告', 'me.php', $rows ? '<button class="tb-btn" id="btnReadAll" style="font-size:13px;color:var(--brand);width:auto;padding:0 4px">全部已读</button>' : ''); ?>

    <div class="page-body no-tab">
      <?php if (!$rows): ?>
      <div class="empty"><div class="ico">📢</div><div>暂无官方公告</div></div>
      <?php else: ?>
      <div class="t3 small" style="padding:4px 18px 0" id="unreadTip"><?= $unread > 0 ? '有 ' . $unread . ' 条未读公告' : '全部已读' ?></div>
      <div id="noticeList">
        <?php foreach ($rows as $r):
            $rid = (int)$r['id'];
            $isRead = isset($readMap[$rid]);
        ?>
        <div class="card" data-nid="<?= $rid ?>" data-read="<?= $isRead ? 1 : 0 ?>"
             style="padding:16px;position:relative<?= $isRead ? '' : ';box-shadow:0 0 0 1.5px rgba(7,193,96,.35)' ?>">
          <?php if (!empty($r['is_top'])): ?>
          <span class="badge red" style="position:absolute;top:12px;right:12px">置顶</span>
          <?php endif; ?>
          <div style="display:flex;align-items:center;gap:8px;padding-right:52px">
            <?php if (!$isRead): ?>
            <span style="width:7px;height:7px;border-radius:50%;background:var(--brand);flex:0 0 auto"></span>
            <?php endif; ?>
            <div style="font-size:15.5px;font-weight:600;line-height:1.45"><?= e($r['title']) ?></div>
          </div>
          <div class="t3 small" style="margin-top:6px"><?= e(date('Y-m-d H:i', (int)$r['created_at'])) ?></div>
          <div class="nt-body" style="font-size:14px;line-height:1.75;color:var(--t2);margin-top:10px;white-space:pre-wrap;word-break:break-word;
               display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden"><?= e((string)$r['content']) ?></div>
          <div class="row-between" style="margin-top:12px">
            <button class="btn small ghost" data-toggle="<?= $rid ?>">展开全文</button>
            <?php if ($isRead): ?>
            <span class="badge gray" data-ack="<?= $rid ?>">已读</span>
            <?php else: ?>
            <button class="btn small" data-ack="<?= $rid ?>">我已知晓</button>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <div style="height:22px"></div>
    </div>
  </div>
</div>

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  function refreshTip(){
    var left = document.querySelectorAll('.card[data-read="0"]').length;
    var tip = document.getElementById('unreadTip');
    if (tip) tip.textContent = left > 0 ? ('有 ' + left + ' 条未读公告') : '全部已读';
  }
  function markRead(card, silent){
    var id = card.getAttribute('data-nid');
    return CC.ajax('notice_read', { id: id }).then(function(res){
      if (res.code !== 0) throw new Error(res.msg || '操作失败');
      card.setAttribute('data-read', '1');
      card.style.boxShadow = '';
      var dot = card.querySelector('span[style*="border-radius:50%"]');
      if (dot) dot.remove();
      var ack = card.querySelector('[data-ack]');
      if (ack){
        var span = document.createElement('span');
        span.className = 'badge gray';
        span.setAttribute('data-ack', id);
        span.textContent = '已读';
        ack.parentNode.replaceChild(span, ack);
      }
      if (!silent) CC.toast('已标记为已读');
      refreshTip();
      return true;
    }).catch(function(e){ if (!silent) CC.toast(e.message); throw e; });
  }

  document.querySelectorAll('[data-toggle]').forEach(function(b){
    b.onclick = function(){
      var card = b.closest('.card');
      var body = card.querySelector('.nt-body');
      var open = b.getAttribute('data-open') === '1';
      if (open){
        body.style.webkitLineClamp = '3';
        body.style.display = '-webkit-box';
        b.textContent = '展开全文';
        b.setAttribute('data-open', '0');
      } else {
        body.style.webkitLineClamp = 'unset';
        body.style.display = 'block';
        b.textContent = '收起';
        b.setAttribute('data-open', '1');
      }
    };
  });

  document.querySelectorAll('button[data-ack]').forEach(function(b){
    b.onclick = function(){
      var card = b.closest('.card');
      b.disabled = true;
      markRead(card).catch(function(){ b.disabled = false; });
    };
  });

  var all = document.getElementById('btnReadAll');
  if (all){
    all.onclick = function(){
      all.disabled = true;
      CC.ajax('notice_read', {}).then(function(res){
        if (res.code !== 0){ all.disabled = false; CC.toast(res.msg || '操作失败'); return; }
        document.querySelectorAll('.card[data-read="0"]').forEach(function(card){
          card.setAttribute('data-read', '1');
          card.style.boxShadow = '';
          var dot = card.querySelector('span[style*="border-radius:50%"]');
          if (dot) dot.remove();
          var ack = card.querySelector('button[data-ack]');
          if (ack){
            var span = document.createElement('span');
            span.className = 'badge gray';
            span.setAttribute('data-ack', ack.getAttribute('data-ack'));
            span.textContent = '已读';
            ack.parentNode.replaceChild(span, ack);
          }
        });
        refreshTip();
        CC.toast('已全部标记为已读');
        all.style.display = 'none';
      }).catch(function(){ all.disabled = false; CC.toast('操作失败'); });
    };
  }
})();
</script>
<?php cc_foot(); ?>
