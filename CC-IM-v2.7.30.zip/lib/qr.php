<?php
/**
 * CC商聊 - 轻量 QR 码生成（无第三方依赖）
 * 支持：字节模式、纠错等级 M、版本 1-7（最多 122 字节，足够放邀请链接）
 * 输出：布尔矩阵，交由 qr.php 渲染成 SVG
 */
declare(strict_types=1);

/** 各版本：总码字数 / 每块纠错码字 / 块数（纠错等级 M，块长均为整数） */
function qr_spec(): array
{
    return [
        1  => ['total' => 26,  'ec' => 10, 'blocks' => 1],
        2  => ['total' => 44,  'ec' => 16, 'blocks' => 1],
        3  => ['total' => 70,  'ec' => 26, 'blocks' => 1],
        4  => ['total' => 100, 'ec' => 18, 'blocks' => 2],
        5  => ['total' => 134, 'ec' => 24, 'blocks' => 2],
        6  => ['total' => 172, 'ec' => 16, 'blocks' => 4],
        7  => ['total' => 196, 'ec' => 18, 'blocks' => 4],
    ];
}

/** 校正图形中心坐标 */
function qr_alignment(int $v): array
{
    return [
        1 => [],
        2 => [6, 18],
        3 => [6, 22],
        4 => [6, 26],
        5 => [6, 30],
        6 => [6, 34],
        7 => [6, 22, 38],
    ][$v] ?? [];
}

/** GF(256) 表 */
function qr_gf(): array
{
    static $t = null;
    if ($t !== null) return $t;
    $exp = array_fill(0, 512, 0);
    $log = array_fill(0, 256, 0);
    $x = 1;
    for ($i = 0; $i < 255; $i++) {
        $exp[$i] = $x;
        $log[$x] = $i;
        $x <<= 1;
        if ($x & 0x100) $x ^= 0x11D;
    }
    for ($i = 255; $i < 512; $i++) $exp[$i] = $exp[$i - 255];
    return $t = ['exp' => $exp, 'log' => $log];
}

function qr_mul(int $a, int $b): int
{
    if ($a === 0 || $b === 0) return 0;
    $g = qr_gf();
    return $g['exp'][$g['log'][$a] + $g['log'][$b]];
}

/** 生成多项式（次数为 n） */
function qr_gen_poly(int $n): array
{
    $poly = [1];
    for ($i = 0; $i < $n; $i++) {
        $next = array_fill(0, count($poly) + 1, 0);
        foreach ($poly as $j => $c) {
            $next[$j] ^= qr_mul($c, 1);                // × x
            $next[$j + 1] ^= qr_mul($c, qr_gf()['exp'][$i]);
        }
        $poly = $next;
    }
    return $poly;
}

/** 计算一块数据的纠错码字 */
function qr_ec_block(array $data, int $ecLen): array
{
    $gen = qr_gen_poly($ecLen);
    $res = array_merge($data, array_fill(0, $ecLen, 0));
    $dlen = count($data);
    for ($i = 0; $i < $dlen; $i++) {
        $factor = $res[$i];
        if ($factor === 0) continue;
        for ($j = 0; $j < count($gen); $j++) {
            $res[$i + $j] ^= qr_mul($gen[$j], $factor);
        }
    }
    return array_slice($res, $dlen);
}

/** 生成 QR 矩阵：$matrix[y][x] = true 表示黑块 */
function qr_matrix(string $text): array
{
    $len = strlen($text);
    $spec = qr_spec();
    $version = 0;
    foreach ($spec as $v => $s) {
        $dataCw = $s['total'] - $s['ec'] * $s['blocks'];
        $cap = $dataCw - 2;   // 4bit 模式 + 8bit 长度
        if ($len <= $cap) { $version = $v; $sel = $s; break; }
    }
    if (!$version) throw new RuntimeException('内容过长，无法生成二维码');

    $dataCw = $sel['total'] - $sel['ec'] * $sel['blocks'];

    // ---- 1. 生成数据比特流 ----
    $bits = '0100';                      // 字节模式
    $bits .= str_pad(decbin($len), 8, '0', STR_PAD_LEFT);
    for ($i = 0; $i < $len; $i++) $bits .= str_pad(decbin(ord($text[$i])), 8, '0', STR_PAD_LEFT);
    $bits .= str_repeat('0', min(4, $dataCw * 8 - strlen($bits)));   // 终止符
    while (strlen($bits) % 8 !== 0) $bits .= '0';

    $codewords = [];
    for ($i = 0; $i < strlen($bits); $i += 8) $codewords[] = bindec(substr($bits, $i, 8));
    $pad = [0xEC, 0x11];
    for ($i = 0; count($codewords) < $dataCw; $i++) $codewords[] = $pad[$i % 2];

    // ---- 2. 分块 + 纠错 + 交织 ----
    $blocks = $sel['blocks'];
    $blockLen = intdiv($dataCw, $blocks);
    $dataBlocks = [];
    $ecBlocks = [];
    for ($b = 0; $b < $blocks; $b++) {
        $chunk = array_slice($codewords, $b * $blockLen, $blockLen);
        $dataBlocks[] = $chunk;
        $ecBlocks[] = qr_ec_block($chunk, $sel['ec']);
    }
    $final = [];
    for ($i = 0; $i < $blockLen; $i++) {
        for ($b = 0; $b < $blocks; $b++) $final[] = $dataBlocks[$b][$i];
    }
    for ($i = 0; $i < $sel['ec']; $i++) {
        for ($b = 0; $b < $blocks; $b++) $final[] = $ecBlocks[$b][$i];
    }

    // ---- 3. 初始化矩阵 ----
    $size = $version * 4 + 17;
    $m = [];
    $fn = [];
    for ($y = 0; $y < $size; $y++) {
        $m[$y] = array_fill(0, $size, 0);
        $fn[$y] = array_fill(0, $size, 0);
    }

    // 定位图形 + 分隔符
    foreach ([[0, 0], [$size - 7, 0], [0, $size - 7]] as $pos) {
        [$ox, $oy] = $pos;
        for ($dy = -1; $dy <= 7; $dy++) {
            for ($dx = -1; $dx <= 7; $dx++) {
                $x = $ox + $dx; $y = $oy + $dy;
                if ($x < 0 || $y < 0 || $x >= $size || $y >= $size) continue;
                $fn[$y][$x] = 1;
                $inRing = ($dx >= 0 && $dx <= 6 && $dy >= 0 && $dy <= 6);
                if (!$inRing) { $m[$y][$x] = 0; continue; }
                $edge = ($dx === 0 || $dx === 6 || $dy === 0 || $dy === 6);
                $core = ($dx >= 2 && $dx <= 4 && $dy >= 2 && $dy <= 4);
                $m[$y][$x] = ($edge || $core) ? 1 : 0;
            }
        }
    }

    // 时序图形
    for ($i = 8; $i < $size - 8; $i++) {
        if (!$fn[6][$i]) { $m[6][$i] = ($i % 2 === 0) ? 1 : 0; $fn[6][$i] = 1; }
        if (!$fn[$i][6]) { $m[$i][6] = ($i % 2 === 0) ? 1 : 0; $fn[$i][6] = 1; }
    }

    // 校正图形
    $centers = qr_alignment($version);
    foreach ($centers as $cy) {
        foreach ($centers as $cx) {
            if (($cx === 6 && $cy === 6) || ($cx === 6 && $cy === $size - 7) || ($cx === $size - 7 && $cy === 6)) continue;
            for ($dy = -2; $dy <= 2; $dy++) {
                for ($dx = -2; $dx <= 2; $dx++) {
                    $x = $cx + $dx; $y = $cy + $dy;
                    if ($x < 0 || $y < 0 || $x >= $size || $y >= $size) continue;
                    $fn[$y][$x] = 1;
                    $ring = (abs($dx) === 2 || abs($dy) === 2);
                    $m[$y][$x] = ($ring || ($dx === 0 && $dy === 0)) ? 1 : 0;
                }
            }
        }
    }

    // 预留格式信息区 + 固定黑块
    for ($i = 0; $i <= 8; $i++) {
        if ($i !== 6) { $fn[8][$i] = 1; $fn[$i][8] = 1; }
    }
    for ($i = 0; $i < 8; $i++) {
        $fn[8][$size - 1 - $i] = 1;
        $fn[$size - 1 - $i][8] = 1;
    }
    $m[$size - 8][8] = 1; $fn[$size - 8][8] = 1;

    // 版本信息（v7+）
    if ($version >= 7) {
        for ($i = 0; $i < 6; $i++) {
            for ($j = 0; $j < 3; $j++) {
                $fn[$size - 11 + $j][$i] = 1;
                $fn[$i][$size - 11 + $j] = 1;
            }
        }
    }

    // ---- 4. 放置数据 ----
    $bitIdx = 0;
    $totalBits = count($final) * 8;
    $bit = static function (int $idx) use ($final, $totalBits): int {
        if ($idx >= $totalBits) return 0;
        return (($final[intdiv($idx, 8)] >> (7 - $idx % 8)) & 1) ? 1 : 0;
    };
    $upward = true;
    for ($col = $size - 1; $col > 0; $col -= 2) {
        if ($col === 6) $col--;                     // 跳过时序列
        for ($i = 0; $i < $size; $i++) {
            $y = $upward ? ($size - 1 - $i) : $i;
            foreach ([$col, $col - 1] as $x) {
                if ($fn[$y][$x]) continue;
                $m[$y][$x] = $bit($bitIdx++);
            }
        }
        $upward = !$upward;
    }

    // ---- 5. 掩码 + 评分 ----
    $best = null; $bestScore = PHP_INT_MAX;
    for ($mask = 0; $mask < 8; $mask++) {
        $tmp = $m;
        for ($y = 0; $y < $size; $y++) {
            for ($x = 0; $x < $size; $x++) {
                if ($fn[$y][$x]) continue;
                if (qr_mask($mask, $x, $y)) $tmp[$y][$x] ^= 1;
            }
        }
        qr_set_format($tmp, $size, $mask);
        if ($version >= 7) qr_set_version($tmp, $size, $version);
        $score = qr_penalty($tmp, $size);
        if ($score < $bestScore) { $bestScore = $score; $best = $tmp; }
    }
    return $best;
}

function qr_mask(int $mask, int $x, int $y): bool
{
    switch ($mask) {
        case 0: return (($x + $y) % 2) === 0;
        case 1: return ($y % 2) === 0;
        case 2: return ($x % 3) === 0;
        case 3: return (($x + $y) % 3) === 0;
        case 4: return ((intdiv($y, 2) + intdiv($x, 3)) % 2) === 0;
        case 5: return ((($x * $y) % 2) + (($x * $y) % 3)) === 0;
        case 6: return (((($x * $y) % 2) + (($x * $y) % 3)) % 2) === 0;
        default: return (((($x + $y) % 2) + (($x * $y) % 3)) % 2) === 0;
    }
}

/** 写入格式信息（纠错等级 M => 0b00） */
function qr_set_format(array &$m, int $size, int $mask): void
{
    $data = (0 << 3) | $mask;           // 等级 M 的两位为 00
    $rem = $data;
    for ($i = 0; $i < 10; $i++) $rem = ($rem << 1) ^ ((($rem >> 9) & 1) * 0x537);
    $bits = (($data << 10) | $rem) ^ 0x5412;   // 15 位
    $get = static function (int $i) use ($bits): int { return ($bits >> $i) & 1; };

    // 第一份：竖排于列 8（行 0-5,7,8），横排于行 8（列 7,5..0）
    for ($i = 0; $i <= 5; $i++) $m[$i][8] = $get($i);
    $m[7][8] = $get(6);
    $m[8][8] = $get(7);
    $m[8][7] = $get(8);
    for ($i = 9; $i <= 14; $i++) $m[8][14 - $i] = $get($i);

    // 第二份：横排于行 8 右侧，竖排于列 8 底部
    for ($i = 0; $i <= 7; $i++) $m[8][$size - 1 - $i] = $get($i);
    for ($i = 8; $i <= 14; $i++) $m[$size - 15 + $i][8] = $get($i);
    $m[$size - 8][8] = 1;
}

/** 写入版本信息（v7+） */
function qr_set_version(array &$m, int $size, int $version): void
{
    $rem = $version;
    for ($i = 0; $i < 12; $i++) $rem = ($rem << 1) ^ ((($rem >> 11) & 1) * 0x1F25);
    $bits = ($version << 12) | $rem;
    for ($i = 0; $i < 18; $i++) {
        $b = ($bits >> $i) & 1;
        $r = intdiv($i, 3);
        $c = $i % 3;
        $m[$size - 11 + $c][$r] = $b;
        $m[$r][$size - 11 + $c] = $b;
    }
}

/** 掩码惩罚分（规则 1-4） */
function qr_penalty(array $m, int $size): int
{
    $score = 0;
    // 规则1：连续同色
    for ($y = 0; $y < $size; $y++) {
        $run = 1;
        for ($x = 1; $x < $size; $x++) {
            if ($m[$y][$x] === $m[$y][$x - 1]) { $run++; }
            else { if ($run >= 5) $score += $run - 2; $run = 1; }
        }
        if ($run >= 5) $score += $run - 2;
    }
    for ($x = 0; $x < $size; $x++) {
        $run = 1;
        for ($y = 1; $y < $size; $y++) {
            if ($m[$y][$x] === $m[$y - 1][$x]) { $run++; }
            else { if ($run >= 5) $score += $run - 2; $run = 1; }
        }
        if ($run >= 5) $score += $run - 2;
    }
    // 规则2：2x2 同色块
    for ($y = 0; $y < $size - 1; $y++) {
        for ($x = 0; $x < $size - 1; $x++) {
            $v = $m[$y][$x];
            if ($v === $m[$y][$x + 1] && $v === $m[$y + 1][$x] && $v === $m[$y + 1][$x + 1]) $score += 3;
        }
    }
    return $score;
}
