<?php
/**
 * CC商聊 - API：CC币钱包（客服充值、提现、转账、红包、礼物、VIP、靓号）
 */
declare(strict_types=1);

$API_WALLET = [];

$API_WALLET['wallet_info'] = function ($me) {
    $u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
    ok([
        'coin' => (int)$u['coin'],
        'total_income' => (int)$u['total_income'],
        'total_expense' => (int)$u['total_expense'],
        'has_pay_pwd' => $u['pay_password'] ? 1 : 0,
        'withdraw_min' => (int)setting('withdraw_min', '100'),
        'vip_level' => is_vip($u) ? (int)$u['vip_level'] : 0,
        'vip_expire_at' => (int)$u['vip_expire_at'],
        'usdt' => [
            'network'  => setting('usdt_network', 'TRC20'),
            'rate'     => (int)setting('usdt_rate', '7'),
            'min_coin' => (int)setting('usdt_min_coin', '10'),
        ],
    ]);
};

$API_WALLET['wallet_logs'] = function ($me) {
    $dir = inp_int('direction', 0); // 0 全部 1 收入 2 支出
    $page = max(1, inp_int('page', 1));
    $limit = 20;
    $where = 'uid=?';
    $params = [(int)$me['id']];
    if ($dir) {
        $where .= ' AND direction=?';
        $params[] = $dir;
    }
    $total = (int)val("SELECT COUNT(*) FROM wallet_logs WHERE $where", $params);
    $rows = all("SELECT * FROM wallet_logs WHERE $where ORDER BY id DESC LIMIT $limit OFFSET " . (($page - 1) * $limit), $params);
    ok(['list' => $rows, 'total' => $total, 'page' => $page, 'has_more' => $page * $limit < $total ? 1 : 0]);
};

/* ---------- 客服充值：生成申请单 + 通知客服 ---------- */
$API_WALLET['wallet_recharge'] = function ($me) {
    $amount = inp_int('amount', inp_int('coin'));
    $remark = mb_substr(trim((string)inp('remark', '')), 0, 100);
    if ($amount < 10) fail('最少充值 10 CC币');
    if ($amount > 1000000) fail('单次最多 100 万 CC币');
    $svc = one('SELECT * FROM users WHERE id=?', [service_uid()]);
    $now = now();
    $orderNo = order_no('RC');
    q('INSERT INTO recharge_orders (order_no,uid,coin,rate,amount_usdt,address,network,status,remark,created_at) VALUES (?,?,?,?,?,?,?,0,?,?)', [
        $orderNo, (int)$me['id'], $amount, 0, '0', '', '客服', $remark, $now,
    ]);
    $oid = last_id();
    $content = "【充值申请】\n订单号：{$orderNo}\n充值 CC币：{$amount}\n备注：" . ($remark ?: '无') . "\n请客服确认到账后为我加币，谢谢！";
    if ($svc) {
        push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => (int)$svc['id'], 'gid' => 0, 'type' => 1, 'content' => $content]);
    }
    ok(['order_no' => $orderNo, 'id' => $oid, 'service_uid' => $svc ? (int)$svc['id'] : 0], '充值申请已提交，即将跳转客服');
};

$API_WALLET['wallet_orders'] = function ($me) {
    $recharges = all('SELECT * FROM recharge_orders WHERE uid=? ORDER BY id DESC LIMIT 30', [(int)$me['id']]);
    $withdraws = all('SELECT * FROM withdraw_orders WHERE uid=? ORDER BY id DESC LIMIT 30', [(int)$me['id']]);
    ok(['recharge' => $recharges, 'withdraw' => $withdraws]);
};

$API_WALLET['wallet_withdraw'] = function ($me) {
    $amount = inp_int('amount');
    $account = trim((string)inp('account', ''));
    $payPwd = (string)inp('pay_password', '');
    $qr = (string)inp('qr', '');
    if ($amount < (int)setting('withdraw_min', '100')) fail('最低提现 ' . setting('withdraw_min', '100') . ' CC币');
    if ($account === '') fail('请填写收款账号');
    check_pay_pwd($me, $payPwd);
    $u = one('SELECT coin FROM users WHERE id=?', [(int)$me['id']]);
    if ((int)$u['coin'] < $amount) fail('CC币余额不足');
    $orderNo = order_no('WD');
    $now = now();
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $aff = q('UPDATE users SET coin=coin-? WHERE id=? AND coin>=?', [$amount, (int)$me['id'], $amount])->rowCount();
        if (!$aff) throw new RuntimeException('CC币余额不足');
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,2,?,?,?,?,?,?)', [
            (int)$me['id'], $amount, (int)$u['coin'] - $amount, 'withdraw', 0, '提现申请 ' . $orderNo, $now,
        ]);
        q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [$amount, (int)$me['id']]);
        q('INSERT INTO withdraw_orders (order_no,uid,amount,account,qr,status,created_at) VALUES (?,?,?,?,?,0,?)', [
            $orderNo, (int)$me['id'], $amount, $account, $qr, $now,
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('提交失败：' . $e->getMessage());
    }
    $svc = one('SELECT id FROM users WHERE id=?', [service_uid()]);
    if ($svc) {
        push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => (int)$svc['id'], 'gid' => 0, 'type' => 1,
            'content' => "【提现申请】\n订单号：{$orderNo}\n金额：{$amount} CC币\n收款账号：{$account}\n请管理员审核。"]);
    }
    ok(['order_no' => $orderNo], '提现申请已提交，等待审核');
};

/* ---------- 转账 ---------- */
$API_WALLET['transfer_create'] = function ($me) {
    $to = inp_int('to');
    $coin = inp_int('coin');
    $note = mb_substr(trim((string)inp('note', '')), 0, 50);
    $payPwd = (string)inp('pay_password', '');
    if ($to <= 0 || $to === (int)$me['id']) fail('请选择收款人');
    if ($coin <= 0) fail('转账金额有误');
    check_pay_pwd($me, $payPwd);
    $toUser = one('SELECT * FROM users WHERE id=?', [$to]);
    if (!$toUser) fail('收款人不存在');
    if ((int)$to !== service_uid() && !one('SELECT id FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $to])) {
        fail('只能向好友转账');
    }
    if ((int)one('SELECT coin FROM users WHERE id=?', [(int)$me['id']])['coin'] < $coin) fail('CC币余额不足');
    $now = now();
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $aff = q('UPDATE users SET coin=coin-? WHERE id=? AND coin>=?', [$coin, (int)$me['id'], $coin])->rowCount();
        if (!$aff) throw new RuntimeException('CC币余额不足');
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,2,?,?,?,?,?,?)', [
            (int)$me['id'], $coin, (int)val('SELECT coin FROM users WHERE id=?', [(int)$me['id']]), 'transfer', $to, '转账给 ' . $toUser['nickname'], $now,
        ]);
        q('UPDATE users SET coin=coin+? WHERE id=?', [$coin, $to]);
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,1,?,?,?,?,?,?)', [
            $to, $coin, (int)val('SELECT coin FROM users WHERE id=?', [$to]), 'transfer', (int)$me['id'], '收到 ' . $me['nickname'] . ' 的转账', $now,
        ]);
        q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [$coin, (int)$me['id']]);
        q('UPDATE users SET total_income=total_income+? WHERE id=?', [$coin, $to]);
        q('INSERT INTO transfers (from_uid,to_uid,coin,note,created_at) VALUES (?,?,?,?,?)', [(int)$me['id'], $to, $coin, $note, $now]);
        $tid = last_id();
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('转账失败：' . $e->getMessage());
    }
    $payload = json_encode(['coin' => $coin, 'note' => $note, 'transfer_id' => $tid], JSON_UNESCAPED_UNICODE);
    $m = push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $to, 'gid' => 0, 'type' => 8, 'content' => $payload]);
    push_message(['ctype' => 1, 'from_uid' => $to, 'to_uid' => (int)$me['id'], 'gid' => 0, 'type' => 8, 'content' => $payload]);
    ok(msg_row($m, $me), '转账成功');
};

/* ---------- 红包 ---------- */
$API_WALLET['redpacket_create'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('to', inp_int('peer'));
    $coin = inp_int('coin');
    $count = inp_int('count', 1);
    $type = inp_int('rp_type', 1); // 1 普通 2 拼手气
    $blessing = mb_substr(trim((string)inp('blessing', '恭喜发财，大吉大利')), 0, 50);
    $payPwd = (string)inp('pay_password', '');
    if ($coin <= 0) fail('红包金额有误');
    if ($ctype === 2) {
        $count = max(1, $count);
        if ($coin < $count) fail('每个红包至少 1 CC币');
    } else {
        $count = 1;
    }
    if ($count > 100) fail('红包个数最多 100');
    if ($ctype === 1 && (int)$peer !== service_uid() && !one('SELECT id FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $peer])) {
        fail('只能给好友发红包');
    }
    check_pay_pwd($me, $payPwd);
    $u = one('SELECT coin FROM users WHERE id=?', [(int)$me['id']]);
    if ((int)$u['coin'] < $coin) fail('CC币余额不足');
    $now = now();
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $aff = q('UPDATE users SET coin=coin-? WHERE id=? AND coin>=?', [$coin, (int)$me['id'], $coin])->rowCount();
        if (!$aff) throw new RuntimeException('CC币余额不足');
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,2,?,?,?,0,?,?)', [
            (int)$me['id'], $coin, (int)$u['coin'] - $coin, 'redpacket', '发红包', $now,
        ]);
        q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [$coin, (int)$me['id']]);
        q('INSERT INTO red_packets (packet_no,uid,ctype,to_uid,gid,rp_type,total,count,remaining,remain_count,blessing,status,created_at,expire_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?,?)', [
            order_no('RP'), (int)$me['id'], $ctype, $ctype === 1 ? $peer : 0, $ctype === 2 ? $peer : 0,
            $type, $coin, $count, $coin, $count, $blessing, $now, $now + 86400,
        ]);
        $pid = last_id();
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('发红包失败：' . $e->getMessage());
    }
    $payload = json_encode(['pid' => $pid, 'coin' => $coin, 'count' => $count, 'rp_type' => $type, 'blessing' => $blessing], JSON_UNESCAPED_UNICODE);
    $m = push_message(['ctype' => $ctype, 'from_uid' => (int)$me['id'], 'to_uid' => $ctype === 1 ? $peer : 0, 'gid' => $ctype === 2 ? $peer : 0, 'type' => $ctype === 2 ? 21 : 7, 'content' => $payload]);
    ok(msg_row($m, $me), '红包已发出');
};

$API_WALLET['redpacket_info'] = function ($me) {
    $pid = inp_int('pid', inp_int('id'));
    $p = one('SELECT * FROM red_packets WHERE id=?', [$pid]);
    if (!$p) fail('红包不存在');
    $from = one('SELECT * FROM users WHERE id=?', [(int)$p['uid']]);
    $got = one('SELECT * FROM red_packet_records WHERE pid=? AND uid=?', [$pid, (int)$me['id']]);
    $records = all('SELECT r.*, u.nickname, u.avatar FROM red_packet_records r JOIN users u ON u.id=r.uid WHERE r.pid=? ORDER BY r.id DESC LIMIT 100', [$pid]);
    ok([
        'id' => (int)$p['id'], 'packet_no' => $p['packet_no'], 'from' => user_public($from),
        'total' => (int)$p['total'], 'count' => (int)$p['count'], 'remaining' => (int)$p['remaining'],
        'remain_count' => (int)$p['remain_count'], 'rp_type' => (int)$p['rp_type'], 'blessing' => $p['blessing'],
        'status' => (int)$p['status'], 'expire_at' => (int)$p['expire_at'], 'created_at' => (int)$p['created_at'],
        'opened' => $got ? 1 : 0, 'my_coin' => $got ? (int)$got['coin'] : 0,
        'records' => $records,
    ]);
};

$API_WALLET['redpacket_open'] = function ($me) {
    $pid = inp_int('pid', inp_int('id'));
    $p = one('SELECT * FROM red_packets WHERE id=?', [$pid]);
    if (!$p) fail('红包不存在');
    if ((int)$p['expire_at'] < now()) fail('红包已过期');
    $got = one('SELECT * FROM red_packet_records WHERE pid=? AND uid=?', [$pid, (int)$me['id']]);
    if ($got) fail('你已经领取过该红包', 2, ['coin' => (int)$got['coin']]);
    if ((int)$p['remain_count'] <= 0 || (int)$p['remaining'] <= 0) fail('红包已被领完');
    if ((int)$p['uid'] === (int)$me['id']) fail('不能领取自己发的红包');

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $cur = one('SELECT * FROM red_packets WHERE id=?', [$pid]);
        if ((int)$cur['remain_count'] <= 0 || (int)$cur['remaining'] <= 0) throw new RuntimeException('红包已被领完');
        if ((int)$cur['rp_type'] === 1) {
            $coin = intdiv((int)$cur['total'], (int)$cur['count']);
            if ((int)$cur['remain_count'] === 1) $coin = (int)$cur['remaining'];
        } else {
            if ((int)$cur['remain_count'] === 1) {
                $coin = (int)$cur['remaining'];
            } else {
                $max = max(1, (int)floor((int)$cur['remaining'] / (int)$cur['remain_count'] * 2));
                $coin = random_int(1, $max);
                $coin = min($coin, (int)$cur['remaining'] - ((int)$cur['remain_count'] - 1));
            }
        }
        $coin = max(1, min($coin, (int)$cur['remaining']));
        $aff = q('UPDATE red_packets SET remaining=remaining-?, remain_count=remain_count-1, status=CASE WHEN remain_count-1<=0 THEN 1 ELSE status END WHERE id=? AND remain_count>0 AND remaining>=?', [$coin, $pid, $coin])->rowCount();
        if (!$aff) throw new RuntimeException('红包已被领完');
        q('INSERT INTO red_packet_records (pid,uid,coin,created_at) VALUES (?,?,?,?)', [$pid, (int)$me['id'], $coin, now()]);
        add_coin((int)$me['id'], $coin, 'redpacket', $pid, '领取红包');
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail($e->getMessage());
    }
    $p = one('SELECT * FROM red_packets WHERE id=?', [$pid]);
    ok(['coin' => $coin, 'remaining' => (int)$p['remaining'], 'remain_count' => (int)$p['remain_count']], '领取成功');
};

/* ---------- 礼物 ---------- */
$API_WALLET['gift_send'] = function ($me) {
    $giftId = inp_int('gift_id');
    $count = max(1, inp_int('count', 1));
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('to', inp_int('peer'));
    $payPwd = (string)inp('pay_password', '');
    $g = one('SELECT * FROM gifts WHERE id=? AND status=1', [$giftId]);
    if (!$g) fail('礼物不存在');
    if ($ctype === 1 && (int)$peer !== service_uid() && !one('SELECT id FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $peer])) {
        fail('只能给好友送礼物');
    }
    $total = (int)$g['price'] * $count;
    check_pay_pwd($me, $payPwd);
    $u = one('SELECT coin FROM users WHERE id=?', [(int)$me['id']]);
    if ((int)$u['coin'] < $total) fail('CC币余额不足');
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $aff = q('UPDATE users SET coin=coin-? WHERE id=? AND coin>=?', [$total, (int)$me['id'], $total])->rowCount();
        if (!$aff) throw new RuntimeException('CC币余额不足');
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,2,?,?,?,?,?,?)', [
            (int)$me['id'], $total, (int)$u['coin'] - $total, 'gift', $giftId, '赠送礼物 ' . $g['name'] . ' x' . $count, now(),
        ]);
        q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [$total, (int)$me['id']]);
        q('INSERT INTO gift_records (from_uid,to_uid,gid,gift_id,count,coin,created_at) VALUES (?,?,?,?,?,?,?)', [
            (int)$me['id'], $ctype === 1 ? $peer : 0, $ctype === 2 ? $peer : 0, $giftId, $count, $total, now(),
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('赠送失败：' . $e->getMessage());
    }
    $payload = json_encode(['gift_id' => $giftId, 'name' => $g['name'], 'icon' => $g['icon'], 'price' => (int)$g['price'], 'count' => $count, 'coin' => $total], JSON_UNESCAPED_UNICODE);
    $m = push_message(['ctype' => $ctype, 'from_uid' => (int)$me['id'], 'to_uid' => $ctype === 1 ? $peer : 0, 'gid' => $ctype === 2 ? $peer : 0, 'type' => $ctype === 2 ? 23 : 9, 'content' => $payload]);
    ok(msg_row($m, $me), '已送出');
};

/* ---------- VIP ---------- */
$API_WALLET['vip_plans'] = function ($me) {
    ok(['list' => all('SELECT * FROM vip_plans WHERE status=1 ORDER BY sort,id')]);
};

$API_WALLET['buy_vip'] = function ($me) {
    $planId = inp_int('plan_id');
    $payPwd = (string)inp('pay_password', '');
    $p = one('SELECT * FROM vip_plans WHERE id=? AND status=1', [$planId]);
    if (!$p) fail('套餐不存在');
    check_pay_pwd($me, $payPwd);
    $u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
    if ((int)$u['coin'] < (int)$p['price']) fail('CC币余额不足，请先充值');
    add_coin((int)$me['id'], -(int)$p['price'], 'vip', $planId, '购买 ' . $p['name']);
    $activeNow = (int)$u['vip_level'] > 0 && (int)$u['vip_expire_at'] > now();
    $base = $activeNow ? (int)$u['vip_expire_at'] : now();
    $newExpire = $base + (int)$p['days'] * 86400;
    // 会员有效期内升级取较高等级（VIP→SVIP 立刻升级）；已过期则按本次套餐等级重新计算
    $level = $activeNow ? max((int)$u['vip_level'], (int)$p['level']) : (int)$p['level'];
    q('UPDATE users SET vip_level=?, vip_expire_at=? WHERE id=?', [$level, $newExpire, (int)$me['id']]);
    ok([
        'vip_level' => $level,
        'vip_tier'  => vip_tier($level),
        'vip_label' => vip_label($level),
        'vip_expire_at' => $newExpire,
    ], '已开通 ' . vip_label($level));
};

/* ---------- 靓号（个人 CC号 / 群号） ---------- */
$API_WALLET['pretty_list'] = function ($me) {
    $type = (string)inp('type', 'user');
    if (!in_array($type, ['user', 'group'], true)) $type = 'user';
    $rows = all('SELECT * FROM pretty_ids WHERE status=0 AND ptype=? ORDER BY price ASC LIMIT 100', [$type]);
    // 我管理的群（用于购买群靓号时选择）
    $myGroups = all('SELECT gid,name,pretty_gid FROM groups WHERE owner_uid=? AND status=1 ORDER BY id DESC LIMIT 50', [(int)$me['id']]);
    ok([
        'list' => $rows,
        'type' => $type,
        'my_yx_id' => $me['pretty_yxid'] ?: ($me['yx_id'] ?: $me['account']),
        'my_groups' => array_map(static function ($g) {
            return ['gid' => (int)$g['gid'], 'name' => $g['name'], 'pretty_gid' => (int)$g['pretty_gid']];
        }, $myGroups),
    ]);
};

$API_WALLET['buy_pretty'] = function ($me) {
    $id = inp_int('id');
    $payPwd = (string)inp('pay_password', '');
    $gid = inp_int('gid');
    $p = one('SELECT * FROM pretty_ids WHERE id=? AND status=0', [$id]);
    if (!$p) fail('靓号已被抢购');
    $ptype = (string)($p['ptype'] ?? 'user');
    if ($ptype === 'group') {
        if ($gid <= 0) fail('请选择要绑定的群聊');
        $g = group_by_gid($gid);
        if (!$g) fail('群聊不存在');
        if ((int)$g['owner_uid'] !== (int)$me['id']) fail('只有群主可以为群购买靓号');
    }
    check_pay_pwd($me, $payPwd);
    $u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
    if ((int)$u['coin'] < (int)$p['price']) fail('CC币余额不足');
    $pdo = db();
    $pdo->beginTransaction();
    try {
        // 购买即从号池删除（原子占用，防止二次购买/并发重复卖出）
        $aff = q('DELETE FROM pretty_ids WHERE id=? AND status=0', [$id])->rowCount();
        if (!$aff) throw new RuntimeException('靓号已被抢购');
        if ($ptype === 'group') {
            $aff2 = q('UPDATE users SET coin=coin-? WHERE id=? AND coin>=?', [(int)$p['price'], (int)$me['id'], (int)$p['price']])->rowCount();
            if (!$aff2) throw new RuntimeException('CC币余额不足');
            q('UPDATE groups SET pretty_gid=? WHERE gid=?', [(int)$p['yx_id'], $gid]);
        } else {
            $aff2 = q('UPDATE users SET coin=coin-?, pretty_yxid=? WHERE id=? AND coin>=?',
                      [(int)$p['price'], $p['yx_id'], (int)$me['id'], (int)$p['price']])->rowCount();
            if (!$aff2) throw new RuntimeException('CC币余额不足');
        }
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,2,?,?,?,?,?,?)', [
            (int)$me['id'], (int)$p['price'], (int)$u['coin'] - (int)$p['price'], 'pretty', $id,
            ($ptype === 'group' ? '购买群靓号 ' : '购买靓号 ') . $p['yx_id'] . '（已从号池移除）', now(),
        ]);
        // 累计支出同步（此处为手写流水，需手动累加，否则「累计支出」会漏计）
        q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [(int)$p['price'], (int)$me['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail($e->getMessage());
    }
    ok(['yx_id' => $p['yx_id'], 'type' => $ptype], $ptype === 'group' ? '群靓号已生效' : '靓号已生效');
};
