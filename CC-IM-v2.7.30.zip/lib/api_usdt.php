<?php
/**
 * CC商聊 - API：USDT 充值（TRC20 链上自动匹配 + 人工审核兜底）
 */
declare(strict_types=1);

$API_USDT = [];

/** TronGrid：拉取收款地址最近的 TRC20 转账 */
function usdt_trc20_transfers(string $address, int $minTs, int $limit = 200): array
{
    $base = rtrim((string)setting('usdt_trongrid_url', 'https://api.trongrid.io'), '/');
    // 只允许 http/https，避免后台配置被写入 file:// 等危险协议
    if (!preg_match('#^https?://#i', $base)) $base = 'https://api.trongrid.io';
    $url = $base . '/v1/accounts/' . rawurlencode($address) . '/transactions/trc20?only_confirmed=true&limit=' . $limit . '&min_timestamp=' . $minTs;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => array_filter([
            'Accept: application/json',
            setting('usdt_trongrid_key', '') ? 'TRON-PRO-API-KEY: ' . setting('usdt_trongrid_key', '') : null,
        ]),
    ]);
    $body = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($body === false) {
        return ['ok' => false, 'msg' => '链上查询失败：' . $err, 'data' => []];
    }
    $j = json_decode((string)$body, true);
    if (!is_array($j) || !isset($j['data'])) {
        return ['ok' => false, 'msg' => '链上返回异常', 'data' => []];
    }
    return ['ok' => true, 'msg' => '', 'data' => $j['data']];
}

$API_USDT['create'] = function ($me) {
    $coin = inp_int('coin', inp_int('amount'));
    $min = (int)setting('usdt_min_coin', '10');
    if ($coin < $min) fail('最少充值 ' . $min . ' CC币');
    $rate = max(1, (int)setting('usdt_rate', '7'));
    $address = (string)setting('usdt_address', '');
    if ($address === '') fail('USDT 收款地址未配置，请联系客服');
    $network = (string)setting('usdt_network', 'TRC20');

    // 金额精确到 2 位，避免同额订单冲突时在金额后加随机分位
    $usdt = round($coin / $rate, 2);
    if ($usdt <= 0) fail('金额有误');
    $same = (int)val('SELECT COUNT(*) FROM recharge_orders WHERE amount_usdt=? AND status IN (0,1) AND address=?', [number_format($usdt, 2, '.', ''), $address]);
    if ($same > 0) {
        // 同金额待支付订单存在，加一个随机分位（0.01~0.09）保证唯一匹配
        $usdt = round($usdt + random_int(1, 9) / 100, 2);
    }
    $expire = (int)setting('usdt_expire', '1800');
    $now = now();
    $orderNo = order_no('U');
    q('INSERT INTO recharge_orders (order_no,uid,coin,rate,amount_usdt,address,network,status,remark,created_at) VALUES (?,?,?,?,?,?,?,0,?,?)', [
        $orderNo, (int)$me['id'], $coin, $rate, number_format($usdt, 2, '.', ''), $address, $network, 'USDT充值', $now,
    ]);
    ok([
        'id' => last_id(),
        'order_no' => $orderNo,
        'coin' => $coin,
        'rate' => $rate,
        'amount_usdt' => number_format($usdt, 2, '.', ''),
        'address' => $address,
        'network' => $network,
        'expire_at' => $now + $expire,
        'created_at' => $now,
    ], '订单已生成');
};

$API_USDT['usdt_orders'] = function ($me) {
    $rows = all('SELECT * FROM recharge_orders WHERE uid=? ORDER BY id DESC LIMIT 50', [(int)$me['id']]);
    foreach ($rows as &$r) {
        unset($r['address']);
    }
    ok(['list' => $rows]);
};

$API_USDT['submit_txid'] = function ($me) {
    $id = inp_int('id');
    $txid = trim((string)inp('txid', ''));
    $o = one('SELECT * FROM recharge_orders WHERE id=? AND uid=?', [$id, (int)$me['id']]);
    if (!$o) fail('订单不存在');
    if ((int)$o['status'] === 2) fail('订单已到账');
    if ($txid === '' || !preg_match('/^[0-9a-fA-F]{64}$/', $txid)) fail('请输入正确的交易哈希（64 位）');
    q('UPDATE recharge_orders SET txid=?, status=1, remark=? WHERE id=?', [$txid, '用户提交哈希，待人工核对', $id]);
    ok(null, '已提交，等待客服核对');
};

$API_USDT['check_pay'] = function ($me) {
    $id = inp_int('id');
    $o = one('SELECT * FROM recharge_orders WHERE id=? AND uid=?', [$id, (int)$me['id']]);
    if (!$o) fail('订单不存在');
    if ((int)$o['status'] === 2) {
        ok(['status' => 'ok', 'amount' => $o['amount_usdt'], 'coin' => (int)$o['coin']]);
    }
    if ((int)$o['status'] === 3) fail('订单已被拒绝：' . $o['remark']);
    if ((int)setting('usdt_auto_check', '1') !== 1) {
        ok(['status' => 'pending', 'msg' => '自动核对已关闭，请等待客服人工确认']);
    }
    $address = (string)$o['address'];
    $expect = (float)$o['amount_usdt'];
    $window = (int)setting('usdt_match_window', '86400');
    $minTs = ((int)$o['created_at'] - 120) * 1000;

    $res = usdt_trc20_transfers($address, $minTs, 200);
    if (!$res['ok']) {
        ok(['status' => 'pending', 'msg' => $res['msg']]);
    }
    $usdtContract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
    $found = null;
    foreach ($res['data'] as $tx) {
        $to = $tx['to'] ?? '';
        $token = $tx['token_info']['address'] ?? '';
        $decimals = (int)($tx['token_info']['decimals'] ?? 6);
        $raw = (float)($tx['value'] ?? 0);
        $value = $raw / pow(10, $decimals);
        $txid = $tx['transaction_id'] ?? '';
        $ts = (int)round(((int)($tx['block_timestamp'] ?? 0)) / 1000);
        if (strcasecmp($to, $address) !== 0) continue;
        if ($usdtContract !== '' && $token && strcasecmp($token, $usdtContract) !== 0) continue;
        if ($ts < $minTs / 1000) continue;
        if (abs($value - $expect) > 0.009) continue;
        if ($txid && val('SELECT id FROM recharge_orders WHERE pay_tx=? AND id<>?', [$txid, (int)$o['id']])) continue;
        $found = ['txid' => $txid, 'amount' => $value, 'ts' => $ts];
        break;
    }

    if (!$found) {
        ok(['status' => 'pending', 'msg' => '暂未查询到金额为 ' . number_format($expect, 2, '.', '') . ' USDT 的到账记录，请确认后重试']);
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $aff = q('UPDATE recharge_orders SET status=2, pay_tx=?, paid_at=?, remark=? WHERE id=? AND status<>2', [
            $found['txid'], now(), '链上自动匹配成功', $id,
        ])->rowCount();
        if (!$aff) {
            $pdo->rollBack();
            ok(['status' => 'ok', 'amount' => $o['amount_usdt'], 'coin' => (int)$o['coin']]);
        }
        q('UPDATE users SET coin=coin+? WHERE id=?', [(int)$o['coin'], (int)$me['id']]);
        $bal = (int)val('SELECT coin FROM users WHERE id=?', [(int)$me['id']]);
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,1,?,?,?,?,?,?)', [
            (int)$me['id'], (int)$o['coin'], $bal, 'usdt_recharge', $id, 'USDT充值 ' . $o['amount_usdt'] . ' USDT', now(),
        ]);
        q('UPDATE users SET total_income=total_income+? WHERE id=?', [(int)$o['coin'], (int)$me['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('入账失败：' . $e->getMessage());
    }
    ok(['status' => 'ok', 'amount' => number_format($found['amount'], 2, '.', ''), 'coin' => (int)$o['coin']], '充值成功');
};
