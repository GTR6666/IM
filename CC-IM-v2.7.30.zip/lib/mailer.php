<?php
/**
 * CC商聊 - 轻量 SMTP 发信（无第三方依赖）
 * 支持：SSL(465) / STARTTLS(587) / 明文(25)，AUTH LOGIN 与 AUTH PLAIN
 */
declare(strict_types=1);

function mail_config(): array
{
    return [
        'enabled' => (string)setting('smtp_enabled', '0') === '1',
        'host'    => trim((string)setting('smtp_host', '')),
        'port'    => (int)setting('smtp_port', '465'),
        'secure'  => strtolower((string)setting('smtp_secure', 'ssl')), // ssl | tls | none
        'user'    => (string)setting('smtp_user', ''),
        'pass'    => (string)setting('smtp_pass', ''),
        'from'    => trim((string)setting('smtp_from', '')),
        'name'    => trim((string)setting('smtp_name', '')) ?: (string)setting('site_name', 'CC商聊'),
        'timeout' => max(5, (int)setting('smtp_timeout', '15')),
    ];
}

/** 邮件功能是否可用（已开启且配置了服务器） */
function mail_ready(): bool
{
    $c = mail_config();
    return $c['enabled'] && $c['host'] !== '' && $c['from'] !== '';
}

/** 后台是否要求注册时验证邮箱 */
function email_verify_register(): bool
{
    return (string)setting('email_verify', '0') === '1';
}

/**
 * SMTP 发信
 * @throws RuntimeException 失败时抛出可读原因
 */
function smtp_send(string $to, string $subject, string $html, string $text = '', array $override = []): void
{
    $c = array_merge(mail_config(), $override);
    if (empty($c['enabled'])) throw new RuntimeException('邮件服务未开启');
    if ($c['host'] === '') throw new RuntimeException('未配置 SMTP 服务器');
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('收件邮箱格式不正确');

    $from = $c['from'] !== '' ? $c['from'] : $c['user'];
    if (!filter_var($from, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('发件邮箱格式不正确');

    $port = (int)$c['port'];
    $secure = $c['secure'];
    $remote = ($secure === 'ssl' ? 'ssl://' : '') . $c['host'] . ':' . $port;
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]]);
    $errno = 0; $errstr = '';
    $fp = @stream_socket_client($remote, $errno, $errstr, (int)$c['timeout'], STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new RuntimeException('连接邮件服务器失败：' . ($errstr ?: ('errno ' . $errno)));
    stream_set_timeout($fp, (int)$c['timeout']);

    $read = static function () use ($fp): string {
        $data = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] !== '-') break;
        }
        return $data;
    };
    $cmd = static function (string $command, array $expect = [250]) use ($fp, $read): string {
        fwrite($fp, $command . "\r\n");
        $resp = $read();
        $code = (int)substr($resp, 0, 3);
        if ($expect && !in_array($code, $expect, true)) {
            throw new RuntimeException('邮件服务器返回异常（' . $code . '）：' . trim($resp));
        }
        return $resp;
    };

    try {
        $read(); // 220 欢迎信息
        $helo = 'EHLO ' . (gethostname() ?: 'localhost');
        $resp = $cmd($helo);
        if ((int)substr($resp, 0, 3) !== 250) {
            $cmd('HELO ' . (gethostname() ?: 'localhost'));
        }
        if ($secure === 'tls') {
            $cmd('STARTTLS', [220]);
            $ok = @stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if (!$ok) throw new RuntimeException('TLS 加密握手失败');
            $cmd($helo);
        }
        if ($c['user'] !== '') {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode($c['user']), [334]);
            $cmd(base64_encode($c['pass']), [235]);
        }
        $cmd('MAIL FROM:<' . $from . '>');
        $cmd('RCPT TO:<' . $to . '>');
        $cmd('DATA', [354]);

        $subjectEnc = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $nameEnc = '=?UTF-8?B?' . base64_encode((string)$c['name']) . '?=';
        $boundary = 'cc_' . bin2hex(random_bytes(8));
        $headers = [
            'Date: ' . date('r'),
            'From: ' . $nameEnc . ' <' . $from . '>',
            'To: <' . $to . '>',
            'Subject: ' . $subjectEnc,
            'MIME-Version: 1.0',
            'Message-ID: <' . bin2hex(random_bytes(10)) . '@' . ($c['host'] ?: 'localhost') . '>',
            'X-Mailer: CC-IM',
            'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        ];
        $body = implode("\r\n", $headers) . "\r\n\r\n";
        $body .= '--' . $boundary . "\r\n";
        $body .= "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
        $body .= chunk_split(base64_encode($text !== '' ? $text : strip_tags($html)), 76, "\r\n");
        $body .= '--' . $boundary . "\r\n";
        $body .= "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
        $body .= chunk_split(base64_encode($html), 76, "\r\n");
        $body .= '--' . $boundary . "--\r\n";
        // 行首单点转义
        $body = preg_replace('/^\./m', '..', $body);

        fwrite($fp, $body . "\r\n.\r\n");
        $resp = $read();
        if ((int)substr($resp, 0, 3) !== 250) throw new RuntimeException('邮件投递失败：' . trim($resp));
        try { fwrite($fp, "QUIT\r\n"); } catch (Throwable $e) {}
    } finally {
        if (is_resource($fp)) @fclose($fp);
    }
}

/** 发送验证码邮件（返回是否成功） */
function send_verify_mail(string $to, string $code, string $purpose = 'register'): void
{
    $site = (string)setting('site_name', 'CC商聊');
    $act = $purpose === 'reset' ? '找回密码' : '注册';
    $subject = '【' . $site . '】' . $act . '验证码';
    $html = '<div style="margin:0;padding:28px 16px;background:#F6F7F9;font-family:-apple-system,BlinkMacSystemFont,\'PingFang SC\',\'Microsoft YaHei\',Arial,sans-serif">'
        . '<div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:28px 26px;box-shadow:0 8px 28px rgba(26,32,60,.06)">'
        . '<div style="font-size:17px;font-weight:700;color:#1A2030">' . e($site) . '</div>'
        . '<div style="height:1px;background:#F0F1F3;margin:16px 0"></div>'
        . '<p style="font-size:14px;color:#4B5563;line-height:1.8;margin:0 0 18px">您正在进行' . e($act) . '操作，本次验证码为：</p>'
        . '<div style="font-size:32px;font-weight:800;letter-spacing:8px;color:#07C160;text-align:center;padding:14px 0 18px">' . e($code) . '</div>'
        . '<p style="font-size:13px;color:#9AA0AC;line-height:1.8;margin:0">验证码 10 分钟内有效，请勿告知他人。若非本人操作请忽略本邮件。</p>'
        . '</div></div>';
    $text = "您正在进行{$act}操作，验证码：{$code}（10 分钟内有效）";
    smtp_send($to, $subject, $html, $text);
}

/** 校验邮箱验证码（失败抛异常） */
function verify_email_code(string $email, string $code, string $purpose = 'register'): void
{
    if ($code === '') throw new RuntimeException('请填写邮箱验证码');
    $vc = one('SELECT * FROM verify_codes WHERE target=? AND purpose=? AND used=0 ORDER BY id DESC LIMIT 1', [$email, $purpose]);
    if (!$vc) throw new RuntimeException('请先获取邮箱验证码');
    if (!hash_equals((string)$vc['code'], $code)) throw new RuntimeException('验证码不正确');
    if ((int)$vc['expire_at'] < now()) throw new RuntimeException('验证码已过期，请重新获取');
    q('UPDATE verify_codes SET used=1 WHERE id=?', [(int)$vc['id']]);
}
