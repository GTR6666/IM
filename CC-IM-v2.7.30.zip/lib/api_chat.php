<?php
/**
 * CC商聊 - API：聊天（会话、消息、长轮询、上传、表情、收藏）
 */
declare(strict_types=1);

$API_CHAT = [];

/* ---------- 消息格式化 ---------- */
function msg_row(array $r, array $me = null): array
{
    $sender = one('SELECT id,nickname,avatar,yx_id,account,vip_level,vip_expire_at,is_developer FROM users WHERE id=?', [(int)$r['from_uid']]);
    $extra = json_decode_arr($r['extra'] ?? '');
    $content = (string)$r['content'];
    $groupNick = '';
    if ((int)$r['ctype'] === 2 && (int)$r['gid'] > 0) {
        $gm = one('SELECT nickname FROM group_members WHERE gid=? AND uid=?', [(int)$r['gid'], (int)$r['from_uid']]);
        $groupNick = $gm ? (string)$gm['nickname'] : '';
    }
    return [
        'id'         => (int)$r['id'],
        'ctype'      => (int)$r['ctype'],
        'from_uid'   => (int)$r['from_uid'],
        'to_uid'     => (int)$r['to_uid'],
        'gid'        => (int)$r['gid'],
        'type'       => (int)$r['type'],
        'content'    => $content,
        'extra'      => $extra ? $extra : new stdClass(),
        'created_at' => (int)$r['created_at'],
        'recalled'   => (int)$r['recalled'],
        'sender'     => [
            'id'       => (int)$r['from_uid'],
            'nickname' => $sender ? ($sender['nickname'] ?: '用户') : '系统',
            'avatar'   => $sender['avatar'] ?? '',
            'yx_id'    => $sender['yx_id'] ?? '',
            'vip_level'=> ($sender && is_vip($sender)) ? (int)$sender['vip_level'] : 0,
            'is_developer' => (int)($sender['is_developer'] ?? 0),
        ],
        'group_nick' => $groupNick,
        'mine'       => ($me && (int)$me['id'] === (int)$r['from_uid']) ? 1 : 0,
    ];
}

function my_group_gids(int $uid): array
{
    $out = [];
    foreach (all('SELECT gm.gid FROM group_members gm JOIN groups g ON g.gid=gm.gid WHERE gm.uid=? AND g.status=1', [$uid]) as $r) {
        $out[] = (int)$r['gid'];
    }
    return $out;
}

function conv_entry(array $me, int $ctype, int $peer): ?array
{
    $uid = (int)$me['id'];
    if ($ctype === 1) {
        $u = one('SELECT * FROM users WHERE id=?', [$peer]);
        if (!$u) return null;
        $f = one('SELECT remark FROM friends WHERE uid=? AND fid=?', [$uid, $peer]);
        $name = $f && $f['remark'] ? $f['remark'] : ($u['nickname'] ?: ('用户' . $u['account']));
        return [
            'ctype' => 1, 'peer' => $peer, 'name' => $name, 'avatar' => $u['avatar'],
            'yx_id' => $u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account']),
            'online' => (int)$u['online'],
            'vip_level' => is_vip($u) ? (int)$u['vip_level'] : 0,
            'pretty' => !empty($u['pretty_yxid']) ? (string)$u['pretty_yxid'] : '',
            'is_bot' => (int)$u['is_developer'] === 1 ? 1 : 0,
        ];
    }
    $g = group_by_gid($peer);
    if (!$g || (int)$g['status'] !== 1) return null;
    if (!group_member($peer, $uid)) return null;
    $prettyGid = (int)($g['pretty_gid'] ?? 0);
    return [
        'ctype' => 2, 'peer' => $peer, 'name' => $g['name'], 'avatar' => $g['avatar'],
        'gid' => (int)$g['gid'],
        'show_gid' => $prettyGid > 0 ? $prettyGid : (int)$g['gid'],
        'members' => (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$peer]),
        'owner_uid' => (int)$g['owner_uid'], 'muted' => (int)$g['mute_all'],
        'pretty' => $prettyGid > 0 ? (string)$prettyGid : '',
        'role' => group_role($peer, $uid),
    ];
}

$API_CHAT['conv_list'] = function ($me) {
    $uid = (int)$me['id'];
    $rows = all('SELECT * FROM conversations WHERE uid=? AND visible=1 ORDER BY pinned DESC, last_time DESC LIMIT 200', [$uid]);
    $out = [];
    foreach ($rows as $r) {
        $e = conv_entry($me, (int)$r['ctype'], (int)$r['peer_id']);
        if (!$e) continue;
        $e['last_msg'] = $r['last_msg'];
        $e['last_time'] = (int)$r['last_time'];
        $e['unread'] = (int)$r['unread'];
        $e['pinned'] = (int)$r['pinned'];
        $e['muted'] = (int)$r['muted'];
        // 群消息发送者昵称前缀
        if ((int)$r['ctype'] === 2 && $r['last_msg'] !== '' && !preg_match('/^\[/', (string)$r['last_msg'])) {
            $lastMsg = one('SELECT from_uid FROM messages WHERE gid=? ORDER BY id DESC LIMIT 1', [(int)$r['peer_id']]);
            if ($lastMsg) {
                $nm = val('SELECT nickname FROM users WHERE id=?', [(int)$lastMsg['from_uid']]);
                if ($nm) $e['last_msg'] = $nm . '：' . $r['last_msg'];
            }
        }
        $out[] = $e;
    }
    // 未在会话列表中的好友/群不显示（与微信一致，首次聊天才建会话）
    ok(['list' => $out]);
};

$API_CHAT['msg_list'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer  = inp_int('peer', inp_int('to'));
    $before = inp_int('before_id', 0);
    $limit = max(1, min(100, inp_int('limit', 30)));
    $uid = (int)$me['id'];
    if ($peer <= 0) fail('参数错误');

    if ($ctype === 1) {
        $where = '((from_uid=? AND to_uid=?) OR (from_uid=? AND to_uid=?))';
        $params = [$uid, $peer, $peer, $uid];
    } else {
        if (!group_member($peer, $uid)) fail('你不在该群聊中');
        $where = 'gid=?';
        $params = [$peer];
    }
    if ($before > 0) {
        $where .= ' AND id<?';
        $params[] = $before;
    }
    $rows = all("SELECT * FROM messages WHERE $where AND deleted=0 ORDER BY id DESC LIMIT $limit", $params);
    $rows = array_reverse($rows);
    $out = [];
    foreach ($rows as $r) $out[] = msg_row($r, $me);

    // 标记已读 & 更新 last_read
    $lastRow = $rows ? end($rows) : null;
    $last = $lastRow ? (int)$lastRow['id'] : 0;
    if ($ctype === 1) {
        conv_clear_unread($uid, 1, $peer);
        if ($last) q('UPDATE conversations SET last_read_id=? WHERE uid=? AND ctype=1 AND peer_id=?', [$last, $uid, $peer]);
    } else {
        conv_clear_unread($uid, 2, $peer);
        $gm = group_member($peer, $uid);
        if ($gm && $last > (int)$gm['last_read_id']) {
            q('UPDATE group_members SET last_read_id=? WHERE id=?', [$last, (int)$gm['id']]);
        }
    }
    ok(['list' => $out, 'has_more' => count($rows) >= $limit ? 1 : 0]);
};

$API_CHAT['send'] = function ($me) {
    if (!rate_limit('msg:' . (int)$me['id'], 60, 60)) fail('发送过于频繁，请稍后再试');
    $ctype = inp_int('ctype', 1);
    $peer  = inp_int('to', inp_int('peer'));
    $type  = inp_int('type', 1);
    $content = (string)inp('content', '');
    $extra = inp('extra', null);
    if (!is_array($extra)) $extra = json_decode_arr((string)$extra);
    if ($peer <= 0) fail('请选择聊天对象');
    // 图文消息（type=30）：content 为 JSON {text, images[]}
    if ($type === 30) {
        $j = json_decode_arr($content);
        $text = trim((string)($j['text'] ?? ''));
        $imgs = $j['images'] ?? [];
        if (!is_array($imgs)) $imgs = [];
        $clean = [];
        foreach ($imgs as $u) {
            $u = trim((string)$u);
            if ($u === '' || !preg_match('#^(https?://|uploads/)#i', $u)) continue;
            $clean[] = mb_substr($u, 0, 255);
        }
        $clean = array_slice($clean, 0, 9);
        if ($text === '' && !$clean) fail('消息不能为空');
        if (mb_strlen($text) > 2000) fail('文字最多 2000 字');
        $content = json_encode(['text' => $text, 'images' => array_values($clean)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    if ($type === 1 && trim($content) === '') fail('消息不能为空');
    if (mb_strlen($content) > 5000) fail('消息过长');

    $uid = (int)$me['id'];
    if ($ctype === 1) {
        $to = one('SELECT * FROM users WHERE id=?', [$peer]);
        if (!$to) fail('对方不存在');
        // 非好友仅允许与官方账号聊天
        $isFriend = one('SELECT id FROM friends WHERE uid=? AND fid=?', [$uid, $peer]);
        $isOfficial = (int)$to['is_developer'] === 1 || (string)$to['account'] === (string)setting('service_uid', '10086');
        if (!$isFriend && !$isOfficial) fail('对方不是你的好友');
        // 黑名单：任意一方拉黑即无法发送（官方账号除外，便于联系客服）
        if (!$isOfficial && function_exists('is_blocked') && is_blocked($uid, $peer)) fail('消息发送失败');
        if (one('SELECT id FROM friends WHERE uid=? AND fid=? AND status=2', [$peer, $uid])) fail('消息已发出，但被对方拒收');
        $m = push_message(['ctype' => 1, 'from_uid' => $uid, 'to_uid' => $peer, 'gid' => 0, 'type' => $type, 'content' => $content, 'extra' => $extra]);
        ok(msg_row($m, $me));
    }

    // 群聊
    $g = group_by_gid($peer);
    if (!$g || (int)$g['status'] !== 1) fail('群聊不存在或已解散');
    $gm = group_member($peer, $uid);
    if (!$gm) fail('你不在该群聊中');
    if ((int)$g['mute_all'] === 1 && (int)$gm['role'] < 1) fail('全员禁言中，仅群主/管理员可发言');
    if ((int)$gm['mute_until'] > now()) fail('你已被禁言至 ' . date('m-d H:i', (int)$gm['mute_until']));
    $m = push_message(['ctype' => 2, 'from_uid' => $uid, 'to_uid' => 0, 'gid' => $peer, 'type' => $type, 'content' => $content, 'extra' => $extra]);
    ok(msg_row($m, $me));
};

$API_CHAT['long_poll'] = function ($me) {
    $uid = (int)$me['id'];
    $last = inp_int('last_id', 0);
    $wait = max(0, min(15, inp_int('wait', 8)));
    // Windows 下 PHP 内置服务器是单进程，长轮询会阻塞其它请求：开发环境退化为短轮询
    if (stripos($_SERVER['SERVER_SOFTWARE'] ?? '', 'Development Server') !== false) $wait = 0;
    $deadline = time() + $wait;
    ignore_user_abort(false);
    $gids = my_group_gids($uid);
    $in = $gids ? implode(',', array_map('intval', $gids)) : '0';

    // 初始化水位：只返回当前最大消息 ID，不回放历史
    if ($last < 0) {
        $max = (int)val("SELECT COALESCE(MAX(id),0) FROM messages WHERE deleted=0 AND ((ctype=1 AND (from_uid=? OR to_uid=?)) OR (ctype=2 AND gid IN ($in)))", [$uid, $uid]);
        ok(['messages' => [], 'conversations' => [], 'signals' => [], 'incoming_call' => null, 'live' => null, 'last_id' => $max, 'time' => now(), 'init' => 1, 'unread' => 0]);
    }

    while (true) {
        $rows = all("SELECT * FROM messages WHERE id>? AND deleted=0 AND ctype IN (1,2) AND ((ctype=1 AND (from_uid=? OR to_uid=?)) OR (ctype=2 AND gid IN ($in))) ORDER BY id ASC LIMIT 200", [$last, $uid, $uid]);
        $convRows = all('SELECT c.*, (SELECT COUNT(*) FROM conversations c2 WHERE c2.uid=c.uid AND c2.unread>0) AS x FROM conversations c WHERE uid=? ORDER BY pinned DESC, last_time DESC LIMIT 100', [$uid]);
        $convs = [];
        foreach ($convRows as $r) {
            $e = conv_entry($me, (int)$r['ctype'], (int)$r['peer_id']);
            if (!$e) continue;
            $e['last_msg'] = $r['last_msg'];
            $e['last_time'] = (int)$r['last_time'];
            $e['unread'] = (int)$r['unread'];
            $e['pinned'] = (int)$r['pinned'];
            $e['muted'] = (int)$r['muted'];
            $convs[] = $e;
        }
        $signals = all('SELECT s.*, u.nickname AS from_name FROM call_signals s LEFT JOIN users u ON u.id=s.from_uid WHERE s.to_uid=? AND s.consumed=0 ORDER BY s.id ASC LIMIT 50', [$uid]);
        $incomingCall = one('SELECT c.*, u.nickname AS from_name, u.avatar AS from_avatar FROM calls c JOIN users u ON u.id=c.from_uid WHERE c.to_uid=? AND c.status=0 AND c.created_at>? ORDER BY c.id DESC LIMIT 1', [$uid, time() - 60]);
        $liveInvite = one('SELECT l.*, u.nickname AS from_name FROM live_rooms l JOIN users u ON u.id=l.uid WHERE l.status=0 AND l.created_at>? AND l.uid<>? AND l.gid IN (' . ($gids ? implode(',', array_map('intval', $gids)) : '0') . ') ORDER BY l.id DESC LIMIT 1', [time() - 600, $uid]);

        if ($rows || $signals || $incomingCall) {
            $msgs = [];
            foreach ($rows as $r) $msgs[] = msg_row($r, $me);
            if ($signals) {
                foreach ($signals as $s) q('UPDATE call_signals SET consumed=1 WHERE id=?', [(int)$s['id']]);
            }
            $maxId = $last;
            if ($rows) { $lastRow = end($rows); $maxId = max($maxId, (int)$lastRow['id']); }
            ok([
                'messages' => $msgs,
                'conversations' => $convs,
                'signals' => $signals,
                'incoming_call' => $incomingCall,
                'live' => $liveInvite,
                'last_id' => $maxId,
                'time' => now(),
                'unread' => (int)val('SELECT COALESCE(SUM(unread),0) FROM conversations WHERE uid=?', [$uid]),
            ]);
        }
        if (time() >= $deadline || connection_aborted()) {
            if (connection_aborted()) exit;
            ok([
                'messages' => [], 'conversations' => $convs, 'signals' => [], 'incoming_call' => null,
                'live' => null, 'last_id' => $last, 'time' => now(),
                'unread' => (int)val('SELECT COALESCE(SUM(unread),0) FROM conversations WHERE uid=?', [$uid]),
            ]);
        }
        usleep(700000);
    }
};

$API_CHAT['mark_read'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('peer');
    conv_clear_unread((int)$me['id'], $ctype, $peer);
    if ($ctype === 2) {
        $lastId = (int)val('SELECT COALESCE(MAX(id),0) FROM messages WHERE gid=?', [$peer]);
        q('UPDATE group_members SET last_read_id=? WHERE gid=? AND uid=?', [$lastId, $peer, (int)$me['id']]);
    } else {
        $lastId = (int)val('SELECT COALESCE(MAX(id),0) FROM messages WHERE ctype=1 AND ((from_uid=? AND to_uid=?) OR (from_uid=? AND to_uid=?))', [(int)$me['id'], $peer, $peer, (int)$me['id']]);
        q('UPDATE conversations SET last_read_id=? WHERE uid=? AND ctype=1 AND peer_id=?', [$lastId, (int)$me['id'], $peer]);
    }
    ok(null, '已读');
};

$API_CHAT['mark_all_read'] = function ($me) {
    q('UPDATE conversations SET unread=0 WHERE uid=?', [(int)$me['id']]);
    ok(null, '全部已读');
};

$API_CHAT['peer_info'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('peer');
    if ($peer <= 0) fail('参数错误');
    if ($ctype === 1) {
        $u = one('SELECT * FROM users WHERE id=?', [$peer]);
        if (!$u) fail('用户不存在');
        $f = one('SELECT remark FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $peer]);
        $isFriend = $f ? 1 : 0;
        ok([
            'ctype' => 1, 'peer' => $peer,
            'name' => ($f && $f['remark']) ? $f['remark'] : ($u['nickname'] ?: ('用户' . $u['account'])),
            'avatar' => $u['avatar'],
            'yx_id' => $u['pretty_yxid'] ?: ($u['yx_id'] ?: $u['account']),
            'pretty' => (string)($u['pretty_yxid'] ?? ''),
            'online' => (int)$u['online'], 'vip_level' => is_vip($u) ? (int)$u['vip_level'] : 0,
            'is_friend' => $isFriend, 'is_bot' => (int)$u['is_developer'],
            'bio' => $u['bio'], 'region' => $u['region'],
        ]);
    }
    $g = group_by_gid($peer);
    if (!$g || (int)$g['status'] !== 1) fail('群聊不存在');
    ok([
        'ctype' => 2, 'peer' => $peer, 'name' => $g['name'], 'avatar' => $g['avatar'],
        'gid' => (int)$g['gid'],
        'show_gid' => (int)($g['pretty_gid'] ?? 0) > 0 ? (int)$g['pretty_gid'] : (int)$g['gid'],
        'pretty' => (int)($g['pretty_gid'] ?? 0) > 0 ? (string)$g['pretty_gid'] : '',
        'members' => (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$peer]),
        'owner_uid' => (int)$g['owner_uid'], 'muted' => (int)$g['mute_all'],
        'role' => group_role($peer, (int)$me['id']),
        'joined' => group_member($peer, (int)$me['id']) ? 1 : 0,
        'intro' => $g['intro'],
    ]);
};

$API_CHAT['recall'] = function ($me) {
    $id = inp_int('id');
    $m = one('SELECT * FROM messages WHERE id=?', [$id]);
    if (!$m) fail('消息不存在');
    if ((int)$m['from_uid'] !== (int)$me['id']) fail('只能撤回自己的消息');
    if (now() - (int)$m['created_at'] > 120) fail('超过 2 分钟的消息不能撤回');
    q('UPDATE messages SET recalled=1, deleted=1 WHERE id=?', [$id]);
    // 发一条系统消息，让双方实时刷新
    $sys = push_message([
        'ctype' => (int)$m['ctype'], 'from_uid' => (int)$me['id'],
        'to_uid' => (int)$m['to_uid'], 'gid' => (int)$m['gid'],
        'type' => 20, 'content' => $me['nickname'] . ' 撤回了一条消息',
        'extra' => ['mid' => $id],
    ]);
    ok(['sys' => msg_row($sys, $me)], '已撤回');
};

$API_CHAT['delete_msg'] = function ($me) {
    $id = inp_int('id');
    $m = one('SELECT * FROM messages WHERE id=?', [$id]);
    if (!$m) fail('消息不存在');
    // 只能删除自己发送的消息，防止越权删除他人聊天记录
    if ((int)$m['from_uid'] !== (int)$me['id']) fail('只能删除自己的消息', 403);
    q('UPDATE messages SET deleted=1 WHERE id=? AND from_uid=?', [$id, (int)$me['id']]);
    ok(null, '已删除');
};

$API_CHAT['conv_pin'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('peer');
    $pin = inp_int('pinned', 0) ? 1 : 0;
    q('UPDATE conversations SET pinned=? WHERE uid=? AND ctype=? AND peer_id=?', [$pin, (int)$me['id'], $ctype, $peer]);
    ok(null, '已更新');
};

$API_CHAT['conv_mute'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('peer');
    $mute = inp_int('muted', 0) ? 1 : 0;
    q('UPDATE conversations SET muted=? WHERE uid=? AND ctype=? AND peer_id=?', [$mute, (int)$me['id'], $ctype, $peer]);
    ok(null, '已更新');
};

$API_CHAT['conv_delete'] = function ($me) {
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('peer');
    q('UPDATE conversations SET visible=0, unread=0 WHERE uid=? AND ctype=? AND peer_id=?', [(int)$me['id'], $ctype, $peer]);
    ok(null, '会话已删除');
};

/* ---------- 转发 ---------- */
$API_CHAT['share_targets'] = function ($me) {
    $uid = (int)$me['id'];
    $friends = [];
    foreach (all('SELECT f.fid,f.remark,u.nickname,u.avatar,u.yx_id FROM friends f JOIN users u ON u.id=f.fid WHERE f.uid=? AND f.status=1 ORDER BY u.nickname', [$uid]) as $r) {
        $friends[] = ['id' => (int)$r['fid'], 'name' => $r['remark'] ?: $r['nickname'], 'avatar' => $r['avatar'], 'yx_id' => $r['yx_id']];
    }
    $groups = [];
    foreach (all('SELECT g.gid,g.name,g.avatar FROM groups g JOIN group_members gm ON gm.gid=g.gid WHERE gm.uid=? AND g.status=1', [$uid]) as $r) {
        $groups[] = ['gid' => (int)$r['gid'], 'name' => $r['name'], 'avatar' => $r['avatar']];
    }
    ok(['friends' => $friends, 'groups' => $groups]);
};

$API_CHAT['forward'] = function ($me) {
    $ids = inp('ids', []);
    if (is_string($ids)) $ids = array_filter(array_map('intval', explode(',', $ids)));
    if (!is_array($ids) || !$ids) fail('请选择消息');
    $targets = inp('targets', []);
    if (is_string($targets)) $targets = json_decode_arr($targets);
    if (!$targets) fail('请选择转发对象');
    $msgs = [];
    foreach ($ids as $id) {
        $m = one('SELECT * FROM messages WHERE id=? AND deleted=0', [(int)$id]);
        if ($m) $msgs[] = msg_row($m, $me);
    }
    if (!$msgs) fail('消息不存在');
    $payload = [
        'title' => '聊天记录',
        'items' => array_map(function ($m) {
            return ['u' => $m['sender']['nickname'], 'a' => $m['sender']['avatar'], 'c' => $m['content'], 'ty' => $m['type'], 't' => $m['created_at'], 'p' => $m['content']];
        }, $msgs),
    ];
    $n = 0;
    foreach ($targets as $t) {
        $ctype = (int)($t['ctype'] ?? 1);
        $peer = (int)($t['peer'] ?? 0);
        if ($peer <= 0) continue;
        if ($ctype === 1) {
            push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $peer, 'gid' => 0, 'type' => 17, 'content' => json_encode($payload, JSON_UNESCAPED_UNICODE)]);
        } else {
            if (!group_member($peer, (int)$me['id'])) continue;
            push_message(['ctype' => 2, 'from_uid' => (int)$me['id'], 'to_uid' => 0, 'gid' => $peer, 'type' => 17, 'content' => json_encode($payload, JSON_UNESCAPED_UNICODE)]);
        }
        $n++;
    }
    ok(['count' => $n], '已转发');
};

/* ---------- 搜索聊天记录 ---------- */
$API_CHAT['search_chat'] = function ($me) {
    $kw = trim((string)inp('keyword', ''));
    if ($kw === '') fail('请输入关键词');
    $uid = (int)$me['id'];
    $gids = my_group_gids($uid);
    $in = $gids ? implode(',', array_map('intval', $gids)) : '0';
    $rows = all("SELECT * FROM messages WHERE deleted=0 AND type=1 AND content LIKE ? AND ((ctype=1 AND (from_uid=? OR to_uid=?)) OR (ctype=2 AND gid IN ($in))) ORDER BY id DESC LIMIT 60", ['%' . $kw . '%', $uid, $uid]);
    $out = [];
    foreach ($rows as $r) {
        $m = msg_row($r, $me);
        if ((int)$r['ctype'] === 1) {
            $peer = (int)$r['from_uid'] === $uid ? (int)$r['to_uid'] : (int)$r['from_uid'];
            $m['conv'] = conv_entry($me, 1, $peer);
        } else {
            $m['conv'] = conv_entry($me, 2, (int)$r['gid']);
        }
        $out[] = $m;
    }
    ok(['list' => $out]);
};

/* ---------- 上传 ---------- */
$API_CHAT['upload_image'] = function ($me) {
    if (!rate_limit('upimg:' . (int)$me['id'], 30, 60)) fail('上传过于频繁，请稍后再试');
    $f = upload_save('file', 'chat', ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'], 20 * 1024 * 1024);
    $w = inp_int('w'); $h = inp_int('h');
    ok(['url' => $f['url'], 'w' => $w, 'h' => $h, 'size' => $f['size']]);
};
$API_CHAT['upload_video'] = function ($me) {
    $f = upload_save('file', 'video', ['mp4', 'mov', 'webm', 'm4v'], 200 * 1024 * 1024);
    ok(['url' => $f['url'], 'size' => $f['size']]);
};
$API_CHAT['upload_voice'] = function ($me) {
    $f = upload_save('file', 'voice', ['webm', 'ogg', 'mp3', 'm4a', 'wav', 'amr', 'aac'], 20 * 1024 * 1024);
    ok(['url' => $f['url'], 'size' => $f['size'], 'duration' => inp_int('duration')]);
};
$API_CHAT['upload_file'] = function ($me) {
    $f = upload_save('file', 'file', [], 60 * 1024 * 1024);
    $name = mb_substr(trim((string)inp('name', $_FILES['file']['name'] ?? '文件')), 0, 100);
    ok(['url' => $f['url'], 'size' => $f['size'], 'name' => $name]);
};

/* ---------- 表情 ---------- */
$API_CHAT['emoji_list'] = function ($me) {
    $sys = all('SELECT id,name,url FROM emojis WHERE uid=0 ORDER BY id');
    $mine = all('SELECT id,name,url FROM emojis WHERE uid=? ORDER BY id DESC', [(int)$me['id']]);
    ok(['system' => $sys, 'mine' => $mine]);
};
$API_CHAT['emoji_add'] = function ($me) {
    $f = upload_save('file', 'emoji', ['jpg', 'jpeg', 'png', 'gif', 'webp'], 4 * 1024 * 1024);
    q('INSERT INTO emojis (uid,name,url,created_at) VALUES (?,?,?,?)', [(int)$me['id'], mb_substr((string)inp('name', ''), 0, 32), $f['url'], now()]);
    ok(['id' => last_id(), 'url' => $f['url']]);
};
$API_CHAT['emoji_del'] = function ($me) {
    $id = inp_int('id');
    q('DELETE FROM emojis WHERE id=? AND uid=?', [$id, (int)$me['id']]);
    ok(null, '已删除');
};

/* ---------- 礼物列表 ---------- */
$API_CHAT['gift_list'] = function ($me) {
    $rows = all('SELECT * FROM gifts WHERE status=1 ORDER BY sort,id');
    ok(['list' => $rows]);
};

/* ---------- 收藏 ---------- */
$API_CHAT['favorite_add'] = function ($me) {
    $mtype = inp_int('mtype', 1);
    $content = (string)inp('content', '');
    if ($content === '') fail('内容为空');
    q('INSERT INTO favorites (uid,mtype,content,created_at) VALUES (?,?,?,?)', [(int)$me['id'], $mtype, $content, now()]);
    ok(null, '已收藏');
};
$API_CHAT['favorite_list'] = function ($me) {
    ok(['list' => all('SELECT * FROM favorites WHERE uid=? ORDER BY id DESC LIMIT 200', [(int)$me['id']])]);
};
$API_CHAT['favorite_del'] = function ($me) {
    q('DELETE FROM favorites WHERE id=? AND uid=?', [inp_int('id'), (int)$me['id']]);
    ok(null, '已删除');
};
