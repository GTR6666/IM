<?php
/**
 * CC商聊 - API：群聊管理
 */
declare(strict_types=1);

$API_GROUP = [];

function group_public(array $g, int $uid = 0): array
{
    $gid = (int)$g['gid'];
    $members = (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid]);
    $role = $uid ? group_role($gid, $uid) : -1;
    $owner = one('SELECT id,nickname,avatar,yx_id FROM users WHERE id=?', [(int)$g['owner_uid']]);
    $gm = $uid ? group_member($gid, $uid) : null;
    return [
        'gid'        => $gid,
        'name'       => $g['name'],
        'avatar'     => $g['avatar'],
        'intro'      => $g['intro'],
        'owner_uid'  => (int)$g['owner_uid'],
        'owner'      => $owner ? ['id' => (int)$owner['id'], 'nickname' => $owner['nickname'], 'avatar' => $owner['avatar']] : null,
        'members'    => $members,
        'member_limit' => (int)$g['member_limit'],
        'join_mode'  => (int)$g['join_mode'],
        'is_public'  => (int)$g['is_public'],
        'mute_all'   => (int)$g['mute_all'],
        'status'     => (int)$g['status'],
        'role'       => $role,
        'joined'     => $role >= 0 ? 1 : 0,
        'created_at' => (int)$g['created_at'],
        'my_nickname'=> $gm ? (string)$gm['nickname'] : '',
        'mute_until' => $gm ? (int)$gm['mute_until'] : 0,
    ];
}

$API_GROUP['group_list'] = function ($me) {
    $uid = (int)$me['id'];
    $rows = all('SELECT g.* FROM groups g JOIN group_members gm ON gm.gid=g.gid WHERE gm.uid=? AND g.status=1 ORDER BY g.id DESC', [$uid]);
    $joined = [];
    $created = [];
    foreach ($rows as $g) {
        $p = group_public($g, $uid);
        $gm = group_member((int)$g['gid'], $uid);
        $readId = $gm ? (int)$gm['last_read_id'] : 0;
        $p['unread'] = (int)val('SELECT COUNT(*) FROM messages m WHERE m.gid=? AND m.id>? AND m.from_uid<>? AND m.deleted=0', [(int)$g['gid'], $readId, $uid]);
        $joined[] = $p;
        if ((int)$g['owner_uid'] === $uid) $created[] = $p;
    }
    ok(['joined' => $joined, 'created' => $created, 'count' => count($joined)]);
};

$API_GROUP['group_create'] = function ($me) {
    if (!rate_limit('gcreate:' . (int)$me['id'], 10, 3600)) fail('创建过于频繁，请稍后再试');
    $name = trim((string)inp('name', ''));
    $intro = mb_substr(trim((string)inp('intro', '')), 0, 200);
    if ($name === '') fail('请填写群名称');
    if (mb_strlen($name) > 20) fail('群名称最多 20 个字');
    $cnt = (int)val('SELECT COUNT(*) FROM groups WHERE owner_uid=? AND status=1', [(int)$me['id']]);
    if ($cnt >= 10) fail('最多创建 10 个群聊');
    $gid = gen_gid();
    $now = now();
    q('INSERT INTO groups (gid,name,avatar,intro,owner_uid,member_limit,join_mode,is_public,mute_all,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', [
        $gid, $name, '', $intro, (int)$me['id'], 100, 0, 1, 0, 1, $now,
    ]);
    q('INSERT INTO group_members (gid,uid,role,nickname,mute_until,joined_at,last_read_id,pinned) VALUES (?,?,?,?,0,?,0,0)', [
        $gid, (int)$me['id'], 2, '', $now,
    ]);
    conv_touch((int)$me['id'], 2, $gid, '群聊已创建', $now, 0);
    ok(group_public(group_by_gid($gid), (int)$me['id']), '群聊创建成功');
};

$API_GROUP['group_info'] = function ($me) {
    $gid = inp_int('gid');
    $g = group_by_gid($gid);
    if (!$g || (int)$g['status'] !== 1) fail('群聊不存在');
    $p = group_public($g, (int)$me['id']);
    // 群公告仅成员可见；非成员仅在公开群下返回空数组，避免私密群内容外泄
    $isMember = group_member($gid, (int)$me['id']) ? true : false;
    $p['notices'] = $isMember
        ? all('SELECT n.*, u.nickname FROM group_notices n LEFT JOIN users u ON u.id=n.uid WHERE n.gid=? ORDER BY n.id DESC LIMIT 10', [$gid])
        : [];
    $p['is_member'] = $isMember ? 1 : 0;
    ok($p);
};

$API_GROUP['group_query'] = function ($me) {
    $gid = inp_int('gid');
    $g = one('SELECT * FROM groups WHERE gid=? OR id=?', [$gid, $gid]);
    if (!$g) fail('群聊不存在');
    $p = group_public($g, (int)$me['id']);
    $p['request_pending'] = (int)val('SELECT COUNT(*) FROM group_join_requests WHERE gid=? AND uid=? AND status=0', [(int)$g['gid'], (int)$me['id']]);
    ok($p);
};

$API_GROUP['group_update'] = function ($me) {
    $gid = inp_int('gid');
    $role = group_role($gid, (int)$me['id']);
    if ($role < 1) fail('无权限');
    $f = [];
    foreach (['name' => 20, 'intro' => 200, 'avatar' => 255] as $k => $max) {
        if (inp($k) !== null) $f[$k] = mb_substr(trim((string)inp($k)), 0, $max);
    }
    if (inp('join_mode') !== null && $role === 2) $f['join_mode'] = max(0, min(2, inp_int('join_mode')));
    if (inp('is_public') !== null && $role === 2) $f['is_public'] = inp_int('is_public') ? 1 : 0;
    if (!$f) fail('没有修改内容');
    $sets = []; $params = [];
    foreach ($f as $k => $v) { $sets[] = "$k=?"; $params[] = $v; }
    $params[] = $gid;
    q('UPDATE groups SET ' . implode(',', $sets) . ' WHERE gid=?', $params);
    ok(group_public(group_by_gid($gid), (int)$me['id']), '已保存');
};

$API_GROUP['group_upload_avatar'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) < 1) fail('无权限');
    $f = upload_save('file', 'avatar', ['jpg', 'jpeg', 'png', 'gif', 'webp'], 8 * 1024 * 1024);
    q('UPDATE groups SET avatar=? WHERE gid=?', [$f['url'], $gid]);
    ok(['url' => $f['url']]);
};

$API_GROUP['group_members'] = function ($me) {
    $gid = inp_int('gid');
    $g = group_by_gid($gid);
    if (!$g) fail('群聊不存在');
    if (group_role($gid, (int)$me['id']) < 0) fail('你不在该群聊中');
    $rows = all('SELECT gm.*, u.nickname AS user_nickname, u.avatar, u.yx_id, u.account, u.online, u.vip_level, u.vip_expire_at, u.is_developer, u.pretty_yxid FROM group_members gm JOIN users u ON u.id=gm.uid WHERE gm.gid=? ORDER BY gm.role DESC, gm.id ASC', [$gid]);
    $out = [];
    foreach ($rows as $r) {
        $nick = $r['nickname'] ?: $r['user_nickname'];
        $out[] = [
            'uid' => (int)$r['uid'],
            'name' => $nick,
            'nickname' => $nick,
            'user_nickname' => $r['user_nickname'],
            'avatar' => $r['avatar'],
            'yx_id' => $r['yx_id'] ?: $r['account'],
            'role' => (int)$r['role'],
            'online' => (int)$r['online'],
            'vip_level' => is_vip($r) ? (int)$r['vip_level'] : 0,
            'pretty' => (string)($r['pretty_yxid'] ?? ''),
            'mute_until' => (int)$r['mute_until'],
            'joined_at' => (int)$r['joined_at'],
            'is_bot' => (int)$r['is_developer'],
        ];
    }
    ok([
        'list' => $out,
        'role' => group_role($gid, (int)$me['id']),
        'mute_all' => (int)$g['mute_all'],
        'hide_member_info' => (int)($g['hide_member_info'] ?? 0),
    ]);
};

$API_GROUP['group_kick'] = function ($me) {
    $gid = inp_int('gid');
    $uid = inp_int('uid');
    $myRole = group_role($gid, (int)$me['id']);
    $target = group_member($gid, $uid);
    if (!$target) fail('成员不存在');
    if ($myRole < 1 || (int)$target['role'] >= $myRole) fail('无权限');
    q('DELETE FROM group_members WHERE gid=? AND uid=?', [$gid, $uid]);
    q('UPDATE conversations SET visible=0 WHERE uid=? AND ctype=2 AND peer_id=?', [$uid, $gid]);
    ok(null, '已移出群聊');
};

$API_GROUP['group_set_admin'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) !== 2) fail('仅群主可设置管理员');
    $uid = inp_int('uid');
    $set = inp_int('set', 1) ? 1 : 0;
    $t = group_member($gid, $uid);
    if (!$t) fail('成员不存在');
    if ((int)$t['role'] === 2) fail('不能修改群主');
    q('UPDATE group_members SET role=? WHERE gid=? AND uid=?', [$set, $gid, $uid]);
    ok(null, $set ? '已设为管理员' : '已取消管理员');
};

$API_GROUP['group_mute_member'] = function ($me) {
    $gid = inp_int('gid');
    $uid = inp_int('uid');
    $minutes = inp_int('minutes', 0);
    $myRole = group_role($gid, (int)$me['id']);
    $t = group_member($gid, $uid);
    if (!$t) fail('成员不存在');
    if ($myRole < 1 || (int)$t['role'] >= $myRole) fail('无权限');
    $until = $minutes > 0 ? now() + $minutes * 60 : 0;
    q('UPDATE group_members SET mute_until=? WHERE gid=? AND uid=?', [$until, $gid, $uid]);
    ok(['mute_until' => $until], $minutes > 0 ? '已禁言' : '已解除禁言');
};

/* ---------- 成员信息可见性（群主/管理员可设置） ---------- */
$API_GROUP['group_set_privacy'] = function ($me) {
    $gid = inp_int('gid');
    $myRole = group_role($gid, (int)$me['id']);
    if ($myRole < 1) fail('仅群主和管理员可设置');
    $hide = inp_int('hide_member_info', -1);
    if (!in_array($hide, [0, 1], true)) fail('参数错误');
    q('UPDATE groups SET hide_member_info=? WHERE gid=?', [$hide, $gid]);
    ok(['hide_member_info' => $hide], $hide ? '已关闭成员信息查看' : '已开启成员信息查看');
};

/* ---------- 群消息置顶（多条，群主/管理员可增删） ---------- */
$API_GROUP['group_pin_msg'] = function ($me) {
    $gid = inp_int('gid');
    $mid = inp_int('msg_id');
    $act = (string)inp('act', 'pin');
    if (group_role($gid, (int)$me['id']) < 1) fail('仅群主和管理员可置顶');

    if ($act === 'clear') {
        q('DELETE FROM group_pins WHERE gid=?', [$gid]);
        q('UPDATE groups SET pinned_msg_id=0, pinned_at=0, pinned_by=0 WHERE gid=?', [$gid]);
        ok(null, '已清空置顶');
    }
    if ($mid <= 0) fail('参数错误');

    if ($act === 'unpin') {
        q('DELETE FROM group_pins WHERE gid=? AND msg_id=?', [$gid, $mid]);
        $left = (int)val('SELECT COUNT(*) FROM group_pins WHERE gid=?', [$gid]);
        if ($left === 0) q('UPDATE groups SET pinned_msg_id=0,pinned_at=0,pinned_by=0 WHERE gid=?', [$gid]);
        ok(['count' => $left], '已取消置顶');
    }

    $m = one('SELECT * FROM messages WHERE id=? AND gid=?', [$mid, $gid]);
    if (!$m) fail('消息不存在');
    $cnt = (int)val('SELECT COUNT(*) FROM group_pins WHERE gid=?', [$gid]);
    if (!val('SELECT id FROM group_pins WHERE gid=? AND msg_id=?', [$gid, $mid]) && $cnt >= 10) {
        fail('最多置顶 10 条消息，请先取消一些');
    }
    if (!val('SELECT id FROM group_pins WHERE gid=? AND msg_id=?', [$gid, $mid])) {
        q('INSERT INTO group_pins (gid,msg_id,uid,created_at) VALUES (?,?,?,?)', [$gid, $mid, (int)$me['id'], now()]);
    }
    // 兼容旧字段（保留最近一条）
    q('UPDATE groups SET pinned_msg_id=?, pinned_at=?, pinned_by=? WHERE gid=?', [$mid, now(), (int)$me['id'], $gid]);
    ok(['count' => $cnt + 1], '已置顶');
};

/** 取消息的可读摘要（最多 20 字） */
function pin_preview(array $m): string
{
    $type = (int)$m['type'];
    $raw = (string)$m['content'];
    if ($type !== 1) {
        $map = [2 => '[图片]', 3 => '[语音]', 4 => '[视频]', 5 => '[图片]', 6 => '[语音]',
                7 => '[名片]', 8 => '[红包]', 9 => '[礼物]', 10 => '[转账]', 11 => '[系统消息]',
                15 => '[视频]', 18 => '[文件]', 19 => '[直播]', 21 => '[红包]', 22 => '[转账]',
                23 => '[礼物]', 24 => '[红包]', 30 => '[图文]', 20 => '[系统消息]'];
        $raw = $map[$type] ?? '[消息]';
        if ($type === 30) {
            $j = json_decode_arr($raw);
            $raw = trim((string)($j['text'] ?? ''));
            if ($raw === '') $raw = '[图片]';
        }
    } elseif (preg_match('/^\{/', $raw)) {
        $j = json_decode_arr($raw);
        $raw = (string)($j['text'] ?? $j['content'] ?? '[消息]');
    }
    return mb_substr(trim(preg_replace('/\s+/u', ' ', $raw)), 0, 20);
}

$API_GROUP['group_pinned'] = function ($me) {
    $gid = inp_int('gid');
    $g = group_by_gid($gid);
    if (!$g) fail('群聊不存在');
    if (!group_member($gid, (int)$me['id'])) fail('你不在该群聊中');
    $rows = all('SELECT p.msg_id, p.created_at AS pin_at, m.type, m.content, m.created_at, u.nickname
        FROM group_pins p
        LEFT JOIN messages m ON m.id=p.msg_id AND m.gid=p.gid
        LEFT JOIN users u ON u.id=m.from_uid
        WHERE p.gid=? ORDER BY p.id DESC LIMIT 10', [$gid]);
    $list = [];
    foreach ($rows as $r) {
        if ($r['content'] === null) { q('DELETE FROM group_pins WHERE gid=? AND msg_id=?', [$gid, (int)$r['msg_id']]); continue; }
        $list[] = [
            'msg_id'    => (int)$r['msg_id'],
            'preview'   => pin_preview($r),
            'sender'    => (string)($r['nickname'] ?: '成员'),
            'type'      => (int)$r['type'],
            'created_at'=> (int)$r['created_at'],
            'pinned_at' => (int)$r['pin_at'],
        ];
    }
    ok(['list' => $list, 'count' => count($list), 'role' => group_role($gid, (int)$me['id'])]);
};

/* ---------- 封禁（群主/管理员可拉黑，禁止再次加入） ---------- */
$API_GROUP['group_ban'] = function ($me) {
    $gid = inp_int('gid');
    $uid = inp_int('uid');
    $reason = mb_substr(trim((string)inp('reason', '')), 0, 200);
    $myRole = group_role($gid, (int)$me['id']);
    if ($myRole < 1) fail('无权限');
    $g = group_by_gid($gid);
    if (!$g) fail('群聊不存在');
    if ($uid === (int)$me['id']) fail('不能封禁自己');
    if ($uid === (int)$g['owner_uid']) fail('不能封禁群主');
    $t = group_member($gid, $uid);
    $tRole = $t ? (int)$t['role'] : 0;
    if ($tRole >= $myRole) fail('无法封禁同级或更高权限成员');
    // 移出群聊
    if ($t) {
        q('DELETE FROM group_members WHERE gid=? AND uid=?', [$gid, $uid]);
        q('UPDATE conversations SET visible=0 WHERE uid=? AND ctype=2 AND peer_id=?', [$uid, $gid]);
    }
    // 写入封禁表（重复封禁则更新原因）
    if (one('SELECT id FROM group_bans WHERE gid=? AND uid=?', [$gid, $uid])) {
        q('UPDATE group_bans SET operator_uid=?, reason=?, created_at=? WHERE gid=? AND uid=?',
          [(int)$me['id'], $reason, now(), $gid, $uid]);
    } else {
        q('INSERT INTO group_bans (gid,uid,operator_uid,reason,created_at) VALUES (?,?,?,?,?)',
          [$gid, $uid, (int)$me['id'], $reason, now()]);
    }
    ok(null, '已封禁并移出群聊');
};

$API_GROUP['group_unban'] = function ($me) {
    $gid = inp_int('gid');
    $uid = inp_int('uid');
    $myRole = group_role($gid, (int)$me['id']);
    if ($myRole < 1) fail('无权限');
    q('DELETE FROM group_bans WHERE gid=? AND uid=?', [$gid, $uid]);
    ok(null, '已解除封禁，对方可重新申请入群');
};

$API_GROUP['group_bans'] = function ($me) {
    $gid = inp_int('gid');
    $myRole = group_role($gid, (int)$me['id']);
    if ($myRole < 1) fail('无权限');
    $rows = all('SELECT b.*, u.nickname, u.avatar, u.yx_id, u.account FROM group_bans b
        LEFT JOIN users u ON u.id=b.uid WHERE b.gid=? ORDER BY b.id DESC LIMIT 200', [$gid]);
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'uid'      => (int)$r['uid'],
            'name'     => $r['nickname'] ?: ('用户' . substr((string)($r['account'] ?? ''), -4)),
            'avatar'   => (string)($r['avatar'] ?? ''),
            'account'  => (string)($r['yx_id'] ?: ($r['account'] ?? '')),
            'reason'   => (string)$r['reason'],
            'created_at' => (int)$r['created_at'],
        ];
    }
    ok(['list' => $out]);
};

$API_GROUP['group_mute_all'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) < 1) fail('无权限');
    $v = inp_int('mute_all', 0) ? 1 : 0;
    q('UPDATE groups SET mute_all=? WHERE gid=?', [$v, $gid]);
    ok(null, $v ? '已开启全员禁言' : '已关闭全员禁言');
};

$API_GROUP['group_transfer'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) !== 2) fail('仅群主可转让');
    $uid = inp_int('uid');
    $t = group_member($gid, $uid);
    if (!$t) fail('成员不存在');
    q('UPDATE group_members SET role=1 WHERE gid=? AND uid=?', [$gid, (int)$me['id']]);
    q('UPDATE group_members SET role=2 WHERE gid=? AND uid=?', [$gid, $uid]);
    q('UPDATE groups SET owner_uid=? WHERE gid=?', [$uid, $gid]);
    ok(null, '群主已转让');
};

$API_GROUP['group_dissolve'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) !== 2) fail('仅群主可解散');
    q('UPDATE groups SET status=0 WHERE gid=?', [$gid]);
    q('UPDATE conversations SET visible=0 WHERE ctype=2 AND peer_id=?', [$gid]);
    ok(null, '群聊已解散');
};

$API_GROUP['group_exit'] = function ($me) {
    $gid = inp_int('gid');
    $gm = group_member($gid, (int)$me['id']);
    if (!$gm) fail('你不在该群聊中');
    if ((int)$gm['role'] === 2) fail('群主不能退出，请先转让或解散群聊');
    q('DELETE FROM group_members WHERE gid=? AND uid=?', [$gid, (int)$me['id']]);
    q('UPDATE conversations SET visible=0 WHERE uid=? AND ctype=2 AND peer_id=?', [(int)$me['id'], $gid]);
    ok(null, '已退出群聊');
};

$API_GROUP['group_join'] = function ($me) {
    if (!rate_limit('gjoin:' . (int)$me['id'], 30, 3600)) fail('操作过于频繁，请稍后再试');
    $gid = inp_int('gid');
    $g = group_by_gid($gid);
    if (!$g || (int)$g['status'] !== 1) fail('群聊不存在或已解散');
    if (group_member($gid, (int)$me['id'])) fail('你已在该群聊中');
    // 被封禁的成员不可再次加入
    if (one('SELECT id FROM group_bans WHERE gid=? AND uid=?', [$gid, (int)$me['id']])) {
        fail('你已被该群封禁，无法加入');
    }
    if ((int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid]) >= (int)$g['member_limit']) fail('群成员已满');
    if ((int)$g['join_mode'] === 2) fail('该群不允许加入');
    if ((int)$g['join_mode'] === 1) {
        if (one('SELECT id FROM group_join_requests WHERE gid=? AND uid=? AND status=0', [$gid, (int)$me['id']])) fail('已提交申请，等待群主处理');
        q('INSERT INTO group_join_requests (gid,uid,reason,status,created_at) VALUES (?,?,?,0,?)', [$gid, (int)$me['id'], mb_substr((string)inp('reason', ''), 0, 100), now()]);
        ok(['pending' => 1], '申请已提交');
    }
    $now = now();
    q('INSERT INTO group_members (gid,uid,role,nickname,mute_until,joined_at,last_read_id,pinned) VALUES (?,?,?,?,0,?,0,0)', [$gid, (int)$me['id'], 0, '', $now]);
    conv_touch((int)$me['id'], 2, $gid, '已加入群聊', $now, 0);
    ok(['pending' => 0], '已加入群聊');
};

$API_GROUP['group_handle_join'] = function ($me) {
    $id = inp_int('id');
    $act = (string)inp('act', 'accept');
    $r = one('SELECT * FROM group_join_requests WHERE id=?', [$id]);
    if (!$r) fail('申请不存在');
    $g = group_by_gid((int)$r['gid']);
    if (!$g) fail('群聊不存在');
    if (group_role((int)$r['gid'], (int)$me['id']) < 1 && (int)$g['owner_uid'] !== (int)$me['id']) fail('无权限');
    if ($act === 'accept') {
        q('UPDATE group_join_requests SET status=1 WHERE id=?', [$id]);
        if (!group_member((int)$r['gid'], (int)$r['uid'])) {
            q('INSERT INTO group_members (gid,uid,role,nickname,mute_until,joined_at,last_read_id,pinned) VALUES (?,?,?,?,0,?,0,0)', [(int)$r['gid'], (int)$r['uid'], 0, '', now()]);
        }
        ok(null, '已同意');
    }
    q('UPDATE group_join_requests SET status=2 WHERE id=?', [$id]);
    ok(null, '已拒绝');
};

$API_GROUP['group_join_requests'] = function ($me) {
    $rows = all('SELECT r.*, u.nickname, u.avatar, u.yx_id, g.name AS gname FROM group_join_requests r JOIN users u ON u.id=r.uid JOIN groups g ON g.gid=r.gid WHERE g.owner_uid=? AND r.status=0 ORDER BY r.id DESC LIMIT 100', [(int)$me['id']]);
    ok(['list' => $rows]);
};

$API_GROUP['group_notice_set'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) < 1) fail('无权限');
    $content = mb_substr(trim((string)inp('content', '')), 0, 500);
    if ($content === '') fail('公告不能为空');
    q('INSERT INTO group_notices (gid,uid,content,created_at) VALUES (?,?,?,?)', [$gid, (int)$me['id'], $content, now()]);
    push_message(['ctype' => 2, 'from_uid' => service_uid(), 'gid' => $gid, 'to_uid' => 0, 'type' => 11, 'content' => '【群公告】' . $content]);
    ok(null, '公告已发布');
};

$API_GROUP['group_upgrade_limit'] = function ($me) {
    $gid = inp_int('gid');
    if (group_role($gid, (int)$me['id']) !== 2) fail('仅群主可升级');
    $g = group_by_gid($gid);
    $vip = is_vip($me) ? (int)$me['vip_level'] : 0;
    if ($vip <= 0) fail('开通 VIP / SVIP 后可升级群人数');
    // SVIP 可升到最高上限，VIP 先升到 500 人
    $target = $vip >= svip_min_level() ? (int)setting('group_max_limit', '2000') : 500;
    if ((int)$g['member_limit'] >= $target) fail('当前已是最高人数');
    q('UPDATE groups SET member_limit=? WHERE gid=?', [$target, $gid]);
    ok(['member_limit' => $target], '已升级到 ' . $target . ' 人');
};

$API_GROUP['group_set_nickname'] = function ($me) {
    $gid = inp_int('gid');
    $gm = group_member($gid, (int)$me['id']);
    if (!$gm) fail('你不在该群聊中');
    $nick = mb_substr(trim((string)inp('nickname', '')), 0, 20);
    q('UPDATE group_members SET nickname=? WHERE gid=? AND uid=?', [$nick, $gid, (int)$me['id']]);
    ok(null, '已保存');
};

$API_GROUP['group_share_card'] = function ($me) {
    $gid = inp_int('gid');
    $to = inp_int('to');
    $g = group_by_gid($gid);
    if (!$g) fail('群聊不存在');
    if ($to !== (int)$me['id'] && (int)$to !== service_uid() && !one('SELECT id FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $to])) {
        fail('只能分享给好友'); // 防止向任意用户群发骚扰
    }
    $content = json_encode(['gid' => $gid, 'name' => $g['name'], 'avatar' => $g['avatar'], 'members' => (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid])], JSON_UNESCAPED_UNICODE);
    $m = push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $to, 'gid' => 0, 'type' => 13, 'content' => $content]);
    ok(msg_row($m, $me));
};
