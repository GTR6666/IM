<?php
/**
 * CC商聊 - API：朋友圈（广场动态）
 */
declare(strict_types=1);

$API_MOMENT = [];

function moment_row(array $m, int $uid): array
{
    $author = one('SELECT * FROM users WHERE id=?', [(int)$m['uid']]);
    $likes = all('SELECT l.uid, u.nickname FROM moment_likes l JOIN users u ON u.id=l.uid WHERE l.mid=? ORDER BY l.id', [(int)$m['id']]);
    $comments = all('SELECT c.*, u.nickname, u.avatar FROM moment_comments c JOIN users u ON u.id=c.uid WHERE c.mid=? AND c.deleted=0 ORDER BY c.id ASC', [(int)$m['id']]);
    $likeUids = array_map(fn($x) => (int)$x['uid'], $likes);
    $cOut = [];
    foreach ($comments as $c) {
        $replyName = '';
        if ((int)$c['reply_uid']) $replyName = (string)val('SELECT nickname FROM users WHERE id=?', [(int)$c['reply_uid']]);
        $cOut[] = [
            'id' => (int)$c['id'], 'uid' => (int)$c['uid'], 'nickname' => $c['nickname'], 'avatar' => $c['avatar'],
            'reply_uid' => (int)$c['reply_uid'], 'reply_name' => $replyName,
            'content' => $c['content'], 'created_at' => (int)$c['created_at'],
            'mine' => (int)$c['uid'] === $uid ? 1 : 0,
        ];
    }
    return [
        'id' => (int)$m['id'],
        'uid' => (int)$m['uid'],
        'author' => $author ? user_public($author) : ['id' => 0, 'nickname' => '已注销', 'avatar' => ''],
        'content' => (string)$m['content'],
        'images' => json_decode_arr($m['images'] ?? ''),
        'video' => (string)$m['video'],
        'visibility' => (int)$m['visibility'],
        'created_at' => (int)$m['created_at'],
        'likes' => array_map(fn($x) => ['uid' => (int)$x['uid'], 'nickname' => $x['nickname']], $likes),
        'liked' => in_array($uid, $likeUids, true) ? 1 : 0,
        'comments' => $cOut,
        'mine' => (int)$m['uid'] === $uid ? 1 : 0,
    ];
}

$API_MOMENT['feed_list'] = function ($me) {
    $uid = (int)$me['id'];
    $scope = (string)inp('scope', 'all'); // all|mine
    if ($scope === 'mine') {
        $rows = all('SELECT * FROM moment WHERE uid=? AND deleted=0 ORDER BY id DESC LIMIT 50', [$uid]);
    } else {
        $friendIds = [$uid];
        foreach (all('SELECT fid FROM friends WHERE uid=? AND status=1', [$uid]) as $r) $friendIds[] = (int)$r['fid'];
        $in = implode(',', array_map('intval', $friendIds));
        $rows = all("SELECT * FROM moment WHERE uid IN ($in) AND deleted=0 AND visibility<2 ORDER BY id DESC LIMIT 50");
    }
    $list = [];
    foreach ($rows as $r) $list[] = moment_row($r, $uid);
    ok(['list' => $list]);
};

$API_MOMENT['send_moment'] = function ($me) {
    if (!rate_limit('moment:' . (int)$me['id'], 20, 3600)) fail('发布过于频繁，请稍后再试');
    $content = trim((string)inp('content', ''));
    $images = inp('images', []);
    if (is_string($images)) $images = json_decode_arr($images);
    if (!is_array($images)) $images = [];
    // 图片地址白名单：仅允许本站 uploads/ 或 http(s) 链接，杜绝 javascript: / data: 等危险协议
    $clean = [];
    foreach ($images as $u) {
        $u = trim((string)$u);
        if ($u === '') continue;
        if (!preg_match('#^(https?://|uploads/)#i', $u)) continue;
        $clean[] = mb_substr($u, 0, 255);
    }
    $images = array_slice($clean, 0, 9);
    $video = trim((string)inp('video', ''));
    if ($video !== '' && !preg_match('#^(https?://|uploads/)#i', $video)) $video = '';
    $visibility = max(0, min(2, inp_int('visibility', 0)));
    if ($content === '' && !$images && $video === '') fail('说点什么吧');
    if (mb_strlen($content) > 1000) fail('内容最多 1000 字');
    if (count($images) > 9) fail('最多 9 张图片');
    q('INSERT INTO moment (uid,content,images,video,visibility,created_at,deleted) VALUES (?,?,?,?,?,?,0)', [
        (int)$me['id'], $content, json_encode(array_values($images), JSON_UNESCAPED_UNICODE), $video, $visibility, now(),
    ]);
    ok(['id' => last_id()], '发布成功');
};

$API_MOMENT['delete_moment'] = function ($me) {
    $id = inp_int('id');
    $m = one('SELECT * FROM moment WHERE id=?', [$id]);
    if (!$m) fail('动态不存在');
    if ((int)$m['uid'] !== (int)$me['id']) fail('只能删除自己的动态');
    q('UPDATE moment SET deleted=1 WHERE id=?', [$id]);
    ok(null, '已删除');
};

$API_MOMENT['like'] = function ($me) {
    $id = inp_int('id');
    $m = one('SELECT * FROM moment WHERE id=? AND deleted=0', [$id]);
    if (!$m) fail('动态不存在');
    $has = one('SELECT id FROM moment_likes WHERE mid=? AND uid=?', [$id, (int)$me['id']]);
    if ($has) {
        q('DELETE FROM moment_likes WHERE id=?', [(int)$has['id']]);
        ok(['liked' => 0], '已取消');
    }
    q('INSERT INTO moment_likes (mid,uid,created_at) VALUES (?,?,?)', [$id, (int)$me['id'], now()]);
    ok(['liked' => 1], '已点赞');
};

$API_MOMENT['comment'] = function ($me) {
    if (!rate_limit('comment:' . (int)$me['id'], 20, 60)) fail('评论过于频繁，请稍后再试');
    $id = inp_int('id');
    $content = trim((string)inp('content', ''));
    $replyUid = inp_int('reply_uid');
    if ($content === '') fail('评论不能为空');
    if (mb_strlen($content) > 500) fail('评论最多 500 字');
    $m = one('SELECT * FROM moment WHERE id=? AND deleted=0', [$id]);
    if (!$m) fail('动态不存在');
    q('INSERT INTO moment_comments (mid,uid,reply_uid,content,created_at,deleted) VALUES (?,?,?,?,?,0)', [
        $id, (int)$me['id'], $replyUid, $content, now(),
    ]);
    ok(['id' => last_id()], '评论成功');
};

$API_MOMENT['delete_comment'] = function ($me) {
    $id = inp_int('id');
    $c = one('SELECT * FROM moment_comments WHERE id=?', [$id]);
    if (!$c) fail('评论不存在');
    $m = one('SELECT * FROM moment WHERE id=?', [(int)$c['mid']]);
    if ((int)$c['uid'] !== (int)$me['id'] && (!$m || (int)$m['uid'] !== (int)$me['id'])) fail('无权限');
    q('UPDATE moment_comments SET deleted=1 WHERE id=?', [$id]);
    ok(null, '已删除');
};

/** 把动态转发成聊天卡片 / 转发到我的动态 */
$API_MOMENT['repost'] = function ($me) {
    $id = inp_int('id');
    $to = inp_int('to');
    $m = one('SELECT * FROM moment WHERE id=? AND deleted=0', [$id]);
    if (!$m) fail('动态不存在');
    $author = one('SELECT nickname,avatar FROM users WHERE id=?', [(int)$m['uid']]);
    $content = json_encode([
        'mid' => $id, 'uid' => (int)$m['uid'], 'name' => $author['nickname'] ?? '',
        'avatar' => $author['avatar'] ?? '', 'text' => mb_substr((string)$m['content'], 0, 120),
        'images' => json_decode_arr($m['images'] ?? ''),
    ], JSON_UNESCAPED_UNICODE);
    if ($to > 0) {
        $mm = push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $to, 'gid' => 0, 'type' => 16, 'content' => $content]);
        ok(msg_row($mm, $me), '已转发');
    }
    q('INSERT INTO moment (uid,content,images,video,visibility,created_at,deleted) VALUES (?,?,?,?,0,?,0)', [
        (int)$me['id'], '转发动态：' . mb_substr((string)$m['content'], 0, 200), $m['images'], $m['video'], now(),
    ]);
    ok(['id' => last_id()], '已转发到我的动态');
};

$API_MOMENT['moment_unread_info'] = function ($me) {
    $uid = (int)$me['id'];
    $last = (int)val('SELECT last_read_at FROM moment_reads WHERE uid=?', [$uid]);
    $likes = (int)val('SELECT COUNT(*) FROM moment_likes l JOIN moment m ON m.id=l.mid WHERE m.uid=? AND l.uid<>? AND l.created_at>?', [$uid, $uid, $last]);
    $comments = (int)val('SELECT COUNT(*) FROM moment_comments c JOIN moment m ON m.id=c.mid WHERE m.uid=? AND c.uid<>? AND c.created_at>? AND c.deleted=0', [$uid, $uid, $last]);
    ok(['likes' => $likes, 'comments' => $comments, 'total' => $likes + $comments]);
};

$API_MOMENT['moment_notify_unread'] = function ($me) {
    $uid = (int)$me['id'];
    $last = (int)val('SELECT last_read_at FROM moment_reads WHERE uid=?', [$uid]);
    $rows = all('SELECT c.*, u.nickname, u.avatar, m.content AS mcontent FROM moment_comments c JOIN users u ON u.id=c.uid JOIN moment m ON m.id=c.mid WHERE m.uid=? AND c.uid<>? AND c.deleted=0 AND c.created_at>? ORDER BY c.id DESC LIMIT 50', [$uid, $uid, $last]);
    ok(['list' => $rows, 'unread' => count($rows)]);
};

$API_MOMENT['moment_mark_read'] = function ($me) {
    $uid = (int)$me['id'];
    if (val('SELECT id FROM moment_reads WHERE uid=?', [$uid])) {
        q('UPDATE moment_reads SET last_read_at=? WHERE uid=?', [now(), $uid]);
    } else {
        q('INSERT INTO moment_reads (uid,last_read_at) VALUES (?,?)', [$uid, now()]);
    }
    ok(null, '已读');
};

$API_MOMENT['upload_cover'] = function ($me) {
    if (!rate_limit('upcover:' . (int)$me['id'], 30, 60)) fail('上传过于频繁，请稍后再试');
    $f = upload_save('file', 'moment', ['jpg', 'jpeg', 'png', 'gif', 'webp'], 20 * 1024 * 1024);
    ok(['url' => $f['url']]);
};
