<?php
/**
 * CC商聊 - 页面布局组件
 */
declare(strict_types=1);

function cc_head(string $title, array $opt = []): void
{
    $site = setting('site_name', 'CC商聊');
    $slogan = (string)setting('site_slogan', '连接每一次商机');
    // SEO：公共页可被收录，应用内页 noindex（登录墙内的私密内容不应被索引）
    $indexable = !empty($opt['index']);
    $desc = (string)($opt['desc'] ?? ($site . ' - ' . $slogan . '。支持私聊、群聊、朋友圈、语音视频通话、直播与移动端安装。'));
    $kw   = (string)($opt['keywords'] ?? ($site . ',即时通讯,聊天软件,群聊,语音通话,视频通话,朋友圈,APP'));
    $cur  = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $cur  = strtok($cur, '?');
    $base = rtrim((string)(setting('site_url', '') ?: (function_exists('site_url') ? site_url('') : '')), '/');
    $canonical = $base . $cur;
    ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#07C160">
<meta name="format-detection" content="telephone=no">
<title><?= e($title) ?> · <?= e($site) ?></title>
<meta name="description" content="<?= e(mb_substr($desc, 0, 150)) ?>">
<meta name="keywords" content="<?= e(mb_substr($kw, 0, 100)) ?>">
<meta name="robots" content="<?= $indexable ? 'index,follow,max-image-preview:large' : 'noindex,nofollow' ?>">
<?php if ($indexable && $base !== ''): ?>
<link rel="canonical" href="<?= e($canonical) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e($site) ?>">
<meta property="og:title" content="<?= e($title . ' · ' . $site) ?>">
<meta property="og:description" content="<?= e(mb_substr($desc, 0, 150)) ?>">
<meta property="og:url" content="<?= e($canonical) ?>">
<meta name="twitter:card" content="summary">
<script type="application/ld+json"><?= json_encode([
  '@context' => 'https://schema.org',
  '@type'    => 'WebSite',
  'name'     => $site,
  'alternateName' => $slogan,
  'url'      => $canonical,
  'inLanguage' => 'zh-CN',
  'potentialAction' => [
      '@type' => 'SearchAction',
      'target' => $base . '/search.php?kw={search_term_string}',
      'query-input' => 'required name=search_term_string',
  ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php endif; ?>
<link rel="manifest" href="manifest.php?v=<?= CC_VERSION ?>">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<link rel="icon" type="image/png" href="icons/icon-192.png">
<link rel="stylesheet" href="assets/app.css?v=<?= CC_VERSION ?>">
<script>window.CC_SVIP_MIN=<?= (int)svip_min_level() ?>;
window.TERMS=<?= json_encode([
  'brand'  => term_brand(),
  'id'     => term_id(),
  'coin'   => term_coin(),
  'pretty' => term_pretty(),
  'member' => term_member(),
], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>window.CC_THEME_BOOT=function(){try{var t=localStorage.getItem('app_theme');if(t==='dark')document.documentElement.classList.add('dark-theme');}catch(e){}};CC_THEME_BOOT();</script>
<?php if (!empty($opt['css'])): ?><style><?= $opt['css'] ?></style><?php endif; ?>
</head>
<body class="<?= e($opt['body_class'] ?? 'app-body') ?>">
<?php
}

function cc_foot(array $scripts = []): void
{
    ?>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<?php if (!empty($scripts)): foreach ($scripts as $s): ?>
<script src="<?= e($s) ?>?v=<?= CC_VERSION ?>"></script>
<?php endforeach; endif; ?>
</body>
</html>
<?php
}

function cc_tabbar(string $active): void
{
    $tabs = [
        'index'    => ['消息', '<path d="M4 5.5h16a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 20 17.5H9l-5 3.5v-3.5H4A1.5 1.5 0 0 1 2.5 16V7A1.5 1.5 0 0 1 4 5.5z"/>'],
        'contacts' => ['通讯录', '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><path d="M16.5 7.5a2.6 2.6 0 0 1 0 5"/><path d="M17.5 19a4.5 4.5 0 0 0-2-3.7"/>'],
        'discover' => ['广场', '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2.2 4.8-4.8 2.2 2.2-4.8z"/>'],
        'me'       => ['我的', '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>'],
    ];
    ?>
<div class="tabbar">
  <?php foreach ($tabs as $key => $t): ?>
  <a class="tab <?= $active === $key ? 'active' : '' ?>" href="<?= $key === 'index' ? 'index.php' : $key . '.php' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><?= $t[1] ?></svg>
    <span><?= $t[0] ?></span>
    <?php if ($key === 'index'): ?><span class="dot hidden" data-badge="chat"></span><?php endif; ?>
    <?php if ($key === 'contacts'): ?><span class="dot hidden" data-badge="notice"></span><?php endif; ?>
  </a>
  <?php endforeach; ?>
</div>
<?php
}

/** 顶部导航：$right 为 HTML */
function cc_topbar(string $title, string $back = '', string $right = '', bool $solid = false): void
{
    ?>
<div class="topbar <?= $solid ? 'solid' : '' ?>">
  <?php if ($back !== ''): ?>
  <button class="tb-back" onclick="location.href='<?= e($back) ?>'">
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
  </button>
  <?php else: ?>
  <span style="width:34px"></span>
  <?php endif; ?>
  <div class="tb-title"><?= e($title) ?></div>
  <div class="tb-right"><?= $right ?></div>
</div>
<?php
}

function cc_me_json(array $me): string
{
    return json_encode(user_public($me, true) + [
        'coin' => (int)$me['coin'],
        'settings' => json_decode_arr($me['settings'] ?? ''),
        'invite_code' => $me['invite_code'],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
       | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}
