<?php
/**
 * CC商聊 - 数据库结构（SQLite / MySQL 双兼容）
 */
declare(strict_types=1);

function cc_schema_tables(): array
{
    $pk = is_mysql() ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $suffix = is_mysql() ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $t = [];

    $t['settings'] = "CREATE TABLE IF NOT EXISTS settings (k VARCHAR(64) NOT NULL PRIMARY KEY, v TEXT)";
    $t['admins'] = "CREATE TABLE IF NOT EXISTS admins (
        id $pk,
        username VARCHAR(64) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'ops',
        status INT NOT NULL DEFAULT 0,
        last_login_at INT NOT NULL DEFAULT 0,
        last_ip VARCHAR(64) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['users'] = "CREATE TABLE IF NOT EXISTS users (
        id $pk,
        account VARCHAR(32) NOT NULL UNIQUE,
        yx_id VARCHAR(32) NOT NULL DEFAULT '',
        pretty_yxid VARCHAR(32) NOT NULL DEFAULT '',
        nickname VARCHAR(64) NOT NULL DEFAULT '',
        avatar VARCHAR(255) NOT NULL DEFAULT '',
        bio VARCHAR(255) NOT NULL DEFAULT '',
        gender INT NOT NULL DEFAULT 0,
        region VARCHAR(64) NOT NULL DEFAULT '',
        email VARCHAR(128) NOT NULL DEFAULT '',
        phone VARCHAR(32) NOT NULL DEFAULT '',
        password VARCHAR(255) NOT NULL,
        pay_password VARCHAR(255) NOT NULL DEFAULT '',
        coin INT NOT NULL DEFAULT 0,
        total_income INT NOT NULL DEFAULT 0,
        total_expense INT NOT NULL DEFAULT 0,
        vip_level INT NOT NULL DEFAULT 0,
        vip_expire_at INT NOT NULL DEFAULT 0,
        is_developer INT NOT NULL DEFAULT 0,
        status INT NOT NULL DEFAULT 0,
        ban_reason VARCHAR(255) NOT NULL DEFAULT '',
        ban_until INT NOT NULL DEFAULT 0,
        ban_forever INT NOT NULL DEFAULT 0,
        invite_code VARCHAR(16) NOT NULL DEFAULT '',
        invited_by INT NOT NULL DEFAULT 0,
        device_id VARCHAR(64) NOT NULL DEFAULT '',
        online INT NOT NULL DEFAULT 0,
        settings TEXT,
        created_at INT NOT NULL DEFAULT 0,
        last_active_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['devices'] = "CREATE TABLE IF NOT EXISTS devices (
        id $pk,
        uid INT NOT NULL,
        device_id VARCHAR(64) NOT NULL DEFAULT '',
        token VARCHAR(128) NOT NULL DEFAULT '',
        ua VARCHAR(255) NOT NULL DEFAULT '',
        ip VARCHAR(64) NOT NULL DEFAULT '',
        last_active_at INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['login_logs'] = "CREATE TABLE IF NOT EXISTS login_logs (
        id $pk, uid INT NOT NULL, ip VARCHAR(64) NOT NULL DEFAULT '', ua VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['friends'] = "CREATE TABLE IF NOT EXISTS friends (
        id $pk,
        uid INT NOT NULL,
        fid INT NOT NULL,
        remark VARCHAR(64) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 1,
        created_at INT NOT NULL DEFAULT 0,
        UNIQUE (uid, fid)
    )$suffix";
    $t['friend_requests'] = "CREATE TABLE IF NOT EXISTS friend_requests (
        id $pk,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL,
        reason VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        handled_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['groups'] = "CREATE TABLE IF NOT EXISTS groups (
        id $pk,
        gid INT NOT NULL UNIQUE,
        name VARCHAR(64) NOT NULL DEFAULT '',
        avatar VARCHAR(255) NOT NULL DEFAULT '',
        intro VARCHAR(512) NOT NULL DEFAULT '',
        owner_uid INT NOT NULL DEFAULT 0,
        member_limit INT NOT NULL DEFAULT 100,
        join_mode INT NOT NULL DEFAULT 0,
        is_public INT NOT NULL DEFAULT 1,
        mute_all INT NOT NULL DEFAULT 0,
        status INT NOT NULL DEFAULT 1,
        created_at INT NOT NULL DEFAULT 0,
        pretty_gid INT NOT NULL DEFAULT 0,
        hide_member_info INT NOT NULL DEFAULT 0,
        pinned_msg_id INT NOT NULL DEFAULT 0,
        pinned_at INT NOT NULL DEFAULT 0,
        pinned_by INT NOT NULL DEFAULT 0
    )$suffix";
    $t['group_members'] = "CREATE TABLE IF NOT EXISTS group_members (
        id $pk,
        gid INT NOT NULL,
        uid INT NOT NULL,
        role INT NOT NULL DEFAULT 0,
        nickname VARCHAR(64) NOT NULL DEFAULT '',
        mute_until INT NOT NULL DEFAULT 0,
        joined_at INT NOT NULL DEFAULT 0,
        last_read_id INT NOT NULL DEFAULT 0,
        pinned INT NOT NULL DEFAULT 0,
        UNIQUE (gid, uid)
    )$suffix";
    $t['group_join_requests'] = "CREATE TABLE IF NOT EXISTS group_join_requests (
        id $pk,
        gid INT NOT NULL,
        uid INT NOT NULL,
        reason VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['group_notices'] = "CREATE TABLE IF NOT EXISTS group_notices (
        id $pk, gid INT NOT NULL, uid INT NOT NULL, content TEXT, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['conversations'] = "CREATE TABLE IF NOT EXISTS conversations (
        id $pk,
        uid INT NOT NULL,
        ctype INT NOT NULL DEFAULT 1,
        peer_id INT NOT NULL,
        last_msg VARCHAR(255) NOT NULL DEFAULT '',
        last_time INT NOT NULL DEFAULT 0,
        unread INT NOT NULL DEFAULT 0,
        pinned INT NOT NULL DEFAULT 0,
        muted INT NOT NULL DEFAULT 0,
        visible INT NOT NULL DEFAULT 1,
        last_read_id INT NOT NULL DEFAULT 0,
        UNIQUE (uid, ctype, peer_id)
    )$suffix";
    $t['messages'] = "CREATE TABLE IF NOT EXISTS messages (
        id $pk,
        ctype INT NOT NULL DEFAULT 1,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        type INT NOT NULL DEFAULT 1,
        content TEXT,
        extra TEXT,
        created_at INT NOT NULL DEFAULT 0,
        recalled INT NOT NULL DEFAULT 0,
        deleted INT NOT NULL DEFAULT 0
    )$suffix";
    $t['moment'] = "CREATE TABLE IF NOT EXISTS moment (
        id $pk,
        uid INT NOT NULL,
        content TEXT,
        images TEXT,
        video VARCHAR(255) NOT NULL DEFAULT '',
        visibility INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        deleted INT NOT NULL DEFAULT 0
    )$suffix";
    $t['moment_likes'] = "CREATE TABLE IF NOT EXISTS moment_likes (
        id $pk, mid INT NOT NULL, uid INT NOT NULL, created_at INT NOT NULL DEFAULT 0, UNIQUE (mid, uid)
    )$suffix";
    $t['moment_comments'] = "CREATE TABLE IF NOT EXISTS moment_comments (
        id $pk, mid INT NOT NULL, uid INT NOT NULL, reply_uid INT NOT NULL DEFAULT 0, content VARCHAR(1000) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0, deleted INT NOT NULL DEFAULT 0
    )$suffix";
    $t['moment_reads'] = "CREATE TABLE IF NOT EXISTS moment_reads (
        id $pk, uid INT NOT NULL UNIQUE, last_read_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['notices'] = "CREATE TABLE IF NOT EXISTS notices (
        id $pk, title VARCHAR(128) NOT NULL DEFAULT '', content TEXT, is_top INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 1, created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['notice_reads'] = "CREATE TABLE IF NOT EXISTS notice_reads (
        id $pk, nid INT NOT NULL, uid INT NOT NULL, read_at INT NOT NULL DEFAULT 0, UNIQUE (nid, uid)
    )$suffix";
    $t['wallet_logs'] = "CREATE TABLE IF NOT EXISTS wallet_logs (
        id $pk, uid INT NOT NULL, direction INT NOT NULL DEFAULT 1, amount INT NOT NULL DEFAULT 0, balance_after INT NOT NULL DEFAULT 0,
        biz VARCHAR(32) NOT NULL DEFAULT '', biz_id INT NOT NULL DEFAULT 0, remark VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['recharge_orders'] = "CREATE TABLE IF NOT EXISTS recharge_orders (
        id $pk,
        order_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        coin INT NOT NULL DEFAULT 0,
        rate INT NOT NULL DEFAULT 7,
        amount_usdt VARCHAR(32) NOT NULL DEFAULT '0',
        address VARCHAR(128) NOT NULL DEFAULT '',
        network VARCHAR(16) NOT NULL DEFAULT 'TRC20',
        status INT NOT NULL DEFAULT 0,
        txid VARCHAR(128) NOT NULL DEFAULT '',
        pay_tx VARCHAR(128) NOT NULL DEFAULT '',
        remark VARCHAR(255) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0,
        paid_at INT NOT NULL DEFAULT 0,
        admin_id INT NOT NULL DEFAULT 0
    )$suffix";
    $t['withdraw_orders'] = "CREATE TABLE IF NOT EXISTS withdraw_orders (
        id $pk,
        order_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        amount INT NOT NULL DEFAULT 0,
        account VARCHAR(128) NOT NULL DEFAULT '',
        qr VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        remark VARCHAR(255) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0,
        handled_at INT NOT NULL DEFAULT 0,
        admin_id INT NOT NULL DEFAULT 0
    )$suffix";
    $t['red_packets'] = "CREATE TABLE IF NOT EXISTS red_packets (
        id $pk,
        packet_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        ctype INT NOT NULL DEFAULT 1,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        rp_type INT NOT NULL DEFAULT 1,
        total INT NOT NULL DEFAULT 0,
        count INT NOT NULL DEFAULT 0,
        remaining INT NOT NULL DEFAULT 0,
        remain_count INT NOT NULL DEFAULT 0,
        blessing VARCHAR(128) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        expire_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['red_packet_records'] = "CREATE TABLE IF NOT EXISTS red_packet_records (
        id $pk, pid INT NOT NULL, uid INT NOT NULL, coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, UNIQUE (pid, uid)
    )$suffix";
    $t['transfers'] = "CREATE TABLE IF NOT EXISTS transfers (
        id $pk, from_uid INT NOT NULL, to_uid INT NOT NULL, coin INT NOT NULL DEFAULT 0, note VARCHAR(128) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['gifts'] = "CREATE TABLE IF NOT EXISTS gifts (
        id $pk, name VARCHAR(64) NOT NULL DEFAULT '', icon VARCHAR(255) NOT NULL DEFAULT '', price INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 1, sort INT NOT NULL DEFAULT 0
    )$suffix";
    $t['gift_records'] = "CREATE TABLE IF NOT EXISTS gift_records (
        id $pk, from_uid INT NOT NULL, to_uid INT NOT NULL DEFAULT 0, gid INT NOT NULL DEFAULT 0, gift_id INT NOT NULL, count INT NOT NULL DEFAULT 1, coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['vip_plans'] = "CREATE TABLE IF NOT EXISTS vip_plans (
        id $pk, name VARCHAR(64) NOT NULL DEFAULT '', days INT NOT NULL DEFAULT 30, price INT NOT NULL DEFAULT 0, level INT NOT NULL DEFAULT 1, status INT NOT NULL DEFAULT 1, sort INT NOT NULL DEFAULT 0
    )$suffix";
    $t['pretty_ids'] = "CREATE TABLE IF NOT EXISTS pretty_ids (
        id $pk, yx_id VARCHAR(32) NOT NULL UNIQUE, price INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 0,
        buyer_uid INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, sold_at INT NOT NULL DEFAULT 0,
        ptype VARCHAR(16) NOT NULL DEFAULT 'user',
        buyer_gid INT NOT NULL DEFAULT 0
    )$suffix";
    $t['emojis'] = "CREATE TABLE IF NOT EXISTS emojis (
        id $pk, uid INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', url VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['favorites'] = "CREATE TABLE IF NOT EXISTS favorites (
        id $pk, uid INT NOT NULL, mtype INT NOT NULL DEFAULT 1, content TEXT, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['calls'] = "CREATE TABLE IF NOT EXISTS calls (
        id $pk,
        call_id VARCHAR(48) NOT NULL UNIQUE,
        ctype INT NOT NULL DEFAULT 1,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        media INT NOT NULL DEFAULT 1,
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        answered_at INT NOT NULL DEFAULT 0,
        ended_at INT NOT NULL DEFAULT 0,
        duration INT NOT NULL DEFAULT 0
    )$suffix";
    $t['call_signals'] = "CREATE TABLE IF NOT EXISTS call_signals (
        id $pk, call_id VARCHAR(48) NOT NULL, from_uid INT NOT NULL, to_uid INT NOT NULL DEFAULT 0,
        kind VARCHAR(16) NOT NULL DEFAULT '', payload TEXT, created_at INT NOT NULL DEFAULT 0, consumed INT NOT NULL DEFAULT 0
    )$suffix";
    $t['live_rooms'] = "CREATE TABLE IF NOT EXISTS live_rooms (
        id $pk,
        room_no VARCHAR(32) NOT NULL UNIQUE,
        uid INT NOT NULL,
        gid INT NOT NULL DEFAULT 0,
        title VARCHAR(128) NOT NULL DEFAULT '',
        cover VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        viewers INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        ended_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['live_messages'] = "CREATE TABLE IF NOT EXISTS live_messages (
        id $pk, room_id INT NOT NULL, uid INT NOT NULL, content VARCHAR(500) NOT NULL DEFAULT '', type INT NOT NULL DEFAULT 1, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['reports'] = "CREATE TABLE IF NOT EXISTS reports (
        id $pk, from_uid INT NOT NULL, target_type VARCHAR(20) NOT NULL DEFAULT '', target_id INT NOT NULL DEFAULT 0,
        reason VARCHAR(128) NOT NULL DEFAULT '', detail VARCHAR(500) NOT NULL DEFAULT '', status INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['appeals'] = "CREATE TABLE IF NOT EXISTS appeals (
        id $pk, uid INT NOT NULL DEFAULT 0, account VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(500) NOT NULL DEFAULT '',
        contact VARCHAR(128) NOT NULL DEFAULT '', status INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, handled_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['admin_logs'] = "CREATE TABLE IF NOT EXISTS admin_logs (
        id $pk, admin_id INT NOT NULL DEFAULT 0, action VARCHAR(64) NOT NULL DEFAULT '', detail VARCHAR(500) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['verify_codes'] = "CREATE TABLE IF NOT EXISTS verify_codes (
        id $pk, target VARCHAR(128) NOT NULL DEFAULT '', code VARCHAR(16) NOT NULL DEFAULT '', purpose VARCHAR(32) NOT NULL DEFAULT '',
        expire_at INT NOT NULL DEFAULT 0, used INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    $t['invites'] = "CREATE TABLE IF NOT EXISTS invites (
        id $pk, uid INT NOT NULL, invitee_uid INT NOT NULL DEFAULT 0, reward_coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    )$suffix";
    // 群消息置顶（多条）：同一群可置顶多条消息
    $uniqPin = is_mysql() ? 'UNIQUE KEY uniq_pin (gid, msg_id)' : 'UNIQUE (gid, msg_id)';
    $t['group_pins'] = "CREATE TABLE IF NOT EXISTS group_pins (
        id $pk,
        gid INT NOT NULL,
        msg_id INT NOT NULL,
        uid INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        $uniqPin
    )$suffix";

    // 群封禁：被群主/管理员封禁的成员无法再次加入该群
    $uniqGBan = is_mysql() ? 'UNIQUE KEY uniq_gban (gid, uid)' : 'UNIQUE (gid, uid)';
    $t['group_bans'] = "CREATE TABLE IF NOT EXISTS group_bans (
        id $pk,
        gid INT NOT NULL,
        uid INT NOT NULL,
        operator_uid INT NOT NULL DEFAULT 0,
        reason VARCHAR(200) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0,
        $uniqGBan
    )$suffix";

    // 黑名单：uid 拉黑 target_uid 后，对方无法发消息 / 看动态 / 加好友
    $uniqBlock = is_mysql() ? 'UNIQUE KEY uniq_block (uid, target_uid)' : 'UNIQUE (uid, target_uid)';
    $t['blocks'] = "CREATE TABLE IF NOT EXISTS blocks (
        id $pk,
        uid INT NOT NULL,
        target_uid INT NOT NULL,
        created_at INT NOT NULL DEFAULT 0,
        $uniqBlock
    )$suffix";

    // 邀请阶梯奖励规则（达到邀请人数即可领取）
    $t['invite_rewards'] = "CREATE TABLE IF NOT EXISTS invite_rewards (
        id $pk,
        name VARCHAR(64) NOT NULL DEFAULT '',
        icon VARCHAR(16) NOT NULL DEFAULT '🎁',
        type VARCHAR(16) NOT NULL DEFAULT 'vip',
        level INT NOT NULL DEFAULT 1,
        days INT NOT NULL DEFAULT 30,
        coin INT NOT NULL DEFAULT 0,
        need_count INT NOT NULL DEFAULT 10,
        sort INT NOT NULL DEFAULT 0,
        status INT NOT NULL DEFAULT 1
    )$suffix";
    // 领取记录：同一用户同一奖励只能领一次
    $uniqClaim = is_mysql() ? 'UNIQUE KEY uniq_uid_reward (uid, reward_id)' : 'UNIQUE (uid, reward_id)';
    $t['invite_claims'] = "CREATE TABLE IF NOT EXISTS invite_claims (
        id $pk,
        uid INT NOT NULL,
        reward_id INT NOT NULL,
        created_at INT NOT NULL DEFAULT 0,
        $uniqClaim
    )$suffix";

    return $t;
}

function cc_schema_indexes(): array
{
    return [
        'CREATE INDEX IF NOT EXISTS idx_msg_private ON messages (ctype, from_uid, to_uid, id)',
        'CREATE INDEX IF NOT EXISTS idx_msg_group ON messages (gid, id)',
        'CREATE INDEX IF NOT EXISTS idx_msg_created ON messages (created_at)',
        'CREATE INDEX IF NOT EXISTS idx_conv_uid ON conversations (uid, last_time)',
        'CREATE INDEX IF NOT EXISTS idx_gm_uid ON group_members (uid)',
        'CREATE INDEX IF NOT EXISTS idx_wallet_uid ON wallet_logs (uid, id)',
        'CREATE INDEX IF NOT EXISTS idx_moment_uid ON moment (uid, id)',
        'CREATE INDEX IF NOT EXISTS idx_likes_mid ON moment_likes (mid)',
        'CREATE INDEX IF NOT EXISTS idx_comments_mid ON moment_comments (mid)',
        'CREATE INDEX IF NOT EXISTS idx_call_signals ON call_signals (call_id, to_uid, consumed)',
        'CREATE INDEX IF NOT EXISTS idx_login_uid ON login_logs (uid, id)',
        'CREATE INDEX IF NOT EXISTS idx_recharge_uid ON recharge_orders (uid, id)',
        'CREATE INDEX IF NOT EXISTS idx_withdraw_uid ON withdraw_orders (uid, id)',
    ];
}

/** 轻量列迁移：为老库补齐新增字段（SQLite / MySQL 通用） */
function cc_schema_upgrade(): int
{
    static $done = false;
    if ($done) return 0;
    $done = true;
    $want = [
        'pretty_ids' => [
            'ptype'     => "VARCHAR(16) NOT NULL DEFAULT 'user'",
            'buyer_gid' => "INT NOT NULL DEFAULT 0",
        ],
        'groups' => [
            'pretty_gid' => "INT NOT NULL DEFAULT 0",
            'hide_member_info' => "INT NOT NULL DEFAULT 0",
            'pinned_msg_id' => "INT NOT NULL DEFAULT 0",
            'pinned_at' => "INT NOT NULL DEFAULT 0",
            'pinned_by' => "INT NOT NULL DEFAULT 0",
        ],
    ];
    $n = 0;
    foreach ($want as $table => $cols) {
        try {
            if (is_mysql()) {
                $have = [];
                foreach (all('SHOW COLUMNS FROM ' . $table) as $r) $have[(string)$r['Field']] = 1;
            } else {
                $have = [];
                foreach (all('PRAGMA table_info(' . $table . ')') as $r) $have[(string)$r['name']] = 1;
            }
        } catch (Throwable $e) {
            continue;
        }
        foreach ($cols as $col => $def) {
            if (isset($have[$col])) continue;
            try {
                db()->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $col . ' ' . $def);
                $n++;
            } catch (Throwable $e) {
            }
        }
    }
    return $n;
}

function cc_install_schema(): void
{
    foreach (cc_schema_tables() as $sql) {
        db()->exec($sql);
    }
    cc_schema_upgrade();
    foreach (cc_schema_indexes() as $sql) {
        try {
            db()->exec($sql);
        } catch (Throwable $e) {
        }
    }
}
