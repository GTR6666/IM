<?php
/**
 * CC商聊 - 引导文件：配置、PDO、会话、通用工具、鉴权、账本、消息、上传
 */
declare(strict_types=1);

define('CC_ROOT', dirname(__DIR__));
define('CC_VERSION', '2.7.30');

mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Shanghai');

/* =========================================================
 * 配置
 * ========================================================= */
function cfg(?string $path = null, $default = null)
{
    static $c = null;
    if ($c === null) {
        $c = require CC_ROOT . '/config.php';
        $local = CC_ROOT . '/config.local.php';
        if (is_file($local)) {
            $c = array_replace_recursive($c, require $local);
        }
    }
    if ($path === null) return $c;
    $node = $c;
    foreach (explode('.', $path) as $k) {
        if (!is_array($node) || !array_key_exists($k, $node)) return $default;
        $node = $node[$k];
    }
    return $node;
}

/* =========================================================
 * 数据库
 * ========================================================= */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $db  = cfg('db');
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    if (($db['driver'] ?? 'sqlite') === 'mysql') {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $db['host'], $db['port'], $db['name'], $db['charset']);
        $pdo = new PDO($dsn, $db['user'], $db['pass'], $opt);
    } else {
        $path = $db['sqlite_path'];
        if (!is_dir(dirname($path))) @mkdir(dirname($path), 0775, true);
        $pdo = new PDO('sqlite:' . $path, null, null, $opt);
        $pdo->exec('PRAGMA journal_mode=WAL');
        $pdo->exec('PRAGMA foreign_keys=ON');
        $pdo->exec('PRAGMA busy_timeout=5000');
    }
    return $pdo;
}

function q(string $sql, array $p = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($p);
    return $st;
}
function one(string $sql, array $p = []): ?array
{
    $r = q($sql, $p)->fetch();
    return $r === false ? null : $r;
}
function all(string $sql, array $p = []): array
{
    return q($sql, $p)->fetchAll();
}
function val(string $sql, array $p = [])
{
    $r = q($sql, $p)->fetch(PDO::FETCH_NUM);
    return $r ? $r[0] : null;
}
function ex(string $sql, array $p = []): int
{
    return q($sql, $p)->rowCount();
}
function last_id(): int
{
    return (int)db()->lastInsertId();
}
function is_mysql(): bool
{
    return cfg('db.driver', 'sqlite') === 'mysql';
}

/* =========================================================
 * 会话
 * ========================================================= */
function cc_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $days = (int)cfg('app.session_days', 30);
    session_name('CCSESSID');
    session_set_cookie_params([
        'lifetime' => $days * 86400,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    @session_start();
}

/* =========================================================
 * 设置（settings 表 + 配置回退）
 * ========================================================= */
function &setting_cache_ref(): array
{
    static $cache = [];
    return $cache;
}
function setting(string $key, $default = null)
{
    $cache = &setting_cache_ref();
    if (array_key_exists($key, $cache)) return $cache[$key];
    try {
        $v = val('SELECT v FROM settings WHERE k=?', [$key]);
    } catch (Throwable $e) {
        $v = null;
    }
    $cache[$key] = ($v === null) ? $default : $v;
    return $cache[$key];
}
/** 清空设置缓存（写入设置后必须调用，否则同一请求内读到的仍是旧值） */
function setting_flush(): void
{
    $cache = &setting_cache_ref();
    $cache = [];
}
function set_setting(string $key, $value): void
{
    $value = (string)$value;
    $exists = val('SELECT k FROM settings WHERE k=?', [$key]);
    if ($exists === null) {
        q('INSERT INTO settings (k,v) VALUES (?,?)', [$key, $value]);
    } else {
        q('UPDATE settings SET v=? WHERE k=?', [$value, $key]);
    }
    setting_flush();
}
/**
 * 品牌迁移：把历史数据里残留的旧品牌字样统一改成 CC
 * （AK商聊 → CC商聊、AK号 → CC号、K币 → CC币）
 * 幂等，可重复执行；返回被修改的记录数。
 */
function brand_migrate(): int
{
    $map = [
        'AK商聊'     => 'CC商聊',
        'AK号'       => 'CC号',
        'AK官方群聊' => 'CC官方群聊',
        'K币'        => 'CC币',
    ];
    $apply = static function (?string $s) use ($map): string {
        $s = (string)$s;
        foreach ($map as $from => $to) $s = str_replace($from, $to, $s);
        return $s;
    };
    $count = 0;
    $tables = [
        ['settings', 'k', ['v']],
        ['users', 'id', ['nickname']],
        ['groups', 'gid', ['name', 'intro']],
        ['notices', 'id', ['title', 'content']],
        ['messages', 'id', ['content', 'extra']],
        ['conversations', 'id', ['last_msg']],
        ['moments', 'id', ['content']],
    ];
    foreach ($tables as $t) {
        [$table, $pk, $cols] = $t;
        try {
            $rows = all('SELECT ' . $pk . ' AS _pk,' . implode(',', $cols) . ' FROM ' . $table);
        } catch (Throwable $e) {
            continue;
        }
        foreach ($rows as $r) {
            $set = [];
            $args = [];
            foreach ($cols as $c) {
                $old = (string)($r[$c] ?? '');
                $new = $apply($old);
                if ($new !== $old) {
                    $set[] = $c . '=?';
                    $args[] = $new;
                }
            }
            if (!$set) continue;
            $args[] = $r['_pk'];
            try {
                q('UPDATE ' . $table . ' SET ' . implode(',', $set) . ' WHERE ' . $pk . '=?', $args);
                $count++;
            } catch (Throwable $e) {
            }
        }
    }
    setting_flush();
    return $count;
}
function settings_all(): array
{
    $out = [];
    foreach (all('SELECT k,v FROM settings') as $r) $out[$r['k']] = $r['v'];
    return $out;
}

/* =========================================================
 * 输出
 * ========================================================= */
function jout(int $code, string $msg = '', $data = null): void
{
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
/** 接口提示文案套用称号（api.php 不经过页面输出过滤，这里单独处理） */
function api_term(string $msg): string
{
    $map = $GLOBALS['__cc_term_map'] ?? null;
    if (!is_array($map) || !$map) {
        try { $map = cc_term_map(); } catch (Throwable $e) { $map = []; }
    }
    return $map ? strtr($msg, $map) : $msg;
}
function ok($data = null, string $msg = 'ok'): void
{
    jout(0, api_term($msg), $data);
}
function fail(string $msg = '操作失败', int $code = 1, $data = null): void
{
    jout($code, api_term($msg), $data);
}
function body_json(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return [];
    $j = json_decode($raw, true);
    return is_array($j) ? $j : [];
}
function inp(string $key, $default = null)
{
    if (isset($_POST[$key])) return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
    if (isset($_GET[$key])) return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
    static $json = null;
    if ($json === null) $json = body_json();
    return $json[$key] ?? $default;
}
function inp_int(string $key, int $default = 0): int
{
    return (int)inp($key, $default);
}
function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function now(): int
{
    return time();
}
function client_ip(): string
{
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = explode(',', $_SERVER[$k])[0];
            return trim($ip);
        }
    }
    return '0.0.0.0';
}

/* =========================================================
 * 登录 / 鉴权
 * ========================================================= */
function current_uid(): int
{
    cc_session_start();
    return (int)($_SESSION['uid'] ?? 0);
}

function current_user(bool $fresh = false): ?array
{
    static $cache = null;
    $uid = current_uid();
    if (!$uid) return null;
    if ($cache !== null && !$fresh && (int)$cache['id'] === $uid) return $cache;

    // 记住我 / 设备令牌
    if (!$uid) return null;

    $u = one('SELECT * FROM users WHERE id=?', [$uid]);
    if (!$u) {
        unset($_SESSION['uid']);
        return null;
    }
    if ((int)$u['status'] === 1) {
        $until = (int)$u['ban_until'];
        $forever = (int)$u['ban_forever'] === 1;
        if ($forever || $until === 0 || $until > now()) {
            // 封禁中：保留在会话里，由页面弹出封禁信息后退出
            $cache = $u;
            return $u;
        }
    }
    $cache = $u;
    return $u;
}

function login_user(array $u, bool $remember = true): string
{
    cc_session_start();
    // 防会话固定：登录成功后更换 Session ID
    @session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['login_at'] = now();
    $token = bin2hex(random_bytes(24));
    $did   = $_COOKIE['cc_did'] ?? '';
    if (!$did || !preg_match('/^[a-f0-9]{16,64}$/', $did)) {
        $did = bin2hex(random_bytes(16));
    }
    setcookie('cc_did', $did, [
        'expires'  => time() + 86400 * 3650,
        'path'     => '/',
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '未知设备', 0, 255);
    $ip = client_ip();
    $dev = one('SELECT id FROM devices WHERE uid=? AND device_id=?', [(int)$u['id'], $did]);
    if ($dev) {
        q('UPDATE devices SET token=?, ua=?, ip=?, last_active_at=? WHERE id=?', [$token, $ua, $ip, now(), (int)$dev['id']]);
    } else {
        q('INSERT INTO devices (uid,device_id,token,ua,ip,last_active_at,created_at) VALUES (?,?,?,?,?,?,?)', [(int)$u['id'], $did, $token, $ua, $ip, now(), now()]);
    }
    if ($remember) {
        setcookie('cc_token', $token, [
            'expires'  => time() + 86400 * (int)cfg('app.session_days', 30),
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    q('UPDATE users SET last_active_at=?, online=1, device_id=? WHERE id=?', [now(), $did, (int)$u['id']]);
    log_adminless_login((int)$u['id']);
    return $token;   // 供「切换账号」保存（等同免密登录凭据，仅返回给本人）
}

function log_adminless_login(int $uid): void
{
    // 登录日志，供后台"登录日志/用户活跃"使用
    try {
        q('INSERT INTO login_logs (uid,ip,ua,created_at) VALUES (?,?,?,?)', [
            $uid, client_ip(), substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255), now(),
        ]);
    } catch (Throwable $e) {
    }
}

/** 自动登录：通过 cc_token 找回账号（当 session 丢失时） */
function try_token_login(): void
{
    if (current_uid()) return;
    $token = $_COOKIE['cc_token'] ?? '';
    if (!$token || !preg_match('/^[a-f0-9]{48}$/', $token)) return;
    $d = one('SELECT * FROM devices WHERE token=?', [$token]);
    if (!$d) return;
    $u = one('SELECT * FROM users WHERE id=?', [(int)$d['uid']]);
    if (!$u) return;
    cc_session_start();
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['login_at'] = now();
    q('UPDATE users SET last_active_at=?, online=1 WHERE id=?', [now(), (int)$u['id']]);
}

function require_user_page(): array
{
    if (!current_uid()) try_token_login();
    $u = current_user();
    if (!$u) {
        header('Location: login.php');
        exit;
    }
    if ((int)$u['status'] === 1 && ((int)$u['ban_forever'] === 1 || (int)$u['ban_until'] === 0 || (int)$u['ban_until'] > now())) {
        // 只允许访问申诉入口
        $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        if ($script !== 'login.php' && $script !== 'logout.php') {
            header('Location: login.php?banned=1');
            exit;
        }
    }
    return $u;
}

function require_user_api(): array
{
    if (!current_uid()) try_token_login();
    $u = current_user();
    if (!$u) fail('未登录', 401);
    if ((int)$u['status'] === 1 && ((int)$u['ban_forever'] === 1 || (int)$u['ban_until'] === 0 || (int)$u['ban_until'] > now())) {
        fail('账号已被封禁', 403, ['ban_reason' => $u['ban_reason'], 'ban_until' => $u['ban_until'], 'ban_forever' => $u['ban_forever']]);
    }
    return $u;
}

function logout_user(): void
{
    cc_session_start();
    $uid = current_uid();
    if ($uid) {
        q('UPDATE users SET online=0 WHERE id=?', [$uid]);
        $token = $_COOKIE['cc_token'] ?? '';
        if ($token) q('DELETE FROM devices WHERE token=?', [$token]);
    }
    setcookie('cc_token', '', ['expires' => time() - 3600, 'path' => '/']);
    $_SESSION = [];
    @session_destroy();
}

/* =========================================================
 * 用户序列化
 * ========================================================= */
function is_vip(array $u): bool
{
    return (int)($u['vip_level'] ?? 0) > 0 && (int)($u['vip_expire_at'] ?? 0) > now();
}

/**
 * SVIP 起始等级（后台可配置，默认 4）：等级 >= 该值即视为 SVIP
 */
function svip_min_level(): int
{
    $lv = (int)setting('svip_min_level', '4');
    if ($lv < 2) $lv = 2;
    if ($lv > 20) $lv = 20;
    return $lv;
}
/** 会员层级：SVIP / VIP */
function vip_tier(int $level): string
{
    if ($level <= 0) return '';
    return $level >= svip_min_level() ? 'SVIP' : 'VIP';
}
/** 会员标识文案：VIP1 / VIP2 / SVIP / SVIP2 … */
function vip_label(int $level): string
{
    if ($level <= 0) return '';
    $min = svip_min_level();
    if ($level < $min) return 'VIP' . $level;
    $step = $level - $min + 1;
    return $step <= 1 ? 'SVIP' : 'SVIP' . $step;
}
/** 会员标识样式类：svip / gold */
function vip_badge_cls(int $level): string
{
    return vip_tier($level) === 'SVIP' ? 'svip' : 'gold';
}
/**
 * 号码展示：靓号时输出「靓 + 号码」渐变胶囊，普通号码输出纯文本
 * @param string $number  实际展示的号码（靓号优先）
 * @param string $pretty  用户的 pretty_yxid / 群的 pretty_gid，空表示非靓号
 */
function pretty_number_html(string $number, string $pretty = ''): string
{
    $number = trim($number);
    $pretty = trim($pretty);
    if ($pretty === '') return e($number);
    return '<span class="num-pretty"><i>靓</i><b>' . e($pretty) . '</b></span>';
}
/** 号码前的标签：靓号显示「靓号：」，否则「CC号：」 */
function pretty_number_label(string $pretty = '', string $plain = 'CC号', string $prettyLabel = '靓号'): string
{
    return trim($pretty) !== '' ? $prettyLabel : $plain;
}

/** 靓号标识 HTML：传 pretty_yxid（空则返回空串） */
function pretty_badge(?string $prettyYxid, string $title = '靓号'): string
{
    $p = trim((string)$prettyYxid);
    if ($p === '') return '';
    return '<span class="tag-pretty" title="' . e($title) . '">靓 ' . e($p) . '</span>';
}
/** 群靓号标识 */
function group_pretty_badge(int $prettyGid): string
{
    if ($prettyGid <= 0) return '';
    return '<span class="tag-pretty" title="群靓号">靓 ' . $prettyGid . '</span>';
}
/** 会员标识 HTML（不可用时返回空串） */
function vip_badge(int $level): string
{
    if ($level <= 0) return '';
    return '<span class="badge ' . vip_badge_cls($level) . '">' . e(vip_label($level)) . '</span>';
}

function user_public(?array $u, bool $full = false): array
{
    if (!$u) return ['id' => 0, 'nickname' => '未知用户', 'avatar' => '', 'yx_id' => ''];
    $vip = is_vip($u);
    $out = [
        'id'          => (int)$u['id'],
        'account'     => $u['account'] ?? '',
        'yx_id'       => $u['yx_id'] ?: ($u['account'] ?? ''),
        'nickname'    => $u['nickname'] ?: ('用户' . substr((string)$u['account'], -4)),
        'avatar'      => $u['avatar'] ?: '',
        'bio'         => $u['bio'] ?? '',
        'gender'      => (int)($u['gender'] ?? 0),
        'region'      => $u['region'] ?? '',
        'vip_level'   => $vip ? (int)$u['vip_level'] : 0,
        'vip_expire_at' => (int)($u['vip_expire_at'] ?? 0),
        'is_vip'      => $vip ? 1 : 0,
        'online'      => (int)($u['online'] ?? 0),
        'is_developer'=> (int)($u['is_developer'] ?? 0),
        'pretty'      => (string)($u['pretty_yxid'] ?? ''),
        'show_yxid'   => (string)(($u['pretty_yxid'] ?? '') ?: (($u['yx_id'] ?? '') ?: ($u['account'] ?? ''))),
    ];
    if ($full) {
        $out += [
            'email'       => $u['email'] ?? '',
            'phone'       => $u['phone'] ?? '',
            'coin'        => (int)($u['coin'] ?? 0),
            'has_pay_pwd' => !empty($u['pay_password']) ? 1 : 0,
            'created_at'  => (int)($u['created_at'] ?? 0),
            'pretty_yxid' => $u['pretty_yxid'] ?? '',
            'show_yxid'   => $u['pretty_yxid'] ?: ($u['yx_id'] ?: ($u['account'] ?? '')),
            'is_pretty'   => !empty($u['pretty_yxid']) ? 1 : 0,
        ];
    }
    return $out;
}

function display_name(array $u): string
{
    return $u['nickname'] ?: ('用户' . ($u['yx_id'] ?: $u['account']));
}

/** 官方客服用户 ID（settings.service_uid 存的是 CC号） */
function service_uid(): int
{
    static $id = null;
    if ($id !== null) return $id;
    $acc = (string)setting('service_uid', '10086');
    $id = (int)val('SELECT id FROM users WHERE account=? OR id=?', [$acc, (int)$acc]);
    return $id;
}

/* =========================================================
 * 账本（CC币）—— 所有加减币必须走这里，保证原子性
 * ========================================================= */
function add_coin(int $uid, int $amount, string $biz, int $bizId = 0, string $remark = ''): int
{
    // amount > 0 收入，< 0 支出；返回最新余额；余额不足抛异常
    $pdo = db();
    $pdo->beginTransaction();
    try {
        // 原子扣加：并发下不会覆盖余额，也不会扣成负数
        $aff = q('UPDATE users SET coin=coin+? WHERE id=? AND coin+?>=0', [$amount, $uid, $amount])->rowCount();
        if (!$aff) throw new RuntimeException('CC币余额不足');
        $new = (int)val('SELECT coin FROM users WHERE id=?', [$uid]);
        $dir = $amount >= 0 ? 1 : 2;
        q('INSERT INTO wallet_logs (uid,direction,amount,balance_after,biz,biz_id,remark,created_at) VALUES (?,?,?,?,?,?,?,?)', [
            $uid, $dir, abs($amount), $new, $biz, $bizId, $remark, now(),
        ]);
        if ($amount > 0) q('UPDATE users SET total_income=total_income+? WHERE id=?', [$amount, $uid]);
        else q('UPDATE users SET total_expense=total_expense+? WHERE id=?', [abs($amount), $uid]);
        $pdo->commit();
        return $new;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/* =========================================================
 * 会话 / 消息
 * ========================================================= */
function conv_touch(int $uid, int $ctype, int $peer, string $lastMsg, int $time = 0, int $incr = 0): void
{
    $time = $time ?: now();
    $row = one('SELECT id FROM conversations WHERE uid=? AND ctype=? AND peer_id=?', [$uid, $ctype, $peer]);
    if ($row) {
        if ($incr) {
            q('UPDATE conversations SET last_msg=?, last_time=?, unread=unread+?, visible=1 WHERE id=?', [$lastMsg, $time, $incr, (int)$row['id']]);
        } else {
            q('UPDATE conversations SET last_msg=?, last_time=?, visible=1 WHERE id=?', [$lastMsg, $time, (int)$row['id']]);
        }
    } else {
        q('INSERT INTO conversations (uid,ctype,peer_id,last_msg,last_time,unread,pinned,muted,visible) VALUES (?,?,?,?,?,?,0,0,1)', [
            $uid, $ctype, $peer, $lastMsg, $time, $incr,
        ]);
    }
}

function conv_clear_unread(int $uid, int $ctype, int $peer): void
{
    q('UPDATE conversations SET unread=0 WHERE uid=? AND ctype=? AND peer_id=?', [$uid, $ctype, $peer]);
}

/** 摘要文本：用于会话列表 */
function msg_digest(int $type, string $content): string
{
    switch ($type) {
        case 5:  return '[图片]';
        case 6:  return '[语音]';
        case 7: case 21: return '[红包]';
        case 8: case 22: return '[转账]';
        case 9: case 23: return '[礼物]';
        case 12: return '[名片]';
        case 13: return '[群名片]';
        case 14: return '[通话]';
        case 15: return '[视频]';
        case 16: return '[动态]';
        case 17: return '[聊天记录]';
        case 18: return '[文件]';
        case 19: return '[直播]';
        case 30: {
            $j = json_decode_arr($content);
            $t = trim((string)($j['text'] ?? ''));
            $n = is_array($j['images'] ?? null) ? count($j['images']) : 0;
            if ($t !== '') return ($n > 0 ? '[图文] ' : '') . mb_substr($t, 0, 50);
            return $n > 0 ? '[图片]' : '[图文]';
        }
        case 11: return $content;
        default:
            $c = trim(strip_tags($content));
            $c = preg_replace('/\s+/u', ' ', $c);
            return mb_substr($c, 0, 60);
    }
}

/**
 * 写入一条消息并更新双方会话。
 * $m: ctype, from_uid, to_uid|gid, type, content, extra(array)
 */
function push_message(array $m): array
{
    $ctype = (int)$m['ctype'];
    $from  = (int)$m['from_uid'];
    $to    = (int)($m['to_uid'] ?? 0);
    $gid   = (int)($m['gid'] ?? 0);
    $type  = (int)($m['type'] ?? 1);
    $content = (string)($m['content'] ?? '');
    $extra = isset($m['extra']) && is_array($m['extra']) ? json_encode($m['extra'], JSON_UNESCAPED_UNICODE) : (string)($m['extra'] ?? '');
    $t = now();

    q('INSERT INTO messages (ctype,from_uid,to_uid,gid,type,content,extra,created_at,recalled,deleted) VALUES (?,?,?,?,?,?,?,?,0,0)', [
        $ctype, $from, $to, $gid, $type, $content, $extra, $t,
    ]);
    $mid = last_id();

    $digest = msg_digest($type, $content);
    if ($ctype === 1) {
        conv_touch($from, 1, $to, $digest, $t, 0);
        conv_touch($to, 1, $from, $digest, $t, 1);
    } else {
        $members = all('SELECT uid FROM group_members WHERE gid=?', [$gid]);
        foreach ($members as $mm) {
            $muid = (int)$mm['uid'];
            if ($muid === $from) {
                conv_touch($muid, 2, $gid, $digest, $t, 0);
            } else {
                conv_touch($muid, 2, $gid, $digest, $t, 1);
            }
        }
    }
    return one('SELECT * FROM messages WHERE id=?', [$mid]) ?: [];
}

/* ---------- 群 ---------- */
function group_by_gid(int $gid): ?array
{
    return one('SELECT * FROM groups WHERE gid=?', [$gid]);
}
function group_member(int $gid, int $uid): ?array
{
    return one('SELECT * FROM group_members WHERE gid=? AND uid=?', [$gid, $uid]);
}
function group_role(int $gid, int $uid): int
{
    $m = group_member($gid, $uid);
    return $m ? (int)$m['role'] : -1; // -1 非成员
}
/** 邀请码：优先使用 CC号，便于分享与识别 */
function my_invite_code(array $me): string
{
    $code = (string)($me['invite_code'] ?? '');
    $uid  = (int)$me['id'];
    // 老数据是 8 位哈希，统一升级为 CC号（如被他人占用则保留原值）
    if ($code === '' || !preg_match('/^\d{6,9}$/', $code)) {
        $want = (string)($me['yx_id'] ?: $me['account']);
        if ($want !== '' && !val('SELECT id FROM users WHERE invite_code=? AND id<>?', [$want, $uid])) {
            q('UPDATE users SET invite_code=? WHERE id=?', [$want, $uid]);
            $code = $want;
        } elseif ($code === '') {
            $code = strtoupper(substr(md5((string)$uid . microtime()), 0, 8));
            q('UPDATE users SET invite_code=? WHERE id=?', [$code, $uid]);
        }
    }
    return $code;
}

/** 邀请阶梯奖励列表（含可领取状态） */
function invite_reward_list(int $uid, int $count): array
{
    $claims = [];
    foreach (all('SELECT reward_id FROM invite_claims WHERE uid=?', [$uid]) as $r) $claims[(int)$r['reward_id']] = 1;
    $out = [];
    foreach (all('SELECT * FROM invite_rewards WHERE status=1 ORDER BY need_count ASC, sort ASC, id ASC') as $r) {
        $rid = (int)$r['id'];
        $need = max(1, (int)$r['need_count']);
        $claimed = isset($claims[$rid]);
        $out[] = [
            'id'         => $rid,
            'name'       => (string)$r['name'],
            'icon'       => (string)$r['icon'],
            'type'       => (string)$r['type'],
            'level'      => (int)$r['level'],
            'days'       => (int)$r['days'],
            'coin'       => (int)$r['coin'],
            'need'       => $need,
            'claimed'    => $claimed ? 1 : 0,
            'claimable'  => (!$claimed && $count >= $need) ? 1 : 0,
        ];
    }
    return $out;
}

/**
 * 群号位数：后台可设置，限制 6 - 9 位（默认 8 位）
 */
function gid_len(): int
{
    $len = (int)setting('gid_len', '8');
    if ($len < 6) $len = 6;
    if ($len > 9) $len = 9;
    return $len;
}

/** 随机生成一个未被占用的群号（按后台设置的位数） */
function gen_gid(): int
{
    $len = gid_len();
    $min = (int)('1' . str_repeat('0', $len - 1));
    $max = (int)(str_repeat('9', $len));
    for ($i = 0; $i < 30; $i++) {
        $g = random_int($min, $max);
        if (!val('SELECT gid FROM groups WHERE gid=?', [$g])) return $g;
    }
    return random_int($min, $max);
}
/**
 * 注册 CC号位数：后台可设置，限制 6 - 9 位
 */
function reg_id_len(): int
{
    $len = (int)setting('reg_id_len', '8');
    if ($len < 6) $len = 6;
    if ($len > 9) $len = 9;
    return $len;
}
/**
 * 随机生成一个未被占用的 CC号（纯数字）
 * 位数由后台「系统设置 → 注册随机 CC号位数」决定，默认 8 位
 */
function gen_account(?int $len = null): string
{
    $len = $len ?: reg_id_len();
    if ($len < 6) $len = 6;
    if ($len > 9) $len = 9;
    $min = (int)('1' . str_repeat('0', $len - 1));
    $max = (int)str_repeat('9', $len);
    for ($i = 0; $i < 60; $i++) {
        $a = (string)random_int($min, $max);
        if (!val('SELECT id FROM users WHERE account=? OR yx_id=?', [$a, $a])) return $a;
    }
    // 极小概率连续撞号：改为逐位随机，仍保证长度与唯一
    for ($i = 0; $i < 200; $i++) {
        $a = (string)random_int(1, 9);
        for ($j = 1; $j < $len; $j++) $a .= (string)random_int(0, 9);
        if (!val('SELECT id FROM users WHERE account=? OR yx_id=?', [$a, $a])) return $a;
    }
    throw new RuntimeException('号码分配失败，请稍后重试');
}

/* =========================================================
 * 上传
 * ========================================================= */
function upload_save(string $field, string $subdir, array $allowExt = [], int $maxBytes = 0): array
{
    if (empty($_FILES[$field]) || ($_FILES[$field]['error'] ?? 4) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('未收到文件');
    }
    $f = $_FILES[$field];
    $maxBytes = $maxBytes ?: (int)cfg('app.max_upload', 60 * 1024 * 1024);
    if ((int)$f['size'] <= 0) throw new RuntimeException('空文件');
    if ((int)$f['size'] > $maxBytes) throw new RuntimeException('文件超过大小限制');

    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    // 可执行 / 可被服务器解析的扩展名一律拒绝，防止上传后 RCE 或存储型 XSS
    $denyExt = [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phar', 'phps',
        'pl', 'py', 'cgi', 'sh', 'bash', 'bat', 'cmd', 'com', 'exe', 'dll', 'so', 'wasm',
        'jsp', 'jspx', 'asp', 'aspx', 'ashx', 'asmx',
        'htaccess', 'htpasswd', 'ini', 'conf',
        'html', 'htm', 'xhtml', 'svg', 'xml', 'xsl', 'js', 'mjs',
    ];
    if ($ext !== '' && in_array($ext, $denyExt, true)) throw new RuntimeException('该文件类型不允许上传');
    if ($allowExt && !in_array($ext, $allowExt, true)) throw new RuntimeException('不支持的文件类型');

    $mime = '';
    if (function_exists('finfo_open')) {
        $fi = finfo_open(FILEINFO_MIME_TYPE);
        $mime = (string)finfo_file($fi, $f['tmp_name']);
        finfo_close($fi);
    }

    $dir = rtrim((string)cfg('app.upload_dir'), '/\\') . '/' . trim($subdir, '/');
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $name = date('Ymd') . '_' . bin2hex(random_bytes(8)) . ($ext ? '.' . $ext : '');
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($f['tmp_name'], $dest)) {
        if (!@copy($f['tmp_name'], $dest)) throw new RuntimeException('保存文件失败');
    }
    return [
        'url'  => 'uploads/' . trim($subdir, '/') . '/' . $name,
        'path' => $dest,
        'size' => (int)$f['size'],
        'mime' => $mime,
        'ext'  => $ext,
    ];
}

/* =========================================================
 * 简单的频率限制（文件计数，零依赖）
 * ========================================================= */
function rate_limit(string $key, int $limit, int $window = 60): bool
{
    $dir = CC_ROOT . '/data/rl';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $file = $dir . '/' . md5($key) . '.json';
    $now = time();
    $data = is_file($file) ? json_decode((string)file_get_contents($file), true) : null;
    if (!is_array($data) || $now - (int)$data['start'] > $window) $data = ['start' => $now, 'n' => 0];
    $data['n']++;
    @file_put_contents($file, json_encode($data));
    return $data['n'] <= $limit;
}

/* =========================================================
 * 杂项
 * ========================================================= */
function order_no(string $prefix = 'CC'): string
{
    return $prefix . date('YmdHis') . str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}
function fmt_time(int $t): string
{
    if ($t <= 0) return '';
    $d = time() - $t;
    if ($d < 60) return '刚刚';
    if ($d < 3600) return floor($d / 60) . '分钟前';
    if ($d < 86400) return floor($d / 3600) . '小时前';
    if (date('Y', $t) === date('Y')) return date('m-d H:i', $t);
    return date('Y-m-d', $t);
}
function fmt_money($n): string
{
    return number_format((float)$n, 2, '.', '');
}
function json_decode_arr($s): array
{
    if (is_array($s)) return $s;
    $j = json_decode((string)$s, true);
    return is_array($j) ? $j : [];
}
/**
 * 落地页配置（后台「运营 → 落地页」可改）：全部字段都有安全默认值
 */
function landing_config(): array
{
    $def = [
        'enabled' => 0,
        'hero' => [
            'show' => 1,
            'badge' => '免费使用 · 多端同步',
            'title' => '安全高效的即时通讯，连接每一次商机',
            'subtitle' => '支持私聊、群聊、朋友圈、语音视频通话与群直播；注册即得专属 CC号，手机与电脑消息实时同步。',
            'btn1' => '免费注册', 'btn1_url' => 'register.php',
            'btn2' => '已有账号，登录', 'btn2_url' => 'login.php',
        ],
        'stats' => [
            'show' => 1,
            'items' => [
                ['num' => '多端', 'label' => '手机 / 电脑同步'],
                ['num' => '秒达', 'label' => '消息实时推送'],
                ['num' => '加密', 'label' => '会话安全存储'],
                ['num' => '7×24', 'label' => '官方客服在线'],
            ],
        ],
        'features' => [
            'show' => 1,
            'title' => '核心功能',
            'subtitle' => '聊天、社交与变现能力一站具备，开箱即用。',
            'items' => [
                ['icon' => '💬', 'title' => '即时私聊群聊', 'desc' => '文字、图片、语音、视频、文件、红包、转账一应俱全，消息秒达不丢失。'],
                ['icon' => '🎥', 'title' => '语音视频通话', 'desc' => '基于 WebRTC 的点对点通话，低延迟、清晰稳定，支持屏幕共享直播。'],
                ['icon' => '🌈', 'title' => '朋友圈动态', 'desc' => '发布图文与视频动态，点赞评论互动，支持可见范围设置。'],
                ['icon' => '👥', 'title' => '群组管理', 'desc' => '群公告、管理员、禁言、踢人、封禁、消息置顶，运营工具齐全。'],
                ['icon' => '💰', 'title' => '钱包与会员', 'desc' => 'CC币钱包、红包转账、VIP/SVIP 会员、靓号商城，支持 USDT 充值。'],
                ['icon' => '📱', 'title' => '可安装到桌面', 'desc' => 'PWA 支持，手机浏览器一键添加到主屏幕，体验接近原生 App。'],
            ],
        ],
        'shots' => ['show' => 0, 'title' => '界面预览', 'subtitle' => '简洁清爽的聊天体验', 'items' => []],
        'download' => [
            'show' => 1,
            'title' => '下载客户端',
            'subtitle' => '也可直接使用网页版，无需安装',
            'android' => '', 'ios' => '',
            'tip' => '提示：手机浏览器打开后，点「分享 → 添加到主屏幕」即可当 App 使用。',
        ],
        'faq' => [
            'show' => 1,
            'title' => '常见问题',
            'subtitle' => '',
            'items' => [
                ['q' => '注册需要付费吗？', 'a' => '完全免费。注册即送专属 CC号，聊天、群聊、朋友圈等基础功能不收费。'],
                ['q' => '支持哪些设备？', 'a' => '支持手机浏览器、电脑浏览器，也可添加到手机主屏幕当 App 使用，消息多端实时同步。'],
                ['q' => '消息安全吗？', 'a' => '会话数据加密存储，仅本人登录后可查看；支持设置支付密码保护资金操作。'],
                ['q' => '忘记密码怎么办？', 'a' => '开启邮箱验证后可通过邮箱验证码自助重置；也可联系官方客服协助处理。'],
            ],
        ],
        'cta' => [
            'show' => 1,
            'title' => '现在注册，立即开始聊天',
            'desc' => '几十秒完成注册，自动分配专属 CC号',
            'btn' => '免费注册', 'btn_url' => 'register.php',
        ],
        'footer' => [
            'show' => 1,
            'text' => '一款轻量、稳定、可私有部署的即时通讯系统。',
            'icp' => '',
            'contact' => '',
        ],
    ];

    $raw = (string)setting('landing_config', '');
    if ($raw === '') return $def;
    $saved = json_decode($raw, true);
    if (!is_array($saved)) return $def;

    // 深合并：以默认值为骨架，用已保存值覆盖（保证新字段有默认值）
    $merge = static function (array $base, array $over) use (&$merge): array {
        foreach ($over as $k => $v) {
            if (is_array($v) && isset($base[$k]) && is_array($base[$k])) {
                $base[$k] = $merge($base[$k], $v);
            } else {
                $base[$k] = $v;
            }
        }
        return $base;
    };
    $cfg = $merge($def, $saved);
    $cfg['enabled'] = !empty($cfg['enabled']) ? 1 : 0;
    return $cfg;
}

function site_url(string $path = ''): string
{
    $base = cfg('app.url');
    if (!$base) {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        $base = ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    return rtrim($base, '/') . '/' . ltrim($path, '/');
}
function avatar_of(array $u): string
{
    return $u['avatar'] ?: 'assets/img/default-avatar.svg';
}
function ensure_default_assets(): void
{
    // 动态生成默认头像（SVG 文本，无需 GD）
    $p = CC_ROOT . '/assets/img';
    if (!is_dir($p)) @mkdir($p, 0775, true);
    $avatar = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#07C160"/><stop offset="1" stop-color="#06AD56"/></linearGradient></defs><rect width="200" height="200" rx="44" fill="url(#g)"/><circle cx="100" cy="78" r="32" fill="#fff" opacity=".92"/><path d="M38 178c8-38 32-56 62-56s54 18 62 56z" fill="#fff" opacity=".92"/></svg>';
    if (!is_file($p . '/default-avatar.svg')) @file_put_contents($p . '/default-avatar.svg', $avatar);
    // 应用图标
    if (!is_file(CC_ROOT . '/icons/icon-192.png')) {
        if (!is_dir(CC_ROOT . '/icons')) @mkdir(CC_ROOT . '/icons', 0775, true);
        if (function_exists('imagecreatetruecolor')) {
            $im = imagecreatetruecolor(192, 192);
            imagesavealpha($im, true);
            $bg = imagecolorallocate($im, 7, 193, 96);
            imagefilledrectangle($im, 0, 0, 192, 192, $bg);
            $white = imagecolorallocate($im, 255, 255, 255);
            imagefilledellipse($im, 96, 74, 56, 56, $white);
            imagefilledarc($im, 96, 168, 116, 100, 180, 360, $white, IMG_ARC_PIE);
            imagepng($im, CC_ROOT . '/icons/icon-192.png');
            imagedestroy($im);
        }
    }
}

/* =========================================================
 * 称号体系：后台可自定义，全站输出自动替换
 * ========================================================= */
/** 取称号设置（带默认值） */
function term(string $key, string $default = ''): string
{
    $v = (string)setting('term_' . $key, '');
    return $v !== '' ? $v : $default;
}
function term_brand(): string   { return term('brand', (string)setting('site_name', 'CC商聊')); }
function term_id(): string      { return term('id', 'CC号'); }
function term_coin(): string    { return term('coin', 'CC币'); }
function term_pretty(): string  { return term('pretty', '靓号'); }
function term_member(): string  { return term('member', '会员'); }

/** 需要全局替换的词表：原词 => 新词 */
function cc_term_map(): array
{
    $map = [
        'CC商聊' => term_brand(),
        'CC号'   => term_id(),
        'CC币'   => term_coin(),
        '靓号'   => term_pretty(),
        '会员'   => term_member(),
    ];
    foreach ($map as $from => $to) {
        if (trim((string)$to) === '' || trim((string)$to) === $from) unset($map[$from]);
    }
    return $map;
}
/** 输出过滤器：页面 HTML 渲染完成后统一替换称号 */
function cc_term_filter(string $buf): string
{
    // 优先使用注册缓冲时缓存的词表：脚本结束时数据库可能已关闭，实时查询会拿到空表
    $map = $GLOBALS['__cc_term_map'] ?? null;
    if (!is_array($map) || !$map) {
        $map = cc_term_map();
    }
    if (!$map) return $buf;
    return strtr($buf, $map);
}

/* 邮件（SMTP） */
require_once __DIR__ . '/mailer.php';

/* 启动 */
cc_session_start();
try {
    current_user();
} catch (Throwable $e) {
    // 数据库尚未安装时，页面会引导到 install.php
}

/* 未安装检测：缺少核心表时跳转安装向导（CLI 除外） */
if (PHP_SAPI !== 'cli' && !defined('CC_SKIP_INSTALL_CHECK')) {
    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if ($script !== 'install.php') {
        try {
            db()->query('SELECT 1 FROM settings LIMIT 1');
        } catch (Throwable $e) {
            header('Location: ' . (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false ? '../install.php' : 'install.php'));
            exit;
        }
    }
}

/* 称号替换：页面输出统一过滤（api.php 返回 JSON，不参与）
   词表在注册时计算一次并缓存，避免脚本结束时数据库已关闭导致替换失效 */
if (PHP_SAPI !== 'cli') {
    $__sc = basename($_SERVER['SCRIPT_NAME'] ?? '');
    if (!in_array($__sc, ['api.php', 'manifest.php'], true) && !defined('CC_TERM_BUFFER')) {
        define('CC_TERM_BUFFER', 1);
        try { $GLOBALS['__cc_term_map'] = cc_term_map(); } catch (Throwable $e) { $GLOBALS['__cc_term_map'] = []; }
        ob_start('cc_term_filter');
        // 主动刷出：确保回调在数据库仍然可用时执行
        register_shutdown_function(static function (): void {
            while (ob_get_level() > 0) {
                if (!@ob_end_flush()) break;
            }
        });
    }
}

/* 一次性品牌迁移：老站点升级代码后，首次访问自动把旧品牌字样改成 CC */
if (PHP_SAPI !== 'cli') {
    try {
        if ((string)setting('brand_ver', '') !== '2') {
            brand_migrate();
            set_setting('brand_ver', '2');
        }
    } catch (Throwable $e) {
        // 数据库未安装或只读时忽略，安装向导会再执行一次
    }
}
