<?php
/**
 * CC商聊 - API 核心：账号、个人资料、好友、公告、客服、举报、申诉、邀请
 */
declare(strict_types=1);

/* =========================================================
 * 账号
 * ========================================================= */
$API_CORE = [];

$API_CORE['ping'] = function () {
    ok(['time' => now(), 'version' => CC_VERSION]);
};

$API_CORE['site_info'] = function () {
    ok([
        'name'      => setting('site_name', 'CC商聊'),
        'slogan'    => setting('site_slogan', '连接每一次商机'),
        'logo'      => setting('site_logo', 'icons/icon-192.png'),
        'version'   => CC_VERSION,
        'download'  => setting('app_download_url', ''),
        'register_open' => (int)setting('register_open', '1'),
        'usdt' => [
            'network' => setting('usdt_network', 'TRC20'),
            'rate'    => (int)setting('usdt_rate', '7'),
            'min'     => (int)setting('usdt_min_coin', '10'),
        ],
    ]);
};

$API_CORE['check_account'] = function () {
    $kw = (string)inp('keyword', '');
    if ($kw === '') fail('请输入 CC号或邮箱');
    $u = one('SELECT id,nickname,avatar,yx_id,account FROM users WHERE account=? OR yx_id=? OR email=?', [$kw, $kw, $kw]);
    if (!$u) fail('账号不存在');
    ok(['exists' => 1, 'nickname' => $u['nickname']]);
};

$API_CORE['login'] = function () {
    if (!rate_limit('login:' . client_ip(), 20, 300)) fail('尝试过于频繁，请稍后再试');
    $kw = trim((string)inp('keyword', inp('account', '')));
    $pwd = (string)inp('password', '');
    $remember = (string)inp('remember', '1') === '1';
    if ($kw === '' || $pwd === '') fail('请输入账号和密码');

    $u = one('SELECT * FROM users WHERE account=? OR yx_id=? OR email=? OR phone=?', [$kw, $kw, $kw, $kw]);
    if (!$u || !password_verify($pwd, $u['password'])) {
        fail('账号或密码错误');
    }
    if ((int)$u['status'] === 1 && ((int)$u['ban_forever'] === 1 || (int)$u['ban_until'] === 0 || (int)$u['ban_until'] > now())) {
        jout(3, '账号已被封禁', [
            'ban_reason'  => $u['ban_reason'] ?: '违反平台规定',
            'ban_until'   => (int)$u['ban_until'],
            'ban_forever' => (int)$u['ban_forever'],
            'service'     => setting('service_contact', ''),
        ]);
    }
    $swToken = login_user($u, $remember);
    ok(array_merge(user_public($u, true), ['switch_token' => $swToken]));
};

/* =========================================================
 * 黑名单
 * ========================================================= */
$API_CORE['block_list'] = function ($me) {
    $rows = all('SELECT b.*, u.nickname, u.avatar, u.yx_id, u.account FROM blocks b
        JOIN users u ON u.id=b.target_uid WHERE b.uid=? ORDER BY b.id DESC', [(int)$me['id']]);
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'uid'     => (int)$r['target_uid'],
            'name'    => $r['nickname'] ?: ('用户' . substr((string)$r['account'], -4)),
            'avatar'  => $r['avatar'],
            'account' => $r['yx_id'] ?: $r['account'],
            'created_at' => (int)$r['created_at'],
        ];
    }
    ok(['list' => $out]);
};

$API_CORE['block_add'] = function ($me) {
    $uid = (int)$me['id'];
    $target = inp_int('uid', inp_int('target_uid'));
    if ($target <= 0 || $target === $uid) fail('参数错误');
    if (!one('SELECT id FROM users WHERE id=?', [$target])) fail('用户不存在');
    if (!one('SELECT id FROM blocks WHERE uid=? AND target_uid=?', [$uid, $target])) {
        q('INSERT INTO blocks (uid,target_uid,created_at) VALUES (?,?,?)', [$uid, $target, now()]);
    }
    // 拉黑即互相移除好友关系与会话
    q('DELETE FROM friends WHERE (uid=? AND fid=?) OR (uid=? AND fid=?)', [$uid, $target, $target, $uid]);
    q('DELETE FROM conversations WHERE uid=? AND ctype=1 AND peer_id=?', [$uid, $target]);
    ok(null, '已加入黑名单');
};

$API_CORE['block_del'] = function ($me) {
    $target = inp_int('uid', inp_int('target_uid'));
    q('DELETE FROM blocks WHERE uid=? AND target_uid=?', [(int)$me['id'], $target]);
    ok(null, '已移出黑名单');
};

/** 双方是否存在拉黑关系 */
function is_blocked(int $a, int $b): bool
{
    return (bool)val('SELECT id FROM blocks WHERE (uid=? AND target_uid=?) OR (uid=? AND target_uid=?)', [$a, $b, $b, $a]);
}

/* =========================================================
 * 注销账号（自助）
 * ========================================================= */
$API_CORE['account_delete'] = function ($me) {
    $pwd = (string)inp('password', '');
    $u = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
    if (!$u) fail('用户不存在');
    if (!password_verify($pwd, (string)$u['password'])) fail('密码不正确');
    $uid = (int)$u['id'];
    // 靓号回收：把已购靓号放回号池，价格沿用历史价或默认 5200
    $pretty = trim((string)($u['pretty_yxid'] ?? ''));
    if ($pretty !== '') {
        $old = one('SELECT price FROM pretty_ids WHERE yx_id=?', [$pretty]);
        if (!one('SELECT id FROM pretty_ids WHERE yx_id=?', [$pretty])) {
            q('INSERT INTO pretty_ids (yx_id,price,status,buyer_uid,created_at,sold_at,ptype) VALUES (?,?,0,0,?,0,?)',
              [$pretty, (int)($old['price'] ?? 5200), now(), 'user']);
        }
        q('UPDATE users SET pretty_yxid="" WHERE id=?', [$uid]);
    }
    // 注销：标记删除 + 清空可识别信息 + 下线
    q('UPDATE users SET status=2, online=0, nickname=?, avatar="", bio="", email="", phone="", pay_password="" WHERE id=?',
      ['已注销用户' . substr((string)$uid, -4), $uid]);
    q('DELETE FROM devices WHERE uid=?', [$uid]);
    q('UPDATE conversations SET visible=0 WHERE uid=?', [$uid]);
    logout_user();
    ok(null, '账号已注销');
};

/* =========================================================
 * 多账号：校验 / 切换
 * ========================================================= */
$API_CORE['account_check'] = function () {
    // 入参 tokens = [{"uid":1,"token":"..."}]
    $raw = inp('tokens', '');
    $arr = is_array($raw) ? $raw : json_decode((string)$raw, true);
    if (!is_array($arr)) $arr = [];
    $out = [];
    foreach (array_slice($arr, 0, 10) as $it) {
        $token = (string)($it['token'] ?? '');
        if (!preg_match('/^[a-f0-9]{48}$/', $token)) continue;
        $d = one('SELECT * FROM devices WHERE token=?', [$token]);
        if (!$d) continue;
        $u = one('SELECT * FROM users WHERE id=? AND status<>2', [(int)$d['uid']]);
        if (!$u) continue;
        $pub = user_public($u);
        $out[] = [
            'uid'      => (int)$u['id'],
            'token'    => $token,
            'name'     => $pub['nickname'],
            'avatar'   => $pub['avatar'],
            'account'  => $pub['yx_id'],
            'pretty'   => (string)($u['pretty_yxid'] ?? ''),
            'online'   => 1,
        ];
    }
    ok(['list' => $out]);
};

$API_CORE['account_current_token'] = function ($me) {
    $tok = (string)($_COOKIE['cc_token'] ?? '');
    if ($tok === '' || !preg_match('/^[a-f0-9]{48}$/', $tok)) {
        $d = one('SELECT token FROM devices WHERE uid=? ORDER BY last_active_at DESC LIMIT 1', [(int)$me['id']]);
        $tok = $d ? (string)$d['token'] : '';
    }
    ok(['token' => $tok]);
};

$API_CORE['account_switch'] = function () {
    $token = trim((string)inp('token', ''));
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) fail('账号凭据无效');
    $d = one('SELECT * FROM devices WHERE token=?', [$token]);
    if (!$d) fail('该账号登录已失效，请重新登录');
    $u = one('SELECT * FROM users WHERE id=? AND status<>2', [(int)$d['uid']]);
    if (!$u) fail('账号不存在或已注销');
    cc_session_start();
    @session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    $_SESSION['login_at'] = now();
    setcookie('cc_token', $token, [
        'expires'  => time() + 86400 * (int)cfg('app.session_days', 30),
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    q('UPDATE devices SET last_active_at=? WHERE id=?', [now(), (int)$d['id']]);
    q('UPDATE users SET last_active_at=?, online=1 WHERE id=?', [now(), (int)$u['id']]);
    ok(array_merge(user_public($u, true), ['switch_token' => $token]), '已切换');
};

$API_CORE['logout'] = function ($me) {
    logout_user();
    ok(null, '已退出');
};

$API_CORE['register'] = function () {
    if ((string)setting('register_open', '1') !== '1') fail('当前暂停注册');
    if (!rate_limit('reg:' . client_ip(), 10, 3600)) fail('注册过于频繁');
    $pwd     = (string)inp('password', '');
    $pwd2    = (string)inp('password2', '');
    $nick    = trim((string)inp('nickname', ''));
    $email   = trim((string)inp('email', ''));
    $invite  = trim((string)inp('invite', ''));
    $code    = trim((string)inp('code', ''));

    // CC号由系统随机分配，用户不可自定义（位数由后台「注册随机 CC号位数」决定）
    $account = gen_account();
    if (!preg_match('/^[0-9]{6,9}$/', $account)) throw new RuntimeException('号码生成异常，请重试');
    if (mb_strlen($pwd) < 6) fail('密码至少 6 位');
    if ($pwd !== $pwd2) fail('两次密码不一致');
    if (val('SELECT id FROM users WHERE account=? OR yx_id=?', [$account, $account])) $account = gen_account();
    if ($email !== '') {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('邮箱格式不正确');
        if (val('SELECT id FROM users WHERE email=?', [$email])) fail('该邮箱已被其他账号使用');
        // 后台开启「注册邮箱验证」时，必须校验邮箱验证码
        if (email_verify_register()) {
            verify_email_code($email, $code, 'register');
        }
    }
    if ($nick === '') $nick = '用户' . substr($account, -4);

    $inviter = null;
    if ($invite !== '') {
        $inviter = one('SELECT * FROM users WHERE invite_code=?', [$invite]);
        if (!$inviter) $inviter = one('SELECT * FROM users WHERE yx_id=? OR account=?', [$invite, $invite]);
    }
    $now = now();
    q('INSERT INTO users (account,yx_id,nickname,password,email,invite_code,invited_by,created_at,last_active_at,settings) VALUES (?,?,?,?,?,?,?,?,?,?)', [
        $account, $account, $nick, password_hash($pwd, PASSWORD_DEFAULT), $email,
        strtoupper(substr(md5($account . $now . random_int(1, 999999)), 0, 8)),
        $inviter ? (int)$inviter['id'] : 0, $now, $now, '{}',
    ]);
    $uid = last_id();
    $u = one('SELECT * FROM users WHERE id=?', [$uid]);

    // 邀请关系：记录邀请（用于阶梯奖励次数统计），可选每人立得奖励
    if ($inviter) {
        $reward = max(0, (int)setting('invite_reward', '0'));
        q('INSERT INTO invites (uid,invitee_uid,reward_coin,created_at) VALUES (?,?,?,?)', [(int)$inviter['id'], $uid, $reward * 2, $now]);
        if ($reward > 0) {
            try {
                add_coin($uid, $reward, 'invite', (int)$inviter['id'], '受邀注册奖励');
                add_coin((int)$inviter['id'], $reward, 'invite', $uid, '邀请好友奖励');
            } catch (Throwable $e) {
            }
        }
        q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [$uid, (int)$inviter['id'], '', 1, $now]);
        q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [(int)$inviter['id'], $uid, '', 1, $now]);
    }

    // 官方客服 & 机器人自动好友
    foreach (['10086', '990375'] as $acc) {
        $b = one('SELECT id FROM users WHERE account=?', [$acc]);
        if ($b && (int)$b['id'] !== $uid) {
            q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [$uid, (int)$b['id'], '', 1, $now]);
            q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,?,?)', [(int)$b['id'], $uid, '', 1, $now]);
        }
    }

    login_user($u, true);
    ok(user_public($u, true), '注册成功');
};

$API_CORE['send_code'] = function () {
    if (!rate_limit('code:' . client_ip(), 5, 600)) fail('发送过于频繁');
    $target = trim((string)inp('target', ''));
    $purpose = (string)inp('purpose', 'register');
    if ($target === '') fail('请输入邮箱');
    if (!filter_var($target, FILTER_VALIDATE_EMAIL)) fail('邮箱格式不正确');

    // 注册用途：后台未开启邮箱验证时无需发码
    if ($purpose === 'register' && !email_verify_register()) fail('当前无需邮箱验证');

    // 找回密码：邮箱必须已绑定在某个账号上，避免给陌生邮箱发信
    if ($purpose === 'reset') {
        $exists = one('SELECT id FROM users WHERE email=?', [$target]);
        if (!$exists) fail('该邮箱未绑定任何账号');
    }

    if (!mail_ready()) {
        fail('邮件服务未配置，请联系客服处理');
    }

    $code = (string)random_int(100000, 999999);
    q('INSERT INTO verify_codes (target,code,purpose,expire_at,used,created_at) VALUES (?,?,?,?,0,?)', [
        $target, $code, $purpose, now() + 600, now(),
    ]);
    try {
        send_verify_mail($target, $code, $purpose);
    } catch (Throwable $e) {
        // 发信失败：作废本次验证码，避免泄露可用码
        q('UPDATE verify_codes SET used=1 WHERE target=? AND code=? AND purpose=?', [$target, $code, $purpose]);
        fail('邮件发送失败：' . $e->getMessage());
    }
    ok(['sent' => 1], '验证码已发送，请查收邮件');
};

$API_CORE['reset_password'] = function () {
    if (!rate_limit('resetpwd:' . client_ip(), 10, 600)) fail('尝试过于频繁，请稍后再试');
    $kw = trim((string)inp('keyword', ''));
    $code = trim((string)inp('code', ''));
    $pwd = (string)inp('password', '');
    if ($kw === '' || mb_strlen($pwd) < 6) fail('参数不完整');
    $u = one('SELECT * FROM users WHERE account=? OR yx_id=? OR email=?', [$kw, $kw, $kw]);
    if (!$u) fail('账号不存在');
    // 邮箱验证关闭时：不支持自助找回，提示联系客服
    if (!email_verify_register()) fail('当前未开启邮箱验证，请联系客服协助重置密码');
    if ($code === '') fail('请填写邮箱验证码');
    if ((string)$u['email'] === '') fail('该账号未绑定邮箱，请联系客服协助重置密码');
    verify_email_code((string)$u['email'], $code, 'reset');
    q('UPDATE users SET password=? WHERE id=?', [password_hash($pwd, PASSWORD_DEFAULT), (int)$u['id']]);
    ok(null, '密码已重置，请重新登录');
};


/* ---------- 封禁申诉（登录页可调用） ---------- */
$API_CORE['appeal_submit'] = function () {
    if (!rate_limit('appeal:' . client_ip(), 5, 600)) fail('提交过于频繁，请稍后再试');
    $account = trim((string)inp('account', inp('keyword', '')));
    $reason = trim((string)inp('reason', ''));
    $contact = trim((string)inp('contact', ''));
    if ($reason === '') fail('请填写申诉理由');
    $u = one('SELECT id FROM users WHERE account=? OR yx_id=? OR email=?', [$account, $account, $account]);
    q('INSERT INTO appeals (uid,account,reason,contact,status,created_at) VALUES (?,?,?,?,0,?)', [
        $u ? (int)$u['id'] : 0, $account, mb_substr($reason, 0, 500), mb_substr($contact, 0, 128), now(),
    ]);
    ok(null, '申诉已提交，请等待管理员处理');
};

/* =========================================================
 * 个人资料 / 账号安全
 * ========================================================= */
$API_CORE['me'] = function ($me) {
    $fresh = one('SELECT * FROM users WHERE id=?', [(int)$me['id']]);
    $out = user_public($fresh, true);
    $out['settings'] = json_decode_arr($fresh['settings'] ?? '');
    $out['invite_code'] = $fresh['invite_code'];
    ok($out);
};

$API_CORE['save_profile'] = function ($me) {
    $f = [];
    foreach (['nickname', 'bio', 'region'] as $k) {
        if (inp($k) !== null) $f[$k] = mb_substr(trim((string)inp($k)), 0, $k === 'bio' ? 100 : 32);
    }
    if (inp('gender') !== null) $f['gender'] = max(0, min(2, inp_int('gender')));
    if (inp('avatar') !== null && inp('avatar') !== '') $f['avatar'] = (string)inp('avatar');
    if (!$f) fail('没有需要保存的内容');
    $sets = [];
    $params = [];
    foreach ($f as $k => $v) {
        $sets[] = "$k=?";
        $params[] = $v;
    }
    $params[] = (int)$me['id'];
    q('UPDATE users SET ' . implode(',', $sets) . ' WHERE id=?', $params);
    ok(user_public(one('SELECT * FROM users WHERE id=?', [(int)$me['id']]), true), '已保存');
};

$API_CORE['upload_avatar'] = function ($me) {
    $f = upload_save('file', 'avatar', ['jpg', 'jpeg', 'png', 'gif', 'webp'], 8 * 1024 * 1024);
    q('UPDATE users SET avatar=? WHERE id=?', [$f['url'], (int)$me['id']]);
    ok(['url' => $f['url']], '头像已更新');
};

$API_CORE['change_password'] = function ($me) {
    $old = (string)inp('old', '');
    $new = (string)inp('new', '');
    if (!password_verify($old, $me['password'])) fail('原密码不正确');
    if (mb_strlen($new) < 6) fail('新密码至少 6 位');
    if ($new === $old) fail('新密码不能与原密码相同');
    q('UPDATE users SET password=? WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), (int)$me['id']]);
    ok(null, '密码已修改，请重新登录');
};

$API_CORE['set_pay_password'] = function ($me) {
    $pwd = (string)inp('password', '');
    $old = (string)inp('old', '');
    if (!preg_match('/^\d{6}$/', $pwd)) fail('支付密码需为 6 位数字');
    if ($me['pay_password'] !== '' && !password_verify($old, $me['pay_password'])) fail('原支付密码不正确');
    q('UPDATE users SET pay_password=? WHERE id=?', [password_hash($pwd, PASSWORD_DEFAULT), (int)$me['id']]);
    ok(null, '支付密码已设置');
};

function check_pay_pwd(array $me, string $pwd): void
{
    if ($me['pay_password'] === '') fail('请先设置支付密码', 1001);
    // 防暴力破解：同一账号 5 分钟内最多校验 10 次
    if (!rate_limit('paypwd:' . (int)$me['id'], 10, 300)) fail('支付密码错误次数过多，请 5 分钟后再试', 1003);
    if (!password_verify($pwd, $me['pay_password'])) fail('支付密码不正确', 1002);
}

$API_CORE['update_settings'] = function ($me) {
    $cur = json_decode_arr($me['settings'] ?? '');
    // 允许保存的用户偏好（隐私 / 通知 / 免打扰）
    $allow = [
        'theme',
        // 隐私
        'allow_add', 'friend_no_verify', 'read_receipt', 'allow_group_invite', 'friend_verify',
        // 通知
        'notify_on', 'notify_sound', 'notify_vibrate', 'notify_group',
        'dnd_on', 'dnd_start', 'dnd_end',
    ];
    foreach ($allow as $k) {
        if (inp($k) !== null) {
            $v = (string)inp($k);
            // 时间类字段做格式校验
            if (in_array($k, ['dnd_start', 'dnd_end'], true) && !preg_match('/^([01]?\d|2[0-3]):[0-5]\d$/', $v)) continue;
            $cur[$k] = mb_substr($v, 0, 10);
        }
    }
    q('UPDATE users SET settings=? WHERE id=?', [json_encode($cur, JSON_UNESCAPED_UNICODE), (int)$me['id']]);
    ok($cur);
};

$API_CORE['device_list'] = function ($me) {
    $rows = all('SELECT id,device_id,ua,ip,last_active_at,created_at FROM devices WHERE uid=? ORDER BY last_active_at DESC', [(int)$me['id']]);
    $cur = $_COOKIE['cc_did'] ?? '';
    foreach ($rows as &$r) $r['current'] = ($r['device_id'] === $cur) ? 1 : 0;
    ok(['list' => $rows]);
};

$API_CORE['device_kick'] = function ($me) {
    $id = inp_int('id');
    $d = one('SELECT * FROM devices WHERE id=? AND uid=?', [$id, (int)$me['id']]);
    if (!$d) fail('设备不存在');
    q('DELETE FROM devices WHERE id=?', [$id]);
    ok(null, '已下线该设备');
};

/* =========================================================
 * 好友
 * ========================================================= */
$API_CORE['friend_list'] = function ($me) {
    $rows = all('SELECT f.*, u.nickname,u.avatar,u.yx_id,u.account,u.online,u.vip_level,u.vip_expire_at,u.pretty_yxid FROM friends f JOIN users u ON u.id=f.fid WHERE f.uid=? AND f.status=1 ORDER BY f.id DESC', [(int)$me['id']]);
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'id' => (int)$r['fid'], 'nickname' => $r['remark'] ?: $r['nickname'],
            'raw_nickname' => $r['nickname'], 'remark' => $r['remark'],
            'avatar' => $r['avatar'],
            'yx_id' => ($r['pretty_yxid'] ?: $r['yx_id']) ?: $r['account'],
            'pretty' => (string)($r['pretty_yxid'] ?? ''),
            'online' => (int)$r['online'], 'vip_level' => is_vip($r) ? (int)$r['vip_level'] : 0,
        ];
    }
    ok(['list' => $out]);
};

$API_CORE['friend_board'] = function ($me) {
    $reqs = all('SELECT r.*, u.nickname,u.avatar,u.yx_id FROM friend_requests r JOIN users u ON u.id=r.from_uid WHERE r.to_uid=? ORDER BY r.id DESC LIMIT 50', [(int)$me['id']]);
    $out = [];
    foreach ($reqs as $r) {
        $out[] = [
            'id' => (int)$r['id'], 'from_uid' => (int)$r['from_uid'], 'nickname' => $r['nickname'],
            'avatar' => $r['avatar'], 'yx_id' => $r['yx_id'], 'reason' => $r['reason'],
            'status' => (int)$r['status'], 'created_at' => (int)$r['created_at'],
        ];
    }
    $pending = (int)val('SELECT COUNT(*) FROM friend_requests WHERE to_uid=? AND status=0', [(int)$me['id']]);
    ok(['list' => $out, 'pending' => $pending]);
};

$API_CORE['search'] = function ($me) {
    $kw = trim((string)inp('keyword', ''));
    $type = (string)inp('type', 'all'); // all|user|group
    if ($kw === '') fail('请输入关键词');
    $users = [];
    $groups = [];
    if ($type !== 'group') {
        $rows = all('SELECT * FROM users WHERE account=? OR yx_id=? OR pretty_yxid=? OR email=? OR nickname=? LIMIT 20', [$kw, $kw, $kw, $kw, $kw]);
        $uid = (int)$me['id'];
        foreach ($rows as $r) {
            $rid = (int)$r['id'];
            $isFriend = val('SELECT id FROM friends WHERE uid=? AND fid=?', [$uid, $rid]) ? 1 : 0;
            $sentReq = (!$isFriend && val('SELECT id FROM friend_requests WHERE from_uid=? AND to_uid=? AND status=0', [$uid, $rid])) ? 1 : 0;
            $inReqId = 0;
            if (!$isFriend) {
                $inReqId = (int)val('SELECT id FROM friend_requests WHERE from_uid=? AND to_uid=? AND status=0 ORDER BY id DESC LIMIT 1', [$rid, $uid]);
            }
            $users[] = user_public($r) + [
                'is_friend' => $isFriend,
                'req_sent' => $sentReq,
                'req_id' => $inReqId,
            ];
        }
        if (!$users && mb_strlen($kw) >= 2) {
            $rows = all('SELECT * FROM users WHERE nickname LIKE ? LIMIT 20', ['%' . $kw . '%']);
            foreach ($rows as $r) $users[] = user_public($r);
        }
    }
    if ($type !== 'user') {
        $rows = all('SELECT g.*, (SELECT COUNT(*) FROM group_members gm WHERE gm.gid=g.gid) AS members FROM groups g WHERE g.status=1 AND (g.gid=? OR g.name=?) LIMIT 20', [$kw, $kw]);
        foreach ($rows as $r) {
            $groups[] = ['gid' => (int)$r['gid'], 'name' => $r['name'], 'avatar' => $r['avatar'], 'members' => (int)$r['members'], 'intro' => $r['intro'], 'joined' => group_member((int)$r['gid'], (int)$me['id']) ? 1 : 0];
        }
    }
    ok(['users' => $users, 'groups' => $groups]);
};

$API_CORE['send_friend_request'] = function ($me) {
    if (!rate_limit('freq:' . (int)$me['id'], 20, 3600)) fail('申请过于频繁，请稍后再试');
    $to = inp_int('to_uid', inp_int('uid'));
    $reason = mb_substr(trim((string)inp('reason', '')), 0, 100);
    if ($to <= 0 || $to === (int)$me['id']) fail('参数错误');
    $target = one('SELECT * FROM users WHERE id=?', [$to]);
    if (!$target) fail('用户不存在');
    if (is_blocked((int)$me['id'], $to)) fail('无法向对方发送好友申请');
    if (one('SELECT id FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $to])) fail('你们已经是好友');
    if ($reason === '') fail('请填写申请理由');
    // 对方隐私设置：不允许任何人添加
    $tset = json_decode_arr($target['settings'] ?? '');
    if ((string)($tset['allow_add'] ?? '1') === '0') fail('对方已关闭好友申请');
    // 对方开启「添加好友无需验证」：直接成为好友
    if ((string)($tset['friend_no_verify'] ?? '0') === '1') {
        $a = (int)$me['id'];
        foreach ([[$a, $to], [$to, $a]] as $fr) {
            if (!one('SELECT id FROM friends WHERE uid=? AND fid=?', $fr)) {
                q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,"",1,?)', [$fr[0], $fr[1], now()]);
            }
        }
        q('INSERT INTO friend_requests (from_uid,to_uid,reason,status,created_at,handled_at) VALUES (?,?,?,1,?,?)',
          [$a, $to, $reason, now(), now()]);
        try {
            push_message(['ctype' => 1, 'from_uid' => $a, 'to_uid' => $to, 'type' => 11, 'content' => '已添加你为好友']);
        } catch (Throwable $e) {}
        ok(['auto' => 1], '已直接添加为好友');
    }
    $last = one('SELECT * FROM friend_requests WHERE from_uid=? AND to_uid=? ORDER BY id DESC LIMIT 1', [(int)$me['id'], $to]);
    if ($last && (int)$last['status'] === 0) fail('已发送申请，等待对方处理');
    q('INSERT INTO friend_requests (from_uid,to_uid,reason,status,created_at) VALUES (?,?,?,0,?)', [(int)$me['id'], $to, $reason, now()]);
    // 通知以「申请人」身份发一条系统消息，避免在对方列表里多出客服会话
    try {
        push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $to, 'type' => 11,
            'content' => '请求添加你为好友：' . $reason]);
    } catch (Throwable $e) {
    }
    ok(null, '申请已发送');
};

$API_CORE['handle_req'] = function ($me) {
    $id = inp_int('id');
    $act = (string)inp('act', ''); // accept|reject
    $r = one('SELECT * FROM friend_requests WHERE id=? AND to_uid=?', [$id, (int)$me['id']]);
    if (!$r) fail('申请不存在');
    if ((int)$r['status'] !== 0) fail('该申请已处理');
    if ($act === 'accept') {
        q('UPDATE friend_requests SET status=1, handled_at=? WHERE id=?', [now(), $id]);
        $a = (int)$me['id'];
        $b = (int)$r['from_uid'];
        if (!one('SELECT id FROM friends WHERE uid=? AND fid=?', [$a, $b])) q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,1,?)', [$a, $b, '', now()]);
        if (!one('SELECT id FROM friends WHERE uid=? AND fid=?', [$b, $a])) q('INSERT INTO friends (uid,fid,remark,status,created_at) VALUES (?,?,?,1,?)', [$b, $a, '', now()]);
        try {
            push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $b, 'type' => 11, 'content' => '通过了你的好友申请，现在可以开始聊天了']);
        } catch (Throwable $e) {
        }
        ok(null, '已添加为好友');
    }
    q('UPDATE friend_requests SET status=2, handled_at=? WHERE id=?', [now(), $id]);
    ok(null, '已拒绝');
};

$API_CORE['set_remark'] = function ($me) {
    $fid = inp_int('fid');
    $remark = mb_substr(trim((string)inp('remark', '')), 0, 32);
    q('UPDATE friends SET remark=? WHERE uid=? AND fid=?', [$remark, (int)$me['id'], $fid]);
    ok(null, '已保存');
};

$API_CORE['delete_friend'] = function ($me) {
    $fid = inp_int('fid');
    q('DELETE FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $fid]);
    q('DELETE FROM friends WHERE uid=? AND fid=?', [$fid, (int)$me['id']]);
    q('DELETE FROM conversations WHERE uid=? AND ctype=1 AND peer_id=?', [(int)$me['id'], $fid]);
    ok(null, '已删除好友');
};

$API_CORE['block_friend'] = function ($me) {
    $fid = inp_int('fid');
    $now = (int)val('SELECT status FROM friends WHERE uid=? AND fid=?', [(int)$me['id'], $fid]);
    q('UPDATE friends SET status=? WHERE uid=? AND fid=?', [$now === 2 ? 1 : 2, (int)$me['id'], $fid]);
    ok(null, '已更新');
};

/* =========================================================
 * 公告 / 客服 / 举报 / 邀请
 * ========================================================= */
$API_CORE['notice_list'] = function ($me) {
    $rows = all('SELECT * FROM notices WHERE status=1 ORDER BY is_top DESC, id DESC LIMIT 50');
    $readIds = [];
    foreach (all('SELECT nid FROM notice_reads WHERE uid=?', [(int)$me['id']]) as $r) $readIds[(int)$r['nid']] = 1;
    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'id' => (int)$r['id'], 'title' => $r['title'], 'content' => $r['content'],
            'is_top' => (int)$r['is_top'], 'created_at' => (int)$r['created_at'],
            'read' => isset($readIds[(int)$r['id']]) ? 1 : 0,
        ];
    }
    $unread = 0;
    foreach ($out as $o) if (!$o['read']) $unread++;
    ok(['list' => $out, 'unread' => $unread]);
};

$API_CORE['notice_read'] = function ($me) {
    $nid = inp_int('id');
    $uid = (int)$me['id'];
    $mark = static function (int $id) use ($uid): void {
        if ($id <= 0) return;
        if (!one('SELECT id FROM notice_reads WHERE nid=? AND uid=?', [$id, $uid])) {
            try {
                q('INSERT INTO notice_reads (nid,uid,read_at) VALUES (?,?,?)', [$id, $uid, now()]);
            } catch (Throwable $e) {
                // 并发重复写入（唯一索引冲突）直接忽略，保证接口幂等
            }
        }
    };
    if ($nid > 0) {
        $mark($nid);
    } else {
        foreach (all('SELECT id FROM notices WHERE status=1') as $n) {
            $mark((int)$n['id']);
        }
    }
    $unread = (int)val(
        'SELECT COUNT(*) FROM notices n WHERE n.status=1 AND NOT EXISTS ('
        . 'SELECT 1 FROM notice_reads r WHERE r.nid=n.id AND r.uid=?)',
        [$uid]
    );
    ok(['unread' => $unread], '已读');
};

$API_CORE['service_info'] = function ($me) {
    $u = one('SELECT * FROM users WHERE id=?', [service_uid()]);
    $gid = (int)setting('official_gid', '666666');
    $g = group_by_gid($gid);
    ok([
        'service' => $u ? user_public($u, true) : null,
        'contact' => setting('service_contact', ''),
        'group'   => $g ? ['gid' => (int)$g['gid'], 'name' => $g['name'], 'avatar' => $g['avatar'], 'members' => (int)val('SELECT COUNT(*) FROM group_members WHERE gid=?', [$gid])] : null,
        'joined_group' => $g ? (group_member($gid, (int)$me['id']) ? 1 : 0) : 0,
    ]);
};

$API_CORE['report_submit'] = function ($me) {
    $tt = (string)inp('target_type', 'message');
    $tid = inp_int('target_id');
    $reason = trim((string)inp('reason', ''));
    $detail = mb_substr(trim((string)inp('detail', '')), 0, 500);
    if ($reason === '') fail('请选择举报原因');
    q('INSERT INTO reports (from_uid,target_type,target_id,reason,detail,status,created_at) VALUES (?,?,?,?,?,0,?)', [
        (int)$me['id'], $tt, $tid, $reason, $detail, now(),
    ]);
    ok(null, '举报已提交');
};

$API_CORE['invite_info'] = function ($me) {
    $uid = (int)$me['id'];
    $code = my_invite_code($me);
    $count = (int)val('SELECT COUNT(*) FROM invites WHERE uid=?', [$uid]);
    $earned = (int)val('SELECT COALESCE(SUM(reward_coin),0) FROM invites WHERE uid=?', [$uid]);
    $rewards = invite_reward_list($uid, $count);
    $next = null;
    foreach ($rewards as $r) {
        if (!$r['claimed'] && $r['need'] > $count) { $next = $r['need']; break; }
    }
    $invited = all(
        'SELECT u.id,u.nickname,u.avatar,u.yx_id,u.created_at FROM invites i JOIN users u ON u.id=i.invitee_uid WHERE i.uid=? ORDER BY i.id DESC LIMIT 50',
        [$uid]
    );
    ok([
        'code'    => $code,
        'count'   => $count,
        'earned'  => $earned,
        'reward'  => (int)setting('invite_reward', '0'),
        'url'     => site_url('register.php?invite=' . $code),
        'rewards' => $rewards,
        'next'    => $next,
        'invited' => array_map(static function ($u) {
            return [
                'id' => (int)$u['id'], 'nickname' => $u['nickname'], 'avatar' => $u['avatar'],
                'yx_id' => $u['yx_id'] ?: '', 'created_at' => (int)$u['created_at'],
            ];
        }, $invited),
    ]);
};

$API_CORE['invite_claim'] = function ($me) {
    $uid = (int)$me['id'];
    $rid = inp_int('reward_id');
    if ($rid <= 0) fail('参数错误');
    $r = one('SELECT * FROM invite_rewards WHERE id=? AND status=1', [$rid]);
    if (!$r) fail('奖励不存在或已下架');
    if (one('SELECT id FROM invite_claims WHERE uid=? AND reward_id=?', [$uid, $rid])) fail('该奖励已领取过');
    $count = (int)val('SELECT COUNT(*) FROM invites WHERE uid=?', [$uid]);
    $need = max(1, (int)$r['need_count']);
    if ($count < $need) fail('还差 ' . ($need - $count) . ' 人才能领取');

    $type = (string)$r['type'];
    $days = max(1, (int)$r['days']);
    $level = max(1, (int)$r['level']);
    if ($type === 'coin') {
        $coin = max(1, (int)$r['coin']);
        add_coin($uid, $coin, 'invite', $rid, '邀请奖励：' . $r['name']);
        $msg = '已发放 ' . $coin . ' CC币';
    } elseif ($type === 'vip' || $type === 'svip') {
        $u = one('SELECT * FROM users WHERE id=?', [$uid]);
        $active = (int)$u['vip_level'] > 0 && (int)$u['vip_expire_at'] > now();
        $base = $active ? (int)$u['vip_expire_at'] : now();
        $lv = $active ? max((int)$u['vip_level'], $level) : $level;
        q('UPDATE users SET vip_level=?, vip_expire_at=? WHERE id=?', [$lv, $base + $days * 86400, $uid]);
        $msg = '已开通 ' . vip_label($lv) . ' ' . $days . ' 天';
    } elseif ($type === 'pretty') {
        // 自动分配一个未售出的靓号
        $p = one('SELECT * FROM pretty_ids WHERE status=0 ORDER BY price ASC, id ASC LIMIT 1');
        if ($p) {
            $u = one('SELECT * FROM users WHERE id=?', [$uid]);
            $old = (string)($u['pretty_yxid'] ?: '');
            // 领取即从号池删除，避免被二次发放
            q('DELETE FROM pretty_ids WHERE id=? AND status=0', [(int)$p['id']]);
            q('UPDATE users SET pretty_yxid=? WHERE id=?', [(string)$p['yx_id'], $uid]);
            $msg = '已获得靓号 ' . $p['yx_id'] . ($old !== '' ? '（原靓号已释放）' : '');
        } else {
            fail('靓号库存不足，请联系客服');
        }
    } else {
        fail('奖励类型不支持');
    }

    try {
        q('INSERT INTO invite_claims (uid,reward_id,created_at) VALUES (?,?,?)', [$uid, $rid, now()]);
    } catch (Throwable $e) {
        fail('领取失败，请重试');
    }
    ok(['count' => $count], $msg);
};

/* =========================================================
 * 全局未读 / 提醒
 * ========================================================= */
$API_CORE['unread_total'] = function ($me) {
    $uid = (int)$me['id'];
    $chat = (int)val('SELECT COALESCE(SUM(unread),0) FROM conversations WHERE uid=? AND visible=1 AND muted=0', [$uid]);
    $req  = (int)val('SELECT COUNT(*) FROM friend_requests WHERE to_uid=? AND status=0', [$uid]);
    $gj   = (int)val('SELECT COUNT(*) FROM group_join_requests r JOIN groups g ON g.gid=r.gid WHERE g.owner_uid=? AND r.status=0', [$uid]);
    $notice = (int)val('SELECT COUNT(*) FROM notices n WHERE n.status=1 AND NOT EXISTS (SELECT 1 FROM notice_reads nr WHERE nr.nid=n.id AND nr.uid=?)', [$uid]);
    ok(['chat' => $chat, 'friend_req' => $req, 'group_req' => $gj, 'notice' => $notice, 'total' => $chat + $req + $gj]);
};

$API_CORE['contacts_unread'] = function ($me) {
    $uid = (int)$me['id'];
    ok([
        'friend_req' => (int)val('SELECT COUNT(*) FROM friend_requests WHERE to_uid=? AND status=0', [$uid]),
        'group_req'  => (int)val('SELECT COUNT(*) FROM group_join_requests r JOIN groups g ON g.gid=r.gid WHERE g.owner_uid=? AND r.status=0', [$uid]),
        'notice'     => (int)val('SELECT COUNT(*) FROM notices n WHERE n.status=1 AND NOT EXISTS (SELECT 1 FROM notice_reads nr WHERE nr.nid=n.id AND nr.uid=?)', [$uid]),
    ]);
};

$API_CORE['poll_notify'] = function ($me) {
    ok(['time' => now(), 'unread' => (int)val('SELECT COALESCE(SUM(unread),0) FROM conversations WHERE uid=?', [(int)$me['id']])]);
};
