<?php
/**
 * CC商聊 - API：语音/视频通话、群通话、群直播（WebRTC 信令）
 */
declare(strict_types=1);

$API_RTC = [];

function rtc_cfg_ice(): array
{
    return cfg('webrtc.ice', [['urls' => 'stun:stun.l.google.com:19302']]);
}

$API_RTC['call_invite'] = function ($me) {
    if ((string)setting('call_enabled', '1') !== '1') fail('通话功能已关闭');
    $ctype = inp_int('ctype', 1);
    $peer = inp_int('to', inp_int('peer'));
    $media = inp_int('media', 1); // 1 语音 2 视频
    $uid = (int)$me['id'];
    if ($peer <= 0) fail('参数错误');

    $callId = bin2hex(random_bytes(16));
    $now = now();
    if ($ctype === 1) {
        $to = one('SELECT * FROM users WHERE id=?', [$peer]);
        if (!$to) fail('对方不存在');
        // 同一对用户已有进行中的通话则复用
        $exist = one('SELECT * FROM calls WHERE ctype=1 AND status IN (0,1) AND ((from_uid=? AND to_uid=?) OR (from_uid=? AND to_uid=?)) ORDER BY id DESC LIMIT 1', [$uid, $peer, $peer, $uid]);
        if ($exist) {
            ok(['call_id' => $exist['call_id'], 'reused' => 1, 'ice' => rtc_cfg_ice()]);
        }
        q('INSERT INTO calls (call_id,ctype,from_uid,to_uid,gid,media,status,created_at) VALUES (?,?,?,?,0,?,0,?)', [
            $callId, 1, $uid, $peer, $media, $now,
        ]);
        $label = $media === 2 ? '视频' : '语音';
        push_message(['ctype' => 1, 'from_uid' => $uid, 'to_uid' => $peer, 'gid' => 0, 'type' => 14,
            'content' => json_encode(['call_id' => $callId, 'media' => $media, 'state' => 'calling', 'label' => $label], JSON_UNESCAPED_UNICODE)]);
        ok(['call_id' => $callId, 'media' => $media, 'ice' => rtc_cfg_ice()]);
    }

    // 群通话
    if (!group_member($peer, $uid)) fail('你不在该群聊中');
    q('INSERT INTO calls (call_id,ctype,from_uid,to_uid,gid,media,status,created_at) VALUES (?,?,?,?,?,?,0,?)', [
        $callId, 2, $uid, 0, $peer, $media, $now,
    ]);
    push_message(['ctype' => 2, 'from_uid' => $uid, 'to_uid' => 0, 'gid' => $peer, 'type' => 14,
        'content' => json_encode(['call_id' => $callId, 'media' => $media, 'state' => 'group_calling', 'label' => '群' . ($media === 2 ? '视频' : '语音') . '通话'], JSON_UNESCAPED_UNICODE)]);
    ok(['call_id' => $callId, 'media' => $media, 'ice' => rtc_cfg_ice()]);
};

$API_RTC['call_info'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    if (!$c) fail('通话不存在');
    $from = one('SELECT * FROM users WHERE id=?', [(int)$c['from_uid']]);
    $to = (int)$c['to_uid'] ? one('SELECT * FROM users WHERE id=?', [(int)$c['to_uid']]) : null;
    $uid = (int)$me['id'];
    if ((int)$c['ctype'] === 1 && $uid !== (int)$c['from_uid'] && $uid !== (int)$c['to_uid']) fail('无权限');
    if ((int)$c['ctype'] === 2 && !group_member((int)$c['gid'], $uid)) fail('无权限');
    ok([
        'call_id' => $c['call_id'], 'ctype' => (int)$c['ctype'], 'media' => (int)$c['media'],
        'status' => (int)$c['status'], 'from' => user_public($from), 'to' => $to ? user_public($to) : null,
        'gid' => (int)$c['gid'], 'created_at' => (int)$c['created_at'], 'ice' => rtc_cfg_ice(),
        'is_caller' => $uid === (int)$c['from_uid'] ? 1 : 0,
    ]);
};

$API_RTC['call_answer'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    if (!$c) fail('通话不存在');
    if ((int)$c['status'] !== 0) {
        ok(['status' => (int)$c['status']]);
    }
    q('UPDATE calls SET status=1, answered_at=? WHERE call_id=?', [now(), $callId]);
    ok(['status' => 1], '已接通');
};

$API_RTC['call_reject'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    if (!$c) fail('通话不存在');
    q('UPDATE calls SET status=3, ended_at=? WHERE call_id=?', [now(), $callId]);
    $payload = json_encode(['call_id' => $callId, 'media' => (int)$c['media'], 'state' => 'rejected', 'label' => '已拒绝'], JSON_UNESCAPED_UNICODE);
    $target = (int)$c['from_uid'] === (int)$me['id'] ? (int)$c['to_uid'] : (int)$c['from_uid'];
    if ($target) push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $target, 'gid' => 0, 'type' => 14, 'content' => $payload]);
    ok(null, '已拒绝');
};

$API_RTC['call_end'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    if (!$c) fail('通话不存在');
    if ((int)$c['status'] === 2) ok(null, '已结束');
    $dur = (int)$c['answered_at'] > 0 ? now() - (int)$c['answered_at'] : 0;
    q('UPDATE calls SET status=2, ended_at=?, duration=? WHERE call_id=?', [now(), $dur, $callId]);
    $label = $dur > 0 ? '通话时长 ' . gmdate($dur >= 3600 ? 'H:i:s' : 'i:s', $dur) : '已取消';
    $payload = json_encode(['call_id' => $callId, 'media' => (int)$c['media'], 'state' => 'ended', 'duration' => $dur, 'label' => $label], JSON_UNESCAPED_UNICODE);
    if ((int)$c['ctype'] === 1) {
        $peer = (int)$c['from_uid'] === (int)$me['id'] ? (int)$c['to_uid'] : (int)$c['from_uid'];
        push_message(['ctype' => 1, 'from_uid' => (int)$me['id'], 'to_uid' => $peer, 'gid' => 0, 'type' => 14, 'content' => $payload]);
    } else {
        push_message(['ctype' => 2, 'from_uid' => (int)$me['id'], 'gid' => (int)$c['gid'], 'to_uid' => 0, 'type' => 14, 'content' => $payload]);
    }
    ok(['duration' => $dur], '通话已结束');
};

$API_RTC['call_signal'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $kind = (string)inp('kind', ''); // offer|answer|ice
    $to = inp_int('to');
    $payload = inp('payload', null);
    if (!in_array($kind, ['offer', 'answer', 'ice'], true)) fail('信令类型错误');
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    if (!$c) fail('通话不存在');
    if (!is_string($payload)) $payload = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ((int)$c['ctype'] === 2 && $to <= 0) fail('缺少目标');
    q('INSERT INTO call_signals (call_id,from_uid,to_uid,kind,payload,created_at,consumed) VALUES (?,?,?,?,?,?,0)', [
        $callId, (int)$me['id'], (int)$to, $kind, (string)$payload, now(),
    ]);
    ok(null, 'ok');
};

$API_RTC['call_poll'] = function ($me) {
    $callId = (string)inp('call_id', '');
    $uid = (int)$me['id'];
    $rows = all('SELECT id,from_uid,kind,payload,created_at FROM call_signals WHERE call_id=? AND to_uid=? AND consumed=0 ORDER BY id ASC LIMIT 50', [$callId, $uid]);
    foreach ($rows as $r) q('UPDATE call_signals SET consumed=1 WHERE id=?', [(int)$r['id']]);
    $c = one('SELECT * FROM calls WHERE call_id=?', [$callId]);
    ok(['signals' => $rows, 'status' => $c ? (int)$c['status'] : -1, 'answered_at' => $c ? (int)$c['answered_at'] : 0, 'ended_at' => $c ? (int)$c['ended_at'] : 0]);
};

/* =========================================================
 * 直播
 * ========================================================= */
$API_RTC['live_create'] = function ($me) {
    if ((string)setting('live_enabled', '1') !== '1') fail('直播功能已关闭');
    $title = mb_substr(trim((string)inp('title', $me['nickname'] . ' 的直播')), 0, 60);
    $gid = inp_int('gid');
    $cover = (string)inp('cover', '');
    if ($gid && !group_member($gid, (int)$me['id'])) fail('你不在该群聊中');
    $open = one('SELECT * FROM live_rooms WHERE uid=? AND status=0 ORDER BY id DESC LIMIT 1', [(int)$me['id']]);
    if ($open) {
        ok(['room' => $open], '你已有正在进行的直播');
    }
    // 生成未被占用的 6 位房间号，并清理该房间可能残留的历史信令
    $roomNo = '';
    for ($i = 0; $i < 30; $i++) {
        $try = (string)random_int(100000, 999999);
        if (!val('SELECT id FROM live_rooms WHERE room_no=?', [$try])) { $roomNo = $try; break; }
    }
    if ($roomNo === '') $roomNo = (string)random_int(100000, 999999);
    q('DELETE FROM call_signals WHERE call_id=?', ['live:' . $roomNo]);
    q('INSERT INTO live_rooms (room_no,uid,gid,title,cover,status,viewers,created_at) VALUES (?,?,?,?,?,0,0,?)', [
        $roomNo, (int)$me['id'], $gid, $title, $cover, now(),
    ]);
    $room = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNo]);
    $payload = json_encode(['room_no' => $roomNo, 'title' => $title, 'cover' => $cover, 'uid' => (int)$me['id'], 'name' => $me['nickname']], JSON_UNESCAPED_UNICODE);
    if ($gid) {
        push_message(['ctype' => 2, 'from_uid' => (int)$me['id'], 'gid' => $gid, 'to_uid' => 0, 'type' => 19, 'content' => $payload]);
    }
    ok(['room' => $room], '直播已开启');
};

$API_RTC['live_info'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $r = one('SELECT * FROM live_rooms WHERE room_no=? OR id=?', [$roomNo, (int)$roomNo]);
    if (!$r) fail('直播间不存在');
    $host = one('SELECT * FROM users WHERE id=?', [(int)$r['uid']]);
    $g = (int)$r['gid'] ? group_by_gid((int)$r['gid']) : null;
    ok([
        'room' => ['id' => (int)$r['id'], 'room_no' => $r['room_no'], 'title' => $r['title'], 'cover' => $r['cover'],
                   'status' => (int)$r['status'], 'viewers' => (int)$r['viewers'], 'created_at' => (int)$r['created_at'], 'gid' => (int)$r['gid']],
        'host' => user_public($host),
        'group' => $g ? ['gid' => (int)$g['gid'], 'name' => $g['name'], 'avatar' => $g['avatar']] : null,
        'ice' => rtc_cfg_ice(),
        'is_host' => (int)$r['uid'] === (int)$me['id'] ? 1 : 0,
    ]);
};

$API_RTC['live_join'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $r = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNo]);
    if (!$r) fail('直播间不存在');
    if ((int)$r['status'] !== 0) fail('直播已结束');
    q('UPDATE live_rooms SET viewers=viewers+1 WHERE id=?', [(int)$r['id']]);
    ok(['room' => $r]);
};

$API_RTC['live_leave'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $r = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNo]);
    if ($r) q('UPDATE live_rooms SET viewers=CASE WHEN viewers>0 THEN viewers-1 ELSE 0 END WHERE id=?', [(int)$r['id']]);
    ok(null, 'ok');
};

$API_RTC['live_end'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $r = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNo]);
    if (!$r) fail('直播间不存在');
    if ((int)$r['uid'] !== (int)$me['id']) fail('只有主播可以结束直播');
    q('UPDATE live_rooms SET status=1, ended_at=? WHERE id=?', [now(), (int)$r['id']]);
    ok(null, '直播已结束');
};

$API_RTC['live_msg'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $r = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNo]);
    if (!$r) fail('直播间不存在');
    $content = trim((string)inp('content', ''));
    if ($content !== '') {
        if (mb_strlen($content) > 200) fail('弹幕最多 200 字');
        q('INSERT INTO live_messages (room_id,uid,content,type,created_at) VALUES (?,?,?,1,?)', [(int)$r['id'], (int)$me['id'], $content, now()]);
    }
    $since = inp_int('since', 0);
    $rows = all('SELECT lm.*, u.nickname, u.avatar FROM live_messages lm JOIN users u ON u.id=lm.uid WHERE lm.room_id=? AND lm.id>? ORDER BY lm.id ASC LIMIT 100', [(int)$r['id'], $since]);
    $viewers = (int)val('SELECT viewers FROM live_rooms WHERE id=?', [(int)$r['id']]);
    ok(['list' => $rows, 'viewers' => $viewers, 'status' => (int)val('SELECT status FROM live_rooms WHERE id=?', [(int)$r['id']])]);
};

$API_RTC['live_list'] = function ($me) {
    $rows = all('SELECT l.*, u.nickname, u.avatar FROM live_rooms l JOIN users u ON u.id=l.uid WHERE l.status=0 ORDER BY l.id DESC LIMIT 50');
    ok(['list' => $rows]);
};

/* 直播信令：复用 call_signals，call_id = "live:房间号" */
$API_RTC['live_signal'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $kind = (string)inp('kind', '');
    $to = inp_int('to');
    $payload = inp('payload', null);
    if (!in_array($kind, ['offer', 'answer', 'ice'], true)) fail('信令类型错误');
    $callId = 'live:' . $roomNo;
    if (!is_string($payload)) $payload = json_encode($payload, JSON_UNESCAPED_UNICODE);
    q('INSERT INTO call_signals (call_id,from_uid,to_uid,kind,payload,created_at,consumed) VALUES (?,?,?,?,?,?,0)', [
        $callId, (int)$me['id'], $to, $kind, (string)$payload, now(),
    ]);
    ok(null, 'ok');
};

$API_RTC['live_poll'] = function ($me) {
    $roomNo = (string)inp('room_no', '');
    $callId = 'live:' . $roomNo;
    // 只取最近 60 秒内的信令：过期 offer/answer 会让新连接错乱
    $rows = all('SELECT id,from_uid,kind,payload FROM call_signals WHERE call_id=? AND to_uid=? AND consumed=0 AND created_at>=? ORDER BY id ASC LIMIT 50',
        [$callId, (int)$me['id'], now() - 60]);
    foreach ($rows as $r) q('UPDATE call_signals SET consumed=1 WHERE id=?', [(int)$r['id']]);
    ok(['signals' => $rows]);
};
