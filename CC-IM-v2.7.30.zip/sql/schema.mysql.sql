-- CC商聊 MySQL 建表脚本（install.php 亦可自动建表）
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS settings (k VARCHAR(64) NOT NULL PRIMARY KEY, v TEXT);

CREATE TABLE IF NOT EXISTS admins (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(64) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'ops',
        status INT NOT NULL DEFAULT 0,
        last_login_at INT NOT NULL DEFAULT 0,
        last_ip VARCHAR(64) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        account VARCHAR(32) NOT NULL UNIQUE,
        yx_id VARCHAR(32) NOT NULL DEFAULT '',
        pretty_yxid VARCHAR(32) NOT NULL DEFAULT '',
        nickname VARCHAR(64) NOT NULL DEFAULT '',
        avatar VARCHAR(255) NOT NULL DEFAULT '',
        bio VARCHAR(255) NOT NULL DEFAULT '',
        gender INT NOT NULL DEFAULT 0,
        region VARCHAR(64) NOT NULL DEFAULT '',
        email VARCHAR(128) NOT NULL DEFAULT '',
        phone VARCHAR(32) NOT NULL DEFAULT '',
        password VARCHAR(255) NOT NULL,
        pay_password VARCHAR(255) NOT NULL DEFAULT '',
        coin INT NOT NULL DEFAULT 0,
        total_income INT NOT NULL DEFAULT 0,
        total_expense INT NOT NULL DEFAULT 0,
        vip_level INT NOT NULL DEFAULT 0,
        vip_expire_at INT NOT NULL DEFAULT 0,
        is_developer INT NOT NULL DEFAULT 0,
        status INT NOT NULL DEFAULT 0,
        ban_reason VARCHAR(255) NOT NULL DEFAULT '',
        ban_until INT NOT NULL DEFAULT 0,
        ban_forever INT NOT NULL DEFAULT 0,
        invite_code VARCHAR(16) NOT NULL DEFAULT '',
        invited_by INT NOT NULL DEFAULT 0,
        device_id VARCHAR(64) NOT NULL DEFAULT '',
        online INT NOT NULL DEFAULT 0,
        settings TEXT,
        created_at INT NOT NULL DEFAULT 0,
        last_active_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS devices (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        device_id VARCHAR(64) NOT NULL DEFAULT '',
        token VARCHAR(128) NOT NULL DEFAULT '',
        ua VARCHAR(255) NOT NULL DEFAULT '',
        ip VARCHAR(64) NOT NULL DEFAULT '',
        last_active_at INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_logs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, ip VARCHAR(64) NOT NULL DEFAULT '', ua VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS friends (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        fid INT NOT NULL,
        remark VARCHAR(64) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 1,
        created_at INT NOT NULL DEFAULT 0,
        UNIQUE (uid, fid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS friend_requests (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL,
        reason VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        handled_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS groups (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        gid INT NOT NULL UNIQUE,
        name VARCHAR(64) NOT NULL DEFAULT '',
        avatar VARCHAR(255) NOT NULL DEFAULT '',
        intro VARCHAR(512) NOT NULL DEFAULT '',
        owner_uid INT NOT NULL DEFAULT 0,
        member_limit INT NOT NULL DEFAULT 100,
        join_mode INT NOT NULL DEFAULT 0,
        is_public INT NOT NULL DEFAULT 1,
        mute_all INT NOT NULL DEFAULT 0,
        status INT NOT NULL DEFAULT 1,
        created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS group_members (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        gid INT NOT NULL,
        uid INT NOT NULL,
        role INT NOT NULL DEFAULT 0,
        nickname VARCHAR(64) NOT NULL DEFAULT '',
        mute_until INT NOT NULL DEFAULT 0,
        joined_at INT NOT NULL DEFAULT 0,
        last_read_id INT NOT NULL DEFAULT 0,
        pinned INT NOT NULL DEFAULT 0,
        UNIQUE (gid, uid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS group_join_requests (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        gid INT NOT NULL,
        uid INT NOT NULL,
        reason VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS group_notices (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, gid INT NOT NULL, uid INT NOT NULL, content TEXT, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversations (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        ctype INT NOT NULL DEFAULT 1,
        peer_id INT NOT NULL,
        last_msg VARCHAR(255) NOT NULL DEFAULT '',
        last_time INT NOT NULL DEFAULT 0,
        unread INT NOT NULL DEFAULT 0,
        pinned INT NOT NULL DEFAULT 0,
        muted INT NOT NULL DEFAULT 0,
        visible INT NOT NULL DEFAULT 1,
        UNIQUE (uid, ctype, peer_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS messages (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ctype INT NOT NULL DEFAULT 1,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        type INT NOT NULL DEFAULT 1,
        content TEXT,
        extra TEXT,
        created_at INT NOT NULL DEFAULT 0,
        recalled INT NOT NULL DEFAULT 0,
        deleted INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moment (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        content TEXT,
        images TEXT,
        video VARCHAR(255) NOT NULL DEFAULT '',
        visibility INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        deleted INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moment_likes (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, mid INT NOT NULL, uid INT NOT NULL, created_at INT NOT NULL DEFAULT 0, UNIQUE (mid, uid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moment_comments (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, mid INT NOT NULL, uid INT NOT NULL, reply_uid INT NOT NULL DEFAULT 0, content VARCHAR(1000) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0, deleted INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moment_reads (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL UNIQUE, last_read_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notices (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, title VARCHAR(128) NOT NULL DEFAULT '', content TEXT, is_top INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 1, created_at INT NOT NULL DEFAULT 0, updated_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notice_reads (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, nid INT NOT NULL, uid INT NOT NULL, read_at INT NOT NULL DEFAULT 0, UNIQUE (nid, uid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallet_logs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, direction INT NOT NULL DEFAULT 1, amount INT NOT NULL DEFAULT 0, balance_after INT NOT NULL DEFAULT 0,
        biz VARCHAR(32) NOT NULL DEFAULT '', biz_id INT NOT NULL DEFAULT 0, remark VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recharge_orders (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        order_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        coin INT NOT NULL DEFAULT 0,
        rate INT NOT NULL DEFAULT 7,
        amount_usdt VARCHAR(32) NOT NULL DEFAULT '0',
        address VARCHAR(128) NOT NULL DEFAULT '',
        network VARCHAR(16) NOT NULL DEFAULT 'TRC20',
        status INT NOT NULL DEFAULT 0,
        txid VARCHAR(128) NOT NULL DEFAULT '',
        pay_tx VARCHAR(128) NOT NULL DEFAULT '',
        remark VARCHAR(255) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0,
        paid_at INT NOT NULL DEFAULT 0,
        admin_id INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS withdraw_orders (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        order_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        amount INT NOT NULL DEFAULT 0,
        account VARCHAR(128) NOT NULL DEFAULT '',
        qr VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        remark VARCHAR(255) NOT NULL DEFAULT '',
        created_at INT NOT NULL DEFAULT 0,
        handled_at INT NOT NULL DEFAULT 0,
        admin_id INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS red_packets (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        packet_no VARCHAR(40) NOT NULL UNIQUE,
        uid INT NOT NULL,
        ctype INT NOT NULL DEFAULT 1,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        rp_type INT NOT NULL DEFAULT 1,
        total INT NOT NULL DEFAULT 0,
        count INT NOT NULL DEFAULT 0,
        remaining INT NOT NULL DEFAULT 0,
        remain_count INT NOT NULL DEFAULT 0,
        blessing VARCHAR(128) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        expire_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS red_packet_records (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, pid INT NOT NULL, uid INT NOT NULL, coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, UNIQUE (pid, uid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transfers (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, from_uid INT NOT NULL, to_uid INT NOT NULL, coin INT NOT NULL DEFAULT 0, note VARCHAR(128) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gifts (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(64) NOT NULL DEFAULT '', icon VARCHAR(255) NOT NULL DEFAULT '', price INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 1, sort INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gift_records (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, from_uid INT NOT NULL, to_uid INT NOT NULL DEFAULT 0, gid INT NOT NULL DEFAULT 0, gift_id INT NOT NULL, count INT NOT NULL DEFAULT 1, coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vip_plans (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(64) NOT NULL DEFAULT '', days INT NOT NULL DEFAULT 30, price INT NOT NULL DEFAULT 0, level INT NOT NULL DEFAULT 1, status INT NOT NULL DEFAULT 1, sort INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pretty_ids (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, yx_id VARCHAR(32) NOT NULL UNIQUE, price INT NOT NULL DEFAULT 0, status INT NOT NULL DEFAULT 0, buyer_uid INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, sold_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS emojis (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL DEFAULT 0, name VARCHAR(64) NOT NULL DEFAULT '', url VARCHAR(255) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS favorites (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, mtype INT NOT NULL DEFAULT 1, content TEXT, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS calls (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        call_id VARCHAR(48) NOT NULL UNIQUE,
        ctype INT NOT NULL DEFAULT 1,
        from_uid INT NOT NULL,
        to_uid INT NOT NULL DEFAULT 0,
        gid INT NOT NULL DEFAULT 0,
        media INT NOT NULL DEFAULT 1,
        status INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        answered_at INT NOT NULL DEFAULT 0,
        ended_at INT NOT NULL DEFAULT 0,
        duration INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS call_signals (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, call_id VARCHAR(48) NOT NULL, from_uid INT NOT NULL, to_uid INT NOT NULL DEFAULT 0,
        kind VARCHAR(16) NOT NULL DEFAULT '', payload TEXT, created_at INT NOT NULL DEFAULT 0, consumed INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS live_rooms (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        room_no VARCHAR(32) NOT NULL UNIQUE,
        uid INT NOT NULL,
        gid INT NOT NULL DEFAULT 0,
        title VARCHAR(128) NOT NULL DEFAULT '',
        cover VARCHAR(255) NOT NULL DEFAULT '',
        status INT NOT NULL DEFAULT 0,
        viewers INT NOT NULL DEFAULT 0,
        created_at INT NOT NULL DEFAULT 0,
        ended_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS live_messages (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, room_id INT NOT NULL, uid INT NOT NULL, content VARCHAR(500) NOT NULL DEFAULT '', type INT NOT NULL DEFAULT 1, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reports (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, from_uid INT NOT NULL, target_type VARCHAR(20) NOT NULL DEFAULT '', target_id INT NOT NULL DEFAULT 0,
        reason VARCHAR(128) NOT NULL DEFAULT '', detail VARCHAR(500) NOT NULL DEFAULT '', status INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS appeals (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL DEFAULT 0, account VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(500) NOT NULL DEFAULT '',
        contact VARCHAR(128) NOT NULL DEFAULT '', status INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0, handled_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_logs (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, admin_id INT NOT NULL DEFAULT 0, action VARCHAR(64) NOT NULL DEFAULT '', detail VARCHAR(500) NOT NULL DEFAULT '', ip VARCHAR(64) NOT NULL DEFAULT '', created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS verify_codes (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, target VARCHAR(128) NOT NULL DEFAULT '', code VARCHAR(16) NOT NULL DEFAULT '', purpose VARCHAR(32) NOT NULL DEFAULT '',
        expire_at INT NOT NULL DEFAULT 0, used INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invites (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, uid INT NOT NULL, invitee_uid INT NOT NULL DEFAULT 0, reward_coin INT NOT NULL DEFAULT 0, created_at INT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_msg_private ON messages (ctype, from_uid, to_uid, id);
CREATE INDEX idx_msg_group ON messages (gid, id);
CREATE INDEX idx_msg_created ON messages (created_at);
CREATE INDEX idx_conv_uid ON conversations (uid, last_time);
CREATE INDEX idx_gm_uid ON group_members (uid);
CREATE INDEX idx_wallet_uid ON wallet_logs (uid, id);
CREATE INDEX idx_moment_uid ON moment (uid, id);
CREATE INDEX idx_likes_mid ON moment_likes (mid);
CREATE INDEX idx_comments_mid ON moment_comments (mid);
CREATE INDEX idx_call_signals ON call_signals (call_id, to_uid, consumed);
CREATE INDEX idx_login_uid ON login_logs (uid, id);
CREATE INDEX idx_recharge_uid ON recharge_orders (uid, id);
CREATE INDEX idx_withdraw_uid ON withdraw_orders (uid, id);
