<?php
/**
 * CC商聊 - 通知设置
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$S = json_decode_arr($me['settings'] ?? '');
$val = static function (string $k, string $d = '1') use ($S): string {
    return (string)($S[$k] ?? $d);
};
cc_head('通知设置', ['body_class' => 'app-body', 'css' => '
.pv-sec{font-size:12.5px;color:var(--t3);padding:18px 18px 8px;font-weight:600;display:flex;align-items:center;gap:7px}
.pv-sec::before{content:"";width:3px;height:12px;border-radius:2px;background:var(--brand)}
.pv-item{display:flex;align-items:flex-start;gap:12px;padding:15px 16px;background:var(--card);cursor:pointer}
.pv-item+.pv-item{border-top:1px solid var(--line)}
.pv-main{flex:1;min-width:0}
.pv-t{font-size:15px;font-weight:500}
.pv-s{font-size:11.5px;color:var(--t3);line-height:1.65;margin-top:4px}
.sw{position:relative;width:48px;height:28px;flex:0 0 auto;border-radius:16px;background:#D5DBE6;transition:.2s;margin-top:2px}
.sw::after{content:"";position:absolute;width:24px;height:24px;border-radius:50%;background:#fff;left:2px;top:2px;transition:.2s;box-shadow:0 1px 4px rgba(0,0,0,.18)}
.sw.on{background:var(--brand)}
.sw.on::after{transform:translateX(20px)}
.time-row{display:flex;align-items:center;gap:8px;padding:0 16px 14px;background:var(--card);font-size:13px;color:var(--t2)}
.time-row input{width:66px;height:34px;border-radius:9px;background:var(--bg);text-align:center;font-size:13px}
']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('通知设置', 'me.php'); ?>
    <div class="page-body no-tab">

      <div class="pv-sec">消息通知</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" data-k="notify_on" data-v="<?= e($val('notify_on')) ?>">
          <div class="pv-main">
            <div class="pv-t">接收新消息通知</div>
            <div class="pv-s">关闭后新消息不再提醒，消息仍会正常接收</div>
          </div>
          <span class="sw <?= $val('notify_on') === '1' ? 'on' : '' ?>"></span>
        </div>
        <div class="pv-item" data-k="notify_sound" data-v="<?= e($val('notify_sound')) ?>">
          <div class="pv-main"><div class="pv-t">声音</div></div>
          <span class="sw <?= $val('notify_sound') === '1' ? 'on' : '' ?>"></span>
        </div>
        <div class="pv-item" data-k="notify_vibrate" data-v="<?= e($val('notify_vibrate')) ?>">
          <div class="pv-main"><div class="pv-t">震动</div></div>
          <span class="sw <?= $val('notify_vibrate') === '1' ? 'on' : '' ?>"></span>
        </div>
      </div>

      <div class="pv-sec">群通知</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" data-k="notify_group" data-v="<?= e($val('notify_group')) ?>">
          <div class="pv-main">
            <div class="pv-t">接收群消息通知</div>
            <div class="pv-s">单个群的提醒可在会话列表长按设置</div>
          </div>
          <span class="sw <?= $val('notify_group') === '1' ? 'on' : '' ?>"></span>
        </div>
      </div>

      <div class="pv-sec">免打扰时段</div>
      <div class="cell-group" style="margin:0 12px;padding-bottom:0">
        <div class="pv-item" data-k="dnd_on" data-v="<?= e($val('dnd_on', '0')) ?>">
          <div class="pv-main"><div class="pv-t">开启免打扰</div></div>
          <span class="sw <?= $val('dnd_on', '0') === '1' ? 'on' : '' ?>"></span>
        </div>
        <div class="time-row" id="dndTime" style="<?= $val('dnd_on', '0') === '1' ? '' : 'display:none' ?>">
          <span>从</span><input id="dndStart" type="text" inputmode="numeric" maxlength="5" value="<?= e($val('dnd_start', '22:00')) ?>">
          <span>到</span><input id="dndEnd" type="text" inputmode="numeric" maxlength="5" value="<?= e($val('dnd_end', '08:00')) ?>">
          <span style="color:var(--t3);font-size:11.5px">（24 小时制）</span>
        </div>
      </div>
      <div class="hint-line" style="padding:0 20px">免打扰时段内不弹系统通知，消息仍会正常接收并计入未读。</div>

      <div class="pv-sec">系统通知权限</div>
      <div class="cell-group" style="margin:0 12px">
        <div class="pv-item" id="cellBrowserNotify">
          <div class="pv-main">
            <div class="pv-t">浏览器通知</div>
            <div class="pv-s" id="bnDesc">正在检测当前浏览器是否支持网页通知…</div>
          </div>
          <span class="badge gray" id="bnState">检测中</span>
        </div>
      </div>

      <div style="height:30px"></div>
    </div>
  </div>
</div>

<script>window.ME = <?= cc_me_json($me) ?>;</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  document.querySelectorAll('.pv-item[data-k]').forEach(function(row){
    row.onclick = function(){
      var k = row.getAttribute('data-k');
      var cur = row.getAttribute('data-v') === '1' ? '1' : '0';
      var next = cur === '1' ? '0' : '1';
      var sw = row.querySelector('.sw');
      var payload = {}; payload[k] = next;
      row.setAttribute('data-v', next);
      sw.classList.toggle('on', next === '1');
      if (k === 'dnd_on'){
        var t = document.getElementById('dndTime');
        if (t) t.style.display = next === '1' ? '' : 'none';
      }
      CC.api('update_settings', payload).then(function(){
        CC.toast(next === '1' ? '已开启' : '已关闭');
      }).catch(function(e){
        row.setAttribute('data-v', cur);
        sw.classList.toggle('on', cur === '1');
        CC.toast(e.message);
      });
    };
  });

  /* 免打扰时间段保存 */
  ['dndStart','dndEnd'].forEach(function(id){
    var el = document.getElementById(id);
    if (!el) return;
    el.onblur = function(){
      var v = (el.value || '').trim();
      if (!/^([01]?\d|2[0-3])[:：]?([0-5]\d)$/.test(v)){ CC.toast('时间格式应为 22:00'); return; }
      v = v.replace('：', ':');
      if (v.indexOf(':') < 0) v = v.slice(0, -2) + ':' + v.slice(-2);
      el.value = v;
      var payload = {};
      payload[id === 'dndStart' ? 'dnd_start' : 'dnd_end'] = v;
      CC.api('update_settings', payload).then(function(){ CC.toast('已保存'); }).catch(function(e){ CC.toast(e.message); });
    };
  });

  /* 浏览器通知能力检测 */
  var st = document.getElementById('bnState'), desc = document.getElementById('bnDesc');
  function refresh(){
    if (!('Notification' in window)){ st.textContent = '不支持'; st.className = 'badge gray';
      desc.textContent = '当前浏览器不支持网页通知，可在手机系统设置里打开 App 通知'; return; }
    var p = Notification.permission;
    if (p === 'granted'){ st.textContent = '已开启'; st.className = 'badge'; desc.textContent = '已授权网页通知，收到新消息时会弹出系统通知'; }
    else if (p === 'denied'){ st.textContent = '已拒绝'; st.className = 'badge gray'; desc.textContent = '你已拒绝通知权限，可在浏览器站点设置中重新开启'; }
    else { st.textContent = '未开启'; st.className = 'badge gray'; desc.textContent = '点击此处开启网页通知'; }
  }
  refresh();
  document.getElementById('cellBrowserNotify').onclick = function(){
    if (!('Notification' in window)){ CC.toast('当前浏览器不支持网页通知'); return; }
    if (Notification.permission === 'granted'){ new Notification('CC商聊', { body: '通知已开启' }); return; }
    if (Notification.permission === 'denied'){ CC.toast('已被拒绝，请在浏览器设置里开启'); return; }
    Notification.requestPermission().then(function(){ refresh(); });
  };
})();
</script>
<?php cc_foot(); ?>
