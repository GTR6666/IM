<?php
/**
 * CC商聊 - 消息（会话列表 + 聊天）
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$siteName = setting('site_name', 'CC商聊');
// 只取「当前用户尚未读」的最新一条公告用于弹窗（已读的不再打扰）
$notice = one(
    'SELECT n.* FROM notices n WHERE n.status=1 AND NOT EXISTS ('
    . 'SELECT 1 FROM notice_reads r WHERE r.nid=n.id AND r.uid=?'
    . ') ORDER BY n.is_top DESC, n.id DESC LIMIT 1',
    [(int)$me['id']]
);
$noticeUnread = $notice ? 1 : 0;
$serviceUid = (int)val('SELECT id FROM users WHERE account=?', [(string)setting('service_uid', '10086')]);
cc_head('消息', ['body_class' => 'app-body']); ?>
<div class="app" id="app">
  <!-- ============ 会话列表 ============ -->
  <div class="page" id="listPage">
    <div class="topbar">
      <h1>消息 <span id="netDot" style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#07C160;margin-left:4px;vertical-align:2px"></span></h1>
      <div class="tb-actions">
        <button class="tb-btn" id="btnSearch" aria-label="搜索">
          <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
        </button>
        <button class="tb-btn" id="btnPlus" aria-label="更多">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
        </button>
      </div>
    </div>

    <div class="page-body" style="padding-bottom:calc(84px + var(--safe-b))">
      <div id="convList"></div>
      <div id="convEmpty" class="empty" style="display:none">
        <div class="ico">💬</div>
        <div>还没有会话</div>
        <div style="font-size:12px;margin-top:4px">去通讯录找好友聊聊吧</div>
      </div>
    </div>
    <?php cc_tabbar('index'); ?>
  </div>

  <!-- ============ 聊天页 ============ -->
  <div class="chat-page" id="chatPage" style="display:none;position:absolute;inset:0;z-index:50;background:var(--bg)">
    <div class="chat-head">
      <button class="tb-back" id="chatBack">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <div class="ch-title" id="chatTitleWrap">
        <div class="ch-name" id="chatName">聊天</div>
        <div class="ch-sub" id="chatSub"></div>
      </div>
      <button class="ch-action" id="chatMore">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>
      </button>
    </div>

    <div class="pin-list hidden" id="pinList"></div>
    <div class="pinned-bar hidden" id="pinnedBar">
      <div class="pb-ico">
        <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6l-1 6 3 3H7l3-3z"/><path d="M12 13v7"/></svg>
      </div>
      <div class="pb-txt" id="pinnedText"></div>
      <button class="pb-close" id="pinnedUnpin" title="清空置顶">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>

    <div class="chat-body" id="chatBody"></div>

    <div class="composer" id="composer">
      <div class="staged-imgs hidden" id="stagedImgs"></div>
      <div class="composer-row">
        <button class="ico-btn" id="btnVoice" title="语音">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>
        </button>
        <textarea id="msgInput" rows="1" placeholder="发消息…"></textarea>
        <button class="ico-btn" id="btnEmoji" title="表情">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1" fill="currentColor"/><circle cx="15" cy="10" r="1" fill="currentColor"/><path d="M8.5 14.5a4.5 4.5 0 0 0 7 0"/></svg>
        </button>
        <button class="ico-btn" id="btnPlus2" title="更多">
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
        </button>
        <button class="send-btn" id="btnSend" disabled>发送</button>
      </div>
      <button class="hold-btn" id="holdBtn" style="display:none">按住 说话</button>
      <div class="plus-panel" id="plusPanel">
        <div class="plus-item" data-act="image"><div class="pi">🖼️</div>相册</div>
        <div class="plus-item" data-act="camera"><div class="pi">📷</div>拍摄</div>
        <div class="plus-item" data-act="video"><div class="pi">🎬</div>视频</div>
        <div class="plus-item" data-act="file"><div class="pi">📄</div>文件</div>
        <div class="plus-item" data-act="call"><div class="pi">📞</div>电话</div>
        <div class="plus-item" data-act="redpacket"><div class="pi">🧧</div>红包</div>
        <div class="plus-item" data-act="transfer"><div class="pi">💸</div>转账</div>
        <div class="plus-item" data-act="gift"><div class="pi">🎁</div>礼物</div>
        <div class="plus-item" data-act="card"><div class="pi">👤</div>名片</div>
        <div class="plus-item" data-act="favorite"><div class="pi">⭐</div>收藏</div>
        <div class="plus-item" data-act="live"><div class="pi">📡</div>直播</div>
        <div class="plus-item" data-act="location"><div class="pi">📍</div>位置</div>
      </div>
      <div class="emoji-panel" id="emojiPanel"></div>
    </div>
  </div>
</div>

<input type="file" id="filePickImage" accept="image/*" multiple style="display:none">
<input type="file" id="filePickVideo" accept="video/*" style="display:none">
<input type="file" id="filePickFile" style="display:none">
<input type="file" id="filePickCamera" accept="image/*" capture="environment" style="display:none">

<script>
window.ME = <?= cc_me_json($me) ?>;
window.CFG = {
  serviceUid: <?= (int)$serviceUid ?>,
  ice: <?= json_encode(cfg('webrtc.ice', []), JSON_UNESCAPED_SLASHES) ?>,
  noticeId: <?= $notice ? (int)$notice['id'] : 0 ?>,
  noticeUnread: <?= (int)$noticeUnread ?>,
  callEnabled: <?= (string)setting('call_enabled', '1') === '1' ? 1 : 0 ?>,
  liveEnabled: <?= (string)setting('live_enabled', '1') === '1' ? 1 : 0 ?>,
  siteName: <?= json_encode($siteName, JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script src="assets/chat.js?v=<?= CC_VERSION ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // 公告弹窗未关闭前不打扰用户
  var guard = 0;
  var t = setInterval(function(){
    guard++;
    var pop = document.getElementById('ccNoticePop');
    if ((!pop || guard > 60) && window.CC && CC.installHint) { clearInterval(t); CC.installHint(); }
  }, 800);
});
</script>
<?php if ($notice && $noticeUnread): ?>
<script>
(function(){
  var NID = <?= (int)$notice['id'] ?>;
  var TITLE = <?= json_encode((string)$notice['title'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var BODY = <?= json_encode((string)$notice['content'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  if (!TITLE) return;

  function esc(s){
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  function show(){
    if (document.getElementById('ccNoticePop')) return;
    // 本地已确认过该公告（网络失败时兜底），不再重复弹出
    try { if (localStorage.getItem('ccNoticeAck_' + NID) === '1') return; } catch (e) {}

    var css = ''
      + '#ccNoticePop{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;'
      + 'padding:22px;background:rgba(16,20,30,.55);-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);'
      + 'box-sizing:border-box;pointer-events:auto;overflow:hidden}'
      + '#ccNoticePop .ccn-card{width:100%;max-width:330px;max-height:76vh;display:flex;flex-direction:column;'
      + 'background:#fff;border-radius:16px;box-shadow:0 18px 48px rgba(0,0,0,.22);padding:20px 18px 14px;box-sizing:border-box;'
      + 'text-align:left;animation:ccnIn .18s ease-out}'
      + '@keyframes ccnIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}'
      + '#ccNoticePop h3{font-size:16px;margin:0 0 8px;text-align:center;color:#1A2030;font-weight:700}'
      + '#ccNoticePop .ccn-body{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;'
      + 'font-size:13.5px;color:#5A6273;line-height:1.75;white-space:pre-wrap;word-break:break-word;margin:10px 0 16px}'
      + '#ccNoticePop .ccn-ok{flex:0 0 auto;display:block;width:100%;height:44px;border:0;border-radius:11px;'
      + 'background:#07C160;color:#fff;font-size:15px;font-weight:600;cursor:pointer;-webkit-appearance:none}'
      + '#ccNoticePop .ccn-ok:active{opacity:.85}'
      + 'body.dark #ccNoticePop .ccn-card{background:#1B2130}'
      + 'body.dark #ccNoticePop h3{color:#E9EDF5}'
      + 'body.dark #ccNoticePop .ccn-body{color:#A8B0C0}';

    var st = document.createElement('style');
    st.id = 'ccNoticePopCss';
    st.textContent = css;
    document.head.appendChild(st);

    var box = document.createElement('div');
    box.id = 'ccNoticePop';
    box.innerHTML = '<div class="ccn-card">'
      + '<h3>' + esc(TITLE) + '</h3>'
      + '<div class="ccn-body">' + esc(BODY) + '</div>'
      + '<button type="button" class="ccn-ok" id="ccNoticeOk">我已知晓</button>'
      + '</div>';
    document.body.appendChild(box);

    var closed = false;
    function close(){
      if (closed) return;
      closed = true;
      try { box.parentNode && box.parentNode.removeChild(box); } catch (e) {}
      try { var c = document.getElementById('ccNoticePopCss'); c && c.parentNode && c.parentNode.removeChild(c); } catch (e) {}
      try { document.body.style.overflow = ''; } catch (e) {}
    }

    // 先关闭界面，再后台同步已读状态：网络异常也不会卡住弹窗
    var acked = false;
    function ack(){
      if (acked) return;
      acked = true;
      close();
      try { localStorage.setItem('ccNoticeAck_' + NID, '1'); } catch (e) {}
      try {
        fetch('api.php?action=notice_read', {
          method: 'POST',
          credentials: 'same-origin',
          cache: 'no-store',
          headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
          body: 'action=notice_read&id=' + encodeURIComponent(NID)
        }).catch(function(){});
      } catch (e) {}
    }

    var btn = document.getElementById('ccNoticeOk');
    btn.addEventListener('click', ack, false);
    btn.addEventListener('touchend', function(ev){ ev.preventDefault(); ack(); }, false);
    // 点击遮罩空白处也视为已知晓
    box.addEventListener('click', function(ev){ if (ev.target === box) ack(); }, false);
    try { document.body.style.overflow = 'hidden'; } catch (e) {}
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', show);
  else show();
})();
</script>
<?php endif; ?>
</body>
</html>
