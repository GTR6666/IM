<?php
/**
 * CC商聊 - WebRTC 语音 / 视频通话（含群通话）
 *
 * 入口：
 *   call.php?to=UID&media=1|2        主动呼叫某人（前端先 call_invite 拿到 call_id）
 *   call.php?call_id=XXX             被动接听 / 群成员加入
 *   call.php?call_id=XXX&host=1      群通话发起者
 *
 * 信令全部走 lib/api_rtc.php 已有接口：
 *   call_invite / call_info / call_answer / call_reject / call_end / call_signal / call_poll
 *
 * 拓扑说明：
 *   1v1   —— 呼叫方发 offer，接听方 answer，双方互换 ICE。
 *   群通话 —— 以发起者（host，calls.from_uid）为中心的星型 mesh：每个成员与 host 各建一条
 *            PeerConnection，成员之间不互联，host 负责转发之外的混流由各端自行播放。
 *            成员进场时向 host 发 offer（to=hostUid），host 逐条 answer。
 *            成员离场时向 host 发一条 kind=ice 且 payload={"bye":1} 的信令，host 关闭对应连接
 *            （后端只认 offer/answer/ice，因此借 ice 通道承载离场通知，不新增接口）。
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$uid       = (int)$me['id'];
$toUid     = (int)($_GET['to'] ?? 0);
$callIdIn  = trim((string)($_GET['call_id'] ?? ''));
$media     = ((int)($_GET['media'] ?? 1) === 2) ? 2 : 1;
$hostParam = ((string)($_GET['host'] ?? '') === '1');

$peer     = null;
$group    = null;
$callRow  = null;
$members  = [];
$badEntry = '';

if ($callIdIn !== '') {
    $callRow = one('SELECT * FROM calls WHERE call_id=?', [$callIdIn]);
    if (!$callRow) {
        $badEntry = '通话不存在或已失效';
    } else {
        $ctype    = (int)$callRow['ctype'];
        $allowed  = $ctype === 1
            ? ($uid === (int)$callRow['from_uid'] || $uid === (int)$callRow['to_uid'])
            : (bool)group_member((int)$callRow['gid'], $uid);
        if (!$allowed) {
            $badEntry = '你不在该通话中';
            $callRow  = null;
        } else {
            $media = (int)$callRow['media'] === 2 ? 2 : 1;
            if ($ctype === 2) {
                $group = group_by_gid((int)$callRow['gid']);
                $peer  = one('SELECT * FROM users WHERE id=?', [(int)$callRow['from_uid']]);
                foreach (all('SELECT gm.uid, u.nickname, u.avatar FROM group_members gm JOIN users u ON u.id=gm.uid WHERE gm.gid=? LIMIT 300', [(int)$callRow['gid']]) as $m) {
                    $members[(int)$m['uid']] = ['nickname' => (string)$m['nickname'], 'avatar' => (string)$m['avatar']];
                }
            } else {
                $peerId = (int)$callRow['from_uid'] === $uid ? (int)$callRow['to_uid'] : (int)$callRow['from_uid'];
                $peer   = $peerId > 0 ? one('SELECT * FROM users WHERE id=?', [$peerId]) : null;
            }
        }
    }
} elseif ($toUid > 0) {
    $peer = one('SELECT * FROM users WHERE id=?', [$toUid]);
    if (!$peer) $badEntry = '对方不存在';
} else {
    $badEntry = '缺少通话参数';
}

$https    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$hostName = (string)($_SERVER['HTTP_HOST'] ?? '');
$isLocal  = (bool)preg_match('/^(localhost|127\.0\.0\.1|\[?::1\]?)(:\d+)?$/i', $hostName);
$insecure = (!$https && !$isLocal);

$callCfg = [
    'me'        => ['id' => $uid, 'nickname' => display_name($me), 'avatar' => (string)($me['avatar'] ?? '')],
    'callId'    => $callRow ? (string)$callRow['call_id'] : ($callIdIn !== '' ? $callIdIn : ''),
    'to'        => $toUid,
    'media'     => $media,
    'host'      => $hostParam ? 1 : 0,
    'bad'       => $badEntry,
    'peer'      => $peer ? user_public($peer) : null,
    'groupName' => $group ? (string)$group['name'] : '',
    'members'   => $members,
    'ice'       => cfg('webrtc.ice', [['urls' => 'stun:stun.l.google.com:19302']]),
    'insecure'  => $insecure ? 1 : 0,
];

$pageCss = <<<'CSS'
html,body{background:#0B0E17;}
body.app-body{align-items:stretch;justify-content:flex-start;padding:0;background:#0B0E17;}
@media (min-width:560px){body.app-body{background:#0B0E17;padding:0;}}
.call-page{background:linear-gradient(165deg,#0E1220,#141B2E 60%,#0B1220);}
.warn-bar{position:relative;z-index:9;background:#F5A623;color:#3A2A00;font-size:12.5px;line-height:1.55;padding:calc(var(--safe-t) + 8px) 14px 8px;text-align:center;font-weight:500;}
.call-top{position:relative;z-index:5;display:flex;align-items:center;justify-content:space-between;padding:10px 12px 8px;flex:0 0 auto;}
.call-top .ct-btn{width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;color:#fff;}
.call-top .ct-btn:active{background:rgba(255,255,255,.22);}
.call-top .ct-title{flex:1;text-align:center;font-size:15px;font-weight:600;color:#fff;letter-spacing:.3px;}
.call-video-wrap{flex:1;min-height:0;}
.call-video-wrap video.remote{display:none;}
.call-video-wrap.video-on video.remote{display:block;}
.call-video-wrap video.local{display:none;}
.call-video-wrap.video-on video.local{display:block;}
.call-avatar{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:1;padding:0 24px;text-align:center;}
.ca-avatar{width:112px;height:112px;border-radius:50%;overflow:hidden;background:#242C42;display:flex;align-items:center;justify-content:center;font-size:40px;font-weight:600;color:#fff;margin-bottom:16px;box-shadow:0 12px 34px rgba(0,0,0,.45);}
.ca-avatar img{width:100%;height:100%;object-fit:cover;display:block;}
.ca-name{font-size:21px;font-weight:600;color:#fff;letter-spacing:.4px;}
.ca-status{font-size:13px;color:rgba(255,255,255,.6);margin-top:8px;min-height:18px;}
.ca-timer{font-size:15px;color:rgba(255,255,255,.86);margin-top:10px;font-variant-numeric:tabular-nums;letter-spacing:1px;}
.call-grid{position:absolute;inset:0;display:none;grid-template-columns:1fr 1fr;grid-auto-rows:1fr;gap:5px;padding:5px;background:#0A0D16;z-index:2;overflow:hidden;}
.call-grid.show{display:grid;}
.call-grid.single{grid-template-columns:1fr;}
.cg-tile{position:relative;border-radius:10px;overflow:hidden;background:#161E31;display:flex;align-items:center;justify-content:center;min-height:0;}
.cg-tile video{width:100%;height:100%;object-fit:cover;display:block;}
.cg-tile video.hidden{display:none;}
.cg-av{width:60px;height:60px;border-radius:50%;background:#2A3350;display:flex;align-items:center;justify-content:center;font-size:22px;color:#fff;overflow:hidden;}
.cg-av.hidden{display:none;}
.cg-av img{width:100%;height:100%;object-fit:cover;}
.cg-name{position:absolute;left:6px;bottom:6px;max-width:82%;font-size:11px;color:#fff;background:rgba(0,0,0,.42);padding:2px 8px;border-radius:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.cg-mic{position:absolute;right:6px;top:6px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;}
.call-actions{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px 0 calc(28px + var(--safe-b));position:relative;z-index:6;}
.call-row{display:flex;justify-content:center;gap:18px;}
.call-actions button{width:56px;height:56px;border-radius:50%;background:rgba(255,255,255,.13);display:flex;align-items:center;justify-content:center;color:#fff;transition:background .15s;}
.call-actions button:active{background:rgba(255,255,255,.3);}
.call-actions button.off{background:rgba(255,255,255,.42);color:#101623;}
.call-actions button.hang{width:66px;height:66px;background:var(--red);box-shadow:0 10px 26px rgba(255,71,87,.34);}
.call-actions button.hang:active{background:#E33B4B;}
.call-overlay{position:absolute;inset:0;z-index:9;background:rgba(8,11,19,.94);display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:28px 24px;text-align:center;color:#fff;}
.call-overlay.show{display:flex;}
.co-avatar{width:96px;height:96px;border-radius:50%;overflow:hidden;background:#242C42;display:flex;align-items:center;justify-content:center;font-size:34px;font-weight:600;margin-bottom:4px;}
.co-avatar img{width:100%;height:100%;object-fit:cover;}
.co-name{font-size:19px;font-weight:600;}
.co-sub{font-size:13px;color:rgba(255,255,255,.66);line-height:1.6;}
.co-actions{display:flex;gap:34px;margin-top:14px;}
.co-actions button{width:66px;height:66px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;color:#fff;font-size:11px;background:rgba(255,255,255,.13);}
.co-actions button.accept{background:var(--brand);}
.co-actions button.reject{background:var(--red);}
.co-ended-ico{width:74px;height:74px;border-radius:50%;background:rgba(255,255,255,.09);display:flex;align-items:center;justify-content:center;margin-bottom:6px;}
#endedBack{height:42px;padding:0 30px;border-radius:21px;background:rgba(255,255,255,.14);color:#fff;font-size:14px;font-weight:500;}
.call-mini{position:fixed;right:14px;bottom:calc(18px + var(--safe-b));z-index:1200;display:none;align-items:center;gap:9px;background:rgba(14,18,32,.95);color:#fff;padding:8px 14px;border-radius:22px;border:1px solid rgba(255,255,255,.14);box-shadow:0 10px 28px rgba(0,0,0,.45);font-size:12.5px;}
.call-mini.show{display:flex;}
.call-mini .cm-dot{width:8px;height:8px;border-radius:50%;background:var(--brand);}
.call-mini .cm-timer{color:rgba(255,255,255,.72);font-variant-numeric:tabular-nums;}
.call-page.minimized{display:none;}
CSS;
cc_head('通话', ['body_class' => 'app-body', 'css' => $pageCss]);
?>
<div class="call-page" id="callPage">
  <?php if ($insecure): ?>
  <div class="warn-bar" id="warnBar">当前不是安全上下文（需 HTTPS 或 localhost），浏览器会拦截摄像头 / 麦克风，通话无法建立。请用 HTTPS 或 http://localhost 访问。</div>
  <?php endif; ?>

  <div class="call-top">
    <button class="ct-btn" id="btnBack" aria-label="返回">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>
    </button>
    <div class="ct-title" id="callTitle"><?= $media === 2 ? '视频通话' : '语音通话' ?></div>
    <button class="ct-btn" id="btnMin" aria-label="最小化">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 12h12"/></svg>
    </button>
  </div>

  <div class="call-video-wrap" id="videoWrap">
    <video id="remoteVideo" class="remote" autoplay playsinline></video>
    <video id="localVideo" class="local" autoplay playsinline muted></video>

    <div class="call-avatar" id="avatarBox">
      <div class="ca-avatar" id="peerAvatarBox"></div>
      <div class="ca-name" id="peerName">连接中…</div>
      <div class="ca-status" id="peerStatus"></div>
      <div class="ca-timer" id="callTimer"></div>
    </div>

    <div class="call-grid" id="callGrid"></div>
    <div class="tap-audio hidden" id="tapAudio" style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:8;background:rgba(0,0,0,.66);color:#fff;font-size:13px;padding:10px 18px;border-radius:20px;">点击开启声音</div>
  </div>

  <div class="call-actions" id="actionsBar">
    <div class="call-row">
      <button id="btnMic" aria-label="静音">
        <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>
      </button>
      <button id="btnCam" aria-label="关闭摄像头">
        <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="7" width="12" height="10" rx="2"/><path d="M15 10.5l6-3v9l-6-3z"/></svg>
      </button>
      <button id="btnSwitch" aria-label="切换摄像头">
        <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9a8 8 0 0 1 13-3.4"/><path d="M20 15a8 8 0 0 1-13 3.4"/><path d="M17 2.6v4h-4"/><path d="M7 21.4v-4h4"/></svg>
      </button>
      <button id="btnSpeaker" aria-label="免提">
        <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M17 8.2a5 5 0 0 1 0 7.6"/></svg>
      </button>
    </div>
    <button id="btnHang" class="hang" aria-label="挂断">
      <svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.2 4.2l3.4 1.4 1.5 3-2 2a12.5 12.5 0 0 0 5.3 5.3l2-2 3 1.5 1.4 3.4a2 2 0 0 1-2.1 2.6A16.5 16.5 0 0 1 2.6 6.3a2 2 0 0 1 2.6-2.1z"/></svg>
    </button>
  </div>

  <div class="call-overlay" id="incoming">
    <div class="co-avatar" id="inAvatar"></div>
    <div class="co-name" id="inName">来电</div>
    <div class="co-sub" id="inSub"></div>
    <div class="co-actions">
      <button class="reject" id="btnReject">
        <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.2 4.2l3.4 1.4 1.5 3-2 2a12.5 12.5 0 0 0 5.3 5.3l2-2 3 1.5 1.4 3.4a2 2 0 0 1-2.1 2.6A16.5 16.5 0 0 1 2.6 6.3a2 2 0 0 1 2.6-2.1z"/></svg>
        拒绝
      </button>
      <button class="accept" id="btnAccept">
        <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.2 4.2l3.4 1.4 1.5 3-2 2a12.5 12.5 0 0 0 5.3 5.3l2-2 3 1.5 1.4 3.4a2 2 0 0 1-2.1 2.6A16.5 16.5 0 0 1 2.6 6.3a2 2 0 0 1 2.6-2.1z"/></svg>
        接听
      </button>
    </div>
  </div>

  <div class="call-overlay" id="endedPanel">
    <div class="co-ended-ico">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.8)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5.2 4.2l3.4 1.4 1.5 3-2 2a12.5 12.5 0 0 0 5.3 5.3l2-2 3 1.5 1.4 3.4a2 2 0 0 1-2.1 2.6A16.5 16.5 0 0 1 2.6 6.3a2 2 0 0 1 2.6-2.1z"/></svg>
    </div>
    <div class="co-name" id="endedTitle">通话已结束</div>
    <div class="co-sub" id="endedSub"></div>
    <button id="endedBack">返回</button>
  </div>
</div>

<div class="call-mini" id="callMini">
  <span class="cm-dot"></span>
  <span id="miniName">通话中</span>
  <span class="cm-timer" id="miniTimer">00:00</span>
</div>

<script>window.CALL_CFG = <?= json_encode($callCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  'use strict';
  var CFG = window.CALL_CFG || {};
  var D = document;
  var W = window;
  function $(id) { return D.getElementById(id); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtDur(sec) {
    sec = Math.max(0, sec | 0);
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return (h ? h + ':' : '') + pad(m) + ':' + pad(s);
  }
  function esc(s) { return CC.esc(s == null ? '' : s); }

  var S = {
    callId: CFG.callId || '',
    ctype: 1,
    media: (CFG.media | 0) === 2 ? 2 : 1,
    isHost: CFG.host === 1,
    isCaller: false,
    peerUid: (CFG.to | 0) || 0,
    hostUid: 0,
    gid: 0,
    peerName: CFG.peer ? CFG.peer.nickname : '',
    peerAvatar: CFG.peer ? CFG.peer.avatar : '',
    groupName: CFG.groupName || '',
    names: {},
    avatars: {},
    ice: CFG.ice || [],
    connected: false,
    ended: false,
    stopped: false,
    endedSent: false,
    answeredAt: 0,
    connAt: 0,
    listenOnly: false,
    localStream: null,
    sendAudio: true,
    sendVideo: true,
    speakerOn: true,
    facing: 'user',
    pcs: {},
    pollTimer: null,
    tickTimer: null,
    ringTimer: null,
    fails: 0,
    unloaded: false
  };

  if (CFG.members) {
    Object.keys(CFG.members).forEach(function (k) {
      S.names[k] = CFG.members[k].nickname;
      S.avatars[k] = CFG.members[k].avatar;
    });
  }

  /* =========================================================
   * 基础 UI
   * ========================================================= */
  function initials(name) { return String(name || '?').slice(0, 1); }
  function avatarHtml(u, cls) {
    u = u || {};
    if (u.avatar) return '<div class="' + cls + '"><img src="' + esc(u.avatar) + '" alt="" onerror="this.style.display=\'none\'"></div>';
    return '<div class="' + cls + '" style="background:' + CC.colorOf(String(u.nickname || '?')) + '">' + esc(initials(u.nickname)) + '</div>';
  }
  function renderPeer() {
    var box = $('peerAvatarBox');
    if (!box) return;
    var u = { nickname: S.peerName || '对方', avatar: S.peerAvatar };
    if (u.avatar) box.innerHTML = '<img src="' + esc(u.avatar) + '" alt="" onerror="this.style.display=\'none\'">';
    else { box.textContent = initials(u.nickname); box.style.background = CC.colorOf(String(u.nickname)); }
    $('peerName').textContent = S.peerName || '连接中…';
    var inBox = $('inAvatar');
    if (inBox) {
      if (u.avatar) inBox.innerHTML = '<img src="' + esc(u.avatar) + '" alt="">';
      else { inBox.textContent = initials(u.nickname); inBox.style.background = CC.colorOf(String(u.nickname)); }
    }
    $('miniName').textContent = S.peerName || '通话中';
  }
  function setStatus(t) { var el = $('peerStatus'); if (el) el.textContent = t; }
  function setTitle(t) { var el = $('callTitle'); if (el) el.textContent = t; }

  function startTick() {
    if (S.tickTimer) return;
    S.tickTimer = setInterval(function () {
      if (S.ended || !S.connAt) return;
      var t = Math.floor(Date.now() / 1000) - S.connAt;
      if (t < 0) t = 0;
      var a = $('callTimer'); if (a) a.textContent = fmtDur(t);
      var b = $('miniTimer'); if (b) b.textContent = fmtDur(t);
    }, 500);
  }
  function stopTick() { if (S.tickTimer) { clearInterval(S.tickTimer); S.tickTimer = null; } }
  function stopRing() { if (S.ringTimer) { clearTimeout(S.ringTimer); S.ringTimer = null; } }

  function hasRemoteVideo() {
    var rv = $('remoteVideo');
    var st = rv && rv.srcObject;
    return !!(st && st.getVideoTracks && st.getVideoTracks().length);
  }

  function liveLayout() {
    if (S.ctype === 2) {
      $('avatarBox').style.display = 'none';
      $('callGrid').classList.toggle('show', !!S.connected);
      return;
    }
    $('callGrid').classList.remove('show');
    var localVideo = !!(S.localStream && S.localStream.getVideoTracks().length);
    var showVideo = S.media === 2 && S.connected && (hasRemoteVideo() || localVideo);
    $('videoWrap').classList.toggle('video-on', !!showVideo);
    $('avatarBox').style.display = showVideo ? 'none' : 'flex';
  }

  /* =========================================================
   * 信令收发
   * ========================================================= */
  function sig(kind, to, payload) {
    if (!S.callId || S.stopped || S.ended) return Promise.resolve();
    return CC.ajax('call_signal', {
      call_id: S.callId, kind: kind, to: to, payload: JSON.stringify(payload)
    }, { silent: true }).catch(function () { });
  }

  function beacon(action, data) {
    try {
      var fd = new FormData();
      fd.append('action', action);
      Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
      if (navigator.sendBeacon) {
        navigator.sendBeacon('api.php?action=' + encodeURIComponent(action), fd);
        return;
      }
      fetch('api.php?action=' + encodeURIComponent(action), {
        method: 'POST', body: fd, credentials: 'same-origin', keepalive: true
      }).catch(function () { });
    } catch (e) { }
  }

  function startPoll() {
    if (S.pollTimer || S.stopped) return;
    S.pollTimer = setTimeout(pollTick, 300);
  }
  function stopPoll() {
    if (S.pollTimer) { clearTimeout(S.pollTimer); S.pollTimer = null; }
  }

  function pollTick() {
    S.pollTimer = null;
    if (S.stopped || S.ended || !S.callId) return;
    CC.ajax('call_poll', { call_id: S.callId }, { silent: true }).then(function (res) {
      if (S.stopped || S.ended) return;
      if (!res || res.code !== 0) {
        S.fails++;
        if (S.fails >= 8) { showEnded('连接已断开', 1400); }
        return;
      }
      S.fails = 0;
      var d = res.data || {};
      if (d.answered_at && !S.answeredAt) S.answeredAt = parseInt(d.answered_at, 10) || 0;
      applyStatus(parseInt(d.status, 10));
      var list = d.signals || [];
      var chain = Promise.resolve();
      list.forEach(function (row) {
        chain = chain.then(function () { return handleSignal(row); }).catch(function () { });
      });
    }).catch(function () {
      S.fails++;
      if (S.fails >= 8 && !S.ended) showEnded('连接已断开', 1400);
    }).then(function () {
      if (!S.stopped && !S.ended) S.pollTimer = setTimeout(pollTick, 1200);
    });
  }

  function applyStatus(st) {
    if (st === 3) { if (!S.ended) showEnded('对方已拒绝', 1600); return; }
    if (st === 2) { if (!S.ended) showEnded('通话已结束', 1200); return; }
    if (st === 1 && !S.connected) {
      if (S.ctype === 1 && S.isCaller) onAnswered();
      else if (S.ctype === 2 && !S.isHost) onAnswered();
    }
  }

  function handleSignal(row) {
    var from = parseInt(row.from_uid, 10) || 0;
    var p = {};
    try { p = JSON.parse(row.payload || '{}'); } catch (e) { return Promise.resolve(); }
    if (row.kind === 'offer') return onOffer(from, p);
    if (row.kind === 'answer') return onAnswer(from, p);
    if (row.kind === 'ice') return onIce(from, p);
    return Promise.resolve();
  }

  /* =========================================================
   * 本地媒体
   * ========================================================= */
  var localPromise = null;
  function ensureLocal() {
    if (localPromise) return localPromise;
    localPromise = new Promise(function (resolve) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        S.listenOnly = true;
        CC.toast('浏览器不支持音视频采集，仅收听');
        resolve(null);
        return;
      }
      var vc = S.media === 2 ? { facingMode: S.facing, width: { ideal: 1280 }, height: { ideal: 720 } } : false;
      navigator.mediaDevices.getUserMedia({ audio: true, video: vc }).then(function (st) {
        S.localStream = st; onLocalStream(); resolve(st);
      }).catch(function () {
        if (S.media !== 2) {
          S.listenOnly = true;
          CC.toast('无法使用麦克风，已进入仅收听');
          resolve(null);
          return;
        }
        // 视频通话失败：退化为纯音频
        navigator.mediaDevices.getUserMedia({ audio: true, video: false }).then(function (st) {
          S.localStream = st; S.sendVideo = false;
          markCamOff(true);
          onLocalStream();
          CC.toast('未获取到摄像头，已切换为语音');
          resolve(st);
        }).catch(function () {
          S.listenOnly = true; S.sendAudio = false; S.sendVideo = false;
          CC.toast('无法使用麦克风/摄像头，已进入仅收听');
          resolve(null);
        });
      });
    });
    return localPromise;
  }

  function onLocalStream() {
    var lv = $('localVideo');
    if (S.localStream && S.media === 2 && S.localStream.getVideoTracks().length) {
      lv.srcObject = S.localStream;
      lv.muted = true;
      var p = lv.play(); if (p && p.catch) p.catch(function () { });
    }
    liveLayout();
  }

  function markCamOff(off) {
    var b = $('btnCam');
    if (b) b.classList.toggle('off', !!off);
  }
  function markMicOff(off) {
    var b = $('btnMic');
    if (b) b.classList.toggle('off', !!off);
  }

  function stopLocal() {
    if (S.localStream) {
      try { S.localStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { }
      S.localStream = null;
    }
    var lv = $('localVideo'); if (lv) lv.srcObject = null;
    var rv = $('remoteVideo'); if (rv) rv.srcObject = null;
  }

  function playSafe(video) {
    if (!video) return;
    var p = video.play();
    if (p && p.catch) p.catch(function () { var t = $('tapAudio'); if (t) t.classList.remove('hidden'); });
  }

  /* =========================================================
   * PeerConnection
   * ========================================================= */
  function makePc(uid, asOfferer) {
    if (S.pcs[uid]) return Promise.resolve(S.pcs[uid]);
    var pc = new RTCPeerConnection({ iceServers: S.ice, iceCandidatePoolSize: 2 });
    var e = { pc: pc, uid: uid, cands: [], stream: new MediaStream(), hasRemote: false };
    S.pcs[uid] = e;

    pc.onicecandidate = function (ev) {
      if (ev.candidate) sig('ice', uid, { candidate: ev.candidate });
    };
    pc.ontrack = function (ev) {
      if (ev.streams && ev.streams[0]) e.stream = ev.streams[0];
      else if (!e.stream.getTracks().some(function (t) { return t.id === ev.track.id; })) e.stream.addTrack(ev.track);
      attachRemote(uid, e);
      if (!S.connected) startConnectedUI();
    };
    pc.onconnectionstatechange = function () {
      var cs = pc.connectionState;
      if (cs === 'connected') { if (S.ctype === 2) setStatus('群通话中'); else if (S.connected) setStatus('通话中'); }
      else if (cs === 'failed') { setStatus('连接不稳定…'); try { pc.restartIce && pc.restartIce(); } catch (err) { } }
    };

    return ensureLocal().then(function (stream) {
      var hasAudio = stream ? stream.getAudioTracks().length > 0 : false;
      var hasVideo = stream ? stream.getVideoTracks().length > 0 : false;
      if (stream) {
        stream.getTracks().forEach(function (t) { try { pc.addTrack(t, stream); } catch (err) { } });
      }
      if (asOfferer) {
        if (!hasAudio) { try { pc.addTransceiver('audio', { direction: 'recvonly' }); } catch (err) { } }
        if (S.media === 2 && !hasVideo) { try { pc.addTransceiver('video', { direction: 'recvonly' }); } catch (err) { } }
      }
      return e;
    });
  }

  function flushCands(e) {
    if (!e || !e.hasRemote) return;
    e.cands.forEach(function (c) { e.pc.addIceCandidate(c).catch(function () { }); });
    e.cands = [];
  }

  function offerTo(uid) {
    if (!uid) return Promise.resolve();
    return makePc(uid, true).then(function (e) {
      return e.pc.createOffer().then(function (off) {
        return e.pc.setLocalDescription(off).then(function () {
          return sig('offer', uid, { sdp: e.pc.localDescription.sdp });
        });
      });
    }).catch(function (err) {
      CC.toast('建立连接失败');
    });
  }

  function onOffer(from, p) {
    if (!from || !p || !p.sdp) return Promise.resolve();
    return makePc(from, false).then(function (e) {
      return e.pc.setRemoteDescription({ type: 'offer', sdp: p.sdp }).then(function () {
        e.hasRemote = true;
        flushCands(e);
        return e.pc.createAnswer();
      }).then(function (ans) {
        return e.pc.setLocalDescription(ans);
      }).then(function () {
        sig('answer', from, { sdp: e.pc.localDescription.sdp });
        if (!S.connected) startConnectedUI();
      });
    }).catch(function () { });
  }

  function onAnswer(from, p) {
    var e = S.pcs[from];
    if (!e || !p || !p.sdp) return Promise.resolve();
    if (e.pc.signalingState !== 'have-local-offer') return Promise.resolve();
    return e.pc.setRemoteDescription({ type: 'answer', sdp: p.sdp }).then(function () {
      e.hasRemote = true;
      flushCands(e);
    }).catch(function () { });
  }

  function onIce(from, p) {
    if (p && p.bye) {
      var e = S.pcs[from];
      if (e) { try { e.pc.close(); } catch (err) { } delete S.pcs[from]; removeTile(from); }
      return Promise.resolve();
    }
    var ent = S.pcs[from];
    if (!ent || !p || !p.candidate) return Promise.resolve();
    if (ent.hasRemote) return ent.pc.addIceCandidate(p.candidate).catch(function () { });
    ent.cands.push(p.candidate);
    return Promise.resolve();
  }

  function closeAllPcs() {
    Object.keys(S.pcs).forEach(function (k) {
      try { S.pcs[k].pc.close(); } catch (e) { }
      delete S.pcs[k];
    });
  }

  /* =========================================================
   * 画面绑定
   * ========================================================= */
  function attachRemote(uid, e) {
    if (S.ctype === 1) {
      var rv = $('remoteVideo');
      if (rv.srcObject !== e.stream) rv.srcObject = e.stream;
      rv.muted = !S.speakerOn;
      playSafe(rv);
      liveLayout();
      return;
    }
    var tile = tileFor(uid);
    var v = tile.querySelector('video');
    if (e.stream.getVideoTracks().length) {
      v.srcObject = e.stream;
      v.classList.remove('hidden');
      tile.querySelector('.cg-av').classList.add('hidden');
    } else {
      v.classList.add('hidden');
      tile.querySelector('.cg-av').classList.remove('hidden');
    }
    v.muted = !S.speakerOn;
    playSafe(v);
  }

  function personOf(uid) {
    return { nickname: (uid === CFG.me.id ? '我' : (S.names[uid] || ('成员' + uid))), avatar: S.avatars[uid] || '' };
  }

  function tileFor(uid, isSelf) {
    var id = 'tile-' + uid;
    var t = $(id);
    if (t) return t;
    t = D.createElement('div');
    t.className = 'cg-tile';
    t.id = id;
    var u = personOf(uid);
    t.innerHTML = '<video autoplay playsinline' + (isSelf ? ' muted' : '') + ' class="hidden"></video>' +
      '<div class="cg-av">' + (u.avatar ? '<img src="' + esc(u.avatar) + '" alt="">' : esc(initials(u.nickname))) + '</div>' +
      '<div class="cg-name">' + esc(u.nickname) + '</div>';
    if (!u.avatar) t.querySelector('.cg-av').style.background = CC.colorOf(String(u.nickname));
    $('callGrid').appendChild(t);
    var n = $('callGrid').children.length;
    $('callGrid').classList.toggle('single', n <= 1);
    return t;
  }

  function removeTile(uid) {
    var t = $('tile-' + uid);
    if (t) t.remove();
    var n = $('callGrid').children.length;
    $('callGrid').classList.toggle('single', n <= 1);
  }

  function addSelfTile() {
    var t = tileFor(CFG.me.id, true);
    var v = t.querySelector('video');
    if (S.localStream && S.localStream.getVideoTracks().length) {
      v.srcObject = S.localStream;
      v.classList.remove('hidden');
      t.querySelector('.cg-av').classList.add('hidden');
    }
  }

  /* =========================================================
   * 状态流转
   * ========================================================= */
  function startConnectedUI() {
    if (S.connected || S.ended) return;
    S.connected = true;
    S.connAt = S.answeredAt || Math.floor(Date.now() / 1000);
    stopRing();
    $('incoming').classList.remove('show');
    setStatus(S.listenOnly ? '仅收听' : (S.ctype === 2 ? '群通话中' : '通话中'));
    if (S.ctype === 2) {
      setTitle(S.groupName || '群通话');
      $('callGrid').classList.add('show');
      addSelfTile();
      liveLayout();
    } else {
      setTitle(S.media === 2 ? '视频通话' : '语音通话');
      liveLayout();
    }
    startTick();
  }

  function showEnded(text, autoBack) {
    if (S.stopped) return;
    S.ended = true;
    stopPoll();
    stopTick();
    stopRing();
    closeAllPcs();
    stopLocal();
    $('incoming').classList.remove('show');
    $('endedTitle').textContent = text || '通话已结束';
    $('endedSub').textContent = S.endedSent ? '' : (S.ctype === 2 ? '群通话已结束' : '');
    $('endedPanel').classList.add('show');
    var btn = $('endedBack');
    if (btn) btn.onclick = function () { goBack(0); };
    if (autoBack) setTimeout(function () { goBack(0); }, autoBack);
  }

  function sendEnd() {
    if (S.endedSent || !S.callId) return;
    S.endedSent = true;
    if (S.ctype === 1 || S.isHost) beacon('call_end', { call_id: S.callId });
    else if (S.hostUid) beacon('call_signal', { call_id: S.callId, kind: 'ice', to: S.hostUid, payload: JSON.stringify({ bye: 1 }) });
  }

  function hangup(back) {
    if (S.stopped) return;
    sendEnd();
    S.stopped = true;
    stopPoll(); stopTick(); stopRing();
    closeAllPcs(); stopLocal();
    if (back !== false) goBack(0);
  }

  function goBack(delay) {
    setTimeout(function () {
      try {
        if (D.referrer && D.referrer.indexOf(location.origin) === 0) history.back();
        else location.href = 'index.php';
      } catch (e) { location.href = 'index.php'; }
    }, delay || 0);
  }

  function onAnswered() {
    if (S.connected || S.ended) return;
    startConnectedUI();
    if (S.ctype === 1) offerTo(S.peerUid);
    else if (S.ctype === 2 && !S.isHost) offerTo(S.hostUid);
  }

  /* =========================================================
   * 接听 / 拒绝
   * ========================================================= */
  function showIncoming() {
    $('inName').textContent = S.ctype === 2 ? (S.groupName || '群通话') : (S.peerName || '来电');
    $('inSub').textContent = (S.ctype === 2 ? '群' : '') + (S.media === 2 ? '视频' : '语音') + '通话邀请';
    $('incoming').classList.add('show');
    setStatus('邀请你通话');
  }

  function accept() {
    $('incoming').classList.remove('show');
    CC.api('call_answer', { call_id: S.callId }).then(function (d) {
      var st = d && d.status !== undefined ? parseInt(d.status, 10) : 1;
      if (st === 3) { showEnded('对方已拒绝', 1500); return; }
      if (st === 2) { showEnded('通话已结束', 1200); return; }
      ensureLocal().then(function () { liveLayout(); });
      startConnectedUI();
      if (S.ctype === 2 && S.hostUid) offerTo(S.hostUid);
    }).catch(function (e) {
      CC.toast((e && e.message) || '接听失败');
      showEnded('接听失败', 1200);
    });
  }

  function reject() {
    CC.ajax('call_reject', { call_id: S.callId }, { silent: true }).catch(function () { });
    S.endedSent = true;
    S.ended = true;
    stopPoll(); stopTick(); stopRing(); closeAllPcs(); stopLocal();
    goBack(0);
  }

  /* =========================================================
   * 入口
   * ========================================================= */
  function init() {
    renderPeer();
    if (CFG.bad) {
      S.ended = true;
      $('endedTitle').textContent = CFG.bad;
      $('endedSub').textContent = '请返回后重试';
      $('endedPanel').classList.add('show');
      $('endedBack').onclick = function () { goBack(0); };
      return;
    }
    bindUI();
    if (CFG.callId) initExisting();
    else if (CFG.to) initOutgoing();
    else showEnded('缺少通话参数', 0);
  }

  function initOutgoing() {
    S.isCaller = true;
    S.ctype = 1;
    setTitle(S.media === 2 ? '视频通话' : '语音通话');
    setStatus('正在呼叫…');
    ensureLocal();
    CC.api('call_invite', { ctype: 1, to: CFG.to, media: S.media }).then(function (d) {
      S.callId = d.call_id;
      if (d.media) S.media = parseInt(d.media, 10) === 2 ? 2 : 1;
      startPoll();
      startRing();
      CC.api('call_info', { call_id: S.callId }).then(function (ci) {
        if (ci.answered_at) S.answeredAt = parseInt(ci.answered_at, 10) || 0;
        if (parseInt(ci.status, 10) === 1) onAnswered();
        if (parseInt(ci.status, 10) === 3) showEnded('对方已拒绝', 1500);
        if (parseInt(ci.status, 10) === 2) showEnded('通话已结束', 1200);
      }).catch(function () { });
    }).catch(function (e) {
      CC.toast((e && e.message) || '呼叫失败');
      showEnded('呼叫失败', 1500);
    });
  }

  function startRing() {
    stopRing();
    S.ringTimer = setTimeout(function () {
      S.ringTimer = null;
      if (!S.connected && !S.ended) {
        beacon('call_end', { call_id: S.callId });
        S.endedSent = true;
        showEnded('对方无应答', 1500);
      }
    }, 60000);
  }

  function initExisting() {
    setStatus('加载中…');
    CC.api('call_info', { call_id: CFG.callId }).then(function (d) {
      S.callId = d.call_id;
      S.ctype = parseInt(d.ctype, 10);
      S.media = parseInt(d.media, 10) === 2 ? 2 : 1;
      S.gid = parseInt(d.gid, 10) || 0;
      S.isCaller = d.is_caller === 1;
      S.hostUid = S.ctype === 2 ? (d.from ? parseInt(d.from.id, 10) : 0) : 0;
      S.isHost = S.ctype === 2 ? (S.hostUid === CFG.me.id) : false;
      if (d.ctype === 2) {
        S.groupName = (d.group_name || CFG.groupName || '群通话');
        if (d.from) { S.names[d.from.id] = d.from.nickname; S.avatars[d.from.id] = d.from.avatar; }
        S.peerName = S.groupName;
      } else {
        var other = S.isCaller ? d.to : d.from;
        S.peerUid = other ? parseInt(other.id, 10) : 0;
        if (other) { S.peerName = other.nickname; S.peerAvatar = other.avatar; }
      }
      renderPeer();
      setTitle(S.ctype === 2 ? (S.groupName || '群通话') : (S.media === 2 ? '视频通话' : '语音通话'));

      var st = parseInt(d.status, 10);
      if (d.answered_at) S.answeredAt = parseInt(d.answered_at, 10) || 0;
      if (st === 3) { showEnded('对方已拒绝', 1500); return; }
      if (st === 2) { showEnded('通话已结束', 1200); return; }

      startPoll();
      if (S.ctype === 1) {
        if (st === 0) {
          if (S.isCaller) { setStatus('正在呼叫…'); startRing(); ensureLocal(); }
          else { showIncoming(); startRing(); }
        } else {
          ensureLocal().then(function () { liveLayout(); });
          startConnectedUI();
          if (S.isCaller) offerTo(S.peerUid);
        }
      } else {
        if (st === 1) {
          ensureLocal().then(function () { liveLayout(); });
          startConnectedUI();
          if (!S.isHost && S.hostUid) offerTo(S.hostUid);
        } else if (S.isHost) {
          CC.api('call_answer', { call_id: S.callId }).then(function () {
            ensureLocal().then(function () { liveLayout(); });
            startConnectedUI();
          }).catch(function () { startConnectedUI(); });
        } else {
          showIncoming();
        }
      }
    }).catch(function (e) {
      showEnded('通话不存在或无权访问', 0);
      $('endedSub').textContent = (e && e.message) || '';
    });
  }

  /* =========================================================
   * 控件
   * ========================================================= */
  function bindUI() {
    $('btnAccept').onclick = accept;
    $('btnReject').onclick = reject;
    $('btnHang').onclick = function () { hangup(true); };
    $('btnBack').onclick = function () { hangup(true); };
    $('btnMin').onclick = function () {
      $('callPage').classList.add('minimized');
      $('callMini').classList.add('show');
    };
    $('callMini').onclick = function () {
      $('callPage').classList.remove('minimized');
      $('callMini').classList.remove('show');
    };

    $('btnMic').onclick = function () {
      if (S.listenOnly) { CC.toast('当前为仅收听模式'); return; }
      S.sendAudio = !S.sendAudio;
      if (S.localStream) S.localStream.getAudioTracks().forEach(function (t) { t.enabled = S.sendAudio; });
      markMicOff(!S.sendAudio);
      CC.toast(S.sendAudio ? '麦克风已开启' : '已静音');
    };

    $('btnCam').onclick = function () {
      if (S.media !== 2) { CC.toast('当前是语音通话'); return; }
      if (!S.localStream || !S.localStream.getVideoTracks().length) { CC.toast('没有可用的摄像头'); return; }
      S.sendVideo = !S.sendVideo;
      S.localStream.getVideoTracks().forEach(function (t) { t.enabled = S.sendVideo; });
      markCamOff(!S.sendVideo);
      CC.toast(S.sendVideo ? '摄像头已开启' : '摄像头已关闭');
    };

    $('btnSwitch').onclick = function () {
      if (!S.localStream || !S.localStream.getVideoTracks().length) { CC.toast('没有可切换的摄像头'); return; }
      S.facing = S.facing === 'user' ? 'environment' : 'user';
      navigator.mediaDevices.getUserMedia({ video: { facingMode: S.facing }, audio: false }).then(function (ns) {
        var nv = ns.getVideoTracks()[0];
        if (!nv) return;
        S.localStream.getVideoTracks().forEach(function (t) { S.localStream.removeTrack(t); t.stop(); });
        S.localStream.addTrack(nv);
        Object.keys(S.pcs).forEach(function (k) {
          var e = S.pcs[k];
          var snd = e.pc.getSenders().filter(function (x) { return x.track && x.track.kind === 'video'; })[0];
          if (snd) snd.replaceTrack(nv).catch(function () { });
        });
        var lv = $('localVideo');
        if (lv) { lv.srcObject = S.localStream; playSafe(lv); }
        if (S.ctype === 2) {
          var t = $('tile-' + CFG.me.id);
          if (t) { var v = t.querySelector('video'); v.srcObject = S.localStream; }
        }
        CC.toast(S.facing === 'user' ? '前置摄像头' : '后置摄像头');
      }).catch(function () { CC.toast('切换摄像头失败'); });
    };

    $('btnSpeaker').onclick = function () {
      S.speakerOn = !S.speakerOn;
      $('btnSpeaker').classList.toggle('off', !S.speakerOn);
      D.querySelectorAll('video.remote, .cg-tile video').forEach(function (v) { v.muted = !S.speakerOn; });
      CC.toast(S.speakerOn ? '已开启声音' : '已静音对方');
    };

    $('tapAudio').onclick = function () {
      $('tapAudio').classList.add('hidden');
      D.querySelectorAll('video').forEach(function (v) { playSafe(v); });
    };
  }

  function onUnload() {
    if (S.unloaded) return;
    S.unloaded = true;
    sendEnd();
    S.stopped = true;
    stopPoll(); stopTick(); stopRing();
    closeAllPcs(); stopLocal();
  }
  W.addEventListener('pagehide', onUnload);
  W.addEventListener('beforeunload', onUnload);

  init();
});
</script>
<?php cc_foot(); ?>
