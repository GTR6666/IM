# CC商聊 复刻项目 - 开发规范（所有人必读）

## 项目位置
`C:\Users\Administrator\Desktop\商聊\akchat` —— 纯 PHP 8.3 + PDO，前端原生 JS/CSS，**不使用任何框架、不引入 CDN**。

## 运行与调试
```powershell
# 本项目已有一个后台服务跑在 8899 端口（如未运行则执行）
$env:PHP_CLI_SERVER_WORKERS='8'
C:\Users\Administrator\Desktop\商聊\tools\php\php.exe -S 127.0.0.1:8899 -t C:\Users\Administrator\Desktop\商聊\akchat
```
访问 `http://127.0.0.1:8899/login.php`。演示账号 `740999800 / aa123456`；后台 `admin / admin123456`。
数据库为 SQLite：`data/akchat.db`，可删除后执行 `install.php` 重建。

## 后端约定
- 每个页面：`require __DIR__.'/lib/bootstrap.php'; require __DIR__.'/lib/layout.php'; $me = require_user_page();`
- 后台页面：`require __DIR__.'/lib/admin.php';` → `$admin = admin_require();`，然后 `admin_head($title)` / `admin_foot()`。
- 统一 JSON：`ok($data)` / `fail($msg)`，前端 `res = {code,msg,data}`，`code=0` 成功。
- 数据库：`db()`、`q($sql,$p)`、`one()`、`all()`、`val()`、`ex()`、`last_id()`；**只写 SQLite/MySQL 通用 SQL**。
- 设置：`setting('usdt_rate','7')`、`set_setting()`。用户：`current_user()`、`user_public($u)`。
- CC币账本必须走 `add_coin($uid,$amount,$biz,$bizId,$remark)`，不要直接 UPDATE coin。
- 消息发送：`push_message(['ctype'=>1,'from_uid'=>..,'to_uid'=>..,'gid'=>0,'type'=>1,'content'=>..])`。
- 上传：`upload_save('file','chat',['jpg','png'],$maxBytes)` 返回 `['url'=>...]`，url 是相对路径。
- 时间：`now()` 时间戳；显示用 JS `CC.fmtTime/fmtFull/fmtChatTime`。

## 前端约定
- 页面骨架 `cc_head($title,['body_class'=>'app-body'])` … `cc_foot(['script.js'])`；移动端 440px 卡片布局。
- 公共样式 `assets/app.css`（设计系统，变量 `--brand/--bg/--card/--text/--t2/--t3/--line`；组件：`.page .page-body .topbar .tabbar .cell .card .avatar .btn .field .sheet .dialog .mask .toast .empty .badge`）。
- 公共脚本 `assets/app.js`：`CC.ajax(action,data)`、`CC.api`、`CC.toast`、`CC.confirm`、`CC.prompt`、`CC.sheet`、`CC.avatarHtml`、`CC.fmtTime`、`CC.previewImage`、`CC.longPress`、`CC.qs`、`CC.startBadgePoll`。
- 底部导航：`cc_tabbar('index|contacts|discover|me')`；顶部：`cc_topbar($title,$backUrl,$rightHtml,$solid)`。
- 深色模式：只用 CSS 变量，不要写死 `#fff` 背景；必要时 `html.dark-theme` 覆盖。
- 所有页面都走 PHP 服务端渲染 + 内联 `<script>`（参考 `index.php`、`login.php`）。

## 现有 API（api.php?action=xxx）
账号：login register logout me save_profile upload_avatar change_password set_pay_password update_settings device_list device_kick send_code reset_password appeal_submit
好友：friend_list friend_board search send_friend_request handle_req set_remark delete_friend block_friend
聊天：conv_list msg_list send recall delete_msg mark_read mark_all_read conv_pin conv_mute conv_delete share_targets forward search_chat upload_image upload_video upload_voice upload_file emoji_list emoji_add emoji_del gift_list favorite_add favorite_list favorite_del long_poll
群：group_list group_create group_info group_query group_update group_upload_avatar group_members group_kick group_set_admin group_mute_member group_mute_all group_transfer group_dissolve group_exit group_join group_handle_join group_join_requests group_notice_set group_upgrade_limit group_set_nickname group_share_card
动态：feed_list send_moment delete_moment like comment delete_comment repost moment_unread_info moment_notify_unread moment_mark_read upload_cover
钱包：wallet_info wallet_logs wallet_recharge wallet_orders wallet_withdraw transfer_create redpacket_create redpacket_info redpacket_open gift_send vip_plans buy_vip pretty_list buy_pretty
USDT：create check_pay usdt_orders submit_txid
通话/直播：call_invite call_info call_answer call_reject call_end call_signal call_poll live_create live_info live_join live_leave live_end live_msg live_list live_signal live_poll
其他：unread_total contacts_unread poll_notify notice_list notice_read service_info report_submit invite_info site_info ping

> 注意：`wallet_orders` 返回钱包充值/提现记录；USDT 页面用 `usdt_orders`。新增接口时把 `$API_EXTRA` 写在自己的 `lib/api_extra_<模块>.php` 里（api.php 会自动 require 并合并），不要改 api.php 或其他模块。

## 数据库表（关键字段）
- users(id, account, yx_id, pretty_yxid, nickname, avatar, bio, gender, region, email, phone, password, pay_password, coin, total_income, total_expense, vip_level, vip_expire_at, is_developer, status, ban_reason, ban_until, ban_forever, invite_code, online, settings, created_at, last_active_at)
- messages(id, ctype 1私聊/2群聊, from_uid, to_uid, gid, type, content, extra, created_at, recalled, deleted)
- conversations(uid, ctype, peer_id, last_msg, last_time, unread, pinned, muted, visible)
- groups(gid, name, avatar, intro, owner_uid, member_limit, join_mode, is_public, mute_all, status), group_members(gid, uid, role 0成员/1管理/2群主, nickname, mute_until, last_read_id, pinned)
- friends(uid, fid, remark, status 1正常/2拉黑), friend_requests(from_uid,to_uid,reason,status 0待处理/1同意/2拒绝)
- moment(id,uid,content,images JSON,video,visibility,created_at,deleted), moment_likes(mid,uid), moment_comments(mid,uid,reply_uid,content)
- wallet_logs(uid,direction 1收入/2支出,amount,balance_after,biz,biz_id,remark,created_at)
- recharge_orders(order_no,uid,coin,rate,amount_usdt,address,network,status 0待支付/1待审核/2已到账/3已拒绝,txid,pay_tx,remark,created_at,paid_at,admin_id)
- withdraw_orders(order_no,uid,amount,account,qr,status 0待审/1通过/2拒绝/3已打款,remark,created_at,handled_at,admin_id)
- red_packets(packet_no,uid,ctype,to_uid,gid,rp_type 1普通/2拼手气,total,count,remaining,remain_count,blessing,status,expire_at), red_packet_records(pid,uid,coin)
- calls(call_id,ctype,from_uid,to_uid,gid,media 1语音/2视频,status 0呼叫/1接通/2结束/3拒绝,created_at,answered_at,ended_at,duration), call_signals(call_id,from_uid,to_uid,kind offer/answer/ice,payload,consumed)
- live_rooms(room_no,uid,gid,title,cover,status 0直播中/1结束,viewers,created_at), live_messages(room_id,uid,content,type)
- notices(id,title,content,is_top,status), notice_reads(nid,uid), reports, appeals, admins(id,username,password,role super/ops/finance,status,last_login_at), admin_logs, login_logs, devices, gifts, vip_plans, pretty_ids, emojis, favorites, invites

## 消息类型
1 文本 / 5 图片(JSON {url,w,h}) / 6 语音({url,duration}) / 7,21 红包 / 8,22 转账 / 9,23 礼物 / 11 系统文本 / 12 个人名片 / 13 群名片 / 14 通话 / 15 视频({url}) / 16 动态 / 17 聊天记录({title,items:[{u,a,c,ty,t,p}]}) / 18 文件({url,name,size}) / 19 直播({room_no,title,uid,name}) / 20 撤回

## 后台约束
- 管理员表独立于用户表；`admin_require()` 未登录跳 `login.php`。
- 角色：super 全部；ops 用户/群/内容；finance 充值/提现/流水。
- 所有写操作记 `admin_logs`。
- 后台风格：深色侧栏 + 浅色内容区，桌面优先，自适应移动端。品牌绿 #07C160，侧栏 #0F1420。
- USDT 后台必须能：改地址/汇率/最低额/自动核对开关/过期时间；查看订单；手动通过（加币）/拒绝；补单；导出 CSV。

## 交付要求
- 每个页面可用、无 PHP 警告、无未实现按钮（点了要有效果）。
- 中文界面，和前台一致的文案风格。
- 不要修改他人负责的文件；需要新增 API 时在对应模块里加，函数名前缀避免冲突。
