<?php
/**
 * CC商聊 - 群直播（WebRTC 单主播多观众）
 *
 * 入口：
 *   live.php?room_no=XXXX&host=1   主播（live_create 已由群聊页调用）
 *   live.php?room_no=XXXX          观众
 *
 * 信令：复用 lib/api_rtc.php 已有接口，call_id 固定为 "live:房间号"
 *   live_info / live_join / live_leave / live_end / live_msg / live_signal / live_poll
 *
 * 拓扑：观众发 offer 给主播 → 主播 answer 并回传自己的流。主播端维护 uid → PeerConnection，
 *       观众端只有一条到主播的连接。主播无摄像头时用 canvas.captureStream() 生成占位画面，
 *       保证 PC 上也能跑通完整流程。
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();

$uid       = (int)$me['id'];
$roomNoIn  = trim((string)($_GET['room_no'] ?? ''));
$hostParam = ((string)($_GET['host'] ?? '') === '1');

$room = null;
if ($roomNoIn !== '') {
    $room = one('SELECT * FROM live_rooms WHERE room_no=?', [$roomNoIn]);
    if (!$room && ctype_digit($roomNoIn)) {
        $room = one('SELECT * FROM live_rooms WHERE id=?', [(int)$roomNoIn]);
    }
}
$hostUser = $room ? one('SELECT * FROM users WHERE id=?', [(int)$room['uid']]) : null;
$group    = ($room && (int)$room['gid']) ? group_by_gid((int)$room['gid']) : null;
$roomNo   = $room ? (string)$room['room_no'] : $roomNoIn;
$isHost   = $room ? ((int)$room['uid'] === $uid) : false;
$bad      = '';
if (!$room) $bad = '直播间不存在';
elseif ((int)$room['status'] !== 0) $bad = '直播已结束';

$https    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$hostName = (string)($_SERVER['HTTP_HOST'] ?? '');
$isLocal  = (bool)preg_match('/^(localhost|127\.0\.0\.1|\[?::1\]?)(:\d+)?$/i', $hostName);
$insecure = (!$https && !$isLocal);

$liveCfg = [
    'me'        => ['id' => $uid, 'nickname' => display_name($me), 'avatar' => (string)($me['avatar'] ?? '')],
    'roomNo'    => $roomNo,
    'isHost'    => $isHost ? 1 : 0,
    'host'      => $hostUser ? user_public($hostUser) : null,
    'title'     => $room ? (string)$room['title'] : '',
    'status'    => $room ? (int)$room['status'] : -1,
    'viewers'   => $room ? (int)$room['viewers'] : 0,
    'gid'       => $room ? (int)$room['gid'] : 0,
    'groupName' => $group ? (string)$group['name'] : '',
    'bad'       => $bad,
    'ice'       => cfg('webrtc.ice', [['urls' => 'stun:stun.l.google.com:19302']]),
    'insecure'  => $insecure ? 1 : 0,
];

$pageCss = <<<'CSS'
html,body{background:#000;}
body.app-body{display:block;padding:0;background:#000;color:#fff;overflow:hidden;}
.live-page{position:fixed;inset:0;display:flex;flex-direction:column;background:#000;color:#fff;}
.warn-bar{position:relative;z-index:9;background:#F5A623;color:#3A2A00;font-size:12.5px;line-height:1.55;padding:calc(var(--safe-t) + 8px) 14px 8px;text-align:center;font-weight:500;flex:0 0 auto;}
.live-stage{flex:1;min-height:0;position:relative;background:#000;display:flex;align-items:center;justify-content:center;overflow:hidden;}
.live-stage video{width:100%;height:100%;object-fit:cover;display:block;background:#000;}
.live-stage video.mirror{transform:scaleX(-1);}
.live-stage video.hidden{display:none;}
.live-wait{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:rgba(255,255,255,.72);font-size:13.5px;background:linear-gradient(160deg,#0A0F16,#111A26);text-align:center;padding:0 30px;line-height:1.7;}
.live-wait .lw-ico{font-size:34px;opacity:.7;}
.live-start{position:absolute;inset:0;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;
  background:linear-gradient(160deg,#0A0F16,#101A26);padding:0 28px;text-align:center;}
.live-start.hidden{display:none;}
.live-start .ls-ico{width:64px;height:64px;border-radius:20px;background:rgba(7,193,96,.16);color:#4ADE80;display:flex;align-items:center;justify-content:center;margin-bottom:2px;}
.live-start .ls-title{font-size:17px;font-weight:600;color:#fff;}
.live-start .ls-sub{font-size:12.5px;color:rgba(255,255,255,.6);line-height:1.7;margin-bottom:6px;max-width:270px;}
.live-start .ls-btn{width:100%;max-width:300px;height:48px;border-radius:14px;font-size:15px;font-weight:600;}
.live-start .ls-btn.main{background:linear-gradient(135deg,#07C160,#06AD56);color:#fff;box-shadow:0 10px 26px rgba(7,193,96,.32);}
.live-start .ls-btn.ghost{background:rgba(255,255,255,.1);color:#E5EAF2;}
.live-start .ls-tip{font-size:11.5px;color:rgba(255,255,255,.42);line-height:1.6;margin-top:4px;max-width:290px;}
.live-wait.hidden{display:none;}
.live-bar{z-index:5;align-items:center;gap:10px;}
.lb-user{display:flex;align-items:center;gap:9px;min-width:0;flex:1;}
.lb-avatar{width:36px;height:36px;border-radius:50%;overflow:hidden;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:600;flex:0 0 auto;border:1.5px solid rgba(255,255,255,.6);}
.lb-avatar img{width:100%;height:100%;object-fit:cover;}
.lb-info{min-width:0;}
.lb-name{font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:52vw;}
.lb-sub{font-size:11px;opacity:.85;display:flex;align-items:center;gap:5px;margin-top:2px;}
.live-dot{width:6px;height:6px;border-radius:50%;background:#FF4757;display:inline-block;box-shadow:0 0 6px #FF4757;}
.lb-close{width:32px;height:32px;border-radius:50%;background:rgba(0,0,0,.3);color:#fff;font-size:15px;display:flex;align-items:center;justify-content:center;flex:0 0 auto;}
.live-danmaku{bottom:74px;max-height:40%;}
.live-danmaku .dm{backdrop-filter:blur(2px);}
.live-ctrl{z-index:6;align-items:center;gap:8px;}
.live-ctrl .host-btn{height:40px;padding:0 16px;border-radius:20px;background:rgba(255,255,255,.16);color:#fff;font-size:13px;flex:0 0 auto;}
.live-ctrl .host-btn.on{background:rgba(255,255,255,.32);color:#0E1220;}
.live-ctrl .host-btn.end{background:var(--red);}
.live-ctrl .gift-btn{width:40px;padding:0;font-size:17px;background:rgba(255,255,255,.16);}
.live-ctrl input{flex:1;min-width:0;}
.live-ended{position:fixed;inset:0;z-index:30;background:rgba(6,9,14,.94);display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;color:#fff;text-align:center;padding:24px;}
.live-ended.show{display:flex;}
.live-ended .le-ico{width:76px;height:76px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:32px;margin-bottom:4px;}
.live-ended .le-title{font-size:18px;font-weight:600;}
.live-ended .le-sub{font-size:13px;color:rgba(255,255,255,.6);line-height:1.7;}
.live-ended button{height:42px;padding:0 32px;border-radius:21px;background:rgba(255,255,255,.14);color:#fff;font-size:14px;}
.gift-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:4px 0 8px;}
.gift-cell{display:flex;flex-direction:column;align-items:center;gap:4px;padding:10px 4px;border-radius:12px;background:var(--bg);cursor:pointer;}
.gift-cell:active{background:var(--line);}
.gift-cell .g-ico{font-size:26px;line-height:1.1;}
.gift-cell .g-ico img{width:34px;height:34px;object-fit:contain;}
.gift-cell .g-name{font-size:11.5px;color:var(--text);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.gift-cell .g-price{font-size:11px;color:var(--gold);font-weight:600;}
.toast{bottom:120px;}

/* ================= 桌面端（PC）自适应 ================= */
@media (min-width:900px){
  body.app-body{overflow:auto;}
  .live-page{position:fixed;inset:0;padding:16px 24px;overflow-y:auto;display:flex;flex-direction:column;align-items:center;}
  .live-page > .warn-bar{width:100%;max-width:1320px;border-radius:12px;padding:10px 16px;font-size:13px;}

  /* 舞台：固定 16:9，居中，圆角 + 阴影，不再铺满整屏 */
  .live-stage{
    flex:0 0 auto;width:100%;max-width:1320px;
    aspect-ratio:16 / 9;max-height:calc(100vh - 100px);
    border-radius:16px;overflow:hidden;background:#000;
    box-shadow:0 18px 48px rgba(0,0,0,.55);
  }
  /* contain：整幅画面可见，不被裁切 */
  .live-stage video{object-fit:contain;}
  .live-wait,.live-start{border-radius:16px;}

  /* 主播信息条：叠在画面顶部，禁止换行 */
  .live-bar{
    position:absolute;left:0;right:0;top:0;z-index:5;
    padding:14px 18px;background:linear-gradient(rgba(0,0,0,.55),transparent);
  }
  .lb-name{max-width:none;font-size:15px;}
  .lb-sub{white-space:nowrap;font-size:12px;}
  .lb-avatar{width:40px;height:40px;}
  .lb-close{width:34px;height:34px;}

  /* 弹幕：画面左下角，占一半宽度 */
  .live-danmaku{
    position:absolute;left:0;right:auto;bottom:82px;z-index:4;
    width:min(54%,680px);max-height:44%;padding:0 0 0 18px;
  }
  .live-danmaku .dm{font-size:13px;}

  /* 控制栏：叠在画面底部 */
  .live-ctrl{
    position:absolute;left:0;right:0;bottom:0;z-index:6;
    padding:12px 18px 16px;background:linear-gradient(transparent,rgba(0,0,0,.55));
  }
  .live-ctrl input{height:44px;border-radius:22px;font-size:14px;}
  .live-ctrl button{height:44px;border-radius:22px;padding:0 24px;font-size:14px;}
  .live-ctrl .host-btn{height:44px;padding:0 20px;font-size:13.5px;}
  .live-ctrl .gift-btn{width:44px;}

  .live-start .ls-sub,.live-start .ls-tip{max-width:440px;font-size:13px;}
  .live-start .ls-btn{max-width:340px;}
  .live-ended .le-title{font-size:22px;}
  .live-ended button{height:46px;padding:0 38px;font-size:15px;}
  .toast{bottom:48px;}
}

@media (min-width:1500px){
  .live-stage{max-width:1400px;}
}
CSS;
cc_head($isHost ? '我的直播' : '直播间', ['body_class' => 'app-body', 'css' => $pageCss]);
?>
<div class="live-page" id="livePage">
  <?php if ($insecure): ?>
  <div class="warn-bar" id="warnBar">当前不是安全上下文（需 HTTPS 或 localhost），浏览器会拦截屏幕共享 / 摄像头 / 麦克风，直播画面无法采集。请用 HTTPS 或 http://localhost 访问。</div>
  <?php endif; ?>

  <div class="live-stage" id="stage">
    <video id="localVideo" autoplay playsinline muted class="mirror<?= $isHost ? '' : ' hidden' ?>"></video>
    <video id="remoteVideo" autoplay playsinline class="<?= $isHost ? 'hidden' : '' ?>"></video>

    <?php if ($isHost): ?>
    <div class="live-start" id="startPanel">
      <div class="ls-ico">
        <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="12" rx="2.2"/><path d="M8.5 20h7M12 16.5V20"/><path d="M9.5 10.5l2 2 3.5-3.5"/></svg>
      </div>
      <div class="ls-title">选择开播方式</div>
      <div class="ls-sub">直播默认共享屏幕，观众可实时看到你的操作画面</div>
      <button class="ls-btn main" id="btnStartScreen">共享屏幕开播</button>
      <button class="ls-btn ghost" id="btnStartCamera">用摄像头开播</button>
      <div class="ls-tip">共享屏幕需在弹窗中选择「整个屏幕」或某个窗口；开播后可随时在下方切换。</div>
    </div>
    <?php endif; ?>

    <div class="live-wait<?= $isHost ? ' hidden' : '' ?>" id="liveWait">
      <div class="lw-ico">📡</div>
      <div id="waitText">正在连接主播…</div>
    </div>

    <div class="live-bar">
      <div class="lb-user">
        <span class="lb-avatar" id="lbAvatar"></span>
        <div class="lb-info">
          <div class="lb-name" id="lbName"><?= e($hostUser ? display_name($hostUser) : '主播') ?></div>
          <div class="lb-sub"><span class="live-dot"></span><span id="viewerCount"><?= (int)($room['viewers'] ?? 0) ?></span> 人观看<?= $room && (int)$room['gid'] ? ' · ' . e((string)($group['name'] ?? '')) : '' ?></div>
        </div>
      </div>
      <button class="lb-close" id="btnClose" aria-label="关闭">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
      </button>
    </div>

    <div class="live-danmaku" id="danmaku"></div>

    <div class="live-ctrl<?= $isHost ? '' : ' hidden' ?>" id="hostBar">
      <button class="host-btn" id="btnSwitch">切换到镜头</button>
      <button class="host-btn" id="btnMute">静音</button>
      <button class="host-btn end" id="btnEnd">结束直播</button>
    </div>

    <div class="live-ctrl<?= $isHost ? ' hidden' : '' ?>" id="viewerBar">
      <input id="dmInput" type="text" maxlength="100" placeholder="说点什么…" autocomplete="off">
      <button id="btnSend">发送</button>
      <button class="gift-btn" id="btnGift" aria-label="送礼物">🎁</button>
    </div>
  </div>
</div>

<div class="live-ended" id="endedBox">
  <div class="le-ico">📴</div>
  <div class="le-title" id="endedTitle">直播已结束</div>
  <div class="le-sub" id="endedSub"></div>
  <button id="btnEndedBack">返回</button>
</div>

<script>window.LIVE_CFG = <?= json_encode($liveCfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
  'use strict';
  var CFG = window.LIVE_CFG || {};
  var D = document;
  var W = window;
  function $(id) { return D.getElementById(id); }
  function esc(s) { return CC.esc(s == null ? '' : s); }

  var S = {
    roomNo: CFG.roomNo || '',
    isHost: CFG.isHost === 1,
    hostUid: CFG.host ? parseInt(CFG.host.id, 10) : 0,
    hostName: CFG.host ? CFG.host.nickname : '主播',
    hostAvatar: CFG.host ? CFG.host.avatar : '',
    ice: CFG.ice || [],
    local: null,
    mode: 'screen',   // screen=屏幕共享（默认） | camera=摄像头
    facing: 'user',
    pcs: {},          // 主播端 uid -> entry
    viewerPc: null,   // 观众端单条连接
    viewerCands: [],
    viewerHasRemote: false,
    retries: 0,
    since: 0,
    seen: {},
    sigTimer: null,
    msgTimer: null,
    cvTimer: null,
    stopped: false,
    ended: false,
    joined: false,
    facing: 'user',
    micOn: true,
    camOn: true,
    remoteEl: null
  };

  function api(action, data) { return CC.api(action, data); }

  function setViewers(n) {
    var el = $('viewerCount');
    if (el) el.textContent = parseInt(n, 10) || 0;
  }

  function renderHostInfo() {
    var box = $('lbAvatar');
    if (!box) return;
    if (S.hostAvatar) box.innerHTML = '<img src="' + esc(S.hostAvatar) + '" alt="">';
    else { box.textContent = String(S.hostName || '主播').slice(0, 1); box.style.background = CC.colorOf(String(S.hostName)); }
    var nm = $('lbName');
    if (nm && !S.isHost) nm.textContent = S.hostName || '主播';
  }

  /* =========================================================
   * 主播：本地画面 / 占位画面
   * ========================================================= */
  function canvasStream() {
    try {
      var c = D.createElement('canvas');
      c.width = 960; c.height = 540;
      var ctx = c.getContext('2d');
      var draw = function () {
        var g = ctx.createLinearGradient(0, 0, 960, 540);
        g.addColorStop(0, '#12202B');
        g.addColorStop(1, '#1B3A2E');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 960, 540);
        ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(255,255,255,.9)';
        ctx.font = '600 44px -apple-system,"PingFang SC","Microsoft YaHei",sans-serif';
        ctx.fillText('屏幕共享占位画面', 480, 250);
        ctx.fillStyle = 'rgba(255,255,255,.62)';
        ctx.font = '400 22px -apple-system,"PingFang SC","Microsoft YaHei",sans-serif';
        ctx.fillText((S.isHost ? CFG.me.nickname : S.hostName) + ' · 模拟视频源', 480, 300);
        ctx.fillStyle = 'rgba(255,255,255,.4)';
        ctx.font = '400 18px monospace';
        ctx.fillText(new Date().toLocaleTimeString(), 480, 344);
      };
      draw();
      if (S.cvTimer) clearInterval(S.cvTimer);
      S.cvTimer = setInterval(draw, 1000);
      if (!c.captureStream) return null;
      return c.captureStream(15);
    } catch (e) { return null; }
  }

  function bindLocal() {
    var v = $('localVideo');
    if (!v) return;
    if (S.local) v.srcObject = S.local;
    var p = v.play(); if (p && p.catch) p.catch(function () { });
  }

  /* ---------- 采集：屏幕共享优先，失败回退摄像头 ---------- */
  function canShareScreen() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia);
  }

  function applyMirror() {
    var v = $('localVideo');
    if (v) v.classList.toggle('mirror', S.mode === 'camera' && S.facing === 'user');
  }

  /** 采集屏幕（带麦克风） */
  function captureScreen() {
    return new Promise(function (resolve, reject) {
      if (!canShareScreen()) { reject(new Error('浏览器不支持屏幕共享')); return; }
      var opts = {
        video: { frameRate: { ideal: 15, max: 30 }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      };
      navigator.mediaDevices.getDisplayMedia(opts).then(function (st) {
        // 屏幕流拿不到系统声音时，单独采集麦克风
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (a) {
          a.getAudioTracks().forEach(function (t) { try { st.addTrack(t); } catch (e) { } });
          S.micOn = true;
        }).catch(function () {
          S.micOn = false;
        }).then(function () { resolve(st); });
      }).catch(reject);
    });
  }

  /** 采集摄像头（带麦克风） */
  function captureCamera() {
    return new Promise(function (resolve, reject) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { reject(new Error('不支持摄像头')); return; }
      navigator.mediaDevices.getUserMedia({
        audio: true,
        video: { facingMode: S.facing, width: { ideal: 1280 }, height: { ideal: 720 } }
      }).then(resolve).catch(function () {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: S.facing } }).then(function (st) {
          S.micOn = false;
          resolve(st);
        }).catch(reject);
      });
    });
  }

  /** 统一采集入口：mode = screen | camera */
  function startHostMedia(mode) {
    S.mode = mode || S.mode || 'screen';
    return new Promise(function (resolve) {
      var done = function (st) {
        S.local = st;
        bindLocal();
        applyMirror();
        markMute();
        resolve(st);
      };
      var fallback = function (reason) {
        if (S.mode === 'screen') {
          CC.toast(reason + '，已切换为摄像头');
          S.mode = 'camera';
          captureCamera().then(done).catch(function () {
            var st = canvasStream();
            if (st) { done(st); CC.toast('未检测到可用设备，已使用模拟画面'); }
            else { CC.toast('无法采集画面，观众将看不到视频'); resolve(null); }
          });
        } else {
          var st = canvasStream();
          if (st) { done(st); CC.toast('未检测到摄像头，已使用模拟画面'); }
          else { CC.toast('无法采集画面，观众将看不到视频'); resolve(null); }
        }
      };

      var capture = S.mode === 'screen' ? captureScreen : captureCamera;
      capture().then(done).catch(function (err) {
        var msg = (err && err.name === 'NotAllowedError') ? '你拒绝了画面授权' : '无法获取画面';
        fallback(msg);
      });
    });
  }

  /** 切换采集源：屏幕 ⇄ 摄像头；同时替换所有对端的视频轨道 */
  function switchSource(mode) {
    var target = mode || (S.mode === 'screen' ? 'camera' : 'screen');
    if (target === 'screen' && !canShareScreen()) { CC.toast('当前浏览器不支持屏幕共享'); return; }
    CC.toast(target === 'screen' ? '正在请求屏幕共享…' : '正在切换摄像头…');
    startHostMedia(target).then(function (st) {
      if (!st) return;
      var track = st.getVideoTracks()[0];
      if (!track) return;
      Object.keys(S.pcs).forEach(function (k) {
        var pc = S.pcs[k].pc;
        var snd = pc.getSenders().filter(function (x) { return x.track && x.track.kind === 'video'; })[0];
        if (snd) snd.replaceTrack(track).catch(function () { });
      });
      // 用户点击浏览器自带的「停止共享」时自动切回摄像头
      track.addEventListener('ended', function () {
        if (S.mode === 'screen') { CC.toast('屏幕共享已停止，切换为摄像头'); switchSource('camera'); }
      });
      CC.toast(target === 'screen' ? '正在共享屏幕' : '已切换为摄像头');
    });
  }

  function markMute() {
    var b = $('btnMute');
    if (b) { b.classList.toggle('on', !S.micOn); b.textContent = S.micOn ? '静音' : '已静音'; }
  }

  /* =========================================================
   * 主播：信令
   * ========================================================= */
  function liveSig(kind, to, payload) {
    if (S.stopped && kind !== 'ice') return Promise.resolve();
    return CC.ajax('live_signal', {
      room_no: S.roomNo, kind: kind, to: to, payload: JSON.stringify(payload)
    }, { silent: true }).catch(function () { });
  }

  function hostSigPoll() {
    S.sigTimer = null;
    if (S.stopped || S.ended) return;
    CC.ajax('live_poll', { room_no: S.roomNo }, { silent: true }).then(function (res) {
      if (S.stopped || !res || res.code !== 0) return;
      var list = (res.data && res.data.signals) || [];
      var chain = Promise.resolve();
      list.forEach(function (row) {
        chain = chain.then(function () { return hostSignal(row); }).catch(function () { });
      });
    }).catch(function () { }).then(function () {
      if (!S.stopped && !S.ended) S.sigTimer = setTimeout(hostSigPoll, 1200);
    });
  }

  function closeViewerPc(uid) {
    var e = S.pcs[uid];
    if (!e) return;
    try { e.pc.close(); } catch (err) { }
    delete S.pcs[uid];
  }

  function hostSignal(row) {
    var from = parseInt(row.from_uid, 10) || 0;
    if (!from) return Promise.resolve();
    var p = {};
    try { p = JSON.parse(row.payload || '{}'); } catch (e) { return Promise.resolve(); }

    if (row.kind === 'ice') {
      if (p.bye) { closeViewerPc(from); return Promise.resolve(); }
      var ent = S.pcs[from];
      if (!ent || !p.candidate) return Promise.resolve();
      if (ent.hasRemote) return ent.pc.addIceCandidate(p.candidate).catch(function () { });
      ent.cands.push(p.candidate);
      return Promise.resolve();
    }

    if (row.kind === 'offer' && p.sdp) {
      closeViewerPc(from);
      var pc = new RTCPeerConnection({ iceServers: S.ice });
      var e2 = { pc: pc, uid: from, cands: [], hasRemote: false };
      S.pcs[from] = e2;
      pc.onicecandidate = function (ev) { if (ev.candidate) liveSig('ice', from, { candidate: ev.candidate }); };
      pc.onconnectionstatechange = function () {
        if (pc.connectionState === 'failed') closeViewerPc(from);
      };
      // 关键：先 setRemoteDescription，再按 kind 把本地轨道挂到对应的 transceiver 上。
      // 若先 addTrack 再 setRemoteDescription，m-line 顺序可能与 offer 不一致，
      // 会导致观众端收不到视频轨（表现为「一直加载中 / 主播没有推流」）。
      return pc.setRemoteDescription({ type: 'offer', sdp: p.sdp }).then(function () {
        e2.hasRemote = true;
        e2.cands.forEach(function (c) { pc.addIceCandidate(c).catch(function () { }); });
        e2.cands = [];
        var tracks = S.local ? S.local.getTracks() : [];
        // 以 offer 的 m-line 顺序作为权威 kind 映射：
        // sendonly 方向的 transceiver 其 receiver.track 为 null，只看 receiver 会匹配不到，
        // 结果视频轨绑不上 —— 观众「有声音没画面（黑屏）」。
        var kinds = [];
        String(p.sdp || '').split(/\r?\n/).forEach(function (line) {
          var mm = line.match(/^m=(video|audio)\b/);
          if (mm) kinds.push(mm[1]);
        });
        var used = {}, bound = 0;
        var txs = pc.getTransceivers ? pc.getTransceivers() : [];
        txs.forEach(function (tx, idx) {
          var kind = kinds[idx] || ((tx.receiver && tx.receiver.track) ? tx.receiver.track.kind : '');
          if (!kind) return;
          var t = null;
          for (var i = 0; i < tracks.length; i++) {
            if (!used[tracks[i].kind] && tracks[i].kind === kind) { t = tracks[i]; used[kind] = 1; break; }
          }
          if (!t) return;
          try { t.enabled = true; } catch (e) { }
          var okBind = false;
          try {
            tx.direction = 'sendonly';
            if (tx.sender && tx.sender.replaceTrack) { tx.sender.replaceTrack(t); okBind = true; }
          } catch (err) { }
          if (!okBind) { try { pc.addTrack(t, S.local); okBind = true; } catch (e3) { } }
          if (okBind) bound++;
        });
        // 兜底：一条都没绑上时直接 addTrack 全部轨道
        if (!bound && tracks.length) {
          tracks.forEach(function (t) { try { pc.addTrack(t, S.local); } catch (e) { } });
        }
        return pc.createAnswer();
      }).then(function (ans) {
        return pc.setLocalDescription(ans);
      }).then(function () {
        return liveSig('answer', from, { sdp: pc.localDescription.sdp });
      }).then(function () {
        CC.toast('有观众进入直播间');
      }).catch(function () { closeViewerPc(from); });
    }
    return Promise.resolve();
  }

  /* =========================================================
   * 观众：建立连接
   * ========================================================= */
  function viewerConnect() {
    if (!S.hostUid) { CC.toast('主播信息缺失'); return; }
    if (S.viewerPc) { try { S.viewerPc.close(); } catch (e) { } S.viewerPc = null; }
    S.viewerCands = [];
    S.viewerHasRemote = false;
    var pc = new RTCPeerConnection({ iceServers: S.ice, iceCandidatePoolSize: 2 });
    S.viewerPc = pc;
    S.rmStream = null;   // 新连接：重新累积远端轨道
    try {
      pc.addTransceiver('video', { direction: 'recvonly' });
      pc.addTransceiver('audio', { direction: 'recvonly' });
    } catch (e) { }
    pc.onicecandidate = function (ev) { if (ev.candidate) liveSig('ice', S.hostUid, { candidate: ev.candidate }); };
    pc.ontrack = function (ev) {
      // 关键：所有轨道累积到同一条 MediaStream。
      // 若每条轨道都 new MediaStream([track]) 并覆盖 srcObject，
      // 后到的音轨会把视频轨顶掉，表现为「有声音没画面（黑屏）」。
      if (!S.rmStream) { try { S.rmStream = new MediaStream(); } catch (e) { S.rmStream = null; } }
      var st = (ev.streams && ev.streams[0]) ? ev.streams[0] : S.rmStream;
      if (st) { try { st.addTrack(ev.track); } catch (e) { } }
      var v = $('remoteVideo');
      if (v) {
        if (v.srcObject !== st) v.srcObject = st;
        try { v.muted = false; } catch (e) { }
        var pr = v.play(); if (pr && pr.catch) pr.catch(function () { });
      }
      $('liveWait').classList.add('hidden');
      S.viewerHasRemote = true;
      S.retries = 0;
      clearTimeout(S.waitTimer);
    };
    pc.onconnectionstatechange = function () {
      var st = pc.connectionState;
      if (st === 'failed') { viewerRetry(); return; }
      if (st === 'disconnected') {
        // 短暂断开先等一下，持续 6 秒仍未恢复再重连
        setTimeout(function () {
          if (S.viewerPc === pc && pc.connectionState === 'disconnected' && !S.viewerHasRemote) viewerRetry();
        }, 6000);
      }
    };
    pc.createOffer().then(function (off) {
      return pc.setLocalDescription(off);
    }).then(function () {
      return liveSig('offer', S.hostUid, { sdp: pc.localDescription.sdp });
    }).catch(function () { viewerRetry(); });

    // 主播长时间不应答 → 重试（首次给 20 秒，主播开播/网络慢时更从容）
    clearTimeout(S.waitTimer);
    S.waitTimer = setTimeout(function () {
      if (!S.stopped && !S.ended && !S.viewerHasRemote) viewerRetry();
    }, 20000);
  }

  function viewerRetry() {
    if (S.stopped || S.ended) return;
    S.retries++;
    var wt = $('waitText');
    if (S.retries > 8) {
      if (wt) wt.textContent = '暂时连不上主播画面：对方可能尚未开播，或双方网络受限（跨运营商/NAT 需 TURN 中继）';
      return;
    }
    if (wt) wt.textContent = '正在连接主播画面…（第 ' + S.retries + ' 次）';
    viewerConnect();
  }

  function viewerSigPoll() {
    S.sigTimer = null;
    if (S.stopped || S.ended) return;
    CC.ajax('live_poll', { room_no: S.roomNo }, { silent: true }).then(function (res) {
      if (S.stopped || !res || res.code !== 0) return;
      var list = (res.data && res.data.signals) || [];
      list.forEach(function (row) {
        var p = {};
        try { p = JSON.parse(row.payload || '{}'); } catch (e) { return; }
        var pc = S.viewerPc;
        if (!pc) return;
        if (row.kind === 'answer' && p.sdp) {
          if (pc.signalingState === 'have-local-offer') {
            pc.setRemoteDescription({ type: 'answer', sdp: p.sdp }).then(function () {
              S.viewerHasRemote = true;
              S.viewerCands.forEach(function (c) { pc.addIceCandidate(c).catch(function () { }); });
              S.viewerCands = [];
            }).catch(function () { });
          }
        } else if (row.kind === 'ice' && p.candidate) {
          if (pc.remoteDescription && pc.remoteDescription.type) pc.addIceCandidate(p.candidate).catch(function () { });
          else S.viewerCands.push(p.candidate);
        }
      });
    }).catch(function () { }).then(function () {
      if (!S.stopped && !S.ended) S.sigTimer = setTimeout(viewerSigPoll, 1200);
    });
  }

  /* =========================================================
   * 弹幕 / 人数
   * ========================================================= */
  function appendDm(m) {
    var id = parseInt(m.id, 10) || 0;
    if (id && S.seen[id]) return;
    if (id) S.seen[id] = 1;
    var box = $('danmaku');
    if (!box) return;
    var div = D.createElement('div');
    div.className = 'dm';
    var name = m.nickname || ('用户' + (m.uid || ''));
    div.innerHTML = '<b>' + esc(name) + '</b> ' + esc(m.content || '');
    box.appendChild(div);
    while (box.children.length > 120) box.removeChild(box.firstChild);
    box.scrollTop = box.scrollHeight;
  }

  function msgPoll() {
    S.msgTimer = null;
    if (S.stopped || S.ended) return;
    CC.ajax('live_msg', { room_no: S.roomNo, since: S.since }, { silent: true }).then(function (res) {
      if (S.stopped || S.ended || !res || res.code !== 0) return;
      var d = res.data || {};
      (d.list || []).forEach(function (m) {
        appendDm(m);
        S.since = Math.max(S.since, parseInt(m.id, 10) || 0);
      });
      if (d.viewers !== undefined) setViewers(d.viewers);
      if (parseInt(d.status, 10) === 1 && !S.ended) endScreen('直播已结束');
    }).catch(function () { }).then(function () {
      if (!S.stopped && !S.ended) S.msgTimer = setTimeout(msgPoll, 3000);
    });
  }

  function sendDm() {
    var inp = $('dmInput');
    if (!inp) return;
    var text = (inp.value || '').trim();
    if (!text) return;
    inp.value = '';
    CC.ajax('live_msg', { room_no: S.roomNo, content: text, since: S.since }, { silent: true }).then(function (res) {
      if (!res || res.code !== 0) { CC.toast((res && res.msg) || '发送失败'); return; }
      var d = res.data || {};
      (d.list || []).forEach(function (m) {
        appendDm(m);
        S.since = Math.max(S.since, parseInt(m.id, 10) || 0);
      });
    }).catch(function () { CC.toast('发送失败'); });
  }

  /* =========================================================
   * 礼物
   * ========================================================= */
  function openGift() {
    api('gift_list', {}).then(function (d) {
      var list = (d && d.list) || [];
      if (!list.length) { CC.toast('暂无礼物'); return; }
      var html = '<div class="gift-grid">';
      list.forEach(function (g) {
        var ico = g.icon ? (String(g.icon).indexOf('/') >= 0 || String(g.icon).indexOf('.') >= 0
          ? '<img src="' + esc(g.icon) + '" alt="">' : esc(g.icon)) : '🎁';
        html += '<div class="gift-cell" data-gid="' + (g.id | 0) + '" data-name="' + esc(g.name) + '">' +
          '<div class="g-ico">' + ico + '</div>' +
          '<div class="g-name">' + esc(g.name) + '</div>' +
          '<div class="g-price">' + (g.price | 0) + ' CC币</div></div>';
      });
      html += '</div>';
      var sh = CC.sheet('送礼物给主播', html);
      sh.el.querySelectorAll('.gift-cell').forEach(function (cell) {
        cell.onclick = function () {
          sh.close();
          sendGift(cell.getAttribute('data-gid'), cell.getAttribute('data-name'));
        };
      });
    }).catch(function (e) { CC.toast((e && e.message) || '礼物列表加载失败'); });
  }

  function sendGift(gid, name, pwd) {
    var data = { ctype: 1, to: S.hostUid, gift_id: gid, count: 1 };
    if (pwd) data.pay_password = pwd;
    CC.ajax('gift_send', data).then(function (res) {
      if (!res) { CC.toast('赠送失败'); return; }
      if (res.code === 0) { CC.toast('已送出「' + (name || '礼物') + '」'); return; }
      if (res.code === 1001) { CC.toast('请先到「我的-安全」设置支付密码'); return; }
      if (res.code === 1002) {
        CC.prompt({ title: '请输入支付密码', placeholder: '支付密码', max: 32 }).then(function (v) {
          if (v) sendGift(gid, name, v);
        });
        return;
      }
      CC.toast(res.msg || '赠送失败');
    }).catch(function () { CC.toast('赠送失败'); });
  }

  /* =========================================================
   * 结束
   * ========================================================= */
  function endScreen(title) {
    if (S.ended) return;
    S.ended = true;
    stopAll();
    $('endedTitle').textContent = title || '直播已结束';
    $('endedSub').textContent = S.isHost ? '你已结束本次直播' : '主播已结束直播';
    $('endedBox').classList.add('show');
  }

  function leave(next) {
    if (S.isHost) {
      if (!S.ended) {
        CC.ajax('live_end', { room_no: S.roomNo }, { silent: true }).catch(function () { });
        if (S.joined) S.joined = false;
      }
    } else if (S.joined) {
      CC.ajax('live_leave', { room_no: S.roomNo }, { silent: true }).catch(function () { });
      S.joined = false;
    }
    stopAll();
    backTo();
  }

  function backTo() {
    try {
      if (D.referrer && D.referrer.indexOf(location.origin) === 0) history.back();
      else location.href = 'index.php';
    } catch (e) { location.href = 'index.php'; }
  }

  function stopAll() {
    S.stopped = true;
    if (S.sigTimer) { clearTimeout(S.sigTimer); S.sigTimer = null; }
    if (S.msgTimer) { clearTimeout(S.msgTimer); S.msgTimer = null; }
    if (S.cvTimer) { clearInterval(S.cvTimer); S.cvTimer = null; }
    Object.keys(S.pcs).forEach(function (k) { try { S.pcs[k].pc.close(); } catch (e) { } delete S.pcs[k]; });
    if (S.viewerPc) { try { S.viewerPc.close(); } catch (e) { } S.viewerPc = null; }
    if (S.local) {
      try { S.local.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { }
      S.local = null;
    }
  }

  /* =========================================================
   * 入口
   * ========================================================= */
  function init() {
    renderHostInfo();
    bindUI();
    if (CFG.bad) {
      endScreen(CFG.bad);
      switchBars(false);
      return;
    }
    if (S.isHost) {
      switchBars(true);
      var startPanel = $('startPanel');
      var begin = function (mode, btn) {
        if (btn) { btn.disabled = true; btn.textContent = mode === 'screen' ? '正在共享…' : '正在开启…'; }
        startHostMedia(mode).then(function () {
          if (startPanel) startPanel.classList.add('hidden');
          var tb = $('btnSwitch');
          if (tb) tb.textContent = S.mode === 'screen' ? '切换到镜头' : '共享屏幕';
          CC.toast(S.mode === 'screen' ? '正在共享屏幕，观众可实时看到你的画面' : '正在使用摄像头直播');
          hostSigPoll();
          msgPoll();
        });
      };
      if (startPanel) {
        var bs = $('btnStartScreen'), bc = $('btnStartCamera');
        if (bs) bs.onclick = function () { begin('screen', bs); };
        if (bc) bc.onclick = function () { begin('camera', bc); };
      } else {
        begin(S.mode, null);
      }
    } else {
      switchBars(false);
      api('live_join', { room_no: S.roomNo }).then(function () {
        S.joined = true;
        setViewers((CFG.viewers | 0) + 1);
        msgPoll();
        viewerConnect();
        viewerSigPoll();
      }).catch(function (e) {
        var msg = (e && e.message) || '';
        if (msg.indexOf('直播已结束') >= 0) { endScreen('直播已结束'); return; }
        CC.toast(msg || '进入直播间失败');
        // 仍尝试拉取弹幕与画面，主播可能刚好在下播
        msgPoll();
      });
    }
  }

  function switchBars(host) {
    var hb = $('hostBar'), vb = $('viewerBar');
    if (hb) hb.classList.toggle('hidden', !host);
    if (vb) vb.classList.toggle('hidden', host);
  }

  function bindUI() {
    $('btnClose').onclick = function () {
      if (S.isHost) {
        CC.confirm({ title: '结束直播', text: '结束后所有观众将断开', ok: '结束直播', danger: true }).then(function (okv) {
          if (okv) leave();
        });
      } else {
        leave();
      }
    };

    $('btnEndedBack').onclick = function () { backTo(); };

    $('btnSend').onclick = sendDm;
    $('dmInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); sendDm(); }
    });
    $('btnGift').onclick = openGift;

    $('btnEnd').onclick = function () {
      CC.confirm({ title: '结束直播', text: '结束后所有观众将断开', ok: '结束直播', danger: true }).then(function (okv) {
        if (okv) leave();
      });
    };

    $('btnMute').onclick = function () {
      S.micOn = !S.micOn;
      if (S.local) S.local.getAudioTracks().forEach(function (t) { t.enabled = S.micOn; });
      markMute();
      if (!S.local || !S.local.getAudioTracks().length) { CC.toast('当前没有麦克风'); return; }
      CC.toast(S.micOn ? '麦克风已开启' : '已静音');
    };

    $('btnSwitch').onclick = function () {
      if (!S.local) { CC.toast('画面尚未就绪'); return; }
      switchSource();
    };
  }

  function onUnload() {
    if (S.stopped) return;
    try {
      // 关键：页面隐藏/切标签/App 退到后台时 iOS 会触发 pagehide，
      // 这里绝不能调用 live_end，否则回来时房间已是「已结束」，
      // 主播不会再应答观众 → 观众黑屏 / 提示「主播没有推流」。
      // 统一只发 live_leave（仅观众计数 -1），直播由「结束直播」按钮显式结束。
      if (S.isHost ? false : !S.joined) { S.stopped = true; return; }
      if (!S.left) {
        S.left = true;
        var action = 'live_leave';
        var fd = new FormData();
        fd.append('action', action);
        fd.append('room_no', S.roomNo);
        if (navigator.sendBeacon) navigator.sendBeacon('api.php?action=' + action, fd);
        else fetch('api.php?action=' + action, { method: 'POST', body: fd, credentials: 'same-origin', keepalive: true }).catch(function () { });
      }
    } catch (e) { }
    S.stopped = true;
    if (S.sigTimer) clearTimeout(S.sigTimer);
    if (S.msgTimer) clearTimeout(S.msgTimer);
    if (S.cvTimer) clearInterval(S.cvTimer);
    Object.keys(S.pcs).forEach(function (k) { try { S.pcs[k].pc.close(); } catch (e) { } });
    if (S.viewerPc) { try { S.viewerPc.close(); } catch (e) { } }
  }
  W.addEventListener('pagehide', onUnload);
  W.addEventListener('beforeunload', onUnload);

  // 从后台/bfcache 回到页面：主播恢复信令与消息轮询（不重新开播，媒体流仍在）
  W.addEventListener('pageshow', function (ev) {
    if (!S.isHost) return;
    if (S.ended || !S.local) return;
    S.stopped = false;
    S.left = false;
    if (!S.sigTimer) hostSigPoll();
    if (!S.msgTimer) msgPoll();
  });

  init();
});
</script>
<?php cc_foot(); ?>
