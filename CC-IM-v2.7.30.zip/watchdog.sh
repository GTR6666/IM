#!/bin/sh
# CC商聊 - PHP 内置服务器看门狗
# 1) 进程退出后自动重启
# 2) 进程存活但端口无响应（容器恢复后套接字失效）也会自动重启
PORT=${PORT:-8102}
ROOT=/var/minis/workspace/im
LOG=${LOG:-/tmp/cc-im-server.log}
PHP=php82
HEALTH="http://127.0.0.1:$PORT/login.php"

cd "$ROOT" || exit 1

while true; do
  PHP_CLI_SERVER_WORKERS=6 "$PHP" -S 0.0.0.0:"$PORT" -t "$ROOT" >> "$LOG" 2>&1 &
  PID=$!
  echo "[watchdog] php 启动 pid=$PID $(date)" >> "$LOG"

  fail=0
  while kill -0 "$PID" 2>/dev/null; do
    sleep 5
    code=$(curl -s -m 3 -o /dev/null -w '%{http_code}' "$HEALTH" 2>/dev/null)
    if [ "$code" = "200" ] || [ "$code" = "302" ]; then
      fail=0
    else
      fail=$((fail + 1))
      echo "[watchdog] 健康检查失败($fail) code=$code $(date)" >> "$LOG"
      if [ "$fail" -ge 3 ]; then
        echo "[watchdog] 连续失败，强制重启 php pid=$PID $(date)" >> "$LOG"
        kill -9 "$PID" 2>/dev/null
        pkill -9 -f "$PHP -S 0.0.0.0:$PORT" 2>/dev/null
        break
      fi
    fi
  done

  wait "$PID" 2>/dev/null
  echo "[watchdog] php 已退出，1 秒后重启 $(date)" >> "$LOG"
  sleep 1
done
