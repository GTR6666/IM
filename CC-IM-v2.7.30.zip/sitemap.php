<?php
/**
 * CC商聊 - 动态 sitemap（只列公共可收录页面）
 * 用法： /sitemap.php
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$base = rtrim((string)(setting('site_url', '') ?: site_url('')), '/');
$today = date('Y-m-d');

/* 公共页面：仅登录 / 注册 / 找回密码 */
$urls = [];
// 落地页（若已开放）作为首要收录目标
if (!empty(landing_config()['enabled'])) {
    $urls[] = ['loc' => $base . '/landing.php', 'changefreq' => 'weekly', 'priority' => '1.0'];
}
$urls[] = ['loc' => $base . '/login.php',    'changefreq' => 'weekly',  'priority' => '0.9'];
$urls[] = ['loc' => $base . '/register.php', 'changefreq' => 'weekly',  'priority' => '0.8'];
$urls[] = ['loc' => $base . '/forget.php',   'changefreq' => 'monthly', 'priority' => '0.3'];

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($urls as $u): ?>
  <url>
    <loc><?= e($u['loc']) ?></loc>
    <lastmod><?= $today ?></lastmod>
    <changefreq><?= $u['changefreq'] ?></changefreq>
    <priority><?= $u['priority'] ?></priority>
  </url>
<?php endforeach; ?>
</urlset>
