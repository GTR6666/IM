<?php
/**
 * CC商聊 - 全局搜索
 */
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/layout.php';
$me = require_user_page();
$kw0 = trim((string)($_GET['kw'] ?? ''));
cc_head('搜索', ['body_class' => 'app-body']); ?>
<div class="app">
  <div class="page">
    <?php cc_topbar('搜索', 'index.php'); ?>

    <div class="page-body no-tab">
      <div style="padding:2px 12px 0">
        <div class="field" style="margin-bottom:8px">
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" style="color:var(--t3)"><circle cx="11" cy="11" r="7"/><path d="M16.5 16.5L21 21"/></svg>
          <input id="kw" type="search" placeholder="CC号 / 靓号 / 邮箱 / 群号 / 聊天内容" autocomplete="off" autofocus>
          <button class="btn small" id="btnSearch" style="flex:0 0 auto">搜索</button>
        </div>
        <div class="tabs" style="padding:0 0 8px">
          <button data-tab="all" class="active">综合</button>
          <button data-tab="user">用户</button>
          <button data-tab="group">群聊</button>
          <button data-tab="chat">聊天记录</button>
        </div>
      </div>

      <div id="result">
        <div class="empty">
          <div class="ico">🔎</div>
          <div>搜索 CC号、群号或聊天内容</div>
          <div style="font-size:12px;margin-top:4px">用户和群号需要精确匹配</div>
        </div>
      </div>
      <div style="height:24px"></div>
    </div>
  </div>
</div>

<script>
window.ME = <?= cc_me_json($me) ?>;
</script>
<script src="assets/app.js?v=<?= CC_VERSION ?>"></script>
<script>
(function(){
  var ME = window.ME || {};
  var kwEl = document.getElementById('kw');
  var result = document.getElementById('result');
  var tab = 'all';
  var lastKw = '';

  function hl(text, kw){
    var s = CC.esc(text == null ? '' : text);
    if (!kw) return s;
    var k = CC.esc(kw).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    try { return s.replace(new RegExp(k, 'gi'), function(m){ return '<mark style="background:rgba(7,193,96,.18);color:var(--brand);border-radius:3px;padding:0 1px">' + m + '</mark>'; }); }
    catch (e) { return s; }
  }

  function userRow(u){
    var isMe = parseInt(u.id, 10) === parseInt(ME.id, 10);
    var right = isMe ? '<span class="badge gray">我</span>'
      : (parseInt(u.is_friend, 10) ? '<button class="btn small ghost" data-msg="' + u.id + '">发消息</button>'
        : '<button class="btn small" data-add="' + u.id + '" data-name="' + CC.esc(u.nickname) + '">加好友</button>');
    return '<div class="cell">' + CC.avatarHtml(u, 'sm')
      + '<div class="c-title" style="min-width:0"><div class="name-row"><span class="name-txt">' + hl(u.nickname, lastKw)
      + '</span><span class="name-tags">' + CC.prettyBadge(u.pretty) + CC.vipTag(u.vip_level) + '</span></div>'
      + '<div class="c-desc">CC号 ' + hl(u.pretty || u.yx_id || u.account || '', lastKw) + '</div></div>' + right + '</div>';
  }
  function groupRow(g){
    var right = parseInt(g.joined, 10)
      ? '<button class="btn small ghost" data-goto-group="' + g.gid + '">进入</button>'
      : '<button class="btn small" data-join="' + g.gid + '">加入</button>';
    return '<div class="cell">' + CC.avatarHtml({ nickname: g.name, avatar: g.avatar }, 'sm')
      + '<div class="c-title" style="min-width:0"><div class="nowrap">' + hl(g.name, lastKw) + '</div>'
      + '<div class="c-desc">群号 ' + g.gid + ' · ' + (g.members || 0) + '人</div></div>' + right + '</div>';
  }
  function chatRow(m){
    var c = m.conv || {};
    var isGroup = parseInt(m.ctype, 10) === 2;
    var title = c.name || (isGroup ? '群聊' : (m.sender && m.sender.nickname) || '会话');
    var sub = isGroup && m.sender ? (m.sender.nickname + '：' + (m.content || '')) : (m.content || '');
    return '<div class="cell" data-chat="' + (isGroup ? 'g' : 'u') + '" data-peer="' + (c.peer || 0) + '">'
      + CC.avatarHtml({ nickname: title, avatar: c.avatar || (m.sender && m.sender.avatar) }, 'sm')
      + '<div class="c-title" style="min-width:0"><div class="nowrap">' + CC.esc(title) + '</div>'
      + '<div class="c-desc nowrap">' + hl(sub, lastKw) + '</div></div>'
      + '<div class="c-value" style="flex:0 0 auto;font-size:11px">' + CC.fmtTime(m.created_at) + '</div></div>';
  }

  function bindActions(){
    result.querySelectorAll('[data-msg]').forEach(function(b){
      b.onclick = function(e){ e.stopPropagation(); location.href = 'index.php?to=' + b.getAttribute('data-msg'); };
    });
    result.querySelectorAll('[data-add]').forEach(function(b){
      b.onclick = function(e){
        e.stopPropagation();
        var uid = b.getAttribute('data-add'), name = b.getAttribute('data-name');
        CC.prompt({ title: '添加好友', text: '向 ' + name + ' 发送好友申请', placeholder: '填写申请理由', value: '我是 ' + (ME.nickname || ''), max: 50 })
          .then(function(reason){
            if (reason === null) return;
            if (!reason){ CC.toast('请填写申请理由'); return; }
            b.disabled = true;
            CC.api('send_friend_request', { to_uid: uid, reason: reason }).then(function(){
              CC.toast('申请已发送'); b.textContent = '已申请';
            }).catch(function(err){ b.disabled = false; CC.toast(err.message); });
          });
      };
    });
    result.querySelectorAll('[data-join]').forEach(function(b){
      b.onclick = function(e){
        e.stopPropagation();
        b.disabled = true;
        CC.api('group_join', { gid: b.getAttribute('data-join') }).then(function(d){
          if (d && d.pending){ CC.toast('申请已提交'); b.textContent = '待审核'; }
          else { CC.toast('已加入群聊'); b.textContent = '进入'; b.disabled = false; }
        }).catch(function(err){ b.disabled = false; CC.toast(err.message); });
      };
    });
    result.querySelectorAll('[data-goto-group]').forEach(function(b){
      b.onclick = function(e){ e.stopPropagation(); location.href = 'group_info.php?gid=' + b.getAttribute('data-goto-group'); };
    });
    result.querySelectorAll('[data-chat]').forEach(function(el){
      el.onclick = function(){
        var peer = el.getAttribute('data-peer');
        if (!peer || peer === '0'){ CC.toast('会话不存在'); return; }
        location.href = el.getAttribute('data-chat') === 'g' ? ('index.php?gid=' + peer) : ('index.php?to=' + peer);
      };
    });
  }

  function empty(msg, tip){
    result.innerHTML = '<div class="empty"><div class="ico">🔍</div><div>' + CC.esc(msg) + '</div>'
      + (tip ? '<div style="font-size:12px;margin-top:4px">' + CC.esc(tip) + '</div>' : '') + '</div>';
  }

  function renderSearch(data, kw){
    var users = (data && data.users) || [], groups = (data && data.groups) || [];
    if (tab === 'user') groups = [];
    if (tab === 'group') users = [];
    if (!users.length && !groups.length){ empty('没有找到「' + kw + '」', '用户与群号需要精确匹配完整号码'); return; }
    var html = '';
    if (users.length) html += '<div class="group-title">用户</div><div class="cell-group">' + users.map(userRow).join('') + '</div>';
    if (groups.length) html += '<div class="group-title">群聊</div><div class="cell-group">' + groups.map(groupRow).join('') + '</div>';
    result.innerHTML = html;
    bindActions();
  }

  function renderChat(list, kw){
    if (!list.length){ empty('没有找到包含「' + kw + '」的聊天记录', '只搜索文本消息'); return; }
    result.innerHTML = '<div class="group-title">聊天记录 · ' + list.length + ' 条</div><div class="cell-group">'
      + list.map(chatRow).join('') + '</div>';
    bindActions();
  }

  function run(){
    var kw = kwEl.value.trim();
    if (!kw){ empty('输入关键词开始搜索'); return; }
    lastKw = kw;
    if (tab === 'chat'){
      result.innerHTML = '<div class="loading"><span class="spin"></span> 搜索中…</div>';
      CC.ajax('search_chat', { keyword: kw }).then(function(res){
        if (res.code !== 0){ renderChat([], kw); return; }
        renderChat((res.data && res.data.list) || [], kw);
      }).catch(function(){ renderChat([], kw); });
      return;
    }
    result.innerHTML = '<div class="loading"><span class="spin"></span> 搜索中…</div>';
    CC.ajax('search', { keyword: kw, type: tab === 'user' ? 'user' : (tab === 'group' ? 'group' : 'all') }).then(function(res){
      if (res.code !== 0){ renderSearch({}, kw); return; }
      renderSearch(res.data || {}, kw);
    }).catch(function(){ renderSearch({}, kw); });
  }

  document.getElementById('btnSearch').onclick = run;
  kwEl.addEventListener('keydown', function(e){ if (e.key === 'Enter'){ e.preventDefault(); run(); } });
  document.querySelectorAll('[data-tab]').forEach(function(b){
    b.onclick = function(){
      tab = b.getAttribute('data-tab');
      document.querySelectorAll('[data-tab]').forEach(function(x){ x.classList.toggle('active', x === b); });
      if (kwEl.value.trim()) run(); else empty('输入关键词开始搜索');
    };
  });

  var pre = <?= json_encode($kw0, JSON_UNESCAPED_UNICODE) ?>;
  if (pre){ kwEl.value = pre; run(); }
  setTimeout(function(){ try { kwEl.focus(); } catch (e) {} }, 80);
})();
</script>
<?php cc_foot(); ?>
